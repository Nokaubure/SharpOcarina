/*
 * File: z_eff_ss_stick.c
 * Overlay: ovl_Effect_Ss_Stick
 * Description: Broken stick as child, broken sword as adult
 */

#include "z_eff_ss_stick.h"
#include "assets/objects/object_link_boy/object_link_boy.h"
#include "assets/objects/object_link_child/object_link_child.h"
#include "object/0x0014-Adult_Link.h"
#include "object/0x0015-Child_Link.h"

#define rObjBankIdx regs[0]
#define rYaw regs[1]

u32 EffectSsStick_Init(PlayState* play, u32 index, EffectSs* this, void* initParamsx);
void EffectSsStick_Draw(PlayState* play, u32 index, EffectSs* this);
void EffectSsStick_Update(PlayState* play, u32 index, EffectSs* this);

EffectSsInit Effect_Ss_Stick_InitVars = {
    EFFECT_SS_STICK,
    EffectSsStick_Init,
};

typedef struct {
    /* 0x00 */ s16 objectID;
    /* 0x04 */ Gfx* displayList;
} StickDrawInfo;

u32 EffectSsStick_Init(PlayState* play, u32 index, EffectSs* this, void* initParamsx) {

    StickDrawInfo drawInfo[] = {
        { OBJECT_LINK_BOY, gPlayasAdult_DlBlade3Piece }, // adult, broken sword
        { OBJECT_LINK_CHILD, gPlayasChild_DlDekuStick }, // child, broken stick
    };

    Player* player = GET_PLAYER(play);

    if (player->heldItemActionParam == PLAYER_AP_STICK){
        drawInfo[0].displayList = gPlayasAdult_DlDekuStickBroken;
        drawInfo[1].displayList = gPlayasChild_DlDekuStickBroken;
    }else{
        if (LINK_IS_ADULT){
            drawInfo[0].displayList = gPlayasAdult_DlBlade3Piece;
        }else{
            drawInfo[1].displayList = gPlayasChild_DlBlade3Piece;
        }
    }

    StickDrawInfo* ageInfoEntry = gSaveContext.linkAge + drawInfo;
    EffectSsStickInitParams* initParams = (EffectSsStickInitParams*)initParamsx;

    this->rObjBankIdx = Object_GetIndex(&play->objectCtx, ageInfoEntry->objectID);
    this->gfx = ageInfoEntry->displayList;
    this->vec = this->pos = initParams->pos;
    this->rYaw = initParams->yaw;
    this->velocity.x = Math_SinS(initParams->yaw) * 6.0f;
    this->velocity.z = Math_CosS(initParams->yaw) * 6.0f;
    this->life = 20;
    this->draw = EffectSsStick_Draw;
    this->update = EffectSsStick_Update;
    this->velocity.y = 26.0f;
    this->accel.y = -4.0f;

    return 1;
}

void EffectSsStick_Draw(PlayState* play, u32 index, EffectSs* this) {
    GraphicsContext* gfxCtx = play->state.gfxCtx;

    OPEN_DISPS(gfxCtx, "../z_eff_ss_stick.c", 153);

    Matrix_Translate(this->pos.x, this->pos.y, this->pos.z, MTXMODE_NEW);

    Matrix_Scale(0.01f, 0.01f, 0.01f, MTXMODE_APPLY);
    Matrix_RotateZYX(0, this->rYaw, play->state.frames * 10000, MTXMODE_APPLY);
    

    gSPMatrix(POLY_OPA_DISP++, Matrix_NewMtx(gfxCtx, "../z_eff_ss_stick.c", 176),
              G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW);
    Gfx_SetupDL_25Opa(gfxCtx);
    gSPSegment(POLY_OPA_DISP++, 0x06, play->objectCtx.status[this->rObjBankIdx].segment);
    gSPSegment(POLY_OPA_DISP++, 0x0C, gCullBackDList);
    gSPDisplayList(POLY_OPA_DISP++, this->gfx);

    CLOSE_DISPS(gfxCtx, "../z_eff_ss_stick.c", 188);
}

void EffectSsStick_Update(PlayState* play, u32 index, EffectSs* this) {
}
