#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "parameter_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gHeartEmptyTex[] = {
#include "assets/interface/parameter_static/heart_empty.ia8.inc.c"
};

u64 gHeartQuarterTex[] = {
#include "assets/interface/parameter_static/heart_quarter.ia8.inc.c"
};

u64 gHeartHalfTex[] = {
#include "assets/interface/parameter_static/heart_half.ia8.inc.c"
};

u64 gHeartThreeQuarterTex[] = {
#include "assets/interface/parameter_static/heart_three_quarter.ia8.inc.c"
};

u64 gHeartFullTex[] = {
#include "assets/interface/parameter_static/heart_full.ia8.inc.c"
};

u64 gDefenseHeartEmptyTex[] = {
#include "assets/interface/parameter_static/defense_heart_empty.ia8.inc.c"
};

u64 gDefenseHeartQuarterTex[] = {
#include "assets/interface/parameter_static/defense_heart_quarter.ia8.inc.c"
};

u64 gDefenseHeartHalfTex[] = {
#include "assets/interface/parameter_static/defense_heart_half.ia8.inc.c"
};

u64 gDefenseHeartThreeQuarterTex[] = {
#include "assets/interface/parameter_static/defense_heart_three_quarter.ia8.inc.c"
};

u64 gDefenseHeartFullTex[] = {
#include "assets/interface/parameter_static/defense_heart_full.ia8.inc.c"
};

u64 gFishermanMinigameTorchIconTex[] = {
#include "assets/interface/parameter_static/fisherman_minigame_torch_icon.ia8.inc.c"
};

u64 gSwordTrainingLogIconTex[] = {
#include "assets/interface/parameter_static/sword_training_log_icon.ia8.inc.c"
};

u64 gSmallKeyCounterIconTex[] = {
#include "assets/interface/parameter_static/small_key_counter_icon.ia8.inc.c"
};

u64 gRupeeCounterIconTex[] = {
#include "assets/interface/parameter_static/rupee_counter_icon.ia8.inc.c"
};

u64 gButtonBackgroundTex[] = {
#include "assets/interface/parameter_static/button_background.ia8.inc.c"
};

u64 gEquippedItemOutlineTex[] = {
#include "assets/interface/parameter_static/equipped_item_outline.ia8.inc.c"
};

u64 gEmptyCLeftArrowTex[] = {
#include "assets/interface/parameter_static/empty_c_left_arrow.ia8.inc.c"
};

u64 gEmptyCDownArrowTex[] = {
#include "assets/interface/parameter_static/empty_c_down_arrow.ia8.inc.c"
};

u64 gEmptyCRightArrowTex[] = {
#include "assets/interface/parameter_static/empty_c_right_arrow.ia8.inc.c"
};

u64 gTimerClockIconTex[] = {
#include "assets/interface/parameter_static/timer_clock_icon.ia8.inc.c"
};

u64 gMapBossIconTex[] = {
#include "assets/interface/parameter_static/map_boss_icon.ia8.inc.c"
};

u64 gOcarinaATex[] = {
#include "assets/interface/parameter_static/ocarina_a.ia8.inc.c"
};

u64 gOcarinaCDownTex[] = {
#include "assets/interface/parameter_static/ocarina_c_down.ia8.inc.c"
};

u64 gOcarinaCRightTex[] = {
#include "assets/interface/parameter_static/ocarina_c_right.ia8.inc.c"
};

u64 gOcarinaCLeftTex[] = {
#include "assets/interface/parameter_static/ocarina_c_left.ia8.inc.c"
};

u64 gOcarinaCUpTex[] = {
#include "assets/interface/parameter_static/ocarina_c_up.ia8.inc.c"
};

u64 gOcarinaTrebleClefTex[] = {
#include "assets/interface/parameter_static/ocarina_treble_clef.i4.inc.c"
};

u64 gSceneTitleCardGradientTex[] = {
#include "assets/interface/parameter_static/scene_title_card_gradient.i8.inc.c"
};

u64 gTatlCUpENGTex[] = {
#include "assets/interface/parameter_static/tatl_c_up_eng.ia4.inc.c"
};

u64 gTatlCUpGERTex[] = {
#include "assets/interface/parameter_static/tatl_c_up_ger.ia4.inc.c"
};

u64 gTatlCUpFRATex[] = {
#include "assets/interface/parameter_static/tatl_c_up_fra.ia4.inc.c"
};

u64 gTatlCUpESPTex[] = {
#include "assets/interface/parameter_static/tatl_c_up_esp.ia4.inc.c"
};

u64 gCarrotIconTex[] = {
#include "assets/interface/parameter_static/carrot_icon.rgba32.inc.c"
};

u64 gGoldSkulltulaCounterIconTex[] = {
#include "assets/interface/parameter_static/gold_skulltula_counter_icon.rgba32.inc.c"
};

u64 gBeaverRingIconTex[] = {
#include "assets/interface/parameter_static/beaver_ring_icon.rgba32.inc.c"
};

u64 gMapDungeonEntranceIconTex[] = {
#include "assets/interface/parameter_static/map_dungeon_entrance_icon.rgba16.inc.c"
};

u64 gMapChestIconTex[] = {
#include "assets/interface/parameter_static/map_chest_icon.rgba16.inc.c"
};

u64 gArcheryScoreIconTex[] = {
#include "assets/interface/parameter_static/archery_score_icon.rgba16.inc.c"
};

u64 gPictoBoxFocusIconTex[] = {
#include "assets/interface/parameter_static/picto_box_focus_icon.i4.inc.c"
};

u64 gPictoBoxFocusBorderTex[] = {
#include "assets/interface/parameter_static/picto_box_focus_border.ia4.inc.c"
};

u64 gPictoBoxFocusTextTex[] = {
#include "assets/interface/parameter_static/picto_box_focus_text.i4.inc.c"
};

u64 gCounterDigit0Tex[] = {
#include "assets/interface/parameter_static/counter_digit_0.i8.inc.c"
};

u64 gCounterDigit1Tex[] = {
#include "assets/interface/parameter_static/counter_digit_1.i8.inc.c"
};

u64 gCounterDigit2Tex[] = {
#include "assets/interface/parameter_static/counter_digit_2.i8.inc.c"
};

u64 gCounterDigit3Tex[] = {
#include "assets/interface/parameter_static/counter_digit_3.i8.inc.c"
};

u64 gCounterDigit4Tex[] = {
#include "assets/interface/parameter_static/counter_digit_4.i8.inc.c"
};

u64 gCounterDigit5Tex[] = {
#include "assets/interface/parameter_static/counter_digit_5.i8.inc.c"
};

u64 gCounterDigit6Tex[] = {
#include "assets/interface/parameter_static/counter_digit_6.i8.inc.c"
};

u64 gCounterDigit7Tex[] = {
#include "assets/interface/parameter_static/counter_digit_7.i8.inc.c"
};

u64 gCounterDigit8Tex[] = {
#include "assets/interface/parameter_static/counter_digit_8.i8.inc.c"
};

u64 gCounterDigit9Tex[] = {
#include "assets/interface/parameter_static/counter_digit_9.i8.inc.c"
};

u64 gCounterColonTex[] = {
#include "assets/interface/parameter_static/counter_colon.i8.inc.c"
};

u64 gStrayFairyMapCounterSlashTex[] = {
#include "assets/interface/parameter_static/stray_fairy_map_counter_slash.i8.inc.c"
};

u64 gAmmoDigit0Tex[] = {
#include "assets/interface/parameter_static/ammo_digit_0.ia8.inc.c"
};

u64 gAmmoDigit1Tex[] = {
#include "assets/interface/parameter_static/ammo_digit_1.ia8.inc.c"
};

u64 gAmmoDigit2Tex[] = {
#include "assets/interface/parameter_static/ammo_digit_2.ia8.inc.c"
};

u64 gAmmoDigit3Tex[] = {
#include "assets/interface/parameter_static/ammo_digit_3.ia8.inc.c"
};

u64 gAmmoDigit4Tex[] = {
#include "assets/interface/parameter_static/ammo_digit_4.ia8.inc.c"
};

u64 gAmmoDigit5Tex[] = {
#include "assets/interface/parameter_static/ammo_digit_5.ia8.inc.c"
};

u64 gAmmoDigit6Tex[] = {
#include "assets/interface/parameter_static/ammo_digit_6.ia8.inc.c"
};

u64 gAmmoDigit7Tex[] = {
#include "assets/interface/parameter_static/ammo_digit_7.ia8.inc.c"
};

u64 gAmmoDigit8Tex[] = {
#include "assets/interface/parameter_static/ammo_digit_8.ia8.inc.c"
};

u64 gAmmoDigit9Tex[] = {
#include "assets/interface/parameter_static/ammo_digit_9.ia8.inc.c"
};

u64 gAmmoDigitHalfTex[] = {
#include "assets/interface/parameter_static/ammo_digit_half.ia8.inc.c"
};

u64 gMagicMeterEndTex[] = {
#include "assets/interface/parameter_static/magic_meter_end.ia8.inc.c"
};

u64 gMagicMeterMidTex[] = {
#include "assets/interface/parameter_static/magic_meter_mid.ia8.inc.c"
};

u64 gMagicMeterFillTex[] = {
#include "assets/interface/parameter_static/magic_meter_fill.ia8.inc.c"
};

u64 gThreeDayClockDiamondTex[] = {
#include "assets/interface/parameter_static/three_day_clock_diamond.ia8.inc.c"
};

u64 gThreeDayClockMoonHourTex[] = {
#include "assets/interface/parameter_static/three_day_clock_moon_hour.ia8.inc.c"
};

u64 gThreeDayClockSunHourTex[] = {
#include "assets/interface/parameter_static/three_day_clock_sun_hour.ia8.inc.c"
};

u64 gThreeDayClockBorderTex[] = {
#include "assets/interface/parameter_static/three_day_clock_border.i4.inc.c"
};

u64 gThreeDayClockHourLinesTex[] = {
#include "assets/interface/parameter_static/three_day_clock_hour_lines.i4.inc.c"
};

u64 gThreeDayClockStarMinuteTex[] = {
#include "assets/interface/parameter_static/three_day_clock_star_minute.i4.inc.c"
};

u64 gThreeDayClockHour12Tex[] = {
#include "assets/interface/parameter_static/three_day_clock_hour_12.i4.inc.c"
};

u64 gThreeDayClockHour1Tex[] = {
#include "assets/interface/parameter_static/three_day_clock_hour_1.i4.inc.c"
};

u64 gThreeDayClockHour2Tex[] = {
#include "assets/interface/parameter_static/three_day_clock_hour_2.i4.inc.c"
};

u64 gThreeDayClockHour3Tex[] = {
#include "assets/interface/parameter_static/three_day_clock_hour_3.i4.inc.c"
};

u64 gThreeDayClockHour4Tex[] = {
#include "assets/interface/parameter_static/three_day_clock_hour_4.i4.inc.c"
};

u64 gThreeDayClockHour5Tex[] = {
#include "assets/interface/parameter_static/three_day_clock_hour_5.i4.inc.c"
};

u64 gThreeDayClockHour6Tex[] = {
#include "assets/interface/parameter_static/three_day_clock_hour_6.i4.inc.c"
};

u64 gThreeDayClockHour7Tex[] = {
#include "assets/interface/parameter_static/three_day_clock_hour_7.i4.inc.c"
};

u64 gThreeDayClockHour8Tex[] = {
#include "assets/interface/parameter_static/three_day_clock_hour_8.i4.inc.c"
};

u64 gThreeDayClockHour9Tex[] = {
#include "assets/interface/parameter_static/three_day_clock_hour_9.i4.inc.c"
};

u64 gThreeDayClockHour10Tex[] = {
#include "assets/interface/parameter_static/three_day_clock_hour_10.i4.inc.c"
};

u64 gThreeDayClockHour11Tex[] = {
#include "assets/interface/parameter_static/three_day_clock_hour_11.i4.inc.c"
};

u64 gFinalHoursClockDigit0Tex[] = {
#include "assets/interface/parameter_static/final_hours_clock_digit_0.i8.inc.c"
};

u64 gFinalHoursClockDigit1Tex[] = {
#include "assets/interface/parameter_static/final_hours_clock_digit_1.i8.inc.c"
};

u64 gFinalHoursClockDigit2Tex[] = {
#include "assets/interface/parameter_static/final_hours_clock_digit_2.i8.inc.c"
};

u64 gFinalHoursClockDigit3Tex[] = {
#include "assets/interface/parameter_static/final_hours_clock_digit_3.i8.inc.c"
};

u64 gFinalHoursClockDigit4Tex[] = {
#include "assets/interface/parameter_static/final_hours_clock_digit_4.i8.inc.c"
};

u64 gFinalHoursClockDigit5Tex[] = {
#include "assets/interface/parameter_static/final_hours_clock_digit_5.i8.inc.c"
};

u64 gFinalHoursClockDigit6Tex[] = {
#include "assets/interface/parameter_static/final_hours_clock_digit_6.i8.inc.c"
};

u64 gFinalHoursClockDigit7Tex[] = {
#include "assets/interface/parameter_static/final_hours_clock_digit_7.i8.inc.c"
};

u64 gFinalHoursClockDigit8Tex[] = {
#include "assets/interface/parameter_static/final_hours_clock_digit_8.i8.inc.c"
};

u64 gFinalHoursClockDigit9Tex[] = {
#include "assets/interface/parameter_static/final_hours_clock_digit_9.i8.inc.c"
};

u64 gFinalHoursClockColonTex[] = {
#include "assets/interface/parameter_static/final_hours_clock_colon.i8.inc.c"
};

u64 gFinalHoursClockFrameTex[] = {
#include "assets/interface/parameter_static/final_hours_clock_frame.ia4.inc.c"
};

u64 gMinigameCountdownGoTex[] = {
#include "assets/interface/parameter_static/minigame_countdown_go.ia8.inc.c"
};

u64 gMinigameCountdown1Tex[] = {
#include "assets/interface/parameter_static/minigame_countdown_1.ia8.inc.c"
};

u64 gMinigameCountdown2Tex[] = {
#include "assets/interface/parameter_static/minigame_countdown_2.ia8.inc.c"
};

u64 gMinigameCountdown3Tex[] = {
#include "assets/interface/parameter_static/minigame_countdown_3.ia8.inc.c"
};

u64 gPerfectLetterPTex[] = {
#include "assets/interface/parameter_static/letter_perfect_p.i4.inc.c"
};

u64 gPerfectLetterETex[] = {
#include "assets/interface/parameter_static/letter_perfect_e.i4.inc.c"
};

u64 gPerfectLetterRTex[] = {
#include "assets/interface/parameter_static/letter_perfect_r.i4.inc.c"
};

u64 gPerfectLetterFTex[] = {
#include "assets/interface/parameter_static/letter_perfect_f.i4.inc.c"
};

u64 gPerfectLetterCTex[] = {
#include "assets/interface/parameter_static/letter_perfect_c.i4.inc.c"
};

u64 gPerfectLetterTTex[] = {
#include "assets/interface/parameter_static/letter_perfect_t.i4.inc.c"
};

u64 gPerfectLetterExclamationTex[] = {
#include "assets/interface/parameter_static/letter_perfect_exclamation.i4.inc.c"
};

u64 gStrayFairyWoodfallIconTex[] = {
#include "assets/interface/parameter_static/stray_fairy_woodfall_icon.rgba32.inc.c"
};

u64 gStrayFairySnowheadIconTex[] = {
#include "assets/interface/parameter_static/stray_fairy_snowhead_icon.rgba32.inc.c"
};

u64 gStrayFairyGreatBayIconTex[] = {
#include "assets/interface/parameter_static/stray_fairy_great_bay_icon.rgba32.inc.c"
};

u64 gStrayFairyStoneTowerIconTex[] = {
#include "assets/interface/parameter_static/stray_fairy_stone_tower_icon.rgba32.inc.c"
};

u64 gStrayFairyGlowingCircleIconTex[] = {
#include "assets/interface/parameter_static/stray_fairy_glowing_circle_icon.i4.inc.c"
};

