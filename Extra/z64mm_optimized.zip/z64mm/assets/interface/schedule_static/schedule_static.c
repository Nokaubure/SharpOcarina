#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "schedule_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gBombersNotebookEntryIconExclamationPointTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_entry_icon_exlamation_point.ia8.inc.c"
};

u64 gBombersNotebookStampTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_stamp.ia8.inc.c"
};

u64 gBombersNotebookArrowTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_arrow.ia8.inc.c"
};

u64 gBombersNotebookConnectorTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_connector.ia8.inc.c"
};

u64 gBombersNotebookEmptyPhotoTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_empty_photo.rgba16.inc.c"
};

u64 gBombersNotebookEntryBoxEndTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_entry_end.rgba16.inc.c"
};

u64 gBombersNotebookEntryBoxMiddleTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_entry_middle.rgba16.inc.c"
};

u64 gBombersNotebookSubColumnBoxTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_sub_column_box.i4.inc.c"
};

u64 gBombersNotebookCircleTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_circle.i4.inc.c"
};

u64 gBombersNotebookBackgroundTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_background.i8.inc.c"
};

u64 gBombersNotebookHeaderBoxTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_header_box.i8.inc.c"
};

u64 gBombersNotebookLineTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_line.i8.inc.c"
};

u64 gBombersNotebookBarSmallTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_bar_small.i8.inc.c"
};

u64 gBombersNotebookBarTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_bar.i8.inc.c"
};

u64 gBombersNotebookCursorTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_cursor.ia4.inc.c"
};

u64 gBombersNoteoobkTimeOfDayBoxTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_time_of_day_box.ia4.inc.c"
};

u64 gBombersNotebookTimeBoxLeftTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_time_box_left.ia4.inc.c"
};

u64 gBombersNotebookTimeBoxRightTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_time_box_right.ia4.inc.c"
};

u64 gBombersNotebookTimeBoxMiddleTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_time_box_middle.ia4.inc.c"
};

u64 gBombersNotebook1800Tex[] = {
#include "assets/interface/schedule_static/bombers_notebook_1800.ia4.inc.c"
};

u64 gBombersNotebookDigit0Tex[] = {
#include "assets/interface/schedule_static/bombers_notebook_digit_0.i4.inc.c"
};

u64 gBombersNotebookDigit1Tex[] = {
#include "assets/interface/schedule_static/bombers_notebook_digit_1.i4.inc.c"
};

u64 gBombersNotebookDigit2Tex[] = {
#include "assets/interface/schedule_static/bombers_notebook_digit_2.i4.inc.c"
};

u64 gBombersNotebookDigit3Tex[] = {
#include "assets/interface/schedule_static/bombers_notebook_digit_3.i4.inc.c"
};

u64 gBombersNotebookDigit4Tex[] = {
#include "assets/interface/schedule_static/bombers_notebook_digit_4.i4.inc.c"
};

u64 gBombersNotebookDigit5Tex[] = {
#include "assets/interface/schedule_static/bombers_notebook_digit_5.i4.inc.c"
};

u64 gBombersNotebookDigit6Tex[] = {
#include "assets/interface/schedule_static/bombers_notebook_digit_6.i4.inc.c"
};

u64 gBombersNotebookDigit7Tex[] = {
#include "assets/interface/schedule_static/bombers_notebook_digit_7.i4.inc.c"
};

u64 gBombersNotebookDigit8Tex[] = {
#include "assets/interface/schedule_static/bombers_notebook_digit_8.i4.inc.c"
};

u64 gBombersNotebookDigit9Tex[] = {
#include "assets/interface/schedule_static/bombers_notebook_digit_9.i4.inc.c"
};

u64 gBombersNotebookColonTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_colon.i4.inc.c"
};

u64 gBombersNotebookDay1stENGTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_day_1st_eng.ia8.inc.c"
};

u64 gBombersNotebookDay2ndENGTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_day_2nd_eng.ia8.inc.c"
};

u64 gBombersNotebookDayFinalENGTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_day_final_eng.ia8.inc.c"
};

u64 gBombersNotebookTimeOfDayENGTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_time_of_day_eng.i4.inc.c"
};

u64 gBombersNotebookDay1stGERTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_day_1st_ger.ia8.inc.c"
};

u64 gBombersNotebookDay2ndGERTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_day_2nd_ger.ia8.inc.c"
};

u64 gBombersNotebookDayFinalGERTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_day_final_ger.ia8.inc.c"
};

u64 gBombersNotebookTimeOfDayGERTex[] = {
#include "assets/interface/schedule_static/bombers_notebook_time_of_day_ger.i4.inc.c"
};

u64 gBombersNotebookDay1stFRATex[] = {
#include "assets/interface/schedule_static/bombers_notebook_day_1st_fra.ia8.inc.c"
};

u64 gBombersNotebookDay2ndFRATex[] = {
#include "assets/interface/schedule_static/bombers_notebook_day_2nd_fra.ia8.inc.c"
};

u64 gBombersNotebookDayFinalFRATex[] = {
#include "assets/interface/schedule_static/bombers_notebook_day_final_fra.ia8.inc.c"
};

u64 gBombersNotebookTimeOfDayFRATex[] = {
#include "assets/interface/schedule_static/bombers_notebook_time_of_day_fra.i4.inc.c"
};

u64 gBombersNotebookDay1stSPATex[] = {
#include "assets/interface/schedule_static/bombers_notebook_day_1st_spa.ia8.inc.c"
};

u64 gBombersNotebookDay2ndSPATex[] = {
#include "assets/interface/schedule_static/bombers_notebook_day_2nd_spa.ia8.inc.c"
};

u64 gBombersNotebookDayFinalSPATex[] = {
#include "assets/interface/schedule_static/bombers_notebook_day_final_spa.ia8.inc.c"
};

u64 gBombersNotebookTimeOfDaySPATex[] = {
#include "assets/interface/schedule_static/bombers_notebook_time_of_day_spa.i4.inc.c"
};

