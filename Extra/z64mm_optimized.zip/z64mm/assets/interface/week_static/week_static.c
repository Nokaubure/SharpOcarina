#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "week_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gClockDay1stTex[] = {
#include "assets/interface/week_static/clock_day_1st.i8.inc.c"
};

u64 gClockDay2ndTex[] = {
#include "assets/interface/week_static/clock_day_2nd.i8.inc.c"
};

u64 gClockDayFinalTex[] = {
#include "assets/interface/week_static/clock_day_final.i8.inc.c"
};

