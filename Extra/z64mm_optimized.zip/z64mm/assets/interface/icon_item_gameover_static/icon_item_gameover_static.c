#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "icon_item_gameover_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gGameOverP1Tex[] = {
#include "assets/interface/icon_item_gameover_static/game_over_p1.ia8.inc.c"
};

u64 gGameOverP2Tex[] = {
#include "assets/interface/icon_item_gameover_static/game_over_p2.ia8.inc.c"
};

u64 gGameOverP3Tex[] = {
#include "assets/interface/icon_item_gameover_static/game_over_p3.ia8.inc.c"
};

u64 gGameOverMaskTex[] = {
#include "assets/interface/icon_item_gameover_static/game_over_mask.ia8.inc.c"
};

u64 gContinuePlayingJAPTex[] = {
#include "assets/interface/icon_item_gameover_static/continue_playing_jap.ia8.inc.c"
};

u64 gContinuePlayingNESTex[] = {
#include "assets/interface/icon_item_gameover_static/continue_playing_nes.ia8.inc.c"
};

