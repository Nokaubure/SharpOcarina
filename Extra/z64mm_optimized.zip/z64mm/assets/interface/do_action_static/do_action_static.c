#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "do_action_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gDoActionAttackENGTex[] = {
#include "assets/interface/do_action_static/attack_eng.ia4.inc.c"
};

u64 gDoActionCheckENGTex[] = {
#include "assets/interface/do_action_static/check_eng.ia4.inc.c"
};

u64 gDoActionEnterENGTex[] = {
#include "assets/interface/do_action_static/enter_eng.ia4.inc.c"
};

u64 gDoActionReturnENGTex[] = {
#include "assets/interface/do_action_static/return_eng.ia4.inc.c"
};

u64 gDoActionOpenENGTex[] = {
#include "assets/interface/do_action_static/open_eng.ia4.inc.c"
};

u64 gDoActionJumpENGTex[] = {
#include "assets/interface/do_action_static/jump_eng.ia4.inc.c"
};

u64 gDoActionDecideENGTex[] = {
#include "assets/interface/do_action_static/decide_eng.ia4.inc.c"
};

u64 gDoActionDiveENGTex[] = {
#include "assets/interface/do_action_static/dive_eng.ia4.inc.c"
};

u64 gDoActionFasterENGTex[] = {
#include "assets/interface/do_action_static/faster_eng.ia4.inc.c"
};

u64 gDoActionThrowENGTex[] = {
#include "assets/interface/do_action_static/throw_eng.ia4.inc.c"
};

u64 gDoActionNaviENGTex[] = {
#include "assets/interface/do_action_static/navi_eng.ia4.inc.c"
};

u64 gDoActionClimbENGTex[] = {
#include "assets/interface/do_action_static/climb_eng.ia4.inc.c"
};

u64 gDoActionDropENGTex[] = {
#include "assets/interface/do_action_static/drop_eng.ia4.inc.c"
};

u64 gDoActionDownENGTex[] = {
#include "assets/interface/do_action_static/down_eng.ia4.inc.c"
};

u64 gDoActionQuitENGTex[] = {
#include "assets/interface/do_action_static/quit_eng.ia4.inc.c"
};

u64 gDoActionSpeakENGTex[] = {
#include "assets/interface/do_action_static/speak_eng.ia4.inc.c"
};

u64 gDoActionNextENGTex[] = {
#include "assets/interface/do_action_static/next_eng.ia4.inc.c"
};

u64 gDoActionGrabENGTex[] = {
#include "assets/interface/do_action_static/grab_eng.ia4.inc.c"
};

u64 gDoActionStopENGTex[] = {
#include "assets/interface/do_action_static/stop_eng.ia4.inc.c"
};

u64 gDoActionPutAwayENGTex[] = {
#include "assets/interface/do_action_static/put_away_eng.ia4.inc.c"
};

u64 gDoActionReelENGTex[] = {
#include "assets/interface/do_action_static/reel_eng.ia4.inc.c"
};

u64 gDoActionInfoENGTex[] = {
#include "assets/interface/do_action_static/info_eng.ia4.inc.c"
};

u64 gDoActionWarpENGTex[] = {
#include "assets/interface/do_action_static/warp_eng.ia4.inc.c"
};

u64 gDoActionSnapENGTex[] = {
#include "assets/interface/do_action_static/snap_eng.ia4.inc.c"
};

u64 gDoActionExplodeENGTex[] = {
#include "assets/interface/do_action_static/explode_eng.ia4.inc.c"
};

u64 gDoActionDanceENGTex[] = {
#include "assets/interface/do_action_static/dance_eng.ia4.inc.c"
};

u64 gDoActionMarchENGTex[] = {
#include "assets/interface/do_action_static/march_eng.ia4.inc.c"
};

u64 gDoActionNum1ENGTex[] = {
#include "assets/interface/do_action_static/num_1_eng.ia4.inc.c"
};

u64 gDoActionNum2ENGTex[] = {
#include "assets/interface/do_action_static/num_2_eng.ia4.inc.c"
};

u64 gDoActionNum3ENGTex[] = {
#include "assets/interface/do_action_static/num_3_eng.ia4.inc.c"
};

u64 gDoActionNum4ENGTex[] = {
#include "assets/interface/do_action_static/num_4_eng.ia4.inc.c"
};

u64 gDoActionNum5ENGTex[] = {
#include "assets/interface/do_action_static/num_5_eng.ia4.inc.c"
};

u64 gDoActionNum6ENGTex[] = {
#include "assets/interface/do_action_static/num_6_eng.ia4.inc.c"
};

u64 gDoActionNum7ENGTex[] = {
#include "assets/interface/do_action_static/num_7_eng.ia4.inc.c"
};

u64 gDoActionNum8ENGTex[] = {
#include "assets/interface/do_action_static/num_8_eng.ia4.inc.c"
};

u64 gDoActionCurlENGTex[] = {
#include "assets/interface/do_action_static/curl_eng.ia4.inc.c"
};

u64 gDoActionSurfaceENGTex[] = {
#include "assets/interface/do_action_static/surface_eng.ia4.inc.c"
};

u64 gDoActionSwimENGTex[] = {
#include "assets/interface/do_action_static/swim_eng.ia4.inc.c"
};

u64 gDoActionPunchENGTex[] = {
#include "assets/interface/do_action_static/punch_eng.ia4.inc.c"
};

u64 gDoActionPoundENGTex[] = {
#include "assets/interface/do_action_static/pound_eng.ia4.inc.c"
};

u64 gDoActionHookENGTex[] = {
#include "assets/interface/do_action_static/hook_eng.ia4.inc.c"
};

u64 gDoActionShootENGTex[] = {
#include "assets/interface/do_action_static/shoot_eng.ia4.inc.c"
};

