#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "icon_item_dungeon_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gDungeonMapBlankFloorButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_blank_floor_button.ia8.inc.c"
};

u64 gDungeonMap1FButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_1f_button.ia8.inc.c"
};

u64 gDungeonMap2FButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_2f_button.ia8.inc.c"
};

u64 gDungeonMap3FButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_3f_button.ia8.inc.c"
};

u64 gDungeonMap4FButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_4f_button.ia8.inc.c"
};

u64 gDungeonMap5FButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_5f_button.ia8.inc.c"
};

u64 gDungeonMap6FButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_6f_button.ia8.inc.c"
};

u64 gDungeonMap7FButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_7f_button.ia8.inc.c"
};

u64 gDungeonMap8FButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_8f_button.ia8.inc.c"
};

u64 gDungeonMapB1ButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_b1_button.ia8.inc.c"
};

u64 gDungeonMapB2ButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_b2_button.ia8.inc.c"
};

u64 gDungeonMapB3ButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_b3_button.ia8.inc.c"
};

u64 gDungeonMapB4ButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_b4_button.ia8.inc.c"
};

u64 gDungeonMapB5ButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_b5_button.ia8.inc.c"
};

u64 gDungeonMapB6ButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_b6_button.ia8.inc.c"
};

u64 gDungeonMapB7ButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_b7_button.ia8.inc.c"
};

u64 gDungeonMapB8ButtonTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_b8_button.ia8.inc.c"
};

u64 gDungeonMapSkullTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_map_skull.rgba16.inc.c"
};

u64 gDungeonStrayFairyWoodfallIconTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_stray_fairy_woodfall_icon.rgba32.inc.c"
};

u64 gDungeonStrayFairySnowheadIconTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_stray_fairy_snowhead_icon.rgba32.inc.c"
};

u64 gDungeonStrayFairyGreatBayIconTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_stray_fairy_great_bay_icon.rgba32.inc.c"
};

u64 gDungeonStrayFairyStoneTowerIconTex[] = {
#include "assets/interface/icon_item_dungeon_static/dungeon_stray_fairy_stone_tower_icon.rgba32.inc.c"
};

