#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "icon_item_vtx_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

Gfx gItemNamePanelDL[] = {
    gsDPLoadTextureBlock(0x08094240, G_IM_FMT_IA, G_IM_SIZ_8b, 72, 24, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(0, 2, 3, 1, 0),
    gsDPLoadTextureBlock(0x08094900, G_IM_FMT_IA, G_IM_SIZ_8b, 72, 24, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(4, 6, 7, 5, 0),
    gsDPPipeSync(),
    gsSPEndDisplayList(),
};

Gfx gZButtonIconDL[] = {
    gsDPLoadTextureBlock(0x08094FC0, G_IM_FMT_IA, G_IM_SIZ_8b, 24, 32, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(8, 10, 11, 9, 0),
    gsDPPipeSync(),
    gsSPEndDisplayList(),
};

Gfx gRButtonIconDL[] = {
    gsDPLoadTextureBlock(0x080952C0, G_IM_FMT_IA, G_IM_SIZ_8b, 24, 32, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(12, 14, 15, 13, 0),
    gsDPPipeSync(),
    gsSPEndDisplayList(),
};

Gfx gCButtonIconsDL[] = {
    gsDPPipeSync(),
    gsDPSetPrimColor(0, 0, 255, 150, 0, 255),
    gsDPLoadTextureBlock(0x08093F40, G_IM_FMT_IA, G_IM_SIZ_8b, 48, 16, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(0, 2, 3, 1, 0),
    gsSPEndDisplayList(),
};

Gfx gAButtonIconDL[] = {
    gsDPPipeSync(),
    gsDPSetPrimColor(0, 0, 0, 100, 255, 255),
    gsDPLoadTextureBlock(0x08093C40, G_IM_FMT_IA, G_IM_SIZ_8b, 24, 16, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(0, 2, 3, 1, 0),
    gsSPEndDisplayList(),
};

Gfx gBButtonIconDL[] = {
    gsDPPipeSync(),
    gsDPSetPrimColor(0, 0, 50, 150, 0, 255),
    gsDPLoadTextureBlock(0x08093DC0, G_IM_FMT_IA, G_IM_SIZ_8b, 24, 16, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(0, 2, 3, 1, 0),
    gsSPEndDisplayList(),
};

Gfx gPromptCursorLeftDL[] = {
    gsDPPipeSync(),
    gsDPLoadTextureBlock_4b(0x08063C80, G_IM_FMT_I, 48, 48, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP,
                            G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(4, 6, 7, 5, 0),
    gsSPEndDisplayList(),
};

Gfx gPromptCursorRightDL[] = {
    gsDPPipeSync(),
    gsDPLoadTextureBlock_4b(0x08063C80, G_IM_FMT_I, 48, 48, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP,
                            G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(8, 10, 11, 9, 0),
    gsSPEndDisplayList(),
};

