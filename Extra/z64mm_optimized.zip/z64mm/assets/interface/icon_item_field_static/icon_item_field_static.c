#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "icon_item_field_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gWorldMapImageTex[] = {
#include "assets/interface/icon_item_field_static/world_map_image.ci8.inc.c"
};

u64 gWorldMapImageTLUT[] = {
#include "assets/interface/icon_item_field_static/world_map_image_tlut.rgba16.inc.c"
};

u64 gWorldMapDotTex[] = {
#include "assets/interface/icon_item_field_static/world_map_dot.ia8.inc.c"
};

u64 gWorldMapAreaBox1Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_area_box_1.ia4.inc.c"
};

u64 gWorldMapAreaBox2Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_area_box_2.ia4.inc.c"
};

u64 gWorldMapAreaBox3Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_area_box_3.ia4.inc.c"
};

u64 gWorldMapAreaBox4Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_area_box_4.ia4.inc.c"
};

u64 gWorldMapAreaBox5Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_area_box_5.ia4.inc.c"
};

u64 gWorldMapAreaBox6Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_area_box_6.ia4.inc.c"
};

u64 gWorldMapAreaBox7Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_area_box_7.ia4.inc.c"
};

u64 gWorldMapAreaBox8Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_area_box_8.ia4.inc.c"
};

u64 gWorldMapArrowTex[] = {
#include "assets/interface/icon_item_field_static/world_map_arrow.ia8.inc.c"
};

u64 gWorldMapClockTownCloud1Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_clock_town_cloud_1.ia8.inc.c"
};

u64 gWorldMapClockTownCloud2Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_clock_town_cloud_2.ia8.inc.c"
};

u64 gWorldMapRomaniRanchCloudTex[] = {
#include "assets/interface/icon_item_field_static/world_map_romani_ranch_cloud.ia8.inc.c"
};

u64 gWorldMapGreatBayCloud1Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_great_bay_cloud_1.ia8.inc.c"
};

u64 gWorldMapGreatBayCloud2Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_great_bay_cloud_2.ia8.inc.c"
};

u64 gWorldMapGreatBayCloud3Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_great_bay_cloud_3.ia8.inc.c"
};

u64 gWorldMapGreatBayCloud4Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_great_bay_cloud_4.ia8.inc.c"
};

u64 gWorldMapSnowheadCloud1Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_snowhead_cloud_1.ia8.inc.c"
};

u64 gWorldMapSnowheadCloud2Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_snowhead_cloud_2.ia8.inc.c"
};

u64 gWorldMapSnowheadCloud3Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_snowhead_cloud_3.ia8.inc.c"
};

u64 gWorldMapStoneTowerCloud1Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_stone_tower_cloud_1.ia8.inc.c"
};

u64 gWorldMapStoneTowerCloud2Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_stone_tower_cloud_2.ia8.inc.c"
};

u64 gWorldMapWoodfallCloud1Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_woodfall_cloud_1.ia8.inc.c"
};

u64 gWorldMapWoodfallCloud2Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_woodfall_cloud_2.ia8.inc.c"
};

u64 gWorldMapWoodfallCloud3Tex[] = {
#include "assets/interface/icon_item_field_static/world_map_woodfall_cloud_3.ia8.inc.c"
};

u64 gWorldMapOwlFaceTex[] = {
#include "assets/interface/icon_item_field_static/world_map_owl_face.rgba32.inc.c"
};

