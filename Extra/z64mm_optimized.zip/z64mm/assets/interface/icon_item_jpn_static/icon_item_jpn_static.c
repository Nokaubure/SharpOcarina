#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "icon_item_jpn_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gPauseWoodfallTitleENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_woodfall_title_eng.ia8.inc.c"
};

u64 gPauseSnowheadTitleENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_snowhead_title_eng.ia8.inc.c"
};

u64 gPauseGreatBayTitleENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_great_bay_title_eng.ia8.inc.c"
};

u64 gPauseStoneTowerTitleENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_stone_tower_title_eng.ia8.inc.c"
};

u64 gPauseToEquipENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_to_equip_eng.ia4.inc.c"
};

u64 gPauseToDecideENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_to_decide_eng.ia4.inc.c"
};

u64 gPauseToPlayMelodyENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_to_play_melody_eng.ia4.inc.c"
};

u64 gPauseToSelectItemENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_to_select_item_eng.ia4.inc.c"
};

u64 gPauseToMapENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_to_map_eng.ia4.inc.c"
};

u64 gPauseToQuestStatusENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_to_quest_status_eng.ia4.inc.c"
};

u64 gPauseToMasksENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_to_masks_eng.ia4.inc.c"
};

u64 gPauseToViewNotebookENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_to_view_notebook_eng.ia4.inc.c"
};

u64 gPauseMasks10ENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_masks_1_0_eng.ia8.inc.c"
};

u64 gPauseSelectItem00ENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_select_item_0_0_eng.ia8.inc.c"
};

u64 gPauseSelectItem10ENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_select_item_1_0_eng.ia8.inc.c"
};

u64 gPauseSelectItem20ENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_select_item_2_0_eng.ia8.inc.c"
};

u64 gPauseMap10ENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_map_1_0_eng.ia8.inc.c"
};

u64 gPauseQuestStatus00ENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_quest_status_0_0_eng.ia8.inc.c"
};

u64 gPauseQuestStatus10ENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_quest_status_1_0_eng.ia8.inc.c"
};

u64 gPauseQuestStatus20ENGTex[] = {
#include "assets/interface/icon_item_jpn_static/pause_quest_status_2_0_eng.ia8.inc.c"
};

