#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_bombiwa.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 object_bombiwa_TLUT_000000[] = {
#include "assets/objects/object_bombiwa/tlut_000000.rgba16.inc.c"
};

u64 object_bombiwa_Tex_000020[] = {
#include "assets/objects/object_bombiwa/tex_000020.ci4.inc.c"
};

Vtx object_bombiwaVtx_000820[] = {
#include "assets/objects/object_bombiwa/object_bombiwaVtx_000820.vtx.inc"
};

Gfx object_bombiwa_DL_0009E0[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock_4b(object_bombiwa_Tex_000020, G_IM_FMT_CI, 64, 64, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadTLUT_pal16(0, object_bombiwa_TLUT_000000),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, 0, 0, 0, COMBINED, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPVertex(object_bombiwaVtx_000820, 28, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(3, 6, 4, 0, 5, 4, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 9, 11, 10, 0),
    gsSP2Triangles(10, 11, 12, 0, 11, 13, 12, 0),
    gsSP2Triangles(12, 14, 15, 0, 15, 6, 16, 0),
    gsSP2Triangles(15, 13, 17, 0, 18, 10, 19, 0),
    gsSP2Triangles(10, 12, 19, 0, 12, 15, 19, 0),
    gsSP2Triangles(19, 15, 20, 0, 3, 20, 15, 0),
    gsSP2Triangles(5, 21, 3, 0, 21, 20, 3, 0),
    gsSP2Triangles(10, 18, 8, 0, 22, 23, 24, 0),
    gsSP2Triangles(23, 25, 24, 0, 25, 26, 24, 0),
    gsSP2Triangles(26, 27, 24, 0, 27, 22, 24, 0),
    gsSPEndDisplayList(),
};

Gfx object_bombiwa_DL_000AF0[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock_4b(object_bombiwa_Tex_000020, G_IM_FMT_CI, 64, 64, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadTLUT_pal16(0, object_bombiwa_TLUT_000000),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, 0, 0, 0, COMBINED, COMBINED, 0, PRIMITIVE, 0),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_XLU_SURF2),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPVertex(object_bombiwaVtx_000820, 28, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(3, 6, 4, 0, 5, 4, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 9, 11, 10, 0),
    gsSP2Triangles(10, 11, 12, 0, 11, 13, 12, 0),
    gsSP2Triangles(12, 14, 15, 0, 15, 6, 16, 0),
    gsSP2Triangles(15, 13, 17, 0, 18, 10, 19, 0),
    gsSP2Triangles(10, 12, 19, 0, 12, 15, 19, 0),
    gsSP2Triangles(19, 15, 20, 0, 3, 20, 15, 0),
    gsSP2Triangles(5, 21, 3, 0, 21, 20, 3, 0),
    gsSP2Triangles(10, 18, 8, 0, 22, 23, 24, 0),
    gsSP2Triangles(23, 25, 24, 0, 25, 26, 24, 0),
    gsSP2Triangles(26, 27, 24, 0, 27, 22, 24, 0),
    gsSPEndDisplayList(),
};

u64 object_bombiwa_Tex_000C00[] = {
#include "assets/objects/object_bombiwa/tex_000C00.i4.inc.c"
};

Vtx object_bombiwaVtx_001400[] = {
#include "assets/objects/object_bombiwa/object_bombiwaVtx_001400.vtx.inc"
};

Gfx object_bombiwa_DL_001700[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock_4b(object_bombiwa_Tex_000C00, G_IM_FMT_I, 64, 64, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR |
                            G_TX_WRAP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsDPSetPrimColor(0, 0, 190, 175, 135, 255),
    gsSPVertex(object_bombiwaVtx_001400, 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 1, 0),
    gsSP2Triangles(5, 6, 1, 0, 7, 8, 4, 0),
    gsSP2Triangles(9, 10, 11, 0, 9, 12, 10, 0),
    gsSP2Triangles(13, 12, 9, 0, 14, 15, 5, 0),
    gsSP2Triangles(16, 17, 3, 0, 18, 19, 20, 0),
    gsSP2Triangles(8, 21, 22, 0, 18, 23, 24, 0),
    gsSP2Triangles(25, 26, 27, 0, 25, 28, 26, 0),
    gsSP2Triangles(19, 25, 27, 0, 21, 25, 19, 0),
    gsSP2Triangles(16, 28, 25, 0, 14, 12, 13, 0),
    gsSP2Triangles(5, 12, 14, 0, 29, 30, 31, 0),
    gsSPVertex(&object_bombiwaVtx_001400[32], 15, 0),
    gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 8, 9, 0),
    gsSP2Triangles(0, 10, 11, 0, 10, 12, 11, 0),
    gsSP1Triangle(0, 13, 14, 0),
    gsSPEndDisplayList(),
};

Gfx object_bombiwa_DL_001800[] = {
    gsSPVertex(&object_bombiwaVtx_001400[47], 1, 0),
    gsSPBranchLessZraw(object_bombiwa_DL_001700, 0, 0x00001770),
    gsSPEndDisplayList(),
};

Gfx object_bombiwa_DL_001820[] = {
    gsSPDisplayList(object_bombiwa_DL_001800),
    gsSPEndDisplayList(),
};

Vtx object_bombiwaVtx_001830[] = {
#include "assets/objects/object_bombiwa/object_bombiwaVtx_001830.vtx.inc"
};

Gfx object_bombiwa_DL_001990[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL1, 0, TEXEL0, 0, TEXEL1, TEXEL0, PRIM_LOD_FRAC, TEXEL0, COMBINED, 0, SHADE, 0, COMBINED, 0,
                       PRIMITIVE, 0),
    gsDPSetPrimColor(0, 0xFF, 255, 255, 255, 255),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(object_bombiwa_Tex_001A70, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock_4b(object_bombiwa_Tex_002270, 0x0100, 1, G_IM_FMT_I, 64, 64, 15, G_TX_NOMIRROR | G_TX_WRAP,
                          G_TX_NOMIRROR | G_TX_WRAP, 6, 6, 15, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_bombiwaVtx_001830, 22, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 2, 4, 0),
    gsSP2Triangles(5, 2, 3, 0, 6, 7, 3, 0),
    gsSP2Triangles(8, 0, 9, 0, 10, 11, 12, 0),
    gsSP2Triangles(0, 13, 4, 0, 14, 15, 16, 0),
    gsSP2Triangles(14, 17, 18, 0, 19, 20, 21, 0),
    gsSPEndDisplayList(),
};

u64 object_bombiwa_Tex_001A70[] = {
#include "assets/objects/object_bombiwa/tex_001A70.rgba16.inc.c"
};

u64 object_bombiwa_Tex_002270[] = {
#include "assets/objects/object_bombiwa/tex_002270.i4.inc.c"
};

Vtx object_bombiwaVtx_002A70[] = {
#include "assets/objects/object_bombiwa/object_bombiwaVtx_002A70.vtx.inc"
};

Gfx object_bombiwa_DL_002F60[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL1, 0, TEXEL0, 0, 0, 0, 0, 1, COMBINED, 0, SHADE, 0, COMBINED, 0, PRIMITIVE, 0),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPDisplayList(0x08000000),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(object_bombiwa_Tex_0032C0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock_4b(object_bombiwa_Tex_003AC0, 0x0100, 1, G_IM_FMT_I, 64, 64, 15, G_TX_NOMIRROR | G_TX_WRAP,
                          G_TX_MIRROR | G_TX_WRAP, 6, 6, 15, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_bombiwaVtx_002A70, 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 0, 0),
    gsSP2Triangles(4, 1, 0, 0, 5, 6, 4, 0),
    gsSP2Triangles(5, 4, 3, 0, 7, 8, 6, 0),
    gsSP2Triangles(7, 6, 5, 0, 9, 10, 8, 0),
    gsSP2Triangles(9, 8, 7, 0, 11, 12, 10, 0),
    gsSP2Triangles(11, 10, 9, 0, 13, 3, 0, 0),
    gsSP2Triangles(14, 5, 3, 0, 14, 3, 13, 0),
    gsSP2Triangles(15, 7, 5, 0, 15, 5, 14, 0),
    gsSP2Triangles(16, 9, 7, 0, 16, 7, 15, 0),
    gsSP2Triangles(17, 11, 9, 0, 17, 9, 16, 0),
    gsSP2Triangles(18, 19, 20, 0, 21, 22, 18, 0),
    gsSP2Triangles(22, 19, 18, 0, 23, 24, 22, 0),
    gsSP2Triangles(23, 22, 21, 0, 25, 26, 24, 0),
    gsSP2Triangles(25, 24, 23, 0, 27, 28, 26, 0),
    gsSP2Triangles(27, 26, 25, 0, 29, 30, 28, 0),
    gsSP2Triangles(29, 28, 27, 0, 31, 21, 18, 0),
    gsSPVertex(&object_bombiwaVtx_002A70[32], 23, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 1, 0, 4, 1, 0, 0),
    gsSP2Triangles(6, 7, 5, 0, 6, 5, 4, 0),
    gsSP2Triangles(8, 9, 7, 0, 8, 7, 6, 0),
    gsSP2Triangles(10, 11, 12, 0, 13, 3, 10, 0),
    gsSP2Triangles(3, 11, 10, 0, 14, 0, 3, 0),
    gsSP2Triangles(14, 3, 13, 0, 15, 4, 0, 0),
    gsSP2Triangles(15, 0, 14, 0, 16, 6, 4, 0),
    gsSP2Triangles(16, 4, 15, 0, 17, 8, 6, 0),
    gsSP2Triangles(17, 6, 16, 0, 18, 13, 10, 0),
    gsSP2Triangles(19, 14, 13, 0, 19, 13, 18, 0),
    gsSP2Triangles(20, 15, 14, 0, 20, 14, 19, 0),
    gsSP2Triangles(21, 16, 15, 0, 21, 15, 20, 0),
    gsSP2Triangles(22, 17, 16, 0, 22, 16, 21, 0),
    gsSPEndDisplayList(),
};

Gfx object_bombiwa_DL_003110[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_XLU_DECAL2),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(object_bombiwa_Tex_0031C0, G_IM_FMT_IA, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bombiwaVtx_002A70[55], 24, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
    gsSPEndDisplayList(),
};

u64 object_bombiwa_Tex_0031C0[] = {
#include "assets/objects/object_bombiwa/tex_0031C0.ia8.inc.c"
};

u64 object_bombiwa_Tex_0032C0[] = {
#include "assets/objects/object_bombiwa/tex_0032C0.rgba16.inc.c"
};

u64 object_bombiwa_Tex_003AC0[] = {
#include "assets/objects/object_bombiwa/tex_003AC0.i4.inc.c"
};

Vtx object_bombiwaVtx_0042C0[] = {
#include "assets/objects/object_bombiwa/object_bombiwaVtx_0042C0.vtx.inc"
};

Gfx object_bombiwa_DL_004560[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL1, 0, TEXEL0, 0, 0, 0, 0, 1, COMBINED, 0, SHADE, 0, COMBINED, 0, PRIMITIVE, 0),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPDisplayList(0x08000000),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(object_bombiwa_Tex_004830, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock_4b(object_bombiwa_Tex_005030, 0x0100, 1, G_IM_FMT_I, 64, 64, 15, G_TX_NOMIRROR | G_TX_WRAP,
                          G_TX_MIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_bombiwaVtx_0042C0, 22, 0),
    gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
    gsSP2Triangles(4, 5, 6, 0, 5, 7, 6, 0),
    gsSP2Triangles(4, 8, 9, 0, 8, 10, 9, 0),
    gsSP2Triangles(11, 12, 13, 0, 12, 4, 13, 0),
    gsSP2Triangles(3, 4, 12, 0, 1, 5, 3, 0),
    gsSP2Triangles(4, 3, 5, 0, 8, 4, 6, 0),
    gsSP2Triangles(6, 10, 8, 0, 11, 2, 12, 0),
    gsSP2Triangles(12, 2, 3, 0, 7, 5, 14, 0),
    gsSP2Triangles(7, 10, 6, 0, 14, 15, 16, 0),
    gsSP2Triangles(16, 7, 14, 0, 0, 2, 17, 0),
    gsSP2Triangles(11, 17, 2, 0, 7, 16, 10, 0),
    gsSP2Triangles(11, 18, 19, 0, 20, 0, 17, 0),
    gsSP2Triangles(18, 11, 21, 0, 17, 11, 19, 0),
    gsSP1Triangle(17, 19, 20, 0),
    gsSPEndDisplayList(),
};

Gfx object_bombiwa_DL_004688[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_XLU_DECAL2),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(object_bombiwa_Tex_004730, G_IM_FMT_IA, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bombiwaVtx_0042C0[22], 20, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSPEndDisplayList(),
};

u64 object_bombiwa_Tex_004730[] = {
#include "assets/objects/object_bombiwa/tex_004730.ia8.inc.c"
};

u64 object_bombiwa_Tex_004830[] = {
#include "assets/objects/object_bombiwa/tex_004830.rgba16.inc.c"
};

u64 object_bombiwa_Tex_005030[] = {
#include "assets/objects/object_bombiwa/tex_005030.i4.inc.c"
};

Vtx object_bombiwaVtx_005830[] = {
#include "assets/objects/object_bombiwa/object_bombiwaVtx_005830.vtx.inc"
};

Gfx object_bombiwa_DL_005990[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL1, 0, TEXEL0, 0, TEXEL1, TEXEL0, PRIM_LOD_FRAC, TEXEL0, COMBINED, 0, SHADE, 0, COMBINED, 0,
                       PRIMITIVE, 0),
    gsDPSetPrimColor(0, 0xFF, 255, 255, 255, 255),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(object_bombiwa_Tex_005A70, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock_4b(object_bombiwa_Tex_006270, 0x0100, 1, G_IM_FMT_I, 64, 64, 15, G_TX_NOMIRROR | G_TX_WRAP,
                          G_TX_NOMIRROR | G_TX_WRAP, 6, 6, G_TX_NOLOD, 1),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_bombiwaVtx_005830, 22, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 2, 4, 0),
    gsSP2Triangles(5, 2, 3, 0, 6, 7, 3, 0),
    gsSP2Triangles(8, 0, 9, 0, 10, 11, 12, 0),
    gsSP2Triangles(0, 13, 4, 0, 14, 15, 16, 0),
    gsSP2Triangles(14, 17, 18, 0, 19, 20, 21, 0),
    gsSPEndDisplayList(),
};

u64 object_bombiwa_Tex_005A70[] = {
#include "assets/objects/object_bombiwa/tex_005A70.rgba16.inc.c"
};

u64 object_bombiwa_Tex_006270[] = {
#include "assets/objects/object_bombiwa/tex_006270.i4.inc.c"
};

