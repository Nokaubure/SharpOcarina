#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_boss03.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

s16 sGyorgIdleAnimFrameData[] = {
    0x0000, 0x0270, 0x00B0, 0x4000, 0x743A, 0x7F3A, 0xF6A7, 0x0B10, 0x0B7E, 0xFF9D, 0xC000, 0x3F9D, 0xEF9F, 0x1F07, 
    0x7D98, 0xEBF4, 0x0147, 0x0063, 0x10B4, 0xE0F9, 0x145F, 0x81B3, 
};

JointIndex sGyorgIdleAnimJointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0000, 0x0003, 0x0000 },
    { 0x0000, 0x0000, 0x0004 },
    { 0x0000, 0x0000, 0x0005 },
    { 0x0000, 0x0000, 0x0006 },
    { 0x0000, 0x0000, 0x0007 },
    { 0x0000, 0x0000, 0x0008 },
    { 0x0009, 0x000A, 0x000B },
    { 0x000C, 0x000D, 0x000E },
    { 0x0000, 0x000F, 0x0010 },
    { 0x0011, 0x0003, 0x000B },
    { 0x0012, 0x0013, 0x000E },
    { 0x0000, 0x0014, 0x0010 },
    { 0x0000, 0x0000, 0x0005 },
    { 0x0000, 0x0000, 0x0015 },
};

AnimationHeader gGyorgIdleAnim = { 
    { 14 }, sGyorgIdleAnimFrameData,
    sGyorgIdleAnimJointIndices, 22
};

u8 object_boss03_possiblePadding_000098[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

u64 gGyorgUnusedMajorasWrathWhipTex[] = {
#include "assets/objects/object_boss03/unused_majoras_wrath_whip.rgba16.inc.c"
};

Vtx object_boss03Vtx_0001A0[] = {
#include "assets/objects/object_boss03/object_boss03Vtx_0001A0.vtx.inc"
};

Gfx gGyorgUnusedMajorasWrathWhipDL1[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gGyorgUnusedMajorasWrathWhipTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 3, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, PRIMITIVE, 0, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPClearGeometryMode(G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPEndDisplayList(),
};

Gfx gGyorgUnusedMajorasWrathWhipDL2[] = {
    gsDPPipeSync(),
    gsSPTexture(0, 0, 0, G_TX_RENDERTILE, G_OFF),
    gsDPSetCombineLERP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, PRIMITIVE, 0, 0, 0, PRIMITIVE),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_XLU_DECAL2),
    gsSPClearGeometryMode(G_CULL_BACK | G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPEndDisplayList(),
};

Gfx gGyorgUnusedMajorasWrathWhipDL3[] = {
    gsSPVertex(object_boss03Vtx_0001A0, 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(3, 2, 4, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 4, 1, 0, 5, 1, 0, 0),
    gsSPVertex(object_boss03Vtx_0001A0, 6, 0),
    gsSPEndDisplayList(),
};

Vtx object_boss03Vtx_0002D8[] = {
#include "assets/objects/object_boss03/object_boss03Vtx_0002D8.vtx.inc"
};

Gfx gGyorgHeadDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gGyorgEyeTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                         | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(object_boss03Vtx_0002D8, 26, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 5, 0),
    gsSP2Triangles(11, 12, 13, 0, 14, 15, 8, 0),
    gsSP2Triangles(8, 15, 16, 0, 5, 4, 17, 0),
    gsSP2Triangles(5, 10, 18, 0, 8, 7, 19, 0),
    gsSP2Triangles(13, 20, 11, 0, 16, 21, 8, 0),
    gsSP2Triangles(19, 22, 8, 0, 8, 21, 6, 0),
    gsSP2Triangles(8, 22, 14, 0, 5, 23, 3, 0),
    gsSP2Triangles(5, 24, 9, 0, 17, 24, 5, 0),
    gsSP2Triangles(2, 25, 0, 0, 18, 23, 5, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_0002D8[26], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 2, 0),
    gsSP2Triangles(1, 5, 3, 0, 2, 1, 3, 0),
    gsSP1Triangle(2, 4, 0, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[32], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(2, 1, 4, 0, 0, 5, 1, 0),
    gsSP1Triangle(4, 3, 2, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[38], 18, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(1, 6, 7, 0, 2, 8, 0, 0),
    gsSP2Triangles(9, 10, 4, 0, 5, 11, 3, 0),
    gsSP2Triangles(12, 13, 2, 0, 3, 14, 15, 0),
    gsSP2Triangles(4, 16, 9, 0, 7, 17, 1, 0),
    gsSP2Triangles(2, 1, 17, 0, 16, 4, 3, 0),
    gsSP2Triangles(15, 16, 3, 0, 2, 17, 12, 0),
    gsDPSetPrimColor(0, 0x80, 119, 116, 121, 255),
    gsSPVertex(&object_boss03Vtx_0002D8[56], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(5, 12, 13, 0, 13, 3, 5, 0),
    gsSP2Triangles(14, 15, 16, 0, 16, 17, 14, 0),
    gsSP2Triangles(18, 8, 19, 0, 18, 19, 20, 0),
    gsSP2Triangles(9, 11, 21, 0, 22, 9, 21, 0),
    gsSP2Triangles(2, 22, 23, 0, 24, 20, 25, 0),
    gsSP2Triangles(17, 26, 14, 0, 8, 7, 19, 0),
    gsSP2Triangles(21, 27, 22, 0, 25, 28, 29, 0),
    gsSP2Triangles(3, 7, 6, 0, 30, 10, 16, 0),
    gsSP2Triangles(20, 31, 18, 0, 16, 15, 30, 0),
    gsSP2Triangles(11, 10, 30, 0, 6, 4, 3, 0),
    gsSP2Triangles(23, 0, 2, 0, 25, 29, 24, 0),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_boss03Vtx_0002D8[88], 20, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(1, 12, 2, 0, 13, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 3, 19, 4, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gGyorgSidesTLUT),
    gsDPLoadTextureBlock_4b(gGyorgSidesTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[108], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 1, 0, 0, 5, 4, 7, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[116], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 6, 7, 0, 1, 8, 2, 0),
    gsSP2Triangles(5, 7, 3, 0, 2, 9, 0, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[126], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 1, 0, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gGyorgMouthAndSpikeBacksideTLUT),
    gsDPLoadTextureBlock_4b(gGyorgMouthAndSpikeBacksideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[136], 16, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
    gsSP2Triangles(2, 10, 0, 0, 3, 11, 4, 0),
    gsSP2Triangles(0, 10, 5, 0, 12, 3, 10, 0),
    gsSP2Triangles(10, 13, 12, 0, 9, 14, 6, 0),
    gsSP2Triangles(10, 2, 13, 0, 1, 15, 2, 0),
    gsSP2Triangles(5, 10, 3, 0, 5, 9, 8, 0),
    gsSP1Triangle(8, 0, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gGyorgBellyAndFinFleshTLUT),
    gsDPLoadTextureBlock_4b(gGyorgBellyAndFinFleshTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[152], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
    gsSP2Triangles(4, 3, 2, 0, 4, 5, 0, 0),
    gsSP2Triangles(1, 0, 6, 0, 7, 0, 5, 0),
    gsSP1Triangle(2, 3, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gGyorgMouthAndSpikeBacksideTLUT),
    gsDPLoadTextureBlock_4b(gGyorgMouthAndSpikeBacksideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[160], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gGyorgHornsTeethAndClawsTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[172], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 4, 6, 0, 6, 4, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 11, 12, 13, 0),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 16, 15, 23, 0),
    gsSP2Triangles(24, 25, 26, 0, 13, 12, 27, 0),
    gsSP1Triangle(28, 29, 30, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[203], 11, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 8, 9, 0),
    gsSP1Triangle(9, 8, 10, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgMouthAndSpikeBacksideTLUT),
    gsDPLoadTextureBlock_4b(gGyorgMouthAndSpikeBacksideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[214], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSP2Triangles(2, 4, 0, 0, 0, 5, 3, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgJawDL[] = {
    gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_0002D8[408], 6, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[414], 4, 6),
    gsSPMatrix(0x0D000200, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_boss03Vtx_0002D8[418], 11, 10),
    gsSP2Triangles(9, 10, 8, 0, 11, 12, 9, 0),
    gsSP2Triangles(8, 13, 14, 0, 9, 7, 15, 0),
    gsSP2Triangles(16, 6, 8, 0, 7, 17, 18, 0),
    gsSP1Triangle(19, 20, 6, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[429], 10, 10),
    gsSP2Triangles(5, 10, 11, 0, 12, 13, 5, 0),
    gsSP2Triangles(3, 4, 14, 0, 15, 5, 1, 0),
    gsSP2Triangles(4, 16, 17, 0, 18, 19, 4, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gGyorgMouthAndSpikeBacksideTLUT),
    gsDPLoadTextureBlock_4b(gGyorgMouthAndSpikeBacksideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[439], 13, 10),
    gsSP2Triangles(2, 10, 11, 0, 12, 13, 0, 0),
    gsSP2Triangles(0, 14, 15, 0, 2, 16, 17, 0),
    gsSP2Triangles(18, 19, 2, 0, 0, 2, 20, 0),
    gsSP1Triangle(21, 22, 0, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[452], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[456], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 4, 0, 3, 10, 11, 0),
    gsSP2Triangles(7, 12, 8, 0, 7, 8, 4, 0),
    gsSP2Triangles(3, 11, 13, 0, 3, 13, 0, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gGyorgHornsTeethAndClawsTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[470], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 1, 0, 0, 7, 8, 9, 0),
    gsSP2Triangles(10, 11, 3, 0, 12, 13, 14, 0),
    gsSP2Triangles(15, 16, 17, 0, 18, 19, 20, 0),
    gsSP2Triangles(21, 22, 23, 0, 24, 25, 26, 0),
    gsSP2Triangles(27, 28, 29, 0, 20, 19, 30, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[501], 17, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 6, 0),
    gsSP2Triangles(11, 12, 13, 0, 14, 15, 16, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgMouthAndSpikeBacksideTLUT),
    gsDPLoadTextureBlock_4b(gGyorgMouthAndSpikeBacksideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[518], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(4, 6, 7, 0, 4, 7, 5, 0),
    gsSP2Triangles(5, 8, 0, 0, 2, 9, 10, 0),
    gsSP2Triangles(2, 10, 11, 0, 2, 11, 3, 0),
    gsSP2Triangles(5, 0, 3, 0, 3, 0, 2, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgUpperLeftFinDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_0002D8[282], 24, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(3, 5, 6, 0, 7, 1, 8, 0),
    gsSP2Triangles(8, 1, 0, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(15, 7, 8, 0, 15, 8, 12, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
    gsSP2Triangles(6, 8, 0, 0, 6, 0, 3, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gGyorgBellyAndFinFleshTLUT),
    gsDPLoadTextureBlock_4b(gGyorgBellyAndFinFleshTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[306], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(3, 5, 6, 0, 0, 7, 1, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgLowerLeftFinDL[] = {
    gsSPMatrix(0x0D000180, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_0002D8[220], 5, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[225], 2, 5),
    gsSPMatrix(0x0D0001C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_boss03Vtx_0002D8[227], 14, 7),
    gsSP2Triangles(0, 4, 7, 0, 8, 4, 3, 0),
    gsSP2Triangles(9, 10, 0, 0, 3, 11, 12, 0),
    gsSP2Triangles(13, 0, 14, 0, 15, 3, 16, 0),
    gsSP2Triangles(17, 0, 18, 0, 19, 3, 20, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gGyorgBellyAndFinFleshTLUT),
    gsDPLoadTextureBlock_4b(gGyorgBellyAndFinFleshTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[241], 6, 7),
    gsSP2Triangles(6, 1, 7, 0, 8, 2, 5, 0),
    gsSP2Triangles(9, 6, 10, 0, 11, 5, 12, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[247], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 1, 6, 0, 7, 8, 9, 0),
    gsSP2Triangles(6, 5, 2, 0, 2, 7, 0, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gGyorgBellyAndFinFleshTLUT),
    gsDPLoadTextureBlock_4b(gGyorgBellyAndFinFleshTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[257], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gGyorgHornsTeethAndClawsTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[263], 19, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 4, 6, 0, 7, 8, 9, 0),
    gsSP2Triangles(10, 11, 12, 0, 6, 13, 14, 0),
    gsSP2Triangles(14, 13, 15, 0, 16, 17, 18, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgUpperRightFinDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_0002D8[376], 24, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 3, 5, 0, 7, 1, 8, 0),
    gsSP2Triangles(2, 1, 7, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 12, 14, 0),
    gsSP2Triangles(7, 8, 15, 0, 14, 7, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 19, 16, 18, 0),
    gsSP2Triangles(20, 21, 22, 0, 23, 20, 22, 0),
    gsSP2Triangles(2, 7, 6, 0, 5, 2, 6, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gGyorgBellyAndFinFleshTLUT),
    gsDPLoadTextureBlock_4b(gGyorgBellyAndFinFleshTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[400], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 3, 5, 0, 1, 7, 2, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgLowerRightFinDL[] = {
    gsSPMatrix(0x0D000100, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_0002D8[314], 5, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[319], 2, 5),
    gsSPMatrix(0x0D000140, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_boss03Vtx_0002D8[321], 14, 7),
    gsSP2Triangles(7, 4, 0, 0, 3, 4, 8, 0),
    gsSP2Triangles(0, 9, 10, 0, 11, 12, 3, 0),
    gsSP2Triangles(13, 0, 14, 0, 15, 3, 16, 0),
    gsSP2Triangles(17, 0, 18, 0, 19, 3, 20, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gGyorgBellyAndFinFleshTLUT),
    gsDPLoadTextureBlock_4b(gGyorgBellyAndFinFleshTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[335], 6, 7),
    gsSP2Triangles(7, 1, 6, 0, 5, 2, 8, 0),
    gsSP2Triangles(9, 6, 10, 0, 11, 5, 12, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[341], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 1, 0, 0, 7, 8, 9, 0),
    gsSP2Triangles(0, 3, 6, 0, 2, 9, 0, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gGyorgBellyAndFinFleshTLUT),
    gsDPLoadTextureBlock_4b(gGyorgBellyAndFinFleshTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[351], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gGyorgHornsTeethAndClawsTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[357], 19, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 4, 3, 0, 7, 8, 9, 0),
    gsSP2Triangles(10, 11, 12, 0, 13, 14, 6, 0),
    gsSP2Triangles(15, 14, 13, 0, 16, 17, 18, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgUpperTrunkDL[] = {
    gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_0002D8[715], 12, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[727], 8, 12),
    gsSPVertex(&object_boss03Vtx_0002D8[735], 3, 20),
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_boss03Vtx_0002D8[738], 4, 23),
    gsSP2Triangles(23, 3, 12, 0, 24, 2, 5, 0),
    gsSP2Triangles(16, 2, 25, 0, 10, 3, 26, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gGyorgSidesTLUT),
    gsDPLoadTextureBlock_4b(gGyorgSidesTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[742], 8, 23),
    gsSP2Triangles(9, 23, 24, 0, 25, 26, 4, 0),
    gsSP2Triangles(27, 28, 9, 0, 4, 29, 30, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[750], 8, 23),
    gsSP2Triangles(23, 13, 19, 0, 13, 24, 25, 0),
    gsSP2Triangles(26, 27, 15, 0, 18, 15, 28, 0),
    gsSP1Triangle(29, 30, 18, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[758], 2, 23),
    gsSP1Triangle(19, 23, 24, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gGyorgBellyAndFinFleshTLUT),
    gsDPLoadTextureBlock_4b(gGyorgBellyAndFinFleshTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[760], 6, 23),
    gsSP2Triangles(23, 20, 21, 0, 22, 20, 24, 0),
    gsSP2Triangles(25, 26, 22, 0, 21, 27, 28, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[766], 6, 23),
    gsSP2Triangles(23, 0, 8, 0, 6, 1, 24, 0),
    gsSP2Triangles(8, 25, 26, 0, 27, 28, 6, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gGyorgMouthAndSpikeBacksideTLUT),
    gsDPLoadTextureBlock_4b(gGyorgMouthAndSpikeBacksideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[772], 8, 23),
    gsSP2Triangles(23, 24, 11, 0, 14, 25, 26, 0),
    gsSP2Triangles(27, 28, 17, 0, 7, 29, 30, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgLowerTrunkDL[] = {
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_0002D8[605], 12, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[617], 8, 12),
    gsSPVertex(&object_boss03Vtx_0002D8[625], 3, 20),
    gsSPMatrix(0x0D000080, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_boss03Vtx_0002D8[628], 6, 23),
    gsSP2Triangles(23, 10, 3, 0, 6, 11, 24, 0),
    gsSP2Triangles(6, 25, 26, 0, 27, 28, 3, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gGyorgSidesTLUT),
    gsDPLoadTextureBlock_4b(gGyorgSidesTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[634], 8, 23),
    gsSP2Triangles(23, 24, 8, 0, 4, 25, 26, 0),
    gsSP2Triangles(27, 28, 4, 0, 8, 29, 30, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 252, 255, 255, 255),
    gsSPVertex(&object_boss03Vtx_0002D8[642], 4, 23),
    gsSP2Triangles(23, 0, 14, 0, 16, 1, 24, 0),
    gsSP2Triangles(2, 0, 25, 0, 26, 1, 7, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gGyorgMouthAndSpikeBacksideTLUT),
    gsDPLoadTextureBlock_4b(gGyorgMouthAndSpikeBacksideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_boss03Vtx_0002D8[646], 8, 23),
    gsSP2Triangles(23, 24, 5, 0, 15, 25, 26, 0),
    gsSP2Triangles(9, 27, 28, 0, 29, 30, 17, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gGyorgSidesTLUT),
    gsDPLoadTextureBlock_4b(gGyorgSidesTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[654], 9, 23),
    gsSP2Triangles(23, 24, 12, 0, 25, 13, 26, 0),
    gsSP2Triangles(13, 27, 28, 0, 18, 12, 29, 0),
    gsSP1Triangle(30, 12, 31, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[663], 5, 23),
    gsSP2Triangles(23, 13, 19, 0, 19, 24, 25, 0),
    gsSP1Triangle(26, 27, 18, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gGyorgBellyAndFinFleshTLUT),
    gsDPLoadTextureBlock_4b(gGyorgBellyAndFinFleshTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[668], 7, 23),
    gsSP2Triangles(20, 21, 23, 0, 24, 25, 20, 0),
    gsSP2Triangles(20, 26, 27, 0, 28, 29, 20, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[675], 3, 23),
    gsSP2Triangles(23, 22, 20, 0, 24, 25, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gGyorgSidesTLUT),
    gsDPLoadTextureBlock_4b(gGyorgSidesTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[678], 9, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 4, 0),
    gsSP2Triangles(2, 5, 0, 0, 4, 6, 3, 0),
    gsSP2Triangles(0, 5, 7, 0, 8, 6, 4, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[687], 28, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 4, 6, 0, 2, 7, 8, 0),
    gsSP2Triangles(2, 9, 10, 0, 5, 11, 3, 0),
    gsSP2Triangles(6, 12, 5, 0, 8, 9, 2, 0),
    gsSP2Triangles(10, 0, 2, 0, 13, 14, 15, 0),
    gsSP2Triangles(15, 16, 17, 0, 18, 19, 20, 0),
    gsSP2Triangles(17, 21, 13, 0, 22, 23, 18, 0),
    gsSP2Triangles(18, 20, 22, 0, 13, 15, 17, 0),
    gsSP2Triangles(20, 24, 22, 0, 25, 11, 5, 0),
    gsSP2Triangles(26, 7, 2, 0, 12, 27, 5, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgTailDL[] = {
    gsSPMatrix(0x0D000080, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_0002D8[530], 2, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[532], 2, 2),
    gsSPVertex(&object_boss03Vtx_0002D8[534], 6, 4),
    gsSPVertex(&object_boss03Vtx_0002D8[540], 1, 10),
    gsSPMatrix(0x0D0000C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgSidesTLUT),
    gsDPLoadTextureBlock_4b(gGyorgSidesTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_boss03Vtx_0002D8[541], 12, 11),
    gsSP2Triangles(11, 0, 2, 0, 2, 8, 12, 0),
    gsSP2Triangles(13, 7, 3, 0, 3, 1, 14, 0),
    gsSP2Triangles(15, 16, 3, 0, 2, 17, 18, 0),
    gsSP2Triangles(19, 20, 2, 0, 3, 21, 22, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[553], 12, 11),
    gsSP2Triangles(11, 12, 4, 0, 5, 13, 14, 0),
    gsSP2Triangles(15, 9, 4, 0, 4, 10, 16, 0),
    gsSP2Triangles(17, 10, 5, 0, 5, 6, 18, 0),
    gsSP2Triangles(4, 19, 20, 0, 21, 22, 5, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gGyorgSidesTLUT),
    gsDPLoadTextureBlock_4b(gGyorgSidesTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[565], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 6, 0, 0, 5, 7, 3, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPLoadTLUT_pal16(15, gGyorgFinsSpikesAndJawTLUT),
    gsDPLoadTextureBlock_4b(gGyorgFinsSpikesAndJawTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_0002D8[573], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 6, 0, 0, 5, 7, 3, 0),
    gsSPVertex(&object_boss03Vtx_0002D8[581], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gGyorgBellyAndFinFleshTLUT),
    gsDPLoadTextureBlock_4b(gGyorgBellyAndFinFleshTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 252, 255, 255, 255),
    gsSPVertex(&object_boss03Vtx_0002D8[593], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSPEndDisplayList(),
};

AnimatedMaterial gGyorgUnused5388TexAnim[] = {
    { 0, 6, NULL },
};

u64 gGyorgFinsSpikesAndJawTLUT[] = {
#include "assets/objects/object_boss03/gyorg_fins_spikes_and_jaw_tlut.rgba16.inc.c"
};

u64 gGyorgSidesTLUT[] = {
#include "assets/objects/object_boss03/gyorg_sides_tlut.rgba16.inc.c"
};

u64 gGyorgMouthAndSpikeBacksideTLUT[] = {
#include "assets/objects/object_boss03/gyorg_mouth_and_spike_backside_tlut.rgba16.inc.c"
};

u64 gGyorgBellyAndFinFleshTLUT[] = {
#include "assets/objects/object_boss03/gyorg_belly_and_fin_flesh_tlut.rgba16.inc.c"
};

u64 gGyorgEyeTex[] = {
#include "assets/objects/object_boss03/gyorg_eye.rgba16.inc.c"
};

u64 gGyorgFinsSpikesAndJawTex[] = {
#include "assets/objects/object_boss03/gyorg_fins_spikes_and_jaw.ci4.inc.c"
};

u64 gGyorgSidesTex[] = {
#include "assets/objects/object_boss03/gyorg_sides.ci4.inc.c"
};

u64 gGyorgMouthAndSpikeBacksideTex[] = {
#include "assets/objects/object_boss03/gyorg_mouth_and_spike_backside.ci4.inc.c"
};

u64 gGyorgBellyAndFinFleshTex[] = {
#include "assets/objects/object_boss03/gyorg_belly_and_fin_flesh.ci4.inc.c"
};

u64 gGyorgHornsTeethAndClawsTex[] = {
#include "assets/objects/object_boss03/gyorg_horns_teeth_claws.rgba16.inc.c"
};

Vtx object_boss03Vtx_007E10[] = {
#include "assets/objects/object_boss03/object_boss03Vtx_007E10.vtx.inc"
};

Gfx gGyorgBubbleMaterialDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(PRIMITIVE, ENVIRONMENT, TEXEL0, ENVIRONMENT, PRIMITIVE, 0, TEXEL0, 0, 0, 0, 0, COMBINED, 0, 0, 0,
                       COMBINED),
    gsDPSetRenderMode(G_RM_PASS, G_RM_ZB_CLD_SURF2),
    gsDPLoadTextureBlock(gEffBubble1Tex, G_IM_FMT_IA, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                         | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPEndDisplayList(),
};

Gfx gGyorgBubbleModelDL[] = {
    gsSPVertex(object_boss03Vtx_007E10, 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

u64 gGyorgTitleCardTex[] = {
#include "assets/objects/object_boss03/gyorg_title_card.ia8.inc.c"
};

StandardLimb gGyorgRootLimb = { 
    { 0, 624, 176 }, GYORG_LIMB_HEAD - 1, LIMB_DONE,
    NULL
};

StandardLimb gGyorgHeadLimb = { 
    { 0, 0, 0 }, GYORG_LIMB_BODY_ROOT - 1, LIMB_DONE,
    gGyorgHeadDL
};

StandardLimb gGyorgBodyRootLimb = { 
    { -67, 1, 0 }, GYORG_LIMB_UPPER_TRUNK - 1, GYORG_LIMB_RIGHT_FIN_ROOT - 1,
    NULL
};

StandardLimb gGyorgUpperTrunkLimb = { 
    { 0, 0, 0 }, GYORG_LIMB_LOWER_TRUNK - 1, LIMB_DONE,
    gGyorgUpperTrunkDL
};

StandardLimb gGyorgLowerTrunkLimb = { 
    { 437, 0, 0 }, GYORG_LIMB_TAIL - 1, LIMB_DONE,
    gGyorgLowerTrunkDL
};

StandardLimb gGyorgTailLimb = { 
    { 403, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gGyorgTailDL
};

StandardLimb gGyorgRightFinRootLimb = { 
    { 93, 306, -165 }, GYORG_LIMB_UPPER_RIGHT_FIN - 1, GYORG_LIMB_LEFT_FIN_ROOT - 1,
    NULL
};

StandardLimb gGyorgUpperRightFinLimb = { 
    { 0, 0, 0 }, GYORG_LIMB_LOWER_RIGHT_FIN - 1, LIMB_DONE,
    gGyorgUpperRightFinDL
};

StandardLimb gGyorgLowerRightFinLimb = { 
    { 407, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gGyorgLowerRightFinDL
};

StandardLimb gGyorgLeftFinRootLimb = { 
    { 93, 306, 165 }, GYORG_LIMB_UPPER_LEFT_FIN - 1, GYORG_LIMB_JAW_ROOT - 1,
    NULL
};

StandardLimb gGyorgUpperLeftFinLimb = { 
    { 0, 0, 0 }, GYORG_LIMB_LOWER_LEFT_FIN - 1, LIMB_DONE,
    gGyorgUpperLeftFinDL
};

StandardLimb gGyorgLowerLeftFinLimb = { 
    { 407, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gGyorgLowerLeftFinDL
};

StandardLimb gGyorgJawRootLimb = { 
    { 325, 230, 0 }, GYORG_LIMB_JAW - 1, LIMB_DONE,
    NULL
};

StandardLimb gGyorgJawLimb = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gGyorgJawDL
};

void* gGyorgSkelLimbs[] = {
    &gGyorgRootLimb, /* GYORG_LIMB_ROOT */
    &gGyorgHeadLimb, /* GYORG_LIMB_HEAD */
    &gGyorgBodyRootLimb, /* GYORG_LIMB_BODY_ROOT */
    &gGyorgUpperTrunkLimb, /* GYORG_LIMB_UPPER_TRUNK */
    &gGyorgLowerTrunkLimb, /* GYORG_LIMB_LOWER_TRUNK */
    &gGyorgTailLimb, /* GYORG_LIMB_TAIL */
    &gGyorgRightFinRootLimb, /* GYORG_LIMB_RIGHT_FIN_ROOT */
    &gGyorgUpperRightFinLimb, /* GYORG_LIMB_UPPER_RIGHT_FIN */
    &gGyorgLowerRightFinLimb, /* GYORG_LIMB_LOWER_RIGHT_FIN */
    &gGyorgLeftFinRootLimb, /* GYORG_LIMB_LEFT_FIN_ROOT */
    &gGyorgUpperLeftFinLimb, /* GYORG_LIMB_UPPER_LEFT_FIN */
    &gGyorgLowerLeftFinLimb, /* GYORG_LIMB_LOWER_LEFT_FIN */
    &gGyorgJawRootLimb, /* GYORG_LIMB_JAW_ROOT */
    &gGyorgJawLimb, /* GYORG_LIMB_JAW */
};

FlexSkeletonHeader gGyorgSkel = { 
    { gGyorgSkelLimbs, ARRAY_COUNT(gGyorgSkelLimbs) }, 9
};

u8 object_boss03_possiblePadding_0093B4[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 sGyorgFloppingAnimFrameData[] = {
    0x0000, 0x0270, 0x00B0, 0x4000, 0x7F3A, 0xFE6E, 0x029C, 0xFF9D, 0xC000, 0x3F9D, 0xEF9F, 0xEBF4, 0x0147, 0x0063, 
    0x10B4, 0x145F, 0x0270, 0x024B, 0x0227, 0x024B, 0x0270, 0x025D, 0x023A, 0x0227, 0x023A, 0x025D, 0xFB66, 0xFB82, 
    0xFBC0, 0xFBFD, 0xFC1A, 0xFC0C, 0xFBEB, 0xFBC0, 0xFB94, 0xFB73, 0xF0AC, 0xF500, 0xFE86, 0x080C, 0x0C60, 0x0A53, 
    0x0531, 0xFE86, 0xF7DB, 0xF2BA, 0x898E, 0x85AC, 0x7D20, 0x7494, 0x70B2, 0x7289, 0x7724, 0x7D20, 0x831C, 0x87B7, 
    0x0C2B, 0x0B82, 0x0A0F, 0x089C, 0x07F4, 0x0844, 0x090C, 0x0A0F, 0x0B13, 0x0BDB, 0xE8DB, 0xEF89, 0xFE39, 0x0CE9, 
    0x1397, 0x106C, 0x0883, 0xFE39, 0xF3F0, 0xEC06, 0xE8E4, 0xEEC6, 0xFBB6, 0x08A6, 0x0E87, 0x0BBE, 0x04C5, 0xFBB6, 
    0xF2A6, 0xEBAE, 0xE89D, 0xEEAC, 0xFC02, 0x0957, 0x0F67, 0x0C87, 0x0558, 0xFC02, 0xF2AB, 0xEB7C, 0xDBBD, 0xE7C5, 
    0x023E, 0x1CB6, 0x28BE, 0x230A, 0x14C7, 0x023E, 0xEFB4, 0xE171, 0x16D9, 0x182F, 0x1916, 0x173A, 0x134D, 0x1132, 
    0x1181, 0x1338, 0x1658, 0x184A, 0x88EB, 0x8625, 0x7DE7, 0x7638, 0x7312, 0x7103, 0x6F7A, 0x6F31, 0x721F, 0x78D3, 
    0xF1D7, 0xF4B6, 0xF697, 0xEFC7, 0xE94E, 0xE955, 0xEE74, 0xF43E, 0xF5F4, 0xF463, 0x93C9, 0x8CE2, 0x7FF4, 0x73E1, 
    0x7102, 0x7B01, 0x8735, 0x9235, 0x99EE, 0x9DA3, 0x8FCB, 0x8705, 0x7CA5, 0x7A67, 0x79DA, 0x7AB3, 0x7CA5, 0x80FC, 
    0x876B, 0x8D40, 
};

JointIndex sGyorgFloppingAnimJointIndices[] = {
    { 0x0000, 0x0010, 0x0002 },
    { 0x0000, 0x0003, 0x0000 },
    { 0x001A, 0x0024, 0x002E },
    { 0x0000, 0x0000, 0x0004 },
    { 0x0038, 0x0042, 0x004C },
    { 0x0000, 0x0056, 0x0005 },
    { 0x0000, 0x0060, 0x0006 },
    { 0x0007, 0x0008, 0x0009 },
    { 0x000A, 0x006A, 0x0074 },
    { 0x0000, 0x000B, 0x000C },
    { 0x000D, 0x0003, 0x0009 },
    { 0x000E, 0x007E, 0x0088 },
    { 0x0000, 0x000F, 0x000C },
    { 0x0000, 0x0000, 0x0004 },
    { 0x0000, 0x0000, 0x0092 },
};

AnimationHeader gGyorgFloppingAnim = { 
    { 10 }, sGyorgFloppingAnimFrameData,
    sGyorgFloppingAnimJointIndices, 16
};

u8 object_boss03_possiblePadding_009564[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 sGyorgJumpingAnimFrameData[] = {
    0x0000, 0x0270, 0x00B0, 0x4000, 0x7F3A, 0xFF9D, 0xC000, 0x3F9D, 0xEF9F, 0x0147, 0x0063, 0x10B4, 0x0270, 0x0269, 
    0x0259, 0x0240, 0x0222, 0x0202, 0x01E2, 0x01C4, 0x01AD, 0x019D, 0x0194, 0x018F, 0x018C, 0x018B, 0x018D, 0x0190, 
    0x0195, 0x019A, 0x01A1, 0x01A7, 0x0199, 0x01ED, 0x033B, 0x04D3, 0x059A, 0x059A, 0x059A, 0x059A, 0x059A, 0x059A, 
    0x743A, 0x746E, 0x7503, 0x75EE, 0x7725, 0x789C, 0x7A48, 0x7C1F, 0x7E15, 0x8021, 0x8236, 0x844A, 0x8653, 0x8844, 
    0x8A14, 0x8BB8, 0x8D24, 0x8E4E, 0x8F2B, 0x8FB0, 0x8DE0, 0x8912, 0x833A, 0x7E4A, 0x7C36, 0x7C36, 0x7C36, 0x7C36, 
    0x7C36, 0x7C36, 0xF6A7, 0xF6D7, 0xF75E, 0xF82F, 0xF940, 0xFA84, 0xFBEE, 0xFD73, 0xFF06, 0x009B, 0x0227, 0x039D, 
    0x04F1, 0x0617, 0x0703, 0x07A8, 0x07FB, 0x07EF, 0x0778, 0x068B, 0x0135, 0xF62E, 0xE96A, 0xDEDB, 0xDA75, 0xDA75, 
    0xDA75, 0xDA75, 0xDA75, 0xDA75, 0x0B10, 0x0B41, 0x0BCB, 0x0CA2, 0x0DB8, 0x0F01, 0x106F, 0x11F7, 0x138A, 0x151C, 
    0x16A0, 0x1809, 0x194B, 0x1A57, 0x1B22, 0x1B9F, 0x1BC0, 0x1B78, 0x1ABB, 0x197C, 0x133A, 0x067E, 0xF7CE, 0xEBAF, 
    0xE6A3, 0xE6A3, 0xE6A3, 0xE6A3, 0xE6A3, 0xE6A3, 0x0000, 0xFFC1, 0xFF0C, 0xFDF0, 0xFC7B, 0xFAB9, 0xF8BA, 0xF68A, 
    0xF437, 0xF1D0, 0xEF62, 0xECFB, 0xEAA9, 0xE879, 0xE679, 0xE4B8, 0xE342, 0xE226, 0xE172, 0xE133, 0xE467, 0xEC0A, 
    0xF528, 0xFCCC, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0B7E, 0x0BC7, 0x0C98, 0x0DDC, 0x0F81, 0x1175, 
    0x13A4, 0x15FC, 0x186A, 0x1ADB, 0x1D3D, 0x1F7B, 0x2185, 0x2346, 0x24AD, 0x25A5, 0x261D, 0x2602, 0x2540, 0x23C6, 
    0x1B67, 0x0A23, 0xF627, 0xE5A2, 0xDEC1, 0xDEC1, 0xDEC1, 0xDEC1, 0xDEC1, 0xDEC1, 0x1F07, 0x1E8F, 0x1D2F, 0x1ADF, 
    0x1791, 0x1358, 0x0E79, 0x0974, 0x04E2, 0x014C, 0xFE93, 0xFC49, 0xFA66, 0xF8E2, 0xF7B6, 0xF6DA, 0xF64B, 0xF604, 
    0xF605, 0xF64C, 0xF639, 0x034C, 0x2379, 0x3277, 0x356E, 0x356E, 0x356E, 0x356E, 0x356E, 0x356E, 0x7D98, 0x7E48, 
    0x802B, 0x82EE, 0x8631, 0x8995, 0x8CCB, 0x8FA3, 0x920C, 0x9410, 0x95CE, 0x9753, 0x98A7, 0x99D4, 0x9ADC, 0x9BC5, 
    0x9C90, 0x9D3D, 0x9DCA, 0x9E33, 0x9D04, 0x9C13, 0x992D, 0x8C02, 0x8079, 0x8079, 0x8079, 0x8079, 0x8079, 0x8079, 
    0xEBF4, 0xEC41, 0xED1C, 0xEE74, 0xF038, 0xF259, 0xF4C5, 0xF76B, 0xFA3B, 0xFD25, 0x0016, 0x02FF, 0x05D0, 0x0876, 
    0x0AE2, 0x0D02, 0x0EC7, 0x101F, 0x10FA, 0x1146, 0x1146, 0x1146, 0x1146, 0x1146, 0x1146, 0x1146, 0x1146, 0x1146, 
    0x1146, 0x1146, 0xE0F9, 0xE171, 0xE2D1, 0xE521, 0xE86F, 0xECA8, 0xF187, 0xF68C, 0xFB1E, 0xFEB4, 0x016D, 0x03B7, 
    0x059A, 0x071E, 0x084A, 0x0926, 0x09B5, 0x09FC, 0x09FB, 0x09B4, 0x09C7, 0xFCB4, 0xDC87, 0xCD89, 0xCA92, 0xCA92, 
    0xCA92, 0xCA92, 0xCA92, 0xCA92, 0x7D98, 0x7E48, 0x802B, 0x82EE, 0x8631, 0x8995, 0x8CCB, 0x8FA3, 0x920C, 0x9410, 
    0x95CE, 0x9753, 0x98A7, 0x99D4, 0x9ADC, 0x9BC5, 0x9C90, 0x9D3D, 0x9DCA, 0x9E33, 0x9D04, 0x9C13, 0x992D, 0x8C02, 
    0x8079, 0x8079, 0x8079, 0x8079, 0x8079, 0x8079, 0x145F, 0x1412, 0x1337, 0x11DE, 0x1019, 0x0DF7, 0x0B8A, 0x08E2, 
    0x0610, 0x0325, 0x0032, 0xFD47, 0xFA75, 0xF7CE, 0xF560, 0xF33F, 0xF179, 0xF020, 0xEF45, 0xEEF8, 0xEEF8, 0xEEF8, 
    0xEEF8, 0xEEF8, 0xEEF8, 0xEEF8, 0xEEF8, 0xEEF8, 0xEEF8, 0xEEF8, 0x8AD3, 0x8AAA, 0x8A37, 0x8981, 0x8892, 0x8772, 
    0x862B, 0x84C4, 0x8348, 0x81BE, 0x8030, 0x7EA6, 0x7D29, 0x7BC3, 0x7A7B, 0x795C, 0x786C, 0x77B7, 0x7743, 0x771B, 
    0x771B, 0x771B, 0x771B, 0x771B, 0x771B, 0x771B, 0x771B, 0x771B, 0x771B, 0x771B, 
};

JointIndex sGyorgJumpingAnimJointIndices[] = {
    { 0x0000, 0x000C, 0x0002 },
    { 0x0000, 0x0003, 0x0000 },
    { 0x0000, 0x0000, 0x002A },
    { 0x0000, 0x0000, 0x0004 },
    { 0x0000, 0x0000, 0x0048 },
    { 0x0000, 0x0000, 0x0066 },
    { 0x0084, 0x0000, 0x00A2 },
    { 0x0005, 0x0006, 0x0007 },
    { 0x0008, 0x00C0, 0x00DE },
    { 0x0000, 0x00FC, 0x0009 },
    { 0x000A, 0x0003, 0x0007 },
    { 0x000B, 0x011A, 0x0138 },
    { 0x0000, 0x0156, 0x0009 },
    { 0x0000, 0x0000, 0x0004 },
    { 0x0000, 0x0000, 0x0174 },
};

AnimationHeader gGyorgJumpingAnim = { 
    { 30 }, sGyorgJumpingAnimFrameData,
    sGyorgJumpingAnimJointIndices, 12
};

s16 sGyorgStunnedAnimFrameData[] = {
    0x0000, 0x0270, 0x00B0, 0x4000, 0x7F3A, 0x053D, 0x0328, 0xF39D, 0x0B7E, 0xFF9D, 0xC000, 0x3F9D, 0xEF9F, 0xEBF4, 
    0x0147, 0x0063, 0x10B4, 0x145F, 0xFEF4, 0xFEEC, 0xFEF4, 0xFEEC, 0xF577, 0xF1CD, 0xF577, 0xF1CD, 0x78F2, 0x790B, 
    0x78F2, 0x790B, 0xEEE3, 0xE584, 0xEEE3, 0xE584, 0xF52A, 0xEE3C, 0xF52A, 0xEE3C, 0x354B, 0x33C3, 0x354B, 0x33C3, 
    0x6E9B, 0x67B8, 0x6E9B, 0x67B8, 0xC77C, 0xC846, 0xC77C, 0xC846, 0xA6E7, 0xB1A3, 0xA6E7, 0xB1A3, 0x81B3, 0x8AE8, 
    0x81B3, 0x8AE8, 
};

JointIndex sGyorgStunnedAnimJointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0000, 0x0003, 0x0000 },
    { 0x0012, 0x0016, 0x001A },
    { 0x0000, 0x0000, 0x0004 },
    { 0x0000, 0x001E, 0x0005 },
    { 0x0000, 0x0022, 0x0006 },
    { 0x0000, 0x0007, 0x0008 },
    { 0x0009, 0x000A, 0x000B },
    { 0x000C, 0x0026, 0x002A },
    { 0x0000, 0x000D, 0x000E },
    { 0x000F, 0x0003, 0x000B },
    { 0x0010, 0x002E, 0x0032 },
    { 0x0000, 0x0011, 0x000E },
    { 0x0000, 0x0000, 0x0004 },
    { 0x0000, 0x0000, 0x0036 },
};

AnimationHeader gGyorgStunnedAnim = { 
    { 4 }, sGyorgStunnedAnimFrameData,
    sGyorgStunnedAnimJointIndices, 18
};

s16 sGyorgBackingUpAnimFrameData[] = {
    0x0000, 0x0270, 0x00B0, 0x4000, 0x7D84, 0x7F3A, 0xFE8F, 0xFE30, 0x032E, 0xC000, 0xEF9F, 0xEBF4, 0x0147, 0x10B4, 
    0x145F, 0x7A9C, 0xFBC3, 0xFBFB, 0xFC91, 0xFD69, 0xFE6A, 0xFF78, 0x0079, 0x0151, 0x01E7, 0x021E, 0x01F8, 0x0191, 
    0x00F5, 0x0035, 0xFF5F, 0xFE82, 0xFDAC, 0xFCEC, 0xFC51, 0xFBE9, 0x0452, 0x0320, 0x006B, 0xFD86, 0xFBC3, 0xFB4B, 
    0xFB58, 0xFBCC, 0xFC8B, 0xFD79, 0xFEDB, 0x00C1, 0x02C8, 0x048A, 0x05A1, 0x05F6, 0x05D7, 0x0571, 0x04EF, 0x0481, 
    0x054C, 0x04EE, 0x03F0, 0x0282, 0x00D0, 0xFF07, 0xFD54, 0xFBE6, 0xFAE9, 0xFA8A, 0xFACA, 0xFB7A, 0xFC81, 0xFDC6, 
    0xFF30, 0x00A6, 0x0210, 0x0355, 0x045C, 0x050C, 0xFF9D, 0xFF4C, 0xFE75, 0xFD3C, 0xFBCA, 0xFA45, 0xF8D2, 0xF79A, 
    0xF6C2, 0xF672, 0xF6A9, 0xF73F, 0xF81E, 0xF933, 0xFA68, 0xFBA7, 0xFCDC, 0xFDF0, 0xFED0, 0xFF66, 0x3F9D, 0x3F4C, 
    0x3E75, 0x3D3C, 0x3BCA, 0x3A45, 0x38D2, 0x379A, 0x36C2, 0x3672, 0x36A9, 0x373F, 0x381E, 0x3933, 0x3A68, 0x3BA7, 
    0x3CDC, 0x3DF0, 0x3ED0, 0x3F66, 0x198F, 0x1A1F, 0x1AD9, 0x1B88, 0x1C0A, 0x1C52, 0x1C66, 0x1C57, 0x1C3F, 0x1C34, 
    0x1C4C, 0x1C84, 0x1CBD, 0x1CD5, 0x1CB5, 0x1C54, 0x1BBA, 0x1B00, 0x1A4B, 0x19C3, 0x9203, 0x8F70, 0x8C87, 0x8967, 
    0x8639, 0x8330, 0x8082, 0x7E63, 0x7CFE, 0x7C7E, 0x7D00, 0x7E69, 0x808D, 0x833A, 0x8634, 0x893C, 0x8C12, 0x8E81, 
    0x9061, 0x9195, 0x09F6, 0x09A4, 0x08C8, 0x0788, 0x060E, 0x0480, 0x0305, 0x01C6, 0x00EA, 0x0097, 0x00CF, 0x0168, 
    0x024D, 0x0368, 0x04A4, 0x05EA, 0x0725, 0x0840, 0x0925, 0x09BE, 0x360A, 0x365C, 0x3738, 0x3878, 0x39F2, 0x3B80, 
    0x3CFB, 0x3E3A, 0x3F16, 0x3F69, 0x3F31, 0x3E98, 0x3DB3, 0x3C98, 0x3B5C, 0x3A16, 0x38DB, 0x37C0, 0x36DB, 0x3642, 
    0xE52C, 0xE4BF, 0xE3B8, 0xE28B, 0xE1A8, 0xE158, 0xE1A3, 0xE24C, 0xE2F6, 0xE340, 0xE30D, 0xE28F, 0xE1F9, 0xE181, 
    0xE159, 0xE19A, 0xE242, 0xE32D, 0xE423, 0xE4E1, 0x7617, 0x76F3, 0x7959, 0x7D12, 0x81C3, 0x86DB, 0x8BA6, 0x8F85, 
    0x920E, 0x92F8, 0x925A, 0x909D, 0x8DE7, 0x8A69, 0x8665, 0x8238, 0x7E46, 0x7AE4, 0x784F, 0x76AC, 
};

JointIndex sGyorgBackingUpAnimJointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0000, 0x0003, 0x0000 },
    { 0x0000, 0x0000, 0x0004 },
    { 0x0000, 0x0000, 0x0005 },
    { 0x0000, 0x0010, 0x0006 },
    { 0x0000, 0x0024, 0x0007 },
    { 0x0000, 0x0038, 0x0008 },
    { 0x004C, 0x0009, 0x0060 },
    { 0x000A, 0x0074, 0x0088 },
    { 0x0000, 0x000B, 0x000C },
    { 0x009C, 0x0003, 0x00B0 },
    { 0x000D, 0x00C4, 0x00D8 },
    { 0x0000, 0x000E, 0x000C },
    { 0x0000, 0x0000, 0x0005 },
    { 0x0000, 0x0000, 0x000F },
};

AnimationHeader gGyorgBackingUpAnim = { 
    { 20 }, sGyorgBackingUpAnimFrameData,
    sGyorgBackingUpAnimJointIndices, 16
};

u8 object_boss03_possiblePadding_009C24[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 sGyorgFastSwimmingAnimFrameData[] = {
    0x0000, 0x0270, 0x00B0, 0x4000, 0xFFDC, 0x7D45, 0x7F3A, 0x0098, 0x0134, 0x0381, 0xFF9D, 0xC000, 0x3F9D, 0xF5F5, 
    0x06B7, 0x85B0, 0x0147, 0x0063, 0x0FAD, 0xFA50, 0x84A2, 0x03D4, 0x787D, 0xF781, 0xFA6F, 0x00E0, 0x0751, 0x0A3F, 
    0x08DC, 0x0563, 0x00E0, 0xFC5D, 0xF8E5, 0x0166, 0xFCC4, 0xF6CE, 0xF564, 0xF6CE, 0xFBAA, 0x01DC, 0x05E2, 0x0581, 
    0x02F4, 0x05D5, 0xF8F9, 0xEB1B, 0xF1FA, 0xFDC4, 0x063F, 0x0E0F, 0x1238, 0x0F9B, 0x0958, 0x0000, 
};

JointIndex sGyorgFastSwimmingAnimJointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0000, 0x0003, 0x0000 },
    { 0x0000, 0x0004, 0x0005 },
    { 0x0000, 0x0000, 0x0006 },
    { 0x0000, 0x0017, 0x0007 },
    { 0x0000, 0x0021, 0x0008 },
    { 0x0000, 0x002B, 0x0009 },
    { 0x000A, 0x000B, 0x000C },
    { 0x000D, 0x000E, 0x000F },
    { 0x0000, 0x0009, 0x0010 },
    { 0x0011, 0x0003, 0x000C },
    { 0x0012, 0x0013, 0x0014 },
    { 0x0000, 0x0015, 0x0010 },
    { 0x0000, 0x0000, 0x0006 },
    { 0x0000, 0x0000, 0x0016 },
};

AnimationHeader gGyorgFastSwimmingAnim = { 
    { 10 }, sGyorgFastSwimmingAnimFrameData,
    sGyorgFastSwimmingAnimJointIndices, 23
};

u8 object_boss03_possiblePadding_009D08[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 sGyorgGentleSwimmingAnimFrameData[] = {
    0x0000, 0x0270, 0x00B0, 0x4000, 0xFFDC, 0x7D45, 0x7F3A, 0x0098, 0x0134, 0x0381, 0xFF9D, 0xC000, 0x3F9D, 0x0147, 
    0x0063, 0x787D, 0xFC4B, 0xFC64, 0xFCA9, 0xFD13, 0xFD9A, 0xFE38, 0xFEE4, 0xFF98, 0x004C, 0x00F8, 0x0196, 0x021E, 
    0x0287, 0x02CC, 0x02E5, 0x02D2, 0x029C, 0x0249, 0x01DD, 0x015D, 0x00CE, 0x0036, 0xFF98, 0xFEFB, 0xFE62, 0xFDD3, 
    0xFD53, 0xFCE7, 0xFC94, 0xFC5E, 0xFFEF, 0xFFB3, 0xFF1F, 0xFE5D, 0xFD9A, 0xFD02, 0xFCC1, 0xFCCA, 0xFCEF, 0xFD2D, 
    0xFD83, 0xFDEE, 0xFE6D, 0xFEFD, 0xFF9B, 0x0075, 0x019E, 0x02EB, 0x0437, 0x0557, 0x0623, 0x0674, 0x063F, 0x05A7, 
    0x04CA, 0x03C2, 0x02AC, 0x01A3, 0x00C3, 0x0029, 0xFFB9, 0xFF6E, 0xFEA9, 0xFD8C, 0xFC3F, 0xFAE4, 0xF9A3, 0xF89F, 
    0xF7FF, 0xF7E6, 0xF83B, 0xF8C6, 0xF97E, 0xFA5D, 0xFB59, 0xFC6C, 0xFD8D, 0xFEB5, 0xFFDB, 0x00F8, 0x0205, 0x02F8, 
    0x03CB, 0x0476, 0x04F0, 0x04CF, 0x03EA, 0x029C, 0x013D, 0x0029, 0x2305, 0x2311, 0x2335, 0x236B, 0x23B1, 0x2402, 
    0x245A, 0x24B7, 0x2513, 0x256C, 0x25BD, 0x2603, 0x2639, 0x265C, 0x2669, 0x265F, 0x2644, 0x2619, 0x25E1, 0x25A0, 
    0x2556, 0x2508, 0x24B7, 0x2466, 0x2417, 0x23CE, 0x238C, 0x2355, 0x232A, 0x230E, 0x06B7, 0x06DA, 0x073B, 0x07D1, 
    0x0891, 0x096F, 0x0A63, 0x0B61, 0x0C5F, 0x0D53, 0x0E32, 0x0EF1, 0x0F87, 0x0FE8, 0x100B, 0x0FF0, 0x0FA5, 0x0F2F, 
    0x0E96, 0x0DE1, 0x0D18, 0x0C40, 0x0B61, 0x0A83, 0x09AB, 0x08E1, 0x082C, 0x0794, 0x071E, 0x06D2, 0x85B0, 0x85DD, 
    0x865C, 0x871F, 0x8818, 0x893A, 0x8A77, 0x8BC2, 0x8D0C, 0x8E49, 0x8F6B, 0x9065, 0x9127, 0x91A6, 0x91D3, 0x91B1, 
    0x914E, 0x90B5, 0x8FEE, 0x8F03, 0x8DFC, 0x8CE3, 0x8BC2, 0x8AA0, 0x8987, 0x8881, 0x8795, 0x86CF, 0x8635, 0x85D3, 
    0x0381, 0x0120, 0xFB36, 0xF39C, 0xEC2A, 0xE6B7, 0xE51C, 0xE679, 0xE8A2, 0xEB78, 0xEEDC, 0xF2B1, 0xF6D8, 0xFB32, 
    0xFFA1, 0x0406, 0x0844, 0x0C3C, 0x0FCE, 0x12DE, 0x154C, 0x16FB, 0x1750, 0x160E, 0x139E, 0x106C, 0x0CE0, 0x0966, 
    0x0666, 0x044C, 0xD9BC, 0xD9AA, 0xD979, 0xD92E, 0xD8CE, 0xD85F, 0xD7E5, 0xD766, 0xD6E6, 0xD66C, 0xD5FD, 0xD59D, 
    0xD552, 0xD521, 0xD510, 0xD51D, 0xD543, 0xD57E, 0xD5CB, 0xD625, 0xD68A, 0xD6F6, 0xD766, 0xD7D5, 0xD841, 0xD8A6, 
    0xD901, 0xD94D, 0xD988, 0xD9AE, 0xFA50, 0xFA28, 0xF9B7, 0xF90A, 0xF82D, 0xF72B, 0xF611, 0xF4EC, 0xF3C6, 0xF2AC, 
    0xF1AA, 0xF0CD, 0xF020, 0xEFAF, 0xEF87, 0xEFA6, 0xEFFE, 0xF086, 0xF136, 0xF207, 0xF2F1, 0xF3EA, 0xF4EC, 0xF5ED, 
    0xF6E7, 0xF7D0, 0xF8A1, 0xF951, 0xF9DA, 0xFA31, 0x84A2, 0x84E1, 0x8593, 0x86A4, 0x8801, 0x8997, 0x8B53, 0x8D22, 
    0x8EF2, 0x90AE, 0x9244, 0x93A1, 0x94B2, 0x9564, 0x95A3, 0x9572, 0x94E8, 0x9412, 0x92FB, 0x91B2, 0x9042, 0x8EB9, 
    0x8D22, 0x8B8C, 0x8A03, 0x8893, 0x874A, 0x8633, 0x855D, 0x84D3, 0xFDF6, 0xFFAF, 0x03F4, 0x0972, 0x0ED5, 0x12C8, 
    0x13F7, 0x1302, 0x117B, 0x0F79, 0x0D10, 0x0A57, 0x0763, 0x044A, 0x0121, 0xFDFF, 0xFAF8, 0xF823, 0xF595, 0xF364, 
    0xF1A6, 0xF070, 0xF02D, 0xF109, 0xF2B8, 0xF4F2, 0xF76B, 0xF9D8, 0xFBF0, 0xFD69, 
};

JointIndex sGyorgGentleSwimmingAnimJointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0000, 0x0003, 0x0000 },
    { 0x0000, 0x0004, 0x0005 },
    { 0x0000, 0x0000, 0x0006 },
    { 0x0000, 0x0010, 0x0007 },
    { 0x0000, 0x002E, 0x0008 },
    { 0x0000, 0x004C, 0x0009 },
    { 0x000A, 0x000B, 0x000C },
    { 0x006A, 0x0088, 0x00A6 },
    { 0x0000, 0x00C4, 0x000D },
    { 0x000E, 0x0003, 0x000C },
    { 0x00E2, 0x0100, 0x011E },
    { 0x0000, 0x013C, 0x000D },
    { 0x0000, 0x0000, 0x0006 },
    { 0x0000, 0x0000, 0x000F },
};

AnimationHeader gGyorgGentleSwimmingAnim = { 
    { 30 }, sGyorgGentleSwimmingAnimFrameData,
    sGyorgGentleSwimmingAnimJointIndices, 16
};

s16 sGyorgTailSweepAnimFrameData[] = {
    0x0000, 0x0270, 0x00B0, 0x4000, 0xFFDC, 0x7D45, 0x7F3A, 0x0098, 0x0134, 0x0381, 0xFF9D, 0xC000, 0x3F9D, 0xF5F5, 
    0x06B7, 0x85B0, 0x0147, 0x0063, 0x0FAD, 0xFA50, 0x84A2, 0x03D4, 0x787D, 0xFFE6, 0xFE78, 0xFAA5, 0xF51A, 0xEE89, 
    0xE79F, 0xE10E, 0xDB83, 0xD7B0, 0xD642, 0xD73A, 0xD9E3, 0xDDDC, 0xE2C6, 0xE83F, 0xEDE9, 0xF362, 0xF84C, 0xFC45, 
    0xFEEE, 0x0004, 0xFEAC, 0xFB14, 0xF5E0, 0xEFB4, 0xE936, 0xE30B, 0xDDD6, 0xDA3E, 0xD8E7, 0xD9D0, 0xDC4F, 0xE00B, 
    0xE4A8, 0xE9CC, 0xEF1E, 0xF443, 0xF8E0, 0xFC9B, 0xFF1B, 0x0021, 0xFEDD, 0xFB78, 0xF68F, 0xF0BC, 0xEA9C, 0xE4C9, 
    0xDFE0, 0xDC7B, 0xDB37, 0xDC13, 0xDE6F, 0xE1F4, 0xE64F, 0xEB29, 0xF02F, 0xF509, 0xF964, 0xFCE9, 0xFF45, 0x0000, 
    
};

JointIndex sGyorgTailSweepAnimJointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0000, 0x0003, 0x0000 },
    { 0x0000, 0x0004, 0x0005 },
    { 0x0000, 0x0000, 0x0006 },
    { 0x0000, 0x0017, 0x0007 },
    { 0x0000, 0x002B, 0x0008 },
    { 0x0000, 0x003F, 0x0009 },
    { 0x000A, 0x000B, 0x000C },
    { 0x000D, 0x000E, 0x000F },
    { 0x0000, 0x0009, 0x0010 },
    { 0x0011, 0x0003, 0x000C },
    { 0x0012, 0x0013, 0x0014 },
    { 0x0000, 0x0015, 0x0010 },
    { 0x0000, 0x0000, 0x0006 },
    { 0x0000, 0x0000, 0x0016 },
};

AnimationHeader gGyorgTailSweepAnim = { 
    { 20 }, sGyorgTailSweepAnimFrameData,
    sGyorgTailSweepAnimJointIndices, 23
};

u8 object_boss03_possiblePadding_00A144[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 sGyorgCrawlingAnimFrameData[] = {
    0x0000, 0x01A7, 0x00B0, 0x4000, 0x743A, 0x7F3A, 0xFF9D, 0xC000, 0x3F9D, 0xEF9F, 0x0147, 0x0063, 0x10B4, 0x01A7, 
    0x01B0, 0x01C9, 0x01ED, 0x0218, 0x0245, 0x0270, 0x0295, 0x02AE, 0x02B7, 0x02AF, 0x029B, 0x027C, 0x0257, 0x022F, 
    0x0206, 0x01E1, 0x01C3, 0x01AE, 0x01A7, 0x01AE, 0x01C3, 0x01E1, 0x0206, 0x022F, 0x0257, 0x027C, 0x029B, 0x02AF, 
    0x02B7, 0x02B1, 0x029F, 0x0285, 0x0265, 0x0241, 0x021C, 0x01F8, 0x01D8, 0x01BE, 0x01AD, 0x0000, 0xFFB7, 0xFEF3, 
    0xFDD8, 0xFC89, 0xFB28, 0xF9D8, 0xF8BD, 0xF7F9, 0xF7B0, 0xF7DB, 0xF853, 0xF909, 0xF9EE, 0xFAF4, 0xFC0C, 0xFD28, 
    0xFE39, 0xFF31, 0x0000, 0x00BE, 0x0188, 0x0255, 0x031F, 0x03DE, 0x048A, 0x051D, 0x058F, 0x05D9, 0x05F3, 0x05CF, 
    0x056E, 0x04DD, 0x0429, 0x0361, 0x0292, 0x01CA, 0x0116, 0x0085, 0x0023, 0x0000, 0xFF59, 0xFD98, 0xFB0E, 0xF80C, 
    0xF4E2, 0xF1E0, 0xEF57, 0xED96, 0xECEF, 0xED4D, 0xEE53, 0xEFE3, 0xF1DE, 0xF427, 0xF6A0, 0xF92A, 0xFBA6, 0xFDF8, 
    0x0000, 0x0200, 0x043B, 0x0697, 0x08F9, 0x0B47, 0x0D65, 0x0F38, 0x10A8, 0x1197, 0x11ED, 0x1182, 0x105D, 0x0EA7, 
    0x0C8A, 0x0A2F, 0x07BF, 0x0563, 0x0346, 0x0190, 0x006B, 0x0708, 0x0678, 0x04F7, 0x02C9, 0x0034, 0xFD7C, 0xFAE6, 
    0xF8B8, 0xF737, 0xF6A7, 0xF71D, 0xF85B, 0xFA31, 0xFC6B, 0xFED8, 0x0144, 0x037F, 0x0554, 0x0693, 0x0708, 0x0693, 
    0x0554, 0x037F, 0x0144, 0xFED8, 0xFC6B, 0xFA31, 0xF85B, 0xF71D, 0xF6A7, 0xF709, 0xF815, 0xF9A5, 0xFB93, 0xFDBB, 
    0xFFF5, 0x021C, 0x040B, 0x059B, 0x06A7, 0xF3DC, 0xF426, 0xF4F1, 0xF625, 0xF7A4, 0xF956, 0xFB20, 0xFCE7, 0xFE8F, 
    0x0000, 0x0166, 0x02F4, 0x0499, 0x0641, 0x07DA, 0x0953, 0x0A97, 0x0B96, 0x0C3C, 0x0C78, 0x0C39, 0x0B8C, 0x0A83, 
    0x0934, 0x07B3, 0x0613, 0x046A, 0x02CC, 0x014C, 0x0000, 0xFEC0, 0xFD5F, 0xFBEC, 0xFA74, 0xF903, 0xF7A7, 0xF66C, 
    0xF561, 0xF491, 0xF40B, 0xFE98, 0xFEE1, 0xFFA5, 0x00C0, 0x020F, 0x0370, 0x04C0, 0x05DB, 0x069F, 0x06E8, 0x06AC, 
    0x060B, 0x051E, 0x03FE, 0x02C4, 0x0189, 0x0068, 0xFF79, 0xFED6, 0xFE98, 0xFECF, 0xFF6B, 0x0051, 0x016A, 0x029D, 
    0x03CF, 0x04E9, 0x05D1, 0x066F, 0x06A9, 0x0679, 0x05F5, 0x0530, 0x043D, 0x032D, 0x0214, 0x0105, 0x0011, 0xFF4C, 
    0xFEC8, 0xFEE7, 0xFEF0, 0xFF0A, 0xFF30, 0xFF60, 0xFF97, 0xFFD2, 0x000D, 0x0045, 0x0077, 0x00AC, 0x00EB, 0x0131, 
    0x0178, 0x01BD, 0x01FB, 0x022C, 0x024E, 0x025B, 0x024F, 0x0221, 0x01D2, 0x016A, 0x00F0, 0x006D, 0xFFE8, 0xFF6A, 
    0xFEFA, 0xFEA1, 0xFE65, 0xFE46, 0xFE39, 0xFE3B, 0xFE49, 0xFE60, 0xFE7C, 0xFE9A, 0xFEB7, 0xFECF, 0xFEE1, 0x2416, 
    0x22ED, 0x1FC1, 0x1B06, 0x1531, 0x0EB8, 0x080F, 0x01AC, 0xFC03, 0xF78A, 0xF3AC, 0xEFA4, 0xEB9B, 0xE7BD, 0xE434, 
    0xE129, 0xDEC6, 0xDD37, 0xDCA4, 0xDD39, 0xDF52, 0xE2F6, 0xE7CF, 0xED8A, 0xF3D1, 0xFA50, 0x00B1, 0x069F, 0x0BC6, 
    0x0FD0, 0x1313, 0x1619, 0x18DE, 0x1B5F, 0x1D97, 0x1F83, 0x211E, 0x2265, 0x2353, 0x23E5, 0x0957, 0x0955, 0x094F, 
    0x0944, 0x0934, 0x091E, 0x0902, 0x08DF, 0x08B4, 0x0882, 0x0842, 0x07F0, 0x0792, 0x072D, 0x06C6, 0x0662, 0x0606, 
    0x05B7, 0x0579, 0x0553, 0x0542, 0x0543, 0x0551, 0x056C, 0x0590, 0x05BC, 0x05ED, 0x0621, 0x0655, 0x0688, 0x06C1, 
    0x0708, 0x0759, 0x07AF, 0x0807, 0x085D, 0x08AC, 0x08F1, 0x0927, 0x094A, 0x062D, 0x060A, 0x05A2, 0x04EA, 0x03D3, 
    0x026F, 0x0118, 0x004C, 0x0057, 0x0150, 0x0356, 0x062D, 0x0971, 0x0CCF, 0x0FFE, 0x12D0, 0x1528, 0x16FB, 0x1844, 
    0x1903, 0x19DE, 0x1B49, 0x1CEF, 0x1E82, 0x1FC9, 0x20A2, 0x2105, 0x20F7, 0x2080, 0x1F9F, 0x1E64, 0x1CDD, 0x1AF8, 
    0x18A3, 0x15D7, 0x12A3, 0x0F32, 0x0BD3, 0x08ED, 0x06EB, 0x66ED, 0x67D0, 0x6A78, 0x6F21, 0x7610, 0x7F08, 0x88BF, 
    0x915C, 0x97BF, 0x9BB4, 0x9E38, 0xA037, 0xA1AD, 0xA293, 0xA2E8, 0xA2B2, 0xA1FC, 0xA0D9, 0x9F59, 0x9D8F, 0x9B3E, 
    0x982C, 0x946A, 0x901F, 0x8B83, 0x86DB, 0x8264, 0x7E4D, 0x7AAB, 0x7783, 0x74C1, 0x7240, 0x6FF2, 0x6DD8, 0x6BF8, 
    0x6A5E, 0x6911, 0x6817, 0x676C, 0x670C, 0xE22D, 0xE483, 0xEAC6, 0xF3D6, 0xFE95, 0x09E4, 0x14A3, 0x1DB4, 0x23F6, 
    0x264D, 0x2497, 0x1FEB, 0x18F8, 0x106E, 0x06FC, 0xFD52, 0xF41F, 0xEC13, 0xE5DD, 0xE22D, 0xE02F, 0xDE94, 0xDD55, 
    0xDC6A, 0xDBCC, 0xDB73, 0xDB57, 0xDB70, 0xDBB8, 0xDC25, 0xDCB2, 0xDD55, 0xDE08, 0xDEC2, 0xDF7C, 0xE02F, 0xE0D2, 
    0xE15E, 0xE1CC, 0xE213, 0xE5A4, 0xE52B, 0xE3F3, 0xE260, 0xE0E0, 0xDFCF, 0xDF5C, 0xDF7C, 0xE002, 0xE0BE, 0xE1B5, 
    0xE30A, 0xE4C7, 0xE6F5, 0xE98E, 0xEC79, 0xEF82, 0xF268, 0xF4E1, 0xF6A6, 0xF80E, 0xF9AC, 0xFB96, 0xFDE2, 0x009D, 
    0x03B3, 0x06C3, 0x0919, 0x0A03, 0x0938, 0x066E, 0x01CB, 0xFC29, 0xF680, 0xF184, 0xED83, 0xEA7B, 0xE84B, 0xE6D0, 
    0xE5F1, 0xA2B9, 0xA1E1, 0x9F76, 0x9B93, 0x966A, 0x905D, 0x89FD, 0x83D2, 0x7E28, 0x7907, 0x7448, 0x6FC8, 0x6B7F, 
    0x6779, 0x63CB, 0x608F, 0x5DD9, 0x5BB0, 0x5A14, 0x58FC, 0x58A5, 0x5944, 0x5AE4, 0x5DAD, 0x61DF, 0x67B7, 0x6F2F, 
    0x77A7, 0x7FD8, 0x8674, 0x8BF3, 0x9135, 0x95E9, 0x99D9, 0x9CEF, 0x9F35, 0xA0C5, 0xA1C5, 0xA25A, 0xA2A4, 0x192E, 
    0x1949, 0x1994, 0x1A05, 0x1A93, 0x1B36, 0x1BE4, 0x1C94, 0x1D3C, 0x1DD4, 0x1E53, 0x1EAE, 0x1EDE, 0x1ED9, 0x1E95, 
    0x1E0B, 0x1D2F, 0x1BFA, 0x1A62, 0x185D, 0x14C0, 0x0ED1, 0x0732, 0xFE87, 0xF574, 0xEC9A, 0xE49E, 0xDE23, 0xD9CC, 
    0xD83C, 0xD9C7, 0xDDF2, 0xE427, 0xEBD1, 0xF459, 0xFD2C, 0x05B3, 0x0D58, 0x1388, 0x17AC, 0x7CE4, 0x7D37, 0x7E15, 
    0x7F57, 0x80D5, 0x8266, 0x83E4, 0x8526, 0x8605, 0x8658, 0x8614, 0x855C, 0x844D, 0x8304, 0x819E, 0x8038, 0x7EEE, 
    0x7DDF, 0x7D27, 0x7CE4, 0x7D27, 0x7DDF, 0x7EEE, 0x8038, 0x819E, 0x8304, 0x844D, 0x855C, 0x8614, 0x8658, 0x861F, 
    0x8585, 0x849E, 0x8380, 0x8242, 0x80F9, 0x7FBB, 0x7E9E, 0x7DB7, 0x7D1C, 0x0000, 
};

JointIndex sGyorgCrawlingAnimJointIndices[] = {
    { 0x0000, 0x000D, 0x0002 },
    { 0x0000, 0x0003, 0x0000 },
    { 0x0035, 0x0000, 0x0004 },
    { 0x0000, 0x0000, 0x0005 },
    { 0x005D, 0x0000, 0x0085 },
    { 0x0000, 0x00AD, 0x00D5 },
    { 0x00FD, 0x0125, 0x014D },
    { 0x0006, 0x0007, 0x0008 },
    { 0x0009, 0x0175, 0x019D },
    { 0x0000, 0x01C5, 0x000A },
    { 0x000B, 0x0003, 0x0008 },
    { 0x000C, 0x01ED, 0x0215 },
    { 0x0000, 0x023D, 0x000A },
    { 0x0000, 0x0000, 0x0005 },
    { 0x0000, 0x0000, 0x0265 },
};

AnimationHeader gGyorgCrawlingAnim = { 
    { 40 }, sGyorgCrawlingAnimFrameData,
    sGyorgCrawlingAnimJointIndices, 13
};

u8 object_boss03_possiblePadding_00A6D8[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx object_boss03Vtx_00A6E0[] = {
#include "assets/objects/object_boss03/object_boss03Vtx_00A6E0.vtx.inc"
};

Gfx gGyorgSeaweedPiece1DL[] = {
    gsSPMatrix(0x0D000100, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPVertex(object_boss03Vtx_00A6E0, 2, 0),
    gsSPMatrix(0x0D000140, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPLoadTLUT_pal16(15, gGyorgSeaweedTopTLUT),
    gsDPLoadTextureBlock_4b(gGyorgSeaweedTopTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss03Vtx_00A6E0[2], 3, 2),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgSeaweedPiece2DL[] = {
    gsSPMatrix(0x0D0000C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPVertex(&object_boss03Vtx_00A6E0[5], 2, 0),
    gsSPMatrix(0x0D000100, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPVertex(&object_boss03Vtx_00A6E0[7], 3, 2),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgSeaweedPiece3DL[] = {
    gsSPMatrix(0x0D000080, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPVertex(&object_boss03Vtx_00A6E0[10], 2, 0),
    gsSPMatrix(0x0D0000C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPVertex(&object_boss03Vtx_00A6E0[12], 3, 2),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgSeaweedPiece4DL[] = {
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPVertex(&object_boss03Vtx_00A6E0[15], 2, 0),
    gsSPMatrix(0x0D000080, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPVertex(&object_boss03Vtx_00A6E0[17], 3, 2),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgSeaweedPiece5DL[] = {
    gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPVertex(&object_boss03Vtx_00A6E0[20], 2, 0),
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPVertex(&object_boss03Vtx_00A6E0[22], 3, 2),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgSeaweedTopDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgSeaweedTLUT),
    gsDPLoadTextureBlock_4b(gGyorgSeaweedTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_00A6E0[25], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

u64 gGyorgSeaweedTopTLUT[] = {
#include "assets/objects/object_boss03/gyorg_seaweed_top_tlut.rgba16.inc.c"
};

u64 gGyorgSeaweedTLUT[] = {
#include "assets/objects/object_boss03/gyord_seaweed_tlut.rgba16.inc.c"
};

u64 gGyorgSeaweedTopTex[] = {
#include "assets/objects/object_boss03/gyorg_seaweed_top.ci4.inc.c"
};

u64 gGyorgSeaweedTex[] = {
#include "assets/objects/object_boss03/gyorg_seaweed.ci4.inc.c"
};

AnimatedMaterial gGyorgUnusedBB00TexAnim[] = {
    { 0, 6, NULL },
};

u8 object_boss03_possiblePadding_00BB08[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx object_boss03Vtx_00BB10[] = {
#include "assets/objects/object_boss03/object_boss03Vtx_00BB10.vtx.inc"
};

Gfx gUnusedGyorgSmallFishHeadDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gUnusedGyorgSmallFishTLUT),
    gsDPLoadTextureBlock_4b(gUnusedGyorgSmallFishTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_boss03Vtx_00BB10, 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(4, 6, 5, 0, 7, 8, 9, 0),
    gsSPEndDisplayList(),
};

Gfx gUnusedGyorgSmallFishTrunkDL[] = {
    gsSPMatrix(0x0D000140, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_00BB10[16], 7, 0),
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gUnusedGyorgSmallFishTLUT),
    gsDPLoadTextureBlock_4b(gUnusedGyorgSmallFishTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_boss03Vtx_00BB10[23], 4, 7),
    gsSP2Triangles(6, 2, 7, 0, 4, 0, 8, 0),
    gsSP2Triangles(3, 5, 9, 0, 1, 6, 10, 0),
    gsSPEndDisplayList(),
};

Gfx gUnusedGyorgSmallFishRightFinDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gUnusedGyorgSmallFishTLUT),
    gsDPLoadTextureBlock_4b(gUnusedGyorgSmallFishTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 178, 178, 178, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_00BB10[36], 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPEndDisplayList(),
};

Gfx gUnusedGyorgSmallFishDorsalFinDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gUnusedGyorgSmallFishTLUT),
    gsDPLoadTextureBlock_4b(gUnusedGyorgSmallFishTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 178, 178, 178, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_00BB10[27], 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_boss03Vtx_00BB10[30], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPEndDisplayList(),
};

Gfx gUnusedGyorgSmallFishLeftFinDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gUnusedGyorgSmallFishTLUT),
    gsDPLoadTextureBlock_4b(gUnusedGyorgSmallFishTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 178, 178, 178, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_00BB10[33], 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPEndDisplayList(),
};

Gfx gUnusedGyorgSmallFishTailFinDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gUnusedGyorgSmallFishTLUT),
    gsDPLoadTextureBlock_4b(gUnusedGyorgSmallFishTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 178, 178, 178, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_00BB10[10], 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_boss03Vtx_00BB10[13], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPEndDisplayList(),
};

u64 gUnusedGyorgSmallFishTLUT[] = {
#include "assets/objects/object_boss03/unused_small_fish_tlut.rgba16.inc.c"
};

u64 gUnusedGyorgSmallFishTex[] = {
#include "assets/objects/object_boss03/unused_small_fish.ci4.inc.c"
};

Vtx object_boss03Vtx_00CA50[] = {
#include "assets/objects/object_boss03/object_boss03Vtx_00CA50.vtx.inc"
};

Gfx gGyorgSmallFishHeadDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgSmallFishTLUT),
    gsDPLoadTextureBlock_4b(gGyorgSmallFishTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_boss03Vtx_00CA50, 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(4, 6, 5, 0, 7, 8, 9, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgSmallFishTrunkDL[] = {
    gsSPMatrix(0x0D000140, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_00CA50[16], 7, 0),
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgSmallFishTLUT),
    gsDPLoadTextureBlock_4b(gGyorgSmallFishTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_boss03Vtx_00CA50[23], 4, 7),
    gsSP2Triangles(6, 2, 7, 0, 4, 0, 8, 0),
    gsSP2Triangles(3, 5, 9, 0, 1, 6, 10, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgSmallFishRightFinDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgSmallFishTLUT),
    gsDPLoadTextureBlock_4b(gGyorgSmallFishTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 178, 178, 178, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_00CA50[36], 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgSmallFishDorsalFinDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgSmallFishTLUT),
    gsDPLoadTextureBlock_4b(gGyorgSmallFishTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 178, 178, 178, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_00CA50[27], 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_boss03Vtx_00CA50[30], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgSmallFishLeftFinDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgSmallFishTLUT),
    gsDPLoadTextureBlock_4b(gGyorgSmallFishTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 178, 178, 178, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_00CA50[33], 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPEndDisplayList(),
};

Gfx gGyorgSmallFishTailFinDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gGyorgSmallFishTLUT),
    gsDPLoadTextureBlock_4b(gGyorgSmallFishTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 178, 178, 178, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss03Vtx_00CA50[10], 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_boss03Vtx_00CA50[13], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPEndDisplayList(),
};

u64 gGyorgSmallFishTLUT[] = {
#include "assets/objects/object_boss03/small_fish_tlut.rgba16.inc.c"
};

u64 gGyorgSmallFishTex[] = {
#include "assets/objects/object_boss03/small_fish.ci4.inc.c"
};

StandardLimb gGyorgSmallFishRootLimb = { 
    { 0, -9, 313 }, GYORG_SMALL_FISH_LIMB_BODY_ROOT - 1, LIMB_DONE,
    NULL
};

StandardLimb gGyorgSmallFishBodyRootLimb = { 
    { 158, 0, 0 }, GYORG_SMALL_FISH_LIMB_TRUNK_ROOT - 1, GYORG_SMALL_FISH_LIMB_HEAD - 1,
    NULL
};

StandardLimb gGyorgSmallFishTrunkRootLimb = { 
    { 0, 0, 0 }, GYORG_SMALL_FISH_LIMB_TAIL_FIN - 1, LIMB_DONE,
    NULL
};

StandardLimb gGyorgSmallFishTailFinLimb = { 
    { 951, 0, 0 }, LIMB_DONE, GYORG_SMALL_FISH_LIMB_TRUNK - 1,
    gGyorgSmallFishTailFinDL
};

StandardLimb gGyorgSmallFishTrunkLimb = { 
    { 0, 0, 0 }, GYORG_SMALL_FISH_LIMB_LEFT_FIN - 1, LIMB_DONE,
    gGyorgSmallFishTrunkDL
};

StandardLimb gGyorgSmallFishLeftFinLimb = { 
    { 0, 0, 0 }, LIMB_DONE, GYORG_SMALL_FISH_LIMB_DORSAL_FIN - 1,
    gGyorgSmallFishLeftFinDL
};

StandardLimb gGyorgSmallFishDorsalFinLimb = { 
    { 0, 0, 0 }, LIMB_DONE, GYORG_SMALL_FISH_LIMB_RIGHT_FIN - 1,
    gGyorgSmallFishDorsalFinDL
};

StandardLimb gGyorgSmallFishRightFinLimb = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gGyorgSmallFishRightFinDL
};

StandardLimb gGyorgSmallFishHeadLimb = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gGyorgSmallFishHeadDL
};

void* gGyorgSmallFishSkelLimbs[] = {
    &gGyorgSmallFishRootLimb, /* GYORG_SMALL_FISH_LIMB_ROOT */
    &gGyorgSmallFishBodyRootLimb, /* GYORG_SMALL_FISH_LIMB_BODY_ROOT */
    &gGyorgSmallFishTrunkRootLimb, /* GYORG_SMALL_FISH_LIMB_TRUNK_ROOT */
    &gGyorgSmallFishTailFinLimb, /* GYORG_SMALL_FISH_LIMB_TAIL_FIN */
    &gGyorgSmallFishTrunkLimb, /* GYORG_SMALL_FISH_LIMB_TRUNK */
    &gGyorgSmallFishLeftFinLimb, /* GYORG_SMALL_FISH_LIMB_LEFT_FIN */
    &gGyorgSmallFishDorsalFinLimb, /* GYORG_SMALL_FISH_LIMB_DORSAL_FIN */
    &gGyorgSmallFishRightFinLimb, /* GYORG_SMALL_FISH_LIMB_RIGHT_FIN */
    &gGyorgSmallFishHeadLimb, /* GYORG_SMALL_FISH_LIMB_HEAD */
};

FlexSkeletonHeader gGyorgSmallFishSkel = { 
    { gGyorgSmallFishSkelLimbs, ARRAY_COUNT(gGyorgSmallFishSkelLimbs) }, 6
};

u8 object_boss03_possiblePadding_00DA2C[] = {
    0x00, 0x00, 0x00, 0x00, 
};

s16 sGyorgSmallFishSwimAnimFrameData[] = {
    0x0000, 0xFFF7, 0x0139, 0x4000, 0xFFB8, 0xFFD3, 0x8000, 0x041D, 0x0356, 0x017A, 0xFF42, 0xFD66, 0xFC9E, 0xFD09, 
    0xFE1B, 0xFF92, 0x012A, 0x02A1, 0x03B3, 0x0000, 0x04F3, 0x0989, 0x0808, 0x0558, 0x020C, 0xFEB6, 0xFBE9, 0xFA37, 
    0xFA95, 0xFCA1, 0xFEEB, 0x0000, 
};

JointIndex sGyorgSmallFishSwimAnimJointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0000, 0x0003, 0x0000 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0007, 0x0004 },
    { 0x0000, 0x0013, 0x0005 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x0006 },
};

AnimationHeader gGyorgSmallFishSwimAnim = { 
    { 12 }, sGyorgSmallFishSwimAnimFrameData,
    sGyorgSmallFishSwimAnimJointIndices, 7
};

