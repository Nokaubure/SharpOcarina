#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_bsmask.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

Vtx object_bsmaskVtx_000000[] = {
#include "assets/objects/object_bsmask/object_bsmaskVtx_000000.vtx.inc"
};

Gfx gRemainsOdolwaDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gRemainsOdolwaPlumeTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 178, 178, 178, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_bsmaskVtx_000000, 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_bsmaskVtx_000000[4], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSPVertex(&object_bsmaskVtx_000000[8], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSPVertex(&object_bsmaskVtx_000000[12], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(4, 5, 6, 0, 6, 7, 4, 0),
    gsSPVertex(&object_bsmaskVtx_000000[20], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(4, 5, 6, 0, 6, 7, 4, 0),
    gsSPVertex(&object_bsmaskVtx_000000[28], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(4, 5, 6, 0, 6, 7, 4, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gRemainsOdolwaFaceTLUT),
    gsDPLoadTextureBlock_4b(gRemainsOdolwaFaceTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bsmaskVtx_000000[36], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 2, 7, 0, 8, 1, 9, 0),
    gsSP2Triangles(10, 9, 0, 0, 11, 2, 1, 0),
    gsSP2Triangles(8, 12, 1, 0, 6, 5, 2, 0),
    gsSP2Triangles(13, 0, 5, 0, 13, 5, 4, 0),
    gsSP2Triangles(1, 12, 11, 0, 1, 0, 9, 0),
    gsSP2Triangles(2, 5, 0, 0, 0, 13, 10, 0),
    gsSP2Triangles(5, 6, 3, 0, 2, 11, 7, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gRemainsOdolwaEarTLUT),
    gsDPLoadTextureBlock_4b(gRemainsOdolwaEarTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_000000[50], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gRemainsOdolwaFaceTLUT),
    gsDPLoadTextureBlock_4b(gRemainsOdolwaFaceTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_000000[56], 28, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
    gsSP2Triangles(4, 0, 2, 0, 18, 19, 9, 0),
    gsSP2Triangles(20, 21, 22, 0, 19, 18, 23, 0),
    gsSP2Triangles(10, 1, 0, 0, 10, 0, 11, 0),
    gsSP2Triangles(2, 5, 4, 0, 6, 8, 24, 0),
    gsSP2Triangles(25, 12, 14, 0, 24, 26, 6, 0),
    gsSP1Triangle(14, 27, 25, 0),
    gsSPVertex(&object_bsmaskVtx_000000[84], 17, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(2, 4, 3, 0, 4, 2, 5, 0),
    gsSP2Triangles(6, 1, 7, 0, 8, 9, 10, 0),
    gsSP2Triangles(7, 11, 6, 0, 0, 7, 1, 0),
    gsSP2Triangles(12, 13, 14, 0, 10, 15, 8, 0),
    gsSP1Triangle(5, 16, 4, 0),
    gsSPVertex(&object_bsmaskVtx_000000[101], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSPEndDisplayList(),
};

Vtx object_bsmaskVtx_0009E0[] = {
#include "assets/objects/object_bsmask/object_bsmaskVtx_0009E0.vtx.inc"
};

Gfx gRemainsGyorgDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gRemainsGyorgTwinmoldEyeTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_bsmaskVtx_0009E0, 20, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 2, 1, 5, 0),
    gsSP2Triangles(9, 10, 11, 0, 12, 10, 8, 0),
    gsSP2Triangles(8, 10, 9, 0, 5, 4, 13, 0),
    gsSP2Triangles(5, 1, 14, 0, 8, 7, 15, 0),
    gsSP2Triangles(11, 16, 9, 0, 9, 16, 8, 0),
    gsSP2Triangles(15, 17, 8, 0, 8, 16, 6, 0),
    gsSP2Triangles(8, 17, 12, 0, 5, 18, 3, 0),
    gsSP2Triangles(5, 19, 2, 0, 13, 19, 5, 0),
    gsSP2Triangles(2, 19, 0, 0, 14, 18, 5, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gRemainsGyorgSkinTLUT),
    gsDPLoadTextureBlock_4b(gRemainsGyorgSkinTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_0009E0[20], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 2, 0),
    gsSP2Triangles(1, 5, 3, 0, 2, 1, 3, 0),
    gsSP1Triangle(2, 4, 0, 0),
    gsSPVertex(&object_bsmaskVtx_0009E0[26], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(2, 1, 4, 0, 0, 5, 1, 0),
    gsSP1Triangle(4, 3, 2, 0),
    gsSPVertex(&object_bsmaskVtx_0009E0[32], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(1, 6, 7, 0, 2, 8, 0, 0),
    gsSP2Triangles(7, 6, 4, 0, 5, 9, 3, 0),
    gsSP2Triangles(10, 11, 2, 0, 3, 11, 10, 0),
    gsSP2Triangles(4, 12, 7, 0, 7, 13, 1, 0),
    gsSP2Triangles(2, 1, 13, 0, 12, 4, 3, 0),
    gsSP2Triangles(10, 12, 3, 0, 2, 13, 10, 0),
    gsDPSetPrimColor(0, 0x80, 119, 116, 121, 255),
    gsSPVertex(&object_bsmaskVtx_0009E0[46], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(5, 12, 13, 0, 13, 3, 5, 0),
    gsSP2Triangles(14, 15, 16, 0, 16, 17, 14, 0),
    gsSP2Triangles(18, 8, 19, 0, 18, 19, 20, 0),
    gsSP2Triangles(9, 11, 21, 0, 22, 9, 21, 0),
    gsSP2Triangles(2, 22, 23, 0, 24, 20, 25, 0),
    gsSP2Triangles(17, 1, 14, 0, 8, 7, 19, 0),
    gsSP2Triangles(21, 23, 22, 0, 25, 12, 26, 0),
    gsSP2Triangles(3, 27, 28, 0, 29, 30, 16, 0),
    gsSP2Triangles(20, 24, 18, 0, 16, 15, 29, 0),
    gsSP2Triangles(11, 10, 31, 0, 28, 4, 3, 0),
    gsSP2Triangles(23, 0, 2, 0, 25, 26, 24, 0),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_bsmaskVtx_0009E0[78], 16, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(3, 6, 7, 0, 8, 9, 10, 0),
    gsSP2Triangles(1, 11, 2, 0, 12, 13, 14, 0),
    gsSP2Triangles(11, 15, 2, 0, 3, 7, 4, 0),
    gsSPVertex(&object_bsmaskVtx_0009E0[94], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSPVertex(&object_bsmaskVtx_0009E0[100], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 6, 3, 0, 2, 7, 0, 0),
    gsSPVertex(&object_bsmaskVtx_0009E0[108], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 1, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gRemainsGyorgMouthTLUT),
    gsDPLoadTextureBlock_4b(gRemainsGyorgMouthTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_0009E0[118], 16, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
    gsSP2Triangles(10, 2, 11, 0, 3, 12, 4, 0),
    gsSP2Triangles(0, 10, 5, 0, 13, 3, 10, 0),
    gsSP2Triangles(10, 11, 13, 0, 2, 10, 0, 0),
    gsSP2Triangles(9, 14, 6, 0, 1, 15, 2, 0),
    gsSP2Triangles(5, 10, 3, 0, 5, 9, 8, 0),
    gsSP1Triangle(8, 0, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gRemainsGyorgSkinTLUT),
    gsDPLoadTextureBlock_4b(gRemainsGyorgSkinTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_0009E0[134], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 2, 4, 0),
    gsSP2Triangles(5, 2, 1, 0, 6, 7, 2, 0),
    gsSP2Triangles(2, 3, 6, 0, 2, 7, 0, 0),
    gsSP1Triangle(0, 7, 6, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gRemainsGyorgMouthTLUT),
    gsDPLoadTextureBlock_4b(gRemainsGyorgMouthTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_0009E0[142], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gRemainsGyorgToothHornTLUT),
    gsDPLoadTextureBlock_4b(gRemainsGyorgToothHornTex, G_IM_FMT_CI, 16, 16, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_0009E0[154], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 8, 7, 9, 0),
    gsSP2Triangles(4, 3, 10, 0, 11, 12, 13, 0),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 23, 24, 25, 0),
    gsSP2Triangles(26, 27, 28, 0, 29, 30, 31, 0),
    gsSPVertex(&object_bsmaskVtx_0009E0[186], 16, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 13, 9, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gRemainsGyorgMouthTLUT),
    gsDPLoadTextureBlock_4b(gRemainsGyorgMouthTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_0009E0[202], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSP2Triangles(2, 4, 0, 0, 0, 5, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gRemainsGyorgSkinTLUT),
    gsDPLoadTextureBlock_4b(gRemainsGyorgSkinTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_0009E0[208], 9, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSP2Triangles(2, 1, 3, 0, 0, 4, 3, 0),
    gsSP2Triangles(3, 5, 2, 0, 3, 6, 7, 0),
    gsSP2Triangles(4, 8, 3, 0, 3, 7, 5, 0),
    gsSP1Triangle(8, 6, 3, 0),
    gsSPVertex(&object_bsmaskVtx_0009E0[217], 19, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(3, 5, 6, 0, 2, 6, 0, 0),
    gsSP2Triangles(7, 8, 9, 0, 1, 0, 10, 0),
    gsSP2Triangles(8, 11, 12, 0, 11, 5, 13, 0),
    gsSP2Triangles(11, 13, 14, 0, 15, 12, 11, 0),
    gsSP2Triangles(6, 2, 16, 0, 12, 9, 8, 0),
    gsSP2Triangles(14, 17, 15, 0, 14, 15, 11, 0),
    gsSP2Triangles(6, 16, 18, 0, 6, 18, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gRemainsGyorgToothHornTLUT),
    gsDPLoadTextureBlock_4b(gRemainsGyorgToothHornTex, G_IM_FMT_CI, 16, 16, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_0009E0[236], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 1, 0, 0, 7, 8, 9, 0),
    gsSP2Triangles(10, 11, 3, 0, 12, 11, 10, 0),
    gsSP2Triangles(13, 14, 15, 0, 16, 17, 18, 0),
    gsSP2Triangles(19, 20, 21, 0, 22, 23, 24, 0),
    gsSP2Triangles(25, 26, 27, 0, 18, 17, 28, 0),
    gsSP1Triangle(29, 30, 31, 0),
    gsSPVertex(&object_bsmaskVtx_0009E0[268], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 3, 0, 5, 4, 8, 0),
    gsSP1Triangle(9, 10, 11, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gRemainsGyorgMouthTLUT),
    gsDPLoadTextureBlock_4b(gRemainsGyorgMouthTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_0009E0[280], 18, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 8, 7, 9, 0),
    gsSP2Triangles(0, 10, 1, 0, 2, 1, 11, 0),
    gsSP2Triangles(1, 12, 13, 0, 1, 13, 11, 0),
    gsSP2Triangles(14, 10, 0, 0, 8, 0, 2, 0),
    gsSP2Triangles(2, 6, 8, 0, 11, 15, 3, 0),
    gsSP2Triangles(5, 16, 17, 0, 5, 17, 6, 0),
    gsSP2Triangles(5, 6, 2, 0, 11, 3, 2, 0),
    gsSP1Triangle(2, 3, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gRemainsGyorgSkinTLUT),
    gsDPLoadTextureBlock_4b(gRemainsGyorgSkinTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_0009E0[298], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 0, 2, 0, 2, 3, 5, 0),
    gsSPVertex(&object_bsmaskVtx_0009E0[304], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 5, 0, 5, 4, 6, 0),
    gsSP2Triangles(5, 7, 1, 0, 8, 3, 9, 0),
    gsSP2Triangles(5, 9, 3, 0, 1, 0, 5, 0),
    gsSPEndDisplayList(),
};

Vtx object_bsmaskVtx_002680[] = {
#include "assets/objects/object_bsmask/object_bsmaskVtx_002680.vtx.inc"
};

Gfx gRemainsGohtDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gRemainsGohtEyeTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_bsmaskVtx_002680, 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(1, 6, 2, 0, 3, 7, 4, 0),
    gsSP2Triangles(8, 9, 10, 0, 11, 12, 13, 0),
    gsSPVertex(&object_bsmaskVtx_002680[14], 17, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 4, 0),
    gsSP2Triangles(5, 6, 7, 0, 8, 9, 10, 0),
    gsSP2Triangles(11, 12, 13, 0, 14, 15, 16, 0),
    gsSPVertex(&object_bsmaskVtx_002680[31], 13, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 2, 9, 0, 0),
    gsSP1Triangle(10, 11, 12, 0),
    gsSPVertex(&object_bsmaskVtx_002680[44], 22, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
    gsSP2Triangles(18, 12, 14, 0, 17, 19, 15, 0),
    gsSP2Triangles(9, 11, 20, 0, 2, 21, 0, 0),
    gsSPVertex(&object_bsmaskVtx_002680[66], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 4, 0),
    gsSP2Triangles(3, 5, 4, 0, 0, 6, 7, 0),
    gsSP2Triangles(2, 4, 0, 0, 0, 7, 1, 0),
    gsSPVertex(&object_bsmaskVtx_002680[74], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 8, 9, 0),
    gsSP2Triangles(6, 10, 4, 0, 9, 11, 7, 0),
    gsSPVertex(&object_bsmaskVtx_002680[86], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 6, 10, 0),
    gsSP2Triangles(8, 10, 6, 0, 10, 11, 9, 0),
    gsSP2Triangles(5, 12, 3, 0, 2, 13, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gRemainsGohtTopPatternTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 237, 191, 255),
    gsSPVertex(&object_bsmaskVtx_002680[100], 7, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(4, 3, 1, 0, 1, 5, 6, 0),
    gsSP2Triangles(1, 0, 5, 0, 6, 4, 1, 0),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_bsmaskVtx_002680[107], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 6, 0, 0, 5, 7, 3, 0),
    gsSP2Triangles(1, 0, 8, 0, 9, 5, 4, 0),
    gsSP2Triangles(0, 6, 10, 0, 7, 5, 11, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gRemainsGohtTwinmoldPatternTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_002680[119], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(1, 6, 2, 0, 7, 8, 4, 0),
    gsSP2Triangles(1, 9, 6, 0, 3, 7, 4, 0),
    gsSPVertex(&object_bsmaskVtx_002680[129], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSPVertex(&object_bsmaskVtx_002680[141], 5, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP1Triangle(3, 4, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gRemainsGohtEyeTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_002680[146], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gRemainsGohtSpikeTwinmoldMandibleTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_002680[150], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 6, 0, 0, 5, 7, 3, 0),
    gsSPVertex(&object_bsmaskVtx_002680[158], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 6, 0, 0, 5, 7, 3, 0),
    gsSPVertex(&object_bsmaskVtx_002680[166], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 6, 0, 0, 7, 6, 2, 0),
    gsSP2Triangles(8, 4, 3, 0, 3, 9, 8, 0),
    gsSP2Triangles(5, 10, 3, 0, 2, 11, 7, 0),
    gsSPVertex(&object_bsmaskVtx_002680[178], 11, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 6, 0, 0, 7, 0, 6, 0),
    gsSP2Triangles(4, 3, 8, 0, 5, 9, 10, 0),
    gsSPVertex(&object_bsmaskVtx_002680[189], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gRemainsGohtTopPatternTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_002680[195], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 0, 0),
    gsSP2Triangles(2, 5, 0, 0, 0, 5, 3, 0),
    gsDPSetPrimColor(0, 0x80, 255, 218, 210, 255),
    gsSPVertex(&object_bsmaskVtx_002680[201], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 6, 0, 0, 5, 7, 8, 0),
    gsSP2Triangles(8, 3, 5, 0, 0, 9, 1, 0),
    gsDPSetPrimColor(0, 0x80, 226, 255, 244, 255),
    gsSPVertex(&object_bsmaskVtx_002680[211], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(4, 5, 6, 0, 6, 7, 8, 0),
    gsSP2Triangles(8, 4, 6, 0, 0, 9, 1, 0),
    gsDPSetPrimColor(0, 0x80, 223, 214, 244, 255),
    gsSPVertex(&object_bsmaskVtx_002680[221], 7, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 4, 0),
    gsSP2Triangles(0, 5, 1, 0, 6, 4, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gRemainsGohtTwinmoldPatternTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_bsmaskVtx_002680[228], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gRemainsGohtEyeTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_002680[232], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 2, 7, 0, 8, 9, 10, 0),
    gsSP2Triangles(11, 4, 3, 0, 4, 11, 12, 0),
    gsSP2Triangles(10, 13, 8, 0, 2, 1, 7, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gRemainsGohtTwinmoldPatternTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_002680[246], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 6, 0, 0, 5, 7, 8, 0),
    gsSP2Triangles(6, 9, 0, 0, 5, 8, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gRemainsGohtSpikeTwinmoldMandibleTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_002680[256], 16, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 4, 3, 0),
    gsSP2Triangles(10, 7, 6, 0, 11, 12, 13, 0),
    gsSP2Triangles(14, 12, 11, 0, 15, 1, 0, 0),
    gsSPVertex(&object_bsmaskVtx_002680[272], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 1, 0, 0, 7, 4, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gRemainsGohtTopPatternTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_002680[280], 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gRemainsGohtEyeTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_002680[283], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSPVertex(&object_bsmaskVtx_002680[287], 18, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gRemainsGohtSpikeTwinmoldMandibleTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_002680[305], 13, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP1Triangle(11, 12, 9, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gRemainsGohtTwinmoldPatternTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_002680[318], 7, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSP2Triangles(4, 5, 0, 0, 0, 2, 4, 0),
    gsSP2Triangles(0, 5, 6, 0, 6, 3, 0, 0),
    gsSPEndDisplayList(),
};

u8 object_bsmask_possiblePadding_004268[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx object_bsmaskVtx_004270[] = {
#include "assets/objects/object_bsmask/object_bsmaskVtx_004270.vtx.inc"
};

Gfx gRemainsTwinmoldDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gRemainsGohtSpikeTwinmoldMandibleTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 178, 178, 178, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_bsmaskVtx_004270, 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gRemainsTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(gRemainsTwinmoldSkinTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_bsmaskVtx_004270[3], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(4, 5, 6, 0, 6, 7, 4, 0),
    gsDPPipeSync(),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gRemainsGyorgTwinmoldEyeTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(&object_bsmaskVtx_004270[11], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(4, 5, 2, 0, 2, 1, 4, 0),
    gsSPVertex(&object_bsmaskVtx_004270[17], 11, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 4, 0),
    gsSP2Triangles(5, 3, 2, 0, 4, 6, 2, 0),
    gsSP2Triangles(2, 7, 5, 0, 2, 1, 8, 0),
    gsSP2Triangles(8, 9, 2, 0, 2, 10, 0, 0),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gRemainsTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(gRemainsTwinmoldSkinTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bsmaskVtx_004270[28], 21, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 4, 8, 0),
    gsSP2Triangles(9, 10, 11, 0, 6, 8, 4, 0),
    gsSP2Triangles(2, 12, 0, 0, 13, 14, 15, 0),
    gsSP2Triangles(10, 9, 16, 0, 3, 17, 2, 0),
    gsSP2Triangles(15, 18, 13, 0, 15, 19, 20, 0),
    gsSP2Triangles(9, 5, 4, 0, 20, 18, 15, 0),
    gsSP1Triangle(11, 5, 9, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gRemainsTwinmoldSnoutTLUT),
    gsDPLoadTextureBlock_4b(gRemainsTwinmoldSnoutTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_004270[49], 7, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 4, 0),
    gsSP2Triangles(0, 5, 1, 0, 3, 6, 4, 0),
    gsSP1Triangle(2, 4, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gRemainsTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(gRemainsTwinmoldSkinTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_004270[56], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSPVertex(&object_bsmaskVtx_004270[60], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(4, 3, 6, 0, 2, 1, 7, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gRemainsGohtTwinmoldPatternTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_004270[68], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gRemainsTwinmoldSnoutTLUT),
    gsDPLoadTextureBlock_4b(gRemainsTwinmoldSnoutTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_004270[72], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gRemainsGohtSpikeTwinmoldMandibleTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_004270[76], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSPVertex(&object_bsmaskVtx_004270[88], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gRemainsTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(gRemainsTwinmoldSkinTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_004270[100], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSP2Triangles(4, 5, 6, 0, 5, 4, 7, 0),
    gsSPVertex(&object_bsmaskVtx_004270[108], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(3, 4, 0, 0, 5, 6, 7, 0),
    gsSP2Triangles(8, 5, 7, 0, 4, 3, 9, 0),
    gsSP2Triangles(6, 5, 10, 0, 11, 1, 0, 0),
    gsSP2Triangles(0, 6, 11, 0, 9, 12, 4, 0),
    gsSP2Triangles(7, 13, 8, 0, 10, 11, 6, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gRemainsGohtSpikeTwinmoldMandibleTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_004270[122], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gRemainsGohtTwinmoldPatternTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_004270[128], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 6, 3, 0, 2, 7, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gRemainsGohtSpikeTwinmoldMandibleTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_004270[136], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(3, 5, 6, 0, 7, 8, 9, 0),
    gsSP2Triangles(7, 9, 10, 0, 11, 12, 13, 0),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(17, 19, 20, 0, 21, 22, 23, 0),
    gsSP2Triangles(21, 23, 24, 0, 16, 25, 26, 0),
    gsSP2Triangles(16, 26, 14, 0, 24, 27, 21, 0),
    gsSP2Triangles(13, 28, 29, 0, 13, 29, 11, 0),
    gsSP2Triangles(20, 30, 17, 0, 6, 31, 3, 0),
    gsSPVertex(&object_bsmaskVtx_004270[168], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 8, 9, 0),
    gsSP2Triangles(7, 9, 10, 0, 10, 11, 7, 0),
    gsSPVertex(&object_bsmaskVtx_004270[180], 31, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
    gsSP2Triangles(15, 17, 18, 0, 19, 20, 21, 0),
    gsSP2Triangles(19, 21, 22, 0, 2, 23, 24, 0),
    gsSP2Triangles(25, 26, 12, 0, 5, 27, 28, 0),
    gsSP2Triangles(29, 30, 9, 0, 9, 11, 29, 0),
    gsSP2Triangles(28, 3, 5, 0, 12, 14, 25, 0),
    gsSP1Triangle(24, 0, 2, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gRemainsTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(gRemainsTwinmoldSkinTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bsmaskVtx_004270[211], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 4, 6, 0, 5, 7, 3, 0),
    gsSPEndDisplayList(),
};

u64 gRemainsOdolwaFaceTLUT[] = {
#include "assets/objects/object_bsmask/remains_odolwa_face_tlut.rgba16.inc.c"
};

u64 gRemainsOdolwaEarTLUT[] = {
#include "assets/objects/object_bsmask/remains_odolwa_ear_tlut.rgba16.inc.c"
};

u64 gRemainsGyorgSkinTLUT[] = {
#include "assets/objects/object_bsmask/remains_gyorg_skin_tlut.rgba16.inc.c"
};

u64 gRemainsGyorgMouthTLUT[] = {
#include "assets/objects/object_bsmask/remains_gyorg_mouth_tlut.rgba16.inc.c"
};

u64 gRemainsGyorgToothHornTLUT[] = {
#include "assets/objects/object_bsmask/remains_gyorg_tooth_horn_tlut.rgba16.inc.c"
};

u64 gRemainsTwinmoldSkinTLUT[] = {
#include "assets/objects/object_bsmask/remains_twinmold_skin_tlut.rgba16.inc.c"
};

u64 gRemainsTwinmoldSnoutTLUT[] = {
#include "assets/objects/object_bsmask/remains_twinmold_snout_tlut.rgba16.inc.c"
};

u64 gRemainsOdolwaPlumeTex[] = {
#include "assets/objects/object_bsmask/remains_odolwa_plume.rgba16.inc.c"
};

u64 gRemainsOdolwaFaceTex[] = {
#include "assets/objects/object_bsmask/remains_odolwa_face.ci4.inc.c"
};

u64 gRemainsOdolwaEarTex[] = {
#include "assets/objects/object_bsmask/remains_odolwa_ear.ci4.inc.c"
};

u64 gRemainsGyorgTwinmoldEyeTex[] = {
#include "assets/objects/object_bsmask/remains_gyorg_twinmold_eye.rgba16.inc.c"
};

u64 gRemainsGyorgSkinTex[] = {
#include "assets/objects/object_bsmask/remains_gyorg_skin.ci4.inc.c"
};

u64 gRemainsGyorgMouthTex[] = {
#include "assets/objects/object_bsmask/remains_gyorg_mouth.ci4.inc.c"
};

u64 gRemainsGyorgToothHornTex[] = {
#include "assets/objects/object_bsmask/remains_gyorg_tooth_horn.ci4.inc.c"
};

u64 gRemainsGohtEyeTex[] = {
#include "assets/objects/object_bsmask/remains_goht_eye.rgba16.inc.c"
};

u64 gRemainsGohtTopPatternTex[] = {
#include "assets/objects/object_bsmask/remains_goht_top_pattern.rgba16.inc.c"
};

u64 gRemainsGohtTwinmoldPatternTex[] = {
#include "assets/objects/object_bsmask/remains_goht_twinmold_pattern.rgba16.inc.c"
};

u64 gRemainsGohtSpikeTwinmoldMandibleTex[] = {
#include "assets/objects/object_bsmask/remains_goht_spike_twinmold_mandible.rgba16.inc.c"
};

u64 gRemainsTwinmoldSkinTex[] = {
#include "assets/objects/object_bsmask/remains_twinmold_skin.ci4.inc.c"
};

u64 gRemainsTwinmoldSnoutTex[] = {
#include "assets/objects/object_bsmask/remains_twinmold_snout.ci4.inc.c"
};

