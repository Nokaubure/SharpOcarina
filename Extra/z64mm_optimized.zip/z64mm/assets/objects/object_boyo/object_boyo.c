#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_boyo.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

Vtx object_boyoVtx_000000[] = {
#include "assets/objects/object_boyo/object_boyoVtx_000000.vtx.inc"
};

Gfx object_boyo_DL_000300[] = {
    gsDPPipeSync(),
    gsDPSetColorDither(G_CD_MAGICSQ),
    gsDPSetAlphaDither(G_AD_PATTERN),
    gsDPSetCombineLERP(TEXEL1, TEXEL0, PRIM_LOD_FRAC, TEXEL0, TEXEL1, TEXEL0, PRIM_LOD_FRAC, TEXEL0, COMBINED, 0, SHADE,
                       0, COMBINED, 0, PRIMITIVE, 0),
    gsDPSetPrimColor(0, 0x20, 255, 255, 255, 255),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetTextureFilter(G_TF_BILERP),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(object_boyo_Tex_000480, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x007C, 0x007C),
    gsDPLoadMultiBlock(object_boyo_Tex_000C80, 0x0100, 1, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                       G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 4, 4, G_TX_NOLOD, 5),
    gsDPSetTileSize(1, 0, 0, 0x003C, 0x003C),
    gsSPDisplayList(0x08000000),
    gsSPClearGeometryMode(G_LIGHTING),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG),
    gsSPVertex(object_boyoVtx_000000, 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSP2Triangles(4, 1, 5, 0, 5, 1, 3, 0),
    gsSP2Triangles(2, 1, 6, 0, 7, 8, 9, 0),
    gsSP2Triangles(7, 9, 10, 0, 11, 12, 13, 0),
    gsSP2Triangles(11, 13, 7, 0, 14, 15, 16, 0),
    gsSP2Triangles(14, 16, 17, 0, 17, 18, 19, 0),
    gsSP2Triangles(17, 19, 20, 0, 21, 22, 23, 0),
    gsSP2Triangles(21, 23, 24, 0, 24, 25, 26, 0),
    gsSP2Triangles(24, 26, 27, 0, 7, 28, 29, 0),
    gsSP2Triangles(7, 29, 11, 0, 30, 31, 28, 0),
    gsSP1Triangle(30, 28, 7, 0),
    gsSPVertex(&object_boyoVtx_000000[32], 16, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(3, 4, 5, 0, 3, 5, 6, 0),
    gsSP2Triangles(7, 8, 9, 0, 7, 9, 10, 0),
    gsSP2Triangles(11, 12, 13, 0, 10, 9, 14, 0),
    gsSP1Triangle(10, 14, 15, 0),
    gsSPEndDisplayList(),
};

u64 object_boyo_Tex_000480[] = {
#include "assets/objects/object_boyo/tex_000480.rgba16.inc.c"
};

u64 object_boyo_Tex_000C80[] = {
#include "assets/objects/object_boyo/tex_000C80.rgba16.inc.c"
};

AnimatedMatTexScrollParams object_boyo_Matanimheader_000E88TexScrollParams_000E80[] = {
    { 0, 0, 0x20, 0x20 },
    { 0, 2, 0x10, 0x10 },
};

AnimatedMaterial object_boyo_Matanimheader_000E88[] = {
    { -1, 1, object_boyo_Matanimheader_000E88TexScrollParams_000E80 },
};

