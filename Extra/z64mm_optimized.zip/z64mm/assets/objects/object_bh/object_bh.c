#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_bh.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

s16 sBhFlyingAnimFrameData[] = {
    0x0002, 0x0000, 0xFD88, 0xE000, 0xC000, 0xBFC3, 0x0174, 0xC03D, 0xC9A6, 0xE656, 0x1B9E, 0x384F, 0x2CCD, 0x115B, 
    0xF09A, 0xD528, 0x0000, 0xE436, 0xEE3B, 0xFE74, 0x0C06, 0x13CD, 0x0ECE, 0x0534, 0xB303, 0x96E4, 0x62AC, 0x468D, 
    0x51D5, 0x6CBB, 0x8CD5, 0xA7BB, 0x0000, 0x17CB, 0x0F99, 0x01A1, 0xF40B, 0xEBCB, 0xF0E3, 0xFAB0, 
};

JointIndex sBhFlyingAnimJointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0003, 0x0004, 0x0003 },
    { 0x0001, 0x0008, 0x0005 },
    { 0x0001, 0x0010, 0x0006 },
    { 0x0001, 0x0018, 0x0007 },
    { 0x0001, 0x0020, 0x0006 },
};

AnimationHeader gBhFlyingAnim = { 
    { 8 }, sBhFlyingAnimFrameData,
    sBhFlyingAnimJointIndices, 8
};

u8 object_bh_possiblePadding_000084[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx object_bhVtx_000090[] = {
#include "assets/objects/object_bh/object_bhVtx_000090.vtx.inc"
};

Gfx gBhBodyDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gBhBodyTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                         G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_bhVtx_000090, 16, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 2, 4, 0),
    gsSP2Triangles(5, 6, 7, 0, 8, 9, 10, 0),
    gsSP2Triangles(10, 9, 11, 0, 4, 2, 10, 0),
    gsSP2Triangles(3, 12, 0, 0, 2, 1, 8, 0),
    gsSP2Triangles(8, 1, 0, 0, 13, 7, 6, 0),
    gsSP2Triangles(12, 7, 13, 0, 12, 11, 14, 0),
    gsSP2Triangles(14, 11, 9, 0, 9, 8, 13, 0),
    gsSP2Triangles(8, 0, 13, 0, 5, 15, 13, 0),
    gsSP2Triangles(13, 6, 5, 0, 7, 14, 15, 0),
    gsSP2Triangles(10, 2, 8, 0, 11, 12, 3, 0),
    gsSP2Triangles(0, 2, 3, 0, 11, 4, 10, 0),
    gsSP2Triangles(3, 4, 11, 0, 14, 7, 12, 0),
    gsSP2Triangles(9, 15, 14, 0, 13, 0, 12, 0),
    gsSP2Triangles(13, 15, 9, 0, 7, 15, 5, 0),
    gsSPEndDisplayList(),
};

Gfx gBhRightWingToEdgeDL[] = {
    gsSPMatrix(0x0D0000C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bhVtx_000090[25], 2, 0),
    gsSPMatrix(0x0D000100, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gBhWingTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                         G_TX_CLAMP, 6, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bhVtx_000090[27], 3, 2),
    gsSP2Triangles(1, 2, 3, 0, 0, 1, 4, 0),
    gsSPEndDisplayList(),
};

Gfx gBhRightWingToBodyDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gBhWingTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                         G_TX_CLAMP, 6, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bhVtx_000090[30], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
    gsSPEndDisplayList(),
};

Gfx gBhLeftWingToEdgeDL[] = {
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bhVtx_000090[16], 2, 0),
    gsSPMatrix(0x0D000080, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gBhWingTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                         G_TX_CLAMP, 6, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bhVtx_000090[18], 3, 2),
    gsSP2Triangles(2, 3, 1, 0, 4, 1, 0, 0),
    gsSPEndDisplayList(),
};

Gfx gBhLeftWingToBodyDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gBhWingTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                         G_TX_CLAMP, 6, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bhVtx_000090[21], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

u64 gBhBodyTex[] = {
#include "assets/objects/object_bh/en_bh_body.rgba16.inc.c"
};

u64 gBhWingTex[] = {
#include "assets/objects/object_bh/en_bh_wing.rgba16.inc.c"
};

StandardLimb gBhBodyLimb = { 
    { 2, 0, -632 }, OBJECT_BH_LIMB_RIGHT_WING_TO_BODY - 1, LIMB_DONE,
    gBhBodyDL
};

StandardLimb gBhRightWingToBodyLimb = { 
    { 634, -175, 0 }, OBJECT_BH_LIMB_RIGHT_WING_TO_EDGE - 1, OBJECT_BH_LIMB_LEFT_WING_TO_BODY - 1,
    gBhLeftWingToBodyDL
};

StandardLimb gBhRightWingToEdgeLimb = { 
    { 638, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gBhLeftWingToEdgeDL
};

StandardLimb gBhLeftWingToBodyLimb = { 
    { 634, 172, 0 }, OBJECT_BH_LIMB_LEFT_WING_TO_EDGE - 1, LIMB_DONE,
    gBhRightWingToBodyDL
};

StandardLimb gBhLeftWingToEdgeLimb = { 
    { 638, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gBhRightWingToEdgeDL
};

void* gBhSkelLimbs[] = {
    &gBhBodyLimb, /* OBJECT_BH_LIMB_BODY */
    &gBhRightWingToBodyLimb, /* OBJECT_BH_LIMB_RIGHT_WING_TO_BODY */
    &gBhRightWingToEdgeLimb, /* OBJECT_BH_LIMB_RIGHT_WING_TO_EDGE */
    &gBhLeftWingToBodyLimb, /* OBJECT_BH_LIMB_LEFT_WING_TO_BODY */
    &gBhLeftWingToEdgeLimb, /* OBJECT_BH_LIMB_LEFT_WING_TO_EDGE */
};

FlexSkeletonHeader gBhSkel = { 
    { gBhSkelLimbs, ARRAY_COUNT(gBhSkelLimbs) }, 5
};

