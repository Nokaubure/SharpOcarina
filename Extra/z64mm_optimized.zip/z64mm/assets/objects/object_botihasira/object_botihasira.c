#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_botihasira.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

Vtx object_botihasiraVtx_000000[] = {
#include "assets/objects/object_botihasira/object_botihasiraVtx_000000.vtx.inc"
};

Gfx object_botihasira_DL_0004A0[] = {
    gsSPVertex(&object_botihasiraVtx_000000[66], 8, 0),
    gsSPCullDisplayList(0, 7),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(object_botihasira_Tex_001648, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 16, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 5, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_botihasiraVtx_000000, 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
    gsSP2Triangles(24, 25, 26, 0, 24, 26, 27, 0),
    gsSP2Triangles(28, 29, 5, 0, 28, 5, 4, 0),
    gsSPVertex(&object_botihasiraVtx_000000[30], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(object_botihasira_Tex_000648, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_WRAP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_botihasiraVtx_000000[38], 28, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
    gsSP2Triangles(0, 4, 3, 0, 0, 5, 4, 0),
    gsSP2Triangles(5, 6, 4, 0, 5, 7, 6, 0),
    gsSP2Triangles(8, 9, 10, 0, 11, 12, 13, 0),
    gsSP2Triangles(14, 15, 16, 0, 8, 17, 16, 0),
    gsSP2Triangles(12, 18, 13, 0, 19, 20, 21, 0),
    gsSP2Triangles(20, 22, 21, 0, 8, 23, 9, 0),
    gsSP2Triangles(17, 14, 16, 0, 0, 24, 25, 0),
    gsSP2Triangles(8, 26, 17, 0, 8, 27, 26, 0),
    gsSP2Triangles(8, 10, 27, 0, 0, 2, 24, 0),
    gsSPEndDisplayList(),
};

Gfx object_botihasira_DL_000628[] = {
    gsSPDisplayList(object_botihasira_DL_0004A0),
    gsSPEndDisplayList(),
};

Gfx object_botihasira_DL_000638[] = {
    gsSPDisplayList(object_botihasira_DL_000628),
    gsSPEndDisplayList(),
};

u64 object_botihasira_Tex_000648[] = {
#include "assets/objects/object_botihasira/tex_000648.rgba16.inc.c"
};

u64 object_botihasira_Tex_001648[] = {
#include "assets/objects/object_botihasira/tex_001648.rgba16.inc.c"
};

u8 object_botihasira_unaccounted_001A48[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

CamData object_botihasira_Colheader_001BD8CamDataList[] = {
    { 0x0000, 0, NULL },
};

SurfaceType object_botihasira_Colheader_001BD8SurfaceType[] = {
    {0x00000000, 0x000007C0},
};

CollisionPoly object_botihasira_Colheader_001BD8Polygons[] = {
    {0x0000, 0x0000, 0x0001, 0x0002, 0x0000, 0x0000, 0x7FFF, 0xFF9C},
    {0x0000, 0x0001, 0x0003, 0x0002, 0x0000, 0x0000, 0x7FFF, 0xFF9C},
    {0x0000, 0x0004, 0x0005, 0x0006, 0x0000, 0x0000, 0x8001, 0xFF9C},
    {0x0000, 0x0005, 0x0007, 0x0006, 0x0000, 0x0000, 0x8001, 0xFF9C},
    {0x0000, 0x0004, 0x0003, 0x0001, 0xC148, 0x6F94, 0x0000, 0xFCC3},
    {0x0000, 0x0004, 0x0001, 0x0005, 0xC148, 0x6F94, 0x0000, 0xFCC3},
    {0x0000, 0x0003, 0x0004, 0x0006, 0x8001, 0x0000, 0x0000, 0xFEA4},
    {0x0000, 0x0003, 0x0006, 0x0002, 0x8001, 0x0000, 0x0000, 0xFEA4},
    {0x0000, 0x0001, 0x0008, 0x0009, 0x0000, 0x0000, 0x7FFF, 0xFF9C},
    {0x0000, 0x0001, 0x0000, 0x0008, 0x0000, 0x0000, 0x7FFF, 0xFF9C},
    {0x0000, 0x0005, 0x000A, 0x0007, 0x0000, 0x0000, 0x8001, 0xFF9C},
    {0x0000, 0x000A, 0x0008, 0x0000, 0x7FE0, 0x059B, 0x0000, 0xFF6C},
    {0x0000, 0x000A, 0x0000, 0x0007, 0x7FE0, 0x059B, 0x0000, 0xFF6C},
    {0x0000, 0x0005, 0x0001, 0x0009, 0x191A, 0x7D83, 0x0000, 0xFCEE},
    {0x0000, 0x0005, 0x0009, 0x000B, 0x191A, 0x7D83, 0x0000, 0xFCEE},
    {0x0000, 0x0005, 0x000B, 0x000A, 0x0000, 0x0000, 0x8001, 0xFF9C},
    {0x0000, 0x000B, 0x0009, 0x0008, 0x3E70, 0x6FBC, 0x0000, 0xFD4A},
    {0x0000, 0x000B, 0x0008, 0x000A, 0x3E70, 0x6FBC, 0x0000, 0xFD4A},
};

Vec3s object_botihasira_Colheader_001BD8Vertices[] = {
    {    148,      0,    100 },
    {   -195,    841,    100 },
    {   -348,      0,    100 },
    {   -348,    755,    100 },
    {   -348,    755,   -100 },
    {   -195,    841,   -100 },
    {   -348,      0,   -100 },
    {    148,      0,   -100 },
    {    116,    730,    100 },
    {    -20,    806,    100 },
    {    116,    730,   -100 },
    {    -20,    806,   -100 },
};

CollisionHeader object_botihasira_Colheader_001BD8 = { 
    { -348, 0, -100 },
    { 148, 841, 100 },
    ARRAY_COUNT(object_botihasira_Colheader_001BD8Vertices), object_botihasira_Colheader_001BD8Vertices,
    ARRAY_COUNT(object_botihasira_Colheader_001BD8Polygons), object_botihasira_Colheader_001BD8Polygons,
    object_botihasira_Colheader_001BD8SurfaceType,
    object_botihasira_Colheader_001BD8CamDataList,
    0, NULL
};

