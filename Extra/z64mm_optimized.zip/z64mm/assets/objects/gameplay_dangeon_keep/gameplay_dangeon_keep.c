#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "gameplay_dangeon_keep.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

Vtx gameplay_dangeon_keepVtx_000000[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_000000.vtx.inc"
};

Gfx gDoorLockDL[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gDoorLockTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP, G_TX_MIRROR |
                         G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPClearGeometryMode(G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_dangeon_keepVtx_000000, 20, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSPEndDisplayList(),
};

Vtx gameplay_dangeon_keepVtx_0001F0[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_0001F0.vtx.inc"
};

Gfx gDoorChainDL[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gDoorChainTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 128, 0, G_TX_MIRROR | G_TX_CLAMP, G_TX_MIRROR |
                         G_TX_CLAMP, 4, 7, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsSPClearGeometryMode(G_CULL_BACK | G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_FOG),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_dangeon_keepVtx_0001F0, 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

u64 gDoorLockTex[] = {
#include "assets/objects/gameplay_dangeon_keep/door_lock.rgba16.inc.c"
};

u64 gBossDoorLockTex[] = {
#include "assets/objects/gameplay_dangeon_keep/boss_door_lock.rgba16.inc.c"
};

u64 gDoorChainTex[] = {
#include "assets/objects/gameplay_dangeon_keep/door_chain.rgba16.inc.c"
};

u8 gameplay_dangeon_keep_possiblePadding_0022C0[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

u64 gameplay_dangeon_keep_Tex_0022C8[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_0022C8.i4.inc.c"
};

u8 gameplay_dangeon_keep_unaccounted_0032B8[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

u64 gameplay_dangeon_keep_Tex_0032C8[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_0032C8.i4.inc.c"
};

u8 gameplay_dangeon_keep_unaccounted_0042B8[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

u64 gameplay_dangeon_keep_Tex_0042C8[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_0042C8.i4.inc.c"
};

u8 gameplay_dangeon_keep_unaccounted_0052B8[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

u64 gameplay_dangeon_keep_Tex_0052C8[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_0052C8.i4.inc.c"
};

u8 gameplay_dangeon_keep_unaccounted_0062B8[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

u64 gameplay_dangeon_keep_Tex_0062C8[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_0062C8.i4.inc.c"
};

u8 gameplay_dangeon_keep_possiblePadding_0072B8[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx gameplay_dangeon_keepVtx_0072C0[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_0072C0.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_007300[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_014AC0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsSPClearGeometryMode(G_CULL_BACK | G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_FOG),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_dangeon_keepVtx_0072C0, 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

CamData gameplay_dangeon_keep_Colheader_007498CamDataList[] = {
    { 0x0000, 0, NULL },
};

SurfaceType gameplay_dangeon_keep_Colheader_007498SurfaceType[] = {
    {0x00E00000, 0x000007C2},   {0x00000000, 0x000007C2},
};

CollisionPoly gameplay_dangeon_keep_Colheader_007498Polygons[] = {
    {0x0000, 0x2000, 0x0001, 0x0002, 0x0000, 0x0000, 0x7FFF, 0xFED4},
    {0x0000, 0x2000, 0x0002, 0x0003, 0x0000, 0x0000, 0x7FFF, 0xFED4},
    {0x0001, 0x2004, 0x0001, 0x0000, 0x0000, 0x8001, 0x0000, 0x0000},
    {0x0001, 0x2004, 0x0000, 0x0005, 0x0000, 0x8001, 0x0000, 0x0000},
    {0x0000, 0x2002, 0x0001, 0x0004, 0x7FFF, 0x0000, 0x0000, 0xFED4},
    {0x0000, 0x2002, 0x0004, 0x0006, 0x7FFF, 0x0000, 0x0000, 0xFED4},
    {0x0001, 0x2007, 0x0003, 0x0002, 0x0000, 0x7FFF, 0x0000, 0xFDA8},
    {0x0001, 0x2007, 0x0002, 0x0006, 0x0000, 0x7FFF, 0x0000, 0xFDA8},
    {0x0000, 0x2005, 0x0000, 0x0003, 0x8001, 0x0000, 0x0000, 0xFED4},
    {0x0000, 0x2005, 0x0003, 0x0007, 0x8001, 0x0000, 0x0000, 0xFED4},
    {0x0000, 0x2006, 0x0004, 0x0005, 0x0000, 0x0000, 0x8001, 0xFED4},
    {0x0000, 0x2006, 0x0005, 0x0007, 0x0000, 0x0000, 0x8001, 0xFED4},
};

Vec3s gameplay_dangeon_keep_Colheader_007498Vertices[] = {
    {   -300,      0,    300 },
    {    300,      0,    300 },
    {    300,    600,    300 },
    {   -300,    600,    300 },
    {    300,      0,   -300 },
    {   -300,      0,   -300 },
    {    300,    600,   -300 },
    {   -300,    600,   -300 },
};

CollisionHeader gameplay_dangeon_keep_Colheader_007498 = { 
    { -300, 0, -300 },
    { 300, 600, 300 },
    ARRAY_COUNT(gameplay_dangeon_keep_Colheader_007498Vertices), gameplay_dangeon_keep_Colheader_007498Vertices,
    ARRAY_COUNT(gameplay_dangeon_keep_Colheader_007498Polygons), gameplay_dangeon_keep_Colheader_007498Polygons,
    gameplay_dangeon_keep_Colheader_007498SurfaceType,
    gameplay_dangeon_keep_Colheader_007498CamDataList,
    0, NULL
};

u8 gameplay_dangeon_keep_possiblePadding_0074C4[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx gameplay_dangeon_keepVtx_0074D0[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_0074D0.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_007650[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_00FEC0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 6, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPClearGeometryMode(G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_dangeon_keepVtx_0074D0, 24, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
    gsSPEndDisplayList(),
};

u8 gameplay_dangeon_keep_possiblePadding_007708[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx gameplay_dangeon_keepVtx_007710[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_007710.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_007890[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_0122C0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_MIRROR |
                         G_TX_WRAP, G_TX_MIRROR | G_TX_WRAP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_dangeon_keepVtx_007710, 24, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 11, 9, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 15, 13, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
    gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
    gsSPEndDisplayList(),
};

u8 gameplay_dangeon_keep_possiblePadding_007948[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx gameplay_dangeon_keepVtx_007950[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_007950.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_007980[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_0132C0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 64, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 6, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsSPClearGeometryMode(G_CULL_BACK | G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_FOG),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_dangeon_keepVtx_007950, 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPEndDisplayList(),
};

Vtx gameplay_dangeon_keepVtx_007A10[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_007A10.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_007A50[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_013AC0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsSPClearGeometryMode(G_CULL_BACK | G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_FOG),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_dangeon_keepVtx_007A10, 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

Vtx gameplay_dangeon_keepVtx_007AE0[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_007AE0.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_007B20[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_0142C0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_MIRROR |
                         G_TX_WRAP, G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsSPClearGeometryMode(G_CULL_BACK | G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_FOG),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_dangeon_keepVtx_007AE0, 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

Vtx gameplay_dangeon_keepVtx_007BB0[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_007BB0.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_007BF0[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_0152C0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsSPClearGeometryMode(G_CULL_BACK | G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_FOG),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_dangeon_keepVtx_007BB0, 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

Vtx gameplay_dangeon_keepVtx_007C80[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_007C80.vtx.inc"
};

Gfx gRustyFloorSwitchDL[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_00DEC0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_MIRROR |
                         G_TX_WRAP, G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPClearGeometryMode(G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_dangeon_keepVtx_007C80, 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_00E6C0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_MIRROR |
                         G_TX_WRAP, G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_dangeon_keepVtx_007C80[4], 20, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSPEndDisplayList(),
};

CamData gFloorSwitchColCamDataList[] = {
    { 0x0000, 0, NULL },
};

SurfaceType gFloorSwitchColSurfaceType[] = {
    {0x00000000, 0x000007C2},
};

CollisionPoly gFloorSwitchColPolygons[] = {
    {0x0000, 0x2000, 0x0001, 0x0002, 0x0000, 0x7FFF, 0x0000, 0xFFF6},
    {0x0000, 0x2000, 0x0002, 0x0003, 0x0000, 0x7FFF, 0x0000, 0xFFF6},
    {0x0000, 0x2004, 0x0005, 0x0006, 0x0000, 0x7FFF, 0x0000, 0xFF92},
    {0x0000, 0x2004, 0x0006, 0x0007, 0x0000, 0x7FFF, 0x0000, 0xFF92},
    {0x0000, 0x2008, 0x0005, 0x0004, 0x5A82, 0x5A82, 0x0000, 0xFF6C},
    {0x0000, 0x2008, 0x0004, 0x0009, 0x5A82, 0x5A82, 0x0000, 0xFF6C},
    {0x0000, 0x200A, 0x0006, 0x0005, 0x0000, 0x5A82, 0xA57E, 0xFF6C},
    {0x0000, 0x200A, 0x0005, 0x0008, 0x0000, 0x5A82, 0xA57E, 0xFF6C},
    {0x0000, 0x200B, 0x0007, 0x0006, 0xA57E, 0x5A82, 0x0000, 0xFF6C},
    {0x0000, 0x200B, 0x0006, 0x000A, 0xA57E, 0x5A82, 0x0000, 0xFF6C},
    {0x0000, 0x2009, 0x0004, 0x0007, 0x0000, 0x5A82, 0x5A82, 0xFF6C},
    {0x0000, 0x2009, 0x0007, 0x000B, 0x0000, 0x5A82, 0x5A82, 0xFF6C},
};

Vec3s gFloorSwitchColVertices[] = {
    {    240,     10,    240 },
    {    240,     10,   -240 },
    {   -240,     10,   -240 },
    {   -240,     10,    240 },
    {    100,    110,    100 },
    {    100,    110,   -100 },
    {   -100,    110,   -100 },
    {   -100,    110,    100 },
    {    200,     10,   -200 },
    {    200,     10,    200 },
    {   -200,     10,   -200 },
    {   -200,     10,    200 },
};

CollisionHeader gFloorSwitchCol = { 
    { -240, 10, -240 },
    { 240, 110, 240 },
    ARRAY_COUNT(gFloorSwitchColVertices), gFloorSwitchColVertices,
    ARRAY_COUNT(gFloorSwitchColPolygons), gFloorSwitchColPolygons,
    gFloorSwitchColSurfaceType,
    gFloorSwitchColCamDataList,
    0, NULL
};

u8 gameplay_dangeon_keep_possiblePadding_008044[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx gameplay_dangeon_keepVtx_008050[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_008050.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_0081D0[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_0086C0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPClearGeometryMode(G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_dangeon_keepVtx_008050, 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_008EC0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_dangeon_keepVtx_008050[4], 20, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSPEndDisplayList(),
};

Vtx gameplay_dangeon_keepVtx_0082D0[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_0082D0.vtx.inc"
};

Gfx gEyeSwitchGoldDL[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0, 0, 0, G_TX_RENDERTILE, G_OFF),
    gsDPSetCombineLERP(SHADE, 0, PRIMITIVE, 0, 0, 0, 0, 1, 0, 0, 0, COMBINED, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPClearGeometryMode(G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_dangeon_keepVtx_0082D0, 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 9, 0, 12, 9, 8, 0),
    gsDPPipeSync(),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(0x08000000, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_MIRROR | G_TX_WRAP, G_TX_MIRROR |
                         G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsSPVertex(&gameplay_dangeon_keepVtx_0082D0[14], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

Vtx gameplay_dangeon_keepVtx_0084C0[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_0084C0.vtx.inc"
};

Gfx gEyeSwitchSilverDL[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0, 0, 0, G_TX_RENDERTILE, G_OFF),
    gsDPSetCombineLERP(SHADE, 0, PRIMITIVE, 0, 0, 0, 0, 1, 0, 0, 0, COMBINED, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPClearGeometryMode(G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_dangeon_keepVtx_0084C0, 15, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 1, 0, 4, 1, 6, 0),
    gsSP2Triangles(7, 8, 9, 0, 7, 9, 10, 0),
    gsSP2Triangles(11, 12, 13, 0, 11, 13, 14, 0),
    gsDPPipeSync(),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(0x08000000, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                         G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsSPVertex(&gameplay_dangeon_keepVtx_0084C0[15], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

u64 gameplay_dangeon_keep_Tex_0086C0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_0086C0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_008EC0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_008EC0.rgba16.inc.c"
};

u64 gEyeSwitchGoldClosedTex[] = {
#include "assets/objects/gameplay_dangeon_keep/eye_gold_closed.rgba16.inc.c"
};

u64 gEyeSwitchGoldOpeningTex[] = {
#include "assets/objects/gameplay_dangeon_keep/eye_gold_opening.rgba16.inc.c"
};

u64 gEyeSwitchGoldClosingTex[] = {
#include "assets/objects/gameplay_dangeon_keep/eye_gold_closing.rgba16.inc.c"
};

u64 gEyeSwitchGoldOpenTex[] = {
#include "assets/objects/gameplay_dangeon_keep/eye_gold_open.rgba16.inc.c"
};

u64 gEyeSwitchSilverOpenTex[] = {
#include "assets/objects/gameplay_dangeon_keep/eye_silver_open.rgba16.inc.c"
};

u64 gEyeSwitchSilverHalfTex[] = {
#include "assets/objects/gameplay_dangeon_keep/eye_silver_half.rgba16.inc.c"
};

u64 gEyeSwitchSilverClosedTex[] = {
#include "assets/objects/gameplay_dangeon_keep/eye_silver_closed.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_00CEC0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_00CEC0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_00D6C0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_00D6C0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_00DEC0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_00DEC0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_00E6C0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_00E6C0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_00EEC0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_00EEC0.i8.inc.c"
};

u64 gameplay_dangeon_keep_Tex_00F2C0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_00F2C0.i8.inc.c"
};

u64 gameplay_dangeon_keep_Tex_00F6C0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_00F6C0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_00FEC0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_00FEC0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_010EC0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_010EC0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_011EC0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_011EC0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_0120C0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_0120C0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_0122C0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_0122C0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_0132C0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_0132C0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_013AC0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_013AC0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_0142C0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_0142C0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_014AC0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_014AC0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_0152C0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_0152C0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_015AC0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_015AC0.i8.inc.c"
};

u64 gameplay_dangeon_keep_Tex_015EC0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_015EC0.i8.inc.c"
};

u64 gameplay_dangeon_keep_Tex_0162C0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_0162C0.i8.inc.c"
};

u64 gameplay_dangeon_keep_Tex_0172C0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_0172C0.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_017AC0[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_017AC0.ia16.inc.c"
};

Vtx gameplay_dangeon_keepVtx_017AE0[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_017AE0.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_017EA0[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_010EC0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_dangeon_keepVtx_017AE0, 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 2, 0),
    gsSP2Triangles(5, 6, 7, 0, 8, 9, 2, 0),
    gsSP2Triangles(1, 0, 10, 0, 1, 10, 11, 0),
    gsSP2Triangles(12, 13, 9, 0, 12, 9, 8, 0),
    gsSP2Triangles(14, 15, 4, 0, 14, 4, 3, 0),
    gsSP2Triangles(16, 17, 18, 0, 19, 20, 21, 0),
    gsSP2Triangles(22, 23, 24, 0, 25, 26, 27, 0),
    gsSP1Triangle(28, 29, 30, 0),
    gsSPVertex(&gameplay_dangeon_keepVtx_017AE0[31], 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_011EC0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsSPVertex(&gameplay_dangeon_keepVtx_017AE0[34], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_010EC0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPVertex(&gameplay_dangeon_keepVtx_017AE0[38], 22, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 1, 0),
    gsSP2Triangles(3, 1, 0, 0, 5, 6, 7, 0),
    gsSP2Triangles(8, 9, 2, 0, 10, 11, 9, 0),
    gsSP2Triangles(10, 9, 8, 0, 12, 13, 14, 0),
    gsSP2Triangles(15, 16, 2, 0, 16, 15, 17, 0),
    gsSP2Triangles(16, 17, 18, 0, 19, 20, 21, 0),
    gsSPEndDisplayList(),
};

Vtx gameplay_dangeon_keepVtx_018060[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_018060.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_018090[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_0120C0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsSPClearGeometryMode(G_CULL_BOTH | G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_FOG),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_dangeon_keepVtx_018060, 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPEndDisplayList(),
};

Vtx gameplay_dangeon_keepVtx_018120[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_018120.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_0182A0[] = {
    gsSPEndDisplayList(),
};

Gfx gameplay_dangeon_keep_DL_0182A8[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(0x08000000, G_IM_FMT_I, G_IM_SIZ_8b, 64, 64, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR |
                         G_TX_WRAP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(gameplay_dangeon_keepVtx_018120, 24, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
    gsSPEndDisplayList(),
};

u64 gameplay_dangeon_keep_Tex_018350[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_018350.i8.inc.c"
};

u64 gameplay_dangeon_keep_Tex_019350[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_019350.i8.inc.c"
};

u64 gameplay_dangeon_keep_Tex_01A350[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_01A350.i8.inc.c"
};

TexturePtr gameplay_dangeon_keepTexCycleTexPtrs_01B350[] = {
    gameplay_dangeon_keep_Tex_018350,
    gameplay_dangeon_keep_Tex_019350,
    gameplay_dangeon_keep_Tex_01A350,
};

u8 gameplay_dangeon_keepTexCycleTexIndices_01B35C[] = {
    0, 1, 2,
};

AnimatedMatTexCycleParams gameplay_dangeon_keep_Matanimheader_01B370TexCycleParams_01B360 = { 
    3, gameplay_dangeon_keepTexCycleTexPtrs_01B350, gameplay_dangeon_keepTexCycleTexIndices_01B35C,
};

u8 gameplay_dangeon_keep_possiblePadding_01B36C[] = {
    0x00, 0x00, 0x00, 0x00, 
};

AnimatedMaterial gameplay_dangeon_keep_Matanimheader_01B370[] = {
    { -1, 5, &gameplay_dangeon_keep_Matanimheader_01B370TexCycleParams_01B360 },
};

u8 gameplay_dangeon_keep_possiblePadding_01B378[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx gameplay_dangeon_keepVtx_01B380[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_01B380.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_01B500[] = {
    gsSPEndDisplayList(),
};

Gfx gFloorSwitch1DL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_015EC0, G_IM_FMT_I, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(gameplay_dangeon_keepVtx_01B380, 20, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_015AC0, G_IM_FMT_I, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_dangeon_keepVtx_01B380[20], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

Vtx gameplay_dangeon_keepVtx_01B600[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_01B600.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_01B780[] = {
    gsSPEndDisplayList(),
};

Gfx gFloorSwitch2DL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_015EC0, G_IM_FMT_I, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 178, 178, 178, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(gameplay_dangeon_keepVtx_01B600, 20, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_015AC0, G_IM_FMT_I, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_dangeon_keepVtx_01B600[20], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

u8 gameplay_dangeon_keep_possiblePadding_01B888[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx gameplay_dangeon_keepVtx_01B890[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_01B890.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_01B9F0[] = {
    gsSPEndDisplayList(),
};

Gfx gFloorSwitch3DL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_015EC0, G_IM_FMT_I, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 178, 178, 178, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(gameplay_dangeon_keepVtx_01B890, 18, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(11, 12, 13, 0, 11, 13, 14, 0),
    gsSP2Triangles(15, 16, 17, 0, 15, 17, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_015AC0, G_IM_FMT_I, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_dangeon_keepVtx_01B890[18], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

u8 gameplay_dangeon_keep_possiblePadding_01BAF8[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx gameplay_dangeon_keepVtx_01BB00[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_01BB00.vtx.inc"
};

Gfx gCrystalSwitchCoreDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineMode(G_CC_TEMPLERP, G_CC_MODULATEIA_PRIM2),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_0172C0, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock(gameplay_dangeon_keep_Tex_0172C0, 0x0000, 1, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0,
                       G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, 15),
    gsSPDisplayList(0x08000000),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(gameplay_dangeon_keepVtx_01BB00, 18, 0),
    gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 8, 6, 0),
    gsSP2Triangles(9, 10, 11, 0, 9, 12, 13, 0),
    gsSP2Triangles(14, 15, 16, 0, 14, 1, 17, 0),
    gsSPEndDisplayList(),
};

Gfx gCrystalSwitchDiamondDL[] = {
    gsSPTexture(0x2710, 0x2710, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_XLU_SURF2),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_017AC0, G_IM_FMT_IA, G_IM_SIZ_16b, 4, 4, 0, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 2, 2, 2, 2),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR |
                         G_SHADING_SMOOTH),
    gsSPVertex(&gameplay_dangeon_keepVtx_01BB00[18], 24, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
    gsSP2Triangles(18, 19, 20, 0, 21, 22, 23, 0),
    gsSPEndDisplayList(),
};

Gfx gCrystalSwitchBaseDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_0162C0, G_IM_FMT_I, G_IM_SIZ_8b, 64, 64, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_WRAP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(&gameplay_dangeon_keepVtx_01BB00[42], 20, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSPEndDisplayList(),
};

u8 gameplay_dangeon_keep_possiblePadding_01C108[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

AnimatedMatTexScrollParams gCrystalSwitchTexAnimTexScrollParams_01C110[] = {
    { -1, -1, 0x20, 0x20 },
    { 1, 1, 0x20, 0x20 },
};

AnimatedMaterial gCrystalSwitchTexAnim[] = {
    { -1, 1, gCrystalSwitchTexAnimTexScrollParams_01C110 },
};

Vtx gameplay_dangeon_keepVtx_01C120[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_01C120.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_01C220[] = {
    gsSPEndDisplayList(),
};

Gfx gameplay_dangeon_keep_DL_01C228[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gameplay_dangeon_keep_Tex_01C2D8, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_MIRROR |
                         G_TX_WRAP, G_TX_MIRROR | G_TX_WRAP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(gameplay_dangeon_keepVtx_01C120, 16, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(7, 6, 8, 0, 7, 8, 9, 0),
    gsSP2Triangles(3, 2, 10, 0, 3, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 15, 13, 0),
    gsSP2Triangles(14, 0, 12, 0, 0, 15, 12, 0),
    gsSPEndDisplayList(),
};

u64 gameplay_dangeon_keep_Tex_01C2D8[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_01C2D8.rgba16.inc.c"
};

u8 gameplay_dangeon_keep_possiblePadding_01D2D8[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

CamData gameplay_dangeon_keep_Colheader_01D488CamDataList[] = {
    { 0x0000, 0, NULL },
};

SurfaceType gameplay_dangeon_keep_Colheader_01D488SurfaceType[] = {
    {0x00E00000, 0x000007C2},   {0x00200000, 0x000007C2},
};

CollisionPoly gameplay_dangeon_keep_Colheader_01D488Polygons[] = {
    {0x0000, 0x2000, 0x0001, 0x0004, 0x0000, 0x0000, 0x7FFF, 0xFED4},
    {0x0000, 0x2001, 0x0005, 0x0004, 0x0000, 0x0000, 0x7FFF, 0xFED4},
    {0x0000, 0x2001, 0x0002, 0x0005, 0x7FFF, 0x0000, 0x0000, 0xFED4},
    {0x0000, 0x2002, 0x0006, 0x0005, 0x7FFF, 0x0000, 0x0000, 0xFED4},
    {0x0000, 0x2002, 0x0003, 0x0006, 0x0000, 0x0000, 0x8001, 0xFED4},
    {0x0000, 0x2003, 0x0007, 0x0006, 0x0000, 0x0000, 0x8001, 0xFED4},
    {0x0000, 0x2003, 0x0000, 0x0007, 0x8001, 0x0000, 0x0000, 0xFED4},
    {0x0000, 0x2000, 0x0004, 0x0007, 0x8001, 0x0000, 0x0000, 0xFED4},
    {0x0001, 0x2004, 0x0005, 0x0008, 0x0000, 0x6A80, 0x4700, 0xFD66},
    {0x0001, 0x2005, 0x0006, 0x0008, 0x4700, 0x6A80, 0x0000, 0xFD66},
    {0x0001, 0x2006, 0x0007, 0x0008, 0x0000, 0x6A80, 0xB900, 0xFD66},
    {0x0001, 0x2007, 0x0004, 0x0008, 0xB900, 0x6A80, 0x0000, 0xFD66},
    {0x0001, 0xA004, 0x8005, 0x0009, 0x0000, 0x0000, 0x7FFF, 0xFED4},
    {0x0001, 0xA005, 0x800A, 0x0009, 0x0000, 0x0000, 0x7FFF, 0xFED4},
    {0x0001, 0xA005, 0x8006, 0x000A, 0x7FFF, 0x0000, 0x0000, 0xFED4},
    {0x0001, 0xA006, 0x800B, 0x000A, 0x7FFF, 0x0000, 0x0000, 0xFED4},
    {0x0001, 0xA006, 0x8007, 0x000B, 0x0000, 0x0000, 0x8001, 0xFED4},
    {0x0001, 0xA007, 0x800C, 0x000B, 0x0000, 0x0000, 0x8001, 0xFED4},
    {0x0001, 0xA007, 0x8004, 0x000C, 0x8001, 0x0000, 0x0000, 0xFED4},
    {0x0001, 0xA004, 0x8009, 0x000C, 0x8001, 0x0000, 0x0000, 0xFED4},
};

Vec3s gameplay_dangeon_keep_Colheader_01D488Vertices[] = {
    {   -300,      0,    300 },
    {    300,      0,    300 },
    {    300,      0,   -300 },
    {   -300,      0,   -300 },
    {   -300,    600,    300 },
    {    300,    600,    300 },
    {    300,    600,   -300 },
    {   -300,    600,   -300 },
    {      0,    800,      0 },
    {   -300,   1600,    300 },
    {    300,   1600,    300 },
    {    300,   1600,   -300 },
    {   -300,   1600,   -300 },
};

CollisionHeader gameplay_dangeon_keep_Colheader_01D488 = { 
    { -300, 0, -300 },
    { 300, 1600, 300 },
    ARRAY_COUNT(gameplay_dangeon_keep_Colheader_01D488Vertices), gameplay_dangeon_keep_Colheader_01D488Vertices,
    ARRAY_COUNT(gameplay_dangeon_keep_Colheader_01D488Polygons), gameplay_dangeon_keep_Colheader_01D488Polygons,
    gameplay_dangeon_keep_Colheader_01D488SurfaceType,
    gameplay_dangeon_keep_Colheader_01D488CamDataList,
    0, NULL
};

u8 gameplay_dangeon_keep_possiblePadding_01D4B4[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx gameplay_dangeon_keepVtx_01D4C0[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_01D4C0.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_01D980[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL1, 0, TEXEL0, 0, TEXEL1, TEXEL0, PRIM_LOD_FRAC, TEXEL0, COMBINED, 0, SHADE, 0, COMBINED, 0,
                       PRIMITIVE, 0),
    gsDPSetPrimColor(0, 0xFF, 255, 255, 255, 255),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock_4b(gameplay_dangeon_keep_Tex_01F470, G_IM_FMT_I, 64, 64, 15, G_TX_NOMIRROR | G_TX_WRAP,
                            G_TX_NOMIRROR | G_TX_WRAP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock(gameplay_dangeon_keep_Tex_01DC70, 0x0100, 1, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0,
                       G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 5, 1, 1),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(gameplay_dangeon_keepVtx_01D4C0, 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 1, 0, 4, 1, 6, 0),
    gsSP2Triangles(7, 8, 9, 0, 7, 9, 10, 0),
    gsSP2Triangles(11, 12, 13, 0, 11, 13, 14, 0),
    gsSP2Triangles(15, 16, 17, 0, 16, 18, 17, 0),
    gsSP2Triangles(19, 18, 20, 0, 19, 20, 21, 0),
    gsSP2Triangles(22, 23, 24, 0, 23, 25, 24, 0),
    gsSP2Triangles(25, 26, 27, 0, 28, 25, 27, 0),
    gsSP1Triangle(29, 30, 31, 0),
    gsSPVertex(&gameplay_dangeon_keepVtx_01D4C0[32], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 2, 0),
    gsSP1Triangle(3, 2, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock_4b(gameplay_dangeon_keep_Tex_020C70, G_IM_FMT_I, 64, 64, 15, G_TX_NOMIRROR | G_TX_WRAP,
                            G_TX_NOMIRROR | G_TX_WRAP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock(gameplay_dangeon_keep_Tex_01EC70, 0x0100, 1, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0,
                       G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_dangeon_keepVtx_01D4C0[38], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock_4b(gameplay_dangeon_keep_Tex_020470, G_IM_FMT_I, 64, 64, 15, G_TX_NOMIRROR | G_TX_WRAP,
                            G_TX_NOMIRROR | G_TX_WRAP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock(gameplay_dangeon_keep_Tex_01E470, 0x0100, 1, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0,
                       G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 5, 1, 1),
    gsSPVertex(&gameplay_dangeon_keepVtx_01D4C0[42], 30, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSP2Triangles(3, 0, 4, 0, 5, 6, 7, 0),
    gsSP2Triangles(5, 7, 8, 0, 7, 6, 9, 0),
    gsSP2Triangles(10, 11, 12, 0, 13, 11, 10, 0),
    gsSP2Triangles(13, 10, 14, 0, 15, 16, 17, 0),
    gsSP2Triangles(15, 17, 18, 0, 17, 16, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 23, 21, 20, 0),
    gsSP2Triangles(23, 20, 24, 0, 25, 26, 27, 0),
    gsSP2Triangles(25, 27, 28, 0, 27, 26, 29, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock_4b(gameplay_dangeon_keep_Tex_01FC70, G_IM_FMT_I, 64, 64, 15, G_TX_NOMIRROR | G_TX_WRAP,
                            G_TX_NOMIRROR | G_TX_WRAP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock(gameplay_dangeon_keep_Tex_01E470, 0x0100, 1, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0,
                       G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 5, 1, 1),
    gsSPVertex(&gameplay_dangeon_keepVtx_01D4C0[72], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

u64 gameplay_dangeon_keep_Tex_01DC70[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_01DC70.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_01E470[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_01E470.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_01EC70[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_01EC70.rgba16.inc.c"
};

u64 gameplay_dangeon_keep_Tex_01F470[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_01F470.i4.inc.c"
};

u64 gameplay_dangeon_keep_Tex_01FC70[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_01FC70.i4.inc.c"
};

u64 gameplay_dangeon_keep_Tex_020470[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_020470.i4.inc.c"
};

u64 gameplay_dangeon_keep_Tex_020C70[] = {
#include "assets/objects/gameplay_dangeon_keep/tex_020C70.i4.inc.c"
};

Vtx gameplay_dangeon_keepVtx_021470[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_021470.vtx.inc"
};

Gfx gameplay_dangeon_keep_DL_0219E0[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL1, 0, TEXEL0, 0, TEXEL1, TEXEL0, PRIM_LOD_FRAC, TEXEL0, COMBINED, 0, SHADE, 0, COMBINED, 0,
                       PRIMITIVE, 0),
    gsDPSetPrimColor(0, 0xFF, 255, 255, 255, 255),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock_4b(gameplay_dangeon_keep_Tex_01F470, G_IM_FMT_I, 64, 64, 15, G_TX_NOMIRROR | G_TX_WRAP,
                            G_TX_NOMIRROR | G_TX_WRAP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock(gameplay_dangeon_keep_Tex_01DC70, 0x0100, 1, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0,
                       G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 5, 1, 1),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(gameplay_dangeon_keepVtx_021470, 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 2, 5, 0, 4, 5, 6, 0),
    gsSP2Triangles(7, 8, 9, 0, 7, 9, 10, 0),
    gsSP2Triangles(11, 12, 13, 0, 11, 13, 14, 0),
    gsSP2Triangles(15, 16, 17, 0, 15, 9, 16, 0),
    gsSP2Triangles(18, 19, 20, 0, 18, 20, 21, 0),
    gsSP2Triangles(22, 23, 24, 0, 22, 20, 23, 0),
    gsSP2Triangles(25, 26, 27, 0, 25, 27, 28, 0),
    gsSP1Triangle(29, 30, 31, 0),
    gsSPVertex(&gameplay_dangeon_keepVtx_021470[32], 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock_4b(gameplay_dangeon_keep_Tex_020C70, G_IM_FMT_I, 64, 64, 15, G_TX_NOMIRROR | G_TX_WRAP,
                            G_TX_NOMIRROR | G_TX_WRAP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock(gameplay_dangeon_keep_Tex_01EC70, 0x0100, 1, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0,
                       G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_dangeon_keepVtx_021470[35], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock_4b(gameplay_dangeon_keep_Tex_020470, G_IM_FMT_I, 64, 64, 15, G_TX_NOMIRROR | G_TX_WRAP,
                            G_TX_NOMIRROR | G_TX_WRAP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock(gameplay_dangeon_keep_Tex_01E470, 0x0100, 1, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0,
                       G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 5, 1, 1),
    gsSPVertex(&gameplay_dangeon_keepVtx_021470[39], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(3, 5, 6, 0, 7, 8, 9, 0),
    gsSP2Triangles(7, 9, 10, 0, 9, 8, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 13, 12, 0),
    gsSP2Triangles(15, 12, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(17, 19, 20, 0, 19, 18, 21, 0),
    gsSP2Triangles(22, 23, 24, 0, 25, 23, 22, 0),
    gsSP2Triangles(25, 22, 26, 0, 27, 28, 29, 0),
    gsSP2Triangles(27, 29, 30, 0, 29, 28, 31, 0),
    gsSPVertex(&gameplay_dangeon_keepVtx_021470[71], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock_4b(gameplay_dangeon_keep_Tex_01FC70, G_IM_FMT_I, 64, 64, 15, G_TX_NOMIRROR | G_TX_WRAP,
                            G_TX_NOMIRROR | G_TX_WRAP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock(gameplay_dangeon_keep_Tex_01E470, 0x0100, 1, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0,
                       G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 5, 1, 1),
    gsSPVertex(&gameplay_dangeon_keepVtx_021470[75], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 5, 7, 6, 0),
    gsSP2Triangles(5, 8, 9, 0, 5, 9, 10, 0),
    gsSP2Triangles(11, 5, 10, 0, 5, 11, 7, 0),
    gsSPEndDisplayList(),
};

Vtx gameplay_dangeon_keepVtx_021CF0[] = {
#include "assets/objects/gameplay_dangeon_keep/gameplay_dangeon_keepVtx_021CF0.vtx.inc"
};

Gfx gWarpTagGoronTrialBaseDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetPrimColor(0, 0xFF, 255, 255, 255, 255),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gWarpTagRainbowTex, G_IM_FMT_RGBA, G_IM_SIZ_32b, 32, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPDisplayList(0x08000000),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_SHADING_SMOOTH),
    gsSPVertex(&gameplay_dangeon_keepVtx_021CF0[19], 13, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 4, 7, 0, 8, 9, 6, 0),
    gsSP2Triangles(10, 11, 12, 0, 12, 9, 8, 0),
    gsSPVertex(gameplay_dangeon_keepVtx_021CF0, 19, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 0, 0, 4, 0, 6, 0),
    gsSP2Triangles(5, 7, 1, 0, 5, 1, 0, 0),
    gsSP2Triangles(8, 9, 5, 0, 8, 5, 4, 0),
    gsSP2Triangles(9, 10, 7, 0, 9, 7, 5, 0),
    gsSP2Triangles(11, 12, 9, 0, 11, 9, 8, 0),
    gsSP2Triangles(12, 13, 10, 0, 12, 10, 9, 0),
    gsSP2Triangles(14, 15, 12, 0, 14, 12, 11, 0),
    gsSP2Triangles(15, 16, 13, 0, 15, 13, 12, 0),
    gsSP2Triangles(17, 3, 15, 0, 17, 15, 14, 0),
    gsSP2Triangles(3, 2, 16, 0, 3, 16, 15, 0),
    gsSP2Triangles(6, 0, 3, 0, 6, 3, 18, 0),
    gsSPEndDisplayList(),
};

u64 gWarpTagRainbowTex[] = {
#include "assets/objects/gameplay_dangeon_keep/warptag_rainbow.rgba32.inc.c"
};

u8 gameplay_dangeon_keep_possiblePadding_022FF8[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

AnimatedMatTexScrollParams gWarpTagRainbowTexAnimTexScrollParams_023000[] = {
    { 0, 4, 0x20, 0x20 },
    { 0, 0, 0x20, 0x20 },
};

AnimatedMaterial gWarpTagRainbowTexAnim[] = {
    { -1, 1, gWarpTagRainbowTexAnimTexScrollParams_023000 },
};

CamData gWarpTagGoronTrialBaseColCamDataList[] = {
    { 0x0000, 0, NULL },
};

SurfaceType gWarpTagGoronTrialBaseColSurfaceType[] = {
    {0x00000000, 0x000007C0},
};

CollisionPoly gWarpTagGoronTrialBaseColPolygons[] = {
    {0x0000, 0x0000, 0x0001, 0x0002, 0xACAE, 0x5352, 0x31FE, 0x000C},
    {0x0000, 0x0000, 0x0002, 0x0003, 0xB5A0, 0x6011, 0x2849, 0x000A},
    {0x0000, 0x0004, 0x0003, 0x0002, 0x6653, 0x354B, 0xC893, 0xFFE7},
    {0x0000, 0x0004, 0x0002, 0x0005, 0x61AD, 0x3D0C, 0xC82F, 0xFFE8},
    {0x0000, 0x0002, 0x0001, 0x0006, 0xACAE, 0x5352, 0xCE02, 0x000C},
    {0x0000, 0x0002, 0x0006, 0x0007, 0xB5A0, 0x6011, 0xD7B7, 0x000A},
    {0x0000, 0x0002, 0x0007, 0x0008, 0x6653, 0x354B, 0x376D, 0xFFE7},
    {0x0000, 0x0002, 0x0008, 0x0005, 0x61AD, 0x3D0C, 0x37D1, 0xFFE8},
    {0x0000, 0x0006, 0x0009, 0x000A, 0x0000, 0x5A82, 0xA57E, 0x000B},
    {0x0000, 0x0006, 0x000A, 0x0007, 0x0000, 0x5A82, 0xA57E, 0x000B},
    {0x0000, 0x0008, 0x0007, 0x000A, 0x0000, 0x393E, 0x727C, 0xFFE7},
    {0x0000, 0x0008, 0x000A, 0x000B, 0x0000, 0x393E, 0x727C, 0xFFE7},
    {0x0000, 0x000A, 0x0009, 0x000C, 0x47C0, 0x60DC, 0xD4F3, 0x000A},
    {0x0000, 0x000A, 0x000C, 0x000D, 0x5485, 0x5485, 0xD238, 0x000D},
    {0x0000, 0x000A, 0x000D, 0x000E, 0x9D5E, 0x3DA5, 0x356D, 0xFFE7},
    {0x0000, 0x000A, 0x000E, 0x000B, 0x9B3C, 0x35FB, 0x3994, 0xFFE7},
    {0x0000, 0x000C, 0x000F, 0x0010, 0x47C0, 0x60DC, 0x2B0D, 0x000A},
    {0x0000, 0x000C, 0x0010, 0x000D, 0x5485, 0x5485, 0x2DC8, 0x000D},
    {0x0000, 0x000E, 0x000D, 0x0010, 0x9D5E, 0x3DA5, 0xCA93, 0xFFE7},
    {0x0000, 0x000E, 0x0010, 0x0011, 0x9B3C, 0x35FB, 0xC66C, 0xFFE7},
    {0x0000, 0x0010, 0x000F, 0x0000, 0x0000, 0x5A82, 0x5A82, 0x000B},
    {0x0000, 0x0010, 0x0000, 0x0003, 0x0000, 0x5A82, 0x5A82, 0x000B},
    {0x0000, 0x0010, 0x0003, 0x0004, 0x0000, 0x393E, 0x8D84, 0xFFE7},
    {0x0000, 0x0010, 0x0004, 0x0011, 0x0000, 0x393E, 0x8D84, 0xFFE7},
    {0x0000, 0x000F, 0x000C, 0x0000, 0x0000, 0x7FFF, 0x0000, 0xFFFC},
    {0x0000, 0x000C, 0x0006, 0x0000, 0x0000, 0x7FFF, 0x0000, 0xFFFC},
    {0x0000, 0x0006, 0x0001, 0x0000, 0x0000, 0x7FFF, 0x0000, 0xFFFC},
    {0x0000, 0x000C, 0x0009, 0x0006, 0x0000, 0x7FFF, 0x0000, 0xFFFC},
};

Vec3s gWarpTagGoronTrialBaseColVertices[] = {
    {     11,      4,    -20 },
    {     23,      4,      0 },
    {     27,      8,      0 },
    {     14,      8,    -24 },
    {     16,      0,    -28 },
    {     32,      0,      0 },
    {     11,      4,     20 },
    {     14,      8,     24 },
    {     16,      0,     28 },
    {    -11,      4,     20 },
    {    -14,      8,     24 },
    {    -16,      0,     28 },
    {    -23,      4,      0 },
    {    -27,      8,      0 },
    {    -32,      0,      0 },
    {    -11,      4,    -20 },
    {    -14,      8,    -24 },
    {    -16,      0,    -28 },
};

CollisionHeader gWarpTagGoronTrialBaseCol = { 
    { -32, 0, -28 },
    { 32, 8, 28 },
    ARRAY_COUNT(gWarpTagGoronTrialBaseColVertices), gWarpTagGoronTrialBaseColVertices,
    ARRAY_COUNT(gWarpTagGoronTrialBaseColPolygons), gWarpTagGoronTrialBaseColPolygons,
    gWarpTagGoronTrialBaseColSurfaceType,
    gWarpTagGoronTrialBaseColCamDataList,
    0, NULL
};

