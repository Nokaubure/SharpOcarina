#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_bg.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

s16 object_bg_Anim_000968FrameData[] = {
    0x0004, 0x0C7F, 0x0000, 0xF2DF, 0xC000, 0x1AB7, 0xF7BD, 0xD555, 0xDAE8, 0xDD7A, 0xC386, 0x2000, 0x4000, 0xE000, 
    0x3D66, 0x8082, 0x0437, 0x041D, 0x03B8, 0x031C, 0x025B, 0x0186, 0x00B0, 0xFFEA, 0xFF48, 0xFEDB, 0xFE97, 0xFE65, 
    0xFE43, 0xFE32, 0xFE32, 0xFE43, 0xFE65, 0xFE97, 0xFEDB, 0xFF49, 0xFFED, 0x00B5, 0x018E, 0x0265, 0x0328, 0x03C3, 
    0x0424, 0x0437, 0x0422, 0x0413, 0x040B, 0x0408, 0x040A, 0x0410, 0x041B, 0x0428, 0x3A34, 0x3AAF, 0x3BF8, 0x3DDB, 
    0x4025, 0x42A2, 0x451F, 0x4768, 0x4949, 0x4A91, 0x4B60, 0x4BFB, 0x4C62, 0x4C96, 0x4C96, 0x4C62, 0x4BFB, 0x4B60, 
    0x4A91, 0x4949, 0x4768, 0x451F, 0x42A2, 0x4025, 0x3DDB, 0x3BF8, 0x3AAF, 0x3A34, 0x3A31, 0x3A2E, 0x3A2D, 0x3A2C, 
    0x3A2C, 0x3A2D, 0x3A2F, 0x3A31, 0xF082, 0xF0BA, 0xF111, 0xF180, 0xF1FE, 0xF281, 0xF301, 0xF376, 0xF3D7, 0xF41B, 
    0xF449, 0xF46B, 0xF482, 0xF48D, 0xF48D, 0xF482, 0xF46B, 0xF449, 0xF41B, 0xF3D9, 0xF37D, 0xF30E, 0xF294, 0xF216, 
    0xF19B, 0xF12A, 0xF0C9, 0xF082, 0xF051, 0xF02F, 0xF01C, 0xF016, 0xF01B, 0xF02A, 0xF041, 0xF05E, 0xFF0E, 0xFEAE, 
    0xFDE7, 0xFCD4, 0xFB8F, 0xFA32, 0xF8D8, 0xF79B, 0xF696, 0xF5E2, 0xF56E, 0xF517, 0xF4DD, 0xF4C0, 0xF4C0, 0xF4DD, 
    0xF517, 0xF56E, 0xF5E2, 0xF695, 0xF79A, 0xF8D6, 0xFA2E, 0xFB8A, 0xFCCF, 0xFDE2, 0xFEAB, 0xFF0E, 0xFF32, 0xFF4C, 
    0xFF5D, 0xFF64, 0xFF64, 0xFF5A, 0xFF49, 0xFF2F, 0x0E11, 0x0D35, 0x0B25, 0x082D, 0x049D, 0x00C2, 0xFCE9, 0xF962, 
    0xF679, 0xF47D, 0xF33A, 0xF247, 0xF1A5, 0xF155, 0xF155, 0xF1A5, 0xF247, 0xF33A, 0xF47D, 0xF678, 0xF960, 0xFCE6, 
    0x00BC, 0x0496, 0x0826, 0x0B1E, 0x0D31, 0x0E11, 0x0E38, 0x0E55, 0x0E67, 0x0E6F, 0x0E6E, 0x0E63, 0x0E50, 0x0E34, 
    0x0FB3, 0x0EF7, 0x0DF0, 0x0CB4, 0x0B58, 0x09F1, 0x0895, 0x0758, 0x0651, 0x0595, 0x0515, 0x04B5, 0x0475, 0x0455, 
    0x0455, 0x0475, 0x04B5, 0x0515, 0x0595, 0x0651, 0x0758, 0x0895, 0x09F1, 0x0B58, 0x0CB4, 0x0DF0, 0x0EF7, 0x0FB3, 
    0x1033, 0x1093, 0x10D3, 0x10F3, 0x10F3, 0x10D3, 0x1093, 0x1033, 0xE899, 0xE916, 0xE9C5, 0xEA97, 0xEB7E, 0xEC6C, 
    0xED54, 0xEE26, 0xEED4, 0xEF51, 0xEFA6, 0xEFE6, 0xF010, 0xF026, 0xF026, 0xF010, 0xEFE6, 0xEFA6, 0xEF51, 0xEED4, 
    0xEE26, 0xED54, 0xEC6C, 0xEB7E, 0xEA97, 0xE9C5, 0xE916, 0xE899, 0xE844, 0xE804, 0xE7DA, 0xE7C5, 0xE7C5, 0xE7DA, 
    0xE804, 0xE844, 0xF127, 0xF2AA, 0xF4C5, 0xF74F, 0xFA19, 0xFCFA, 0xFFC5, 0x024E, 0x046A, 0x05EC, 0x06F3, 0x07B8, 
    0x083B, 0x087D, 0x087D, 0x083B, 0x07B8, 0x06F3, 0x05EC, 0x046A, 0x024E, 0xFFC5, 0xFCFA, 0xFA19, 0xF74F, 0xF4C5, 
    0xF2AA, 0xF127, 0xF021, 0xEF5C, 0xEED8, 0xEE97, 0xEE97, 0xEED8, 0xEF5C, 0xF021, 0xF72A, 0xF807, 0xF93D, 0xFAB2, 
    0xFC4C, 0xFDF1, 0xFF88, 0x00F5, 0x0220, 0x02EE, 0x0378, 0x03E9, 0x0440, 0x047C, 0x049D, 0x04A1, 0x0488, 0x0451, 
    0x03FB, 0x0384, 0x02EE, 0x01E3, 0x003B, 0xFE33, 0xFC09, 0xF9FB, 0xF847, 0xF72A, 0xF685, 0xF60D, 0xF5C0, 0xF59D, 
    0xF5A2, 0xF5CE, 0xF61F, 0xF693, 0x191C, 0x1932, 0x1952, 0x1977, 0x19A0, 0x19CA, 0x19F3, 0x1A17, 0x1A35, 0x1A4A, 
    0x1A58, 0x1A63, 0x1A6C, 0x1A72, 0x1A75, 0x1A75, 0x1A73, 0x1A6D, 0x1A65, 0x1A59, 0x1A4A, 0x1A2F, 0x1A05, 0x19D1, 
    0x1999, 0x1965, 0x1939, 0x191C, 0x190C, 0x1900, 0x18F8, 0x18F5, 0x18F5, 0x18FA, 0x1902, 0x190D, 0xF5B2, 0xF723, 
    0xF92A, 0xFB9A, 0xFE49, 0x010A, 0x03B2, 0x0616, 0x080A, 0x0963, 0x0A4A, 0x0B07, 0x0B99, 0x0BFE, 0x0C35, 0x0C3C, 
    0x0C12, 0x0BB5, 0x0B25, 0x0A5F, 0x0963, 0x07A4, 0x04DE, 0x0178, 0xFDD9, 0xFA68, 0xF78E, 0xF5B2, 0xF49D, 0xF3D4, 
    0xF353, 0xF318, 0xF321, 0xF36A, 0xF3F2, 0xF4B5, 0xFFAE, 0xFDBE, 0xFA39, 0xF588, 0xF015, 0xEA4A, 0xE493, 0xDF59, 
    0xDB07, 0xD807, 0xD611, 0xD499, 0xD39F, 0xD321, 0xD321, 0xD39F, 0xD499, 0xD611, 0xD807, 0xDB05, 0xDF53, 0xE488, 
    0xEA3A, 0xF000, 0xF571, 0xFA24, 0xFDB1, 0xFFAE, 0x009F, 0x0151, 0x01C5, 0x01FD, 0x01F9, 0x01BA, 0x0143, 0x0093, 
    0xFE38, 0xFF31, 0x00A6, 0x0275, 0x047C, 0x0697, 0x08A6, 0x0A85, 0x0C13, 0x0D2D, 0x0DEA, 0x0E78, 0x0ED7, 0x0F06, 
    0x0F06, 0x0ED7, 0x0E78, 0x0DEA, 0x0D2D, 0x0C15, 0x0A8D, 0x08B5, 0x06AD, 0x0497, 0x0293, 0x00C2, 0xFF43, 0xFE38, 
    0xFD8A, 0xFD0C, 0xFCBB, 0xFC96, 0xFC9C, 0xFCCA, 0xFD1F, 0xFD9A, 0x151D, 0x1793, 0x1C94, 0x2378, 0x2B97, 0x344C, 
    0x3CEE, 0x44D6, 0x4B5E, 0x4FDD, 0x52C4, 0x54F1, 0x5664, 0x571E, 0x571E, 0x5664, 0x54F1, 0x52C4, 0x4FDD, 0x4B60, 
    0x44DD, 0x3CFB, 0x345F, 0x2BAF, 0x2391, 0x1CAB, 0x17A2, 0x151D, 0x1431, 0x1383, 0x1312, 0x12DC, 0x12E1, 0x131E, 
    0x1393, 0x143E, 0xEAE2, 0xEAD0, 0xEA9B, 0xEA49, 0xE9DD, 0xE95C, 0xE8CA, 0xE82B, 0xE784, 0xE6D8, 0xE62D, 0xE585, 
    0xE4E7, 0xE455, 0xE3D3, 0xE368, 0xE315, 0xE2E1, 0xE2CF, 0xE2E1, 0xE315, 0xE368, 0xE3D3, 0xE455, 0xE4E7, 0xE585, 
    0xE62D, 0xE6D8, 0xE784, 0xE82B, 0xE8CA, 0xE95C, 0xE9DD, 0xEA49, 0xEA9B, 0xEAD0, 0x112E, 0x119F, 0x1230, 0x12DE, 
    0x13A3, 0x147B, 0x1560, 0x164F, 0x1742, 0x1834, 0x1921, 0x1A04, 0x1AD9, 0x1B99, 0x1C42, 0x1CCD, 0x1D37, 0x1D7A, 
    0x1D92, 0x1D30, 0x1C27, 0x1AA4, 0x18D2, 0x16DF, 0x14F6, 0x1345, 0x11F7, 0x1139, 0x10DE, 0x109A, 0x106D, 0x1058, 
    0x1058, 0x106E, 0x1099, 0x10DA, 0x1136, 0x10D3, 0x105D, 0x0FD9, 0x0F49, 0x0EB0, 0x0E11, 0x0D6E, 0x0CCA, 0x0C28, 
    0x0B8C, 0x0AF7, 0x0A6D, 0x09F0, 0x0984, 0x092B, 0x08E8, 0x08BE, 0x08B0, 0x08D7, 0x0942, 0x09E5, 0x0AB4, 0x0BA1, 
    0x0CA1, 0x0DA6, 0x0EA4, 0x0F8F, 0x1059, 0x10F6, 0x115D, 0x119E, 0x11C1, 0x11C9, 0x11B3, 0x1182, 0xF393, 0xF5C6, 
    0xF906, 0xFD08, 0x0182, 0x0628, 0x0AB0, 0x0ED0, 0x123C, 0x14AB, 0x164D, 0x1787, 0x1858, 0x18C1, 0x18C1, 0x1858, 
    0x1787, 0x164D, 0x14AB, 0x123C, 0x0ECF, 0x0AAE, 0x0625, 0x017E, 0xFD05, 0xF903, 0xF5C4, 0xF393, 0xF22E, 0xF122, 
    0xF06F, 0xF015, 0xF014, 0xF06D, 0xF120, 0xF22C, 0xFEDE, 0x003F, 0x01B1, 0x032C, 0x04A3, 0x060C, 0x075C, 0x0888, 
    0x0985, 0x0A48, 0x0AD8, 0x0B44, 0x0B8D, 0x0BB1, 0x0BB1, 0x0B8D, 0x0B44, 0x0AD8, 0x0A48, 0x0985, 0x0887, 0x075A, 
    0x0609, 0x049F, 0x0328, 0x01AD, 0x003C, 0xFEDE, 0xFDB4, 0xFCD3, 0xFC3C, 0xFBF1, 0xFBF0, 0xFC3A, 0xFCD0, 0xFDB1, 
    0xDEC1, 0xDCB2, 0xD903, 0xD421, 0xCE79, 0xC879, 0xC28D, 0xBD24, 0xB8AB, 0xB58E, 0xB385, 0xB1FE, 0xB0FA, 0xB078, 
    0xB078, 0xB0FA, 0xB1FE, 0xB385, 0xB58E, 0xB8AA, 0xBD22, 0xC289, 0xC872, 0xCE71, 0xD418, 0xD8FB, 0xDCAD, 0xDEC1, 
    0xDFC1, 0xE080, 0xE0FF, 0xE13D, 0xE13B, 0xE0FA, 0xE07A, 0xDFBD, 0x0CC6, 0x0CC8, 0x0CCD, 0x0CD8, 0x0CE8, 0x0CFF, 
    0x0D1E, 0x0D46, 0x0D78, 0x0DB4, 0x0E0E, 0x0E8D, 0x0F25, 0x0FC9, 0x106C, 0x1101, 0x117C, 0x11CF, 0x11ED, 0x11CF, 
    0x117D, 0x1103, 0x106F, 0x0FCD, 0x0F29, 0x0E90, 0x0E10, 0x0DB3, 0x0D74, 0x0D41, 0x0D19, 0x0CFA, 0x0CE4, 0x0CD5, 
    0x0CCC, 0x0CC7, 0x01E9, 0x01E9, 0x01EC, 0x01F3, 0x0201, 0x0216, 0x0235, 0x025E, 0x0293, 0x02D7, 0x0370, 0x048C, 
    0x0604, 0x07B1, 0x096C, 0x0B0F, 0x0C71, 0x0D6D, 0x0DDB, 0x0D97, 0x0CB3, 0x0B59, 0x09B4, 0x07EF, 0x0634, 0x04AD, 
    0x0386, 0x02E9, 0x02A6, 0x0270, 0x0245, 0x0224, 0x020C, 0x01FB, 0x01F1, 0x01EB, 0xEDE1, 0xEE70, 0xEF1F, 0xEFE9, 
    0xF0CA, 0xF1BB, 0xF2B9, 0xF3BE, 0xF4C5, 0xF5CB, 0xF6C9, 0xF7BC, 0xF89D, 0xF969, 0xFA1A, 0xFAAC, 0xFB1A, 0xFB5F, 
    0xFB76, 0xFB05, 0xF9DA, 0xF825, 0xF61A, 0xF3EB, 0xF1C9, 0xEFE7, 0xEE78, 0xEDAD, 0xED50, 0xED09, 0xECD9, 0xECC2, 
    0xECC3, 0xECE0, 0xED18, 0xED6D, 0x0000, 0x0000, 0x0000, 0x0001, 0xFFEC, 0xFF8A, 0xFEF9, 0xFE50, 0xFDAF, 0xFD35, 
    0xFCE4, 0xFCA4, 0xFC78, 0xFC62, 0xFC62, 0xFC78, 0xFCA4, 0xFCE4, 0xFD35, 0xFDAF, 0xFE50, 0xFEF8, 0xFF89, 0xFFEC, 
    0x0001, 0x0000, 0x0003, 0x0003, 0x0003, 0x0000, 0x0000, 0x0003, 0x0000, 0x0003, 0x0003, 0x0003, 0xFBFB, 0xFC5F, 
    0xFD62, 0xFEDF, 0x00AD, 0x029F, 0x0488, 0x0642, 0x07A8, 0x0898, 0x092E, 0x099E, 0x09E8, 0x0A0D, 0x0A0D, 0x09E8, 
    0x099E, 0x092E, 0x0898, 0x07A8, 0x0643, 0x0489, 0x02A1, 0x00B0, 0xFEE2, 0xFD65, 0xFC60, 0xFBFB, 0xFBF3, 0xFBED, 
    0xFBEA, 0xFBE9, 0xFBE9, 0xFBEC, 0xFBEF, 0xFBF5, 0xB5F4, 0xB5FE, 0xB617, 0xB612, 0xB1B1, 0xAF2D, 0xAD1F, 0xAB5B, 
    0xA9ED, 0xA8F3, 0xA854, 0xA7DB, 0xA78B, 0xA762, 0xA762, 0xA78B, 0xA7DB, 0xA854, 0xA8F3, 0xA9ED, 0xAB5B, 0xAD1F, 
    0xAF2D, 0xB1AE, 0xB612, 0xB618, 0xB5DC, 0xB5D3, 0xB5D2, 0xB5F4, 0xB5F4, 0xB5D2, 0xB5F4, 0xB5D2, 0xB5D2, 0xB5D2, 
    0x0000, 0x0000, 0x0000, 0x0037, 0x076F, 0x0B81, 0x0EA9, 0x1132, 0x131E, 0x145D, 0x1521, 0x15B2, 0x1611, 0x1640, 
    0x1640, 0x1611, 0x15B2, 0x1521, 0x145D, 0x131F, 0x1133, 0x0EAB, 0x0B84, 0x0776, 0x0037, 0x0000, 0x0037, 0x0036, 
    0x0037, 0x0000, 0x0000, 0x0036, 0x0000, 0x0036, 0x0037, 0x0036, 0x00DB, 0x00BD, 0x0076, 0x0026, 0xFFF8, 0xFFFE, 
    0xFFFC, 0x0000, 0x0000, 0xFFF9, 0x0000, 0xFFF8, 0x0000, 0xFFF7, 0xFFF7, 0x0000, 0x0000, 0x0000, 0x0000, 0xFFF9, 
    0x0000, 0xFFFC, 0x0000, 0xFFF8, 0x0025, 0x0076, 0x00BC, 0x00DB, 0x00DD, 0x00DF, 0x00E0, 0x00E0, 0x00E0, 0x00DF, 
    0x00DE, 0x00DD, 0xFC11, 0xFC72, 0xFD6F, 0xFEE6, 0x00B1, 0x02A6, 0x049A, 0x0663, 0x07DB, 0x08DA, 0x097B, 0x09F4, 
    0x0A44, 0x0A6C, 0x0A6C, 0x0A44, 0x09F4, 0x097B, 0x08DA, 0x07DB, 0x0664, 0x049B, 0x02A9, 0x00B4, 0xFEE9, 0xFD72, 
    0xFC74, 0xFC11, 0xFC09, 0xFC03, 0xFC00, 0xFBFF, 0xFBFF, 0xFC02, 0xFC05, 0xFC0A, 0xAC8A, 0xACFB, 0xAE34, 0xB037, 
    0xB3F0, 0xB5DA, 0xB5E8, 0xB607, 0xB5F9, 0xB5C8, 0xB5DE, 0xB5B1, 0xB5CC, 0xB5A5, 0xB5A5, 0xB5CC, 0xB5D3, 0xB5DE, 
    0xB5EA, 0xB5D7, 0xB608, 0xB5E8, 0xB5FB, 0xB3F8, 0xB03A, 0xAE35, 0xACFB, 0xAC8A, 0xAC87, 0xAC85, 0xAC84, 0xAC83, 
    0xAC83, 0xAC84, 0xAC85, 0xAC87, 0x0E0F, 0x0D73, 0x0BC0, 0x08D5, 0x031B, 0x0036, 0x0036, 0x0000, 0x0000, 0x0036, 
    0x0000, 0x0036, 0x0000, 0x0037, 0x0036, 0x0000, 0x0000, 0x0000, 0x0000, 0x0036, 0x0000, 0x0037, 0x0000, 0x030C, 
    0x08CF, 0x0BBC, 0x0D71, 0x0E0F, 0x0E1A, 0x0E21, 0x0E26, 0x0E27, 0x0E27, 0x0E24, 0x0E1F, 0x0E18, 
};

JointIndex object_bg_Anim_000968JointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0002, 0x0002, 0x0002 },
    { 0x0010, 0x0003, 0x0034 },
    { 0x0058, 0x007C, 0x00A0 },
    { 0x00C4, 0x00E8, 0x010C },
    { 0x0130, 0x0154, 0x0178 },
    { 0x0002, 0x0002, 0x0004 },
    { 0x0005, 0x0006, 0x0007 },
    { 0x019C, 0x01C0, 0x01E4 },
    { 0x0208, 0x022C, 0x0250 },
    { 0x0002, 0x0002, 0x0004 },
    { 0x0008, 0x0009, 0x000A },
    { 0x0274, 0x0298, 0x02BC },
    { 0x02E0, 0x0304, 0x0328 },
    { 0x000B, 0x000C, 0x000D },
    { 0x034C, 0x0370, 0x0394 },
    { 0x0002, 0x0002, 0x03B8 },
    { 0x0002, 0x0002, 0x000E },
    { 0x0002, 0x0002, 0x000F },
    { 0x000B, 0x000C, 0x000D },
    { 0x03DC, 0x0400, 0x0424 },
    { 0x0002, 0x0002, 0x0448 },
    { 0x0002, 0x0002, 0x000E },
    { 0x0002, 0x0002, 0x000F },
};

AnimationHeader object_bg_Anim_000968 = { 
    { 36 }, object_bg_Anim_000968FrameData,
    object_bg_Anim_000968JointIndices, 16
};

u8 object_bg_possiblePadding_000978[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 object_bg_Anim_000A00FrameData[] = {
    0x0004, 0x0C7F, 0x0000, 0xE8C7, 0x4000, 0x002B, 0xFFA3, 0xFAB1, 0x0128, 0xE3EE, 0xFF4F, 0xF615, 0x1E6C, 0xEC1D, 
    0xFD46, 0xDD6B, 0x9B4B, 0x9625, 0x060C, 0xFAC0, 0x1161, 0x2951, 0xF929, 0xF0E0, 0x6FF7, 0x7DC3, 0xCFCB, 0x76C4, 
    0xED42, 0x06E7, 
};

JointIndex object_bg_Anim_000A00JointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0002, 0x0003, 0x0004 },
    { 0x0005, 0x0006, 0x0007 },
    { 0x0008, 0x0009, 0x000A },
    { 0x000B, 0x000C, 0x000D },
    { 0x000E, 0x000F, 0x0010 },
    { 0x0002, 0x0011, 0x0012 },
    { 0x0013, 0x0014, 0x0015 },
    { 0x0016, 0x0017, 0x0018 },
    { 0x0019, 0x001A, 0x001B },
    { 0x001C, 0x0002, 0x001D },
};

AnimationHeader object_bg_Anim_000A00 = { 
    { 71 }, object_bg_Anim_000A00FrameData,
    object_bg_Anim_000A00JointIndices, 30
};

s16 object_bg_Anim_001384FrameData[] = {
    0x0004, 0x0C7F, 0x0000, 0xF23C, 0xEA43, 0xC000, 0x723C, 0xD044, 0x7ADD, 0x084B, 0xB7AC, 0x8839, 0xE9E4, 0x2000, 
    0x4000, 0xE000, 0x00F6, 0x3D66, 0x471C, 0x45EB, 0x4439, 0x4232, 0x4000, 0x3DCE, 0x3BC7, 0x3A15, 0x38E4, 0x381C, 
    0x378E, 0x3739, 0x371C, 0x3739, 0x378E, 0x381C, 0x38E4, 0x3A15, 0x3BC7, 0x3DCE, 0x4000, 0x4232, 0x4439, 0x45EB, 
    0x471C, 0x47E4, 0x4872, 0x48C7, 0x48E4, 0x48C7, 0x4872, 0x47E4, 0xFB1B, 0xFBF1, 0xFD20, 0xFE8B, 0x0014, 0x019D, 
    0x0308, 0x0438, 0x050E, 0x0599, 0x05FD, 0x0638, 0x064C, 0x0638, 0x05FD, 0x0599, 0x050E, 0x0438, 0x0308, 0x019D, 
    0x0014, 0xFE8B, 0xFD20, 0xFBF1, 0xFB1B, 0xFA90, 0xFA2C, 0xF9F1, 0xF9DD, 0xF9F1, 0xFA2C, 0xFA90, 0xF245, 0xF492, 
    0xF7D5, 0xFBBD, 0xFFF7, 0x0431, 0x0819, 0x0B5C, 0x0DA9, 0x0F29, 0x103A, 0x10DF, 0x1116, 0x10DF, 0x103A, 0x0F29, 
    0x0DA9, 0x0B5C, 0x0819, 0x0431, 0xFFF7, 0xFBBD, 0xF7D5, 0xF492, 0xF245, 0xF0C5, 0xEFB3, 0xEF0F, 0xEED8, 0xEF0F, 
    0xEFB3, 0xF0C5, 0x040D, 0x0226, 0xFFDF, 0xFD69, 0xFAF2, 0xF8AC, 0xF6C5, 0xF56E, 0xF48E, 0xF3EF, 0xF38F, 0xF36F, 
    0xF38F, 0xF3EF, 0xF48E, 0xF56E, 0xF6C5, 0xF8AC, 0xFAF2, 0xFD69, 0xFFDF, 0x0226, 0x040D, 0x0564, 0x0643, 0x06E3, 
    0x0743, 0x0763, 0x0743, 0x06E3, 0x0643, 0x0564, 0xF629, 0xF58F, 0xF4D7, 0xF410, 0xF348, 0xF290, 0xF1F6, 0xF18A, 
    0xF143, 0xF111, 0xF0F3, 0xF0E8, 0xF0F3, 0xF111, 0xF143, 0xF18A, 0xF1F6, 0xF290, 0xF348, 0xF410, 0xF4D7, 0xF58F, 
    0xF629, 0xF695, 0xF6DC, 0xF70E, 0xF72D, 0xF737, 0xF72D, 0xF70E, 0xF6DC, 0xF695, 0x05FD, 0x035A, 0x0034, 0xFCCA, 
    0xF961, 0xF63A, 0xF398, 0xF1BD, 0xF087, 0xEFAA, 0xEF26, 0xEEFA, 0xEF26, 0xEFAA, 0xF087, 0xF1BD, 0xF398, 0xF63A, 
    0xF961, 0xFCCA, 0x0034, 0x035A, 0x05FD, 0x07D8, 0x090D, 0x09EA, 0x0A6F, 0x0A9B, 0x0A6F, 0x09EA, 0x090D, 0x07D8, 
    0xFEB1, 0xFC64, 0xFA43, 0xF87C, 0xF73B, 0xF66A, 0xF5D5, 0xF57B, 0xF55E, 0xF57B, 0xF5D5, 0xF66A, 0xF73B, 0xF87C, 
    0xFA43, 0xFC64, 0xFEB1, 0x00FE, 0x031F, 0x04E6, 0x0627, 0x06F8, 0x078D, 0x07E6, 0x0804, 0x07E6, 0x078D, 0x06F8, 
    0x0627, 0x04E6, 0x031F, 0x00FE, 0x1BBB, 0x1BA7, 0x1B95, 0x1B86, 0x1B7C, 0x1B75, 0x1B70, 0x1B6D, 0x1B6C, 0x1B6D, 
    0x1B70, 0x1B75, 0x1B7C, 0x1B86, 0x1B95, 0x1BA7, 0x1BBB, 0x1BCF, 0x1BE1, 0x1BF0, 0x1BFA, 0x1C01, 0x1C06, 0x1C09, 
    0x1C0A, 0x1C09, 0x1C06, 0x1C01, 0x1BFA, 0x1BF0, 0x1BE1, 0x1BCF, 0x056C, 0x0203, 0xFEDC, 0xFC3B, 0xFA60, 0xF92A, 
    0xF84D, 0xF7C9, 0xF79D, 0xF7C9, 0xF84D, 0xF92A, 0xFA60, 0xFC3B, 0xFEDC, 0x0203, 0x056C, 0x08D4, 0x0BFB, 0x0E9D, 
    0x1078, 0x11AD, 0x128A, 0x130E, 0x133B, 0x130E, 0x128A, 0x11AD, 0x1078, 0x0E9D, 0x0BFB, 0x08D4, 0xFF02, 0xFFB2, 
    0x00AC, 0x01D7, 0x031B, 0x045E, 0x0589, 0x0683, 0x0733, 0x07A6, 0x07F8, 0x0829, 0x083A, 0x0829, 0x07F8, 0x07A6, 
    0x0733, 0x0683, 0x0589, 0x045E, 0x031B, 0x01D7, 0x00AC, 0xFFB2, 0xFF02, 0xFE8F, 0xFE3D, 0xFE0C, 0xFDFC, 0xFE0C, 
    0xFE3D, 0xFE8F, 0xF30E, 0xF371, 0xF3FE, 0xF4A7, 0xF55E, 0xF615, 0xF6BD, 0xF74B, 0xF7AE, 0xF7EF, 0xF81D, 0xF839, 
    0xF842, 0xF839, 0xF81D, 0xF7EF, 0xF7AE, 0xF74B, 0xF6BD, 0xF615, 0xF55E, 0xF4A7, 0xF3FE, 0xF371, 0xF30E, 0xF2CD, 
    0xF29F, 0xF283, 0xF27A, 0xF283, 0xF29F, 0xF2CD, 0x18D8, 0x18CF, 0x18C2, 0x18B2, 0x18A1, 0x1890, 0x1880, 0x1873, 
    0x186A, 0x1864, 0x185F, 0x185D, 0x185C, 0x185D, 0x185F, 0x1864, 0x186A, 0x1873, 0x1880, 0x1890, 0x18A1, 0x18B2, 
    0x18C2, 0x18CF, 0x18D8, 0x18DE, 0x18E2, 0x18E5, 0x18E6, 0x18E5, 0x18E2, 0x18DE, 0x1442, 0x1442, 0x1442, 0x1442, 
    0x1442, 0x1443, 0x1443, 0x1443, 0x1443, 0x1443, 0x1444, 0x1444, 0x1444, 0x1445, 0x1445, 0x1445, 0x1446, 0x1446, 
    0x1447, 0x1447, 0x1447, 0x1448, 0x1448, 0x1449, 0x1449, 0x144A, 0x144A, 0x144B, 0x144B, 0x144C, 0x144D, 0x144D, 
    0x0D31, 0x0C65, 0x0B43, 0x09E9, 0x0872, 0x06FC, 0x05A1, 0x0480, 0x03B4, 0x032F, 0x02D0, 0x0297, 0x0284, 0x0297, 
    0x02D0, 0x032F, 0x03B4, 0x0480, 0x05A1, 0x06FC, 0x0872, 0x09E9, 0x0B43, 0x0C65, 0x0D31, 0x0DB5, 0x0E14, 0x0E4D, 
    0x0E60, 0x0E4D, 0x0E14, 0x0DB5, 0x0091, 0x0124, 0x01F4, 0x02EE, 0x03FB, 0x0509, 0x0602, 0x06D2, 0x0765, 0x07C5, 
    0x0809, 0x0832, 0x0840, 0x0832, 0x0809, 0x07C5, 0x0765, 0x06D2, 0x0602, 0x0509, 0x03FB, 0x02EE, 0x01F4, 0x0124, 
    0x0091, 0x0032, 0xFFEE, 0xFFC5, 0xFFB7, 0xFFC5, 0xFFEE, 0x0032, 0x03E6, 0x03D8, 0x03C4, 0x03AC, 0x0393, 0x0379, 
    0x0362, 0x034E, 0x0340, 0x0337, 0x0331, 0x032D, 0x032C, 0x032D, 0x0331, 0x0337, 0x0340, 0x034E, 0x0362, 0x0379, 
    0x0393, 0x03AC, 0x03C4, 0x03D8, 0x03E6, 0x03EF, 0x03F5, 0x03F9, 0x03FA, 0x03F9, 0x03F5, 0x03EF, 0xF1ED, 0xF1D7, 
    0xF1B8, 0xF192, 0xF169, 0xF141, 0xF11B, 0xF0FC, 0xF0E6, 0xF0D7, 0xF0CD, 0xF0C7, 0xF0C5, 0xF0C7, 0xF0CD, 0xF0D7, 
    0xF0E6, 0xF0FC, 0xF11B, 0xF141, 0xF169, 0xF192, 0xF1B8, 0xF1D7, 0xF1ED, 0xF1FC, 0xF206, 0xF20C, 0xF20E, 0xF20C, 
    0xF206, 0xF1FC, 0xE3E1, 0xE3BB, 0xE385, 0xE344, 0xE2FD, 0xE2B7, 0xE275, 0xE23F, 0xE219, 0xE200, 0xE1EE, 0xE1E3, 
    0xE1E0, 0xE1E3, 0xE1EE, 0xE200, 0xE219, 0xE23F, 0xE275, 0xE2B7, 0xE2FD, 0xE344, 0xE385, 0xE3BB, 0xE3E1, 0xE3FA, 
    0xE40C, 0xE417, 0xE41A, 0xE417, 0xE40C, 0xE3FA, 0x0154, 0x0174, 0x01A0, 0x01D6, 0x0210, 0x024B, 0x0280, 0x02AD, 
    0x02CD, 0x02E2, 0x02F0, 0x02F9, 0x02FC, 0x02F9, 0x02F0, 0x02E2, 0x02CD, 0x02AD, 0x0280, 0x024B, 0x0210, 0x01D6, 
    0x01A0, 0x0174, 0x0154, 0x013F, 0x0131, 0x0128, 0x0125, 0x0128, 0x0131, 0x013F, 0x0121, 0x0176, 0x01CF, 0x022A, 
    0x0285, 0x02E0, 0x033B, 0x0393, 0x03E9, 0x0432, 0x0467, 0x0486, 0x0491, 0x0486, 0x0467, 0x0432, 0x03E9, 0x0393, 
    0x033B, 0x02E0, 0x0285, 0x022A, 0x01CF, 0x0176, 0x0121, 0x00D8, 0x00A3, 0x0084, 0x0079, 0x0084, 0x00A3, 0x00D8, 
    0xFD48, 0xFEAE, 0xFE5D, 0xFDCE, 0xFD95, 0xFD38, 0xFCF2, 0xFCBB, 0xFC99, 0xFC76, 0xFC62, 0xFC53, 0xFC4E, 0xFC62, 
    0xFC71, 0xFC73, 0xFC99, 0xFCDD, 0xFD29, 0xFD78, 0xFDCF, 0xFDD6, 0xFDB2, 0xFD7D, 0xFD47, 0xFD1C, 0xFCFF, 0xFCF0, 
    0xFCF0, 0xFCFF, 0xFD00, 0xFD04, 0x05BD, 0x0505, 0x036F, 0x0196, 0xFFC5, 0xFE17, 0xFC56, 0xFADF, 0xF9D5, 0xF92C, 
    0xF8AF, 0xF866, 0xF850, 0xF866, 0xF8AF, 0xF92C, 0xF9D5, 0xFADC, 0xFC53, 0xFE17, 0xFFCB, 0x0197, 0x034C, 0x04BB, 
    0x05BD, 0x0665, 0x06DD, 0x0726, 0x0740, 0x072B, 0x06DD, 0x065E, 0xAAEC, 0xABCB, 0xAD23, 0xAEFA, 0xB1A4, 0xB579, 
    0xB578, 0xB579, 0xB557, 0xB57B, 0xB55A, 0xB55A, 0xB57D, 0xB559, 0xB55A, 0xB57B, 0xB557, 0xB556, 0xB556, 0xB579, 
    0xB1A3, 0xAEFA, 0xAD25, 0xABCE, 0xAAEC, 0xAA5D, 0xA9F9, 0xA9BE, 0xA9AA, 0xA9BD, 0xA9F9, 0xAA5E, 0x1112, 0x0FAE, 
    0x0D8A, 0x0A94, 0x063E, 0x0000, 0x0000, 0x0000, 0x0039, 0x0000, 0x0036, 0x0037, 0x0000, 0x0038, 0x0036, 0x0000, 
    0x0039, 0x0037, 0x0037, 0x0000, 0x063E, 0x0A94, 0x0D8A, 0x0FAE, 0x1112, 0x11F0, 0x128A, 0x12E5, 0x1304, 0x12E5, 
    0x128A, 0x11F0, 0xFF94, 0xFF95, 0xFF98, 0xFF9B, 0xFF9E, 0xFFA2, 0xFFA5, 0xFFA8, 0xFFAA, 0xFFAB, 0xFFAC, 0xFFAC, 
    0xFFAC, 0xFFAC, 0xFFAB, 0xFFAB, 0xFFAA, 0xFFA9, 0xFFA8, 0xFFA6, 0xFFA4, 0xFFA2, 0xFFA0, 0xFF9F, 0xFF9D, 0xFF9C, 
    0xFF9A, 0xFF98, 0xFF96, 0xFF95, 0xFF94, 0xFF94, 0xFE00, 0xFE09, 0xFE18, 0xFE2C, 0xFE43, 0xFE5A, 0xFE6F, 0xFE81, 
    0xFE8D, 0xFE94, 0xFE99, 0xFE9B, 0xFE9B, 0xFE99, 0xFE96, 0xFE92, 0xFE8D, 0xFE86, 0xFE7E, 0xFE73, 0xFE67, 0xFE5B, 
    0xFE4F, 0xFE44, 0xFE3B, 0xFE31, 0xFE26, 0xFE1A, 0xFE0F, 0xFE06, 0xFE00, 0xFDFD, 0x74E2, 0x7538, 0x75CC, 0x768A, 
    0x7760, 0x783B, 0x7906, 0x79B0, 0x7A25, 0x7A6B, 0x7A96, 0x7AAA, 0x7AAA, 0x7A9A, 0x7A7C, 0x7A54, 0x7A25, 0x79E7, 
    0x7993, 0x792E, 0x78BF, 0x784C, 0x77DA, 0x7770, 0x7713, 0x76B5, 0x764A, 0x75DC, 0x7575, 0x751E, 0x74E2, 0x74CB, 
    0xFA48, 0xFB4A, 0xFB63, 0xFB77, 0xFBE5, 0xFCB8, 0xFDB4, 0xFEAA, 0xFF58, 0xFFCC, 0x0026, 0x005F, 0x006C, 0x0055, 
    0x0024, 0xFFE8, 0xFF74, 0xFEA9, 0xFDB9, 0xFCC4, 0xFBF0, 0xFB6E, 0xFAFA, 0xFA94, 0xFA4D, 0xFA30, 0xFA14, 0xFA00, 
    0xF9ED, 0xF9EF, 0xF9F3, 0xFA0E, 0x0624, 0x0521, 0x03AA, 0x01E9, 0xFF9C, 0xFD88, 0xFBC0, 0xFA57, 0xF95F, 0xF8BF, 
    0xF851, 0xF80F, 0xF7F8, 0xF80C, 0xF850, 0xF8C7, 0xF966, 0xFA57, 0xFBC1, 0xFD8A, 0xFF9D, 0x01E9, 0x03AA, 0x0521, 
    0x0624, 0x06D4, 0x074E, 0x0797, 0x07AB, 0x0797, 0x074E, 0x06D4, 0xB558, 0xB579, 0xB578, 0xB579, 0xB1A7, 0xAF06, 
    0xAD33, 0xABDB, 0xAAF8, 0xAA69, 0xAA05, 0xA9C9, 0xA9B6, 0xA9C9, 0xAA05, 0xAA69, 0xAAF8, 0xABDB, 0xAD32, 0xAF05, 
    0xB1A7, 0xB579, 0xB578, 0xB579, 0xB558, 0xB57B, 0xB57C, 0xB57D, 0xB55B, 0xB57D, 0xB57C, 0xB57B, 0x034A, 0x0348, 
    0x0344, 0x033F, 0x033A, 0x0334, 0x032F, 0x032B, 0x0328, 0x0326, 0x0325, 0x0325, 0x0325, 0x0325, 0x0326, 0x0327, 
    0x0328, 0x032A, 0x032C, 0x032E, 0x0331, 0x0334, 0x0337, 0x0339, 0x033C, 0x033E, 0x0341, 0x0343, 0x0346, 0x0348, 
    0x034A, 0x034A, 0x0036, 0x0000, 0x0000, 0x0000, 0x063E, 0x0A86, 0x0D74, 0x0F93, 0x10F5, 0x11D1, 0x126A, 0x12C5, 
    0x12E3, 0x12C5, 0x126A, 0x11D1, 0x10F5, 0x0F93, 0x0D74, 0x0A86, 0x063E, 0x0000, 0x0000, 0x0000, 0x0037, 0x0000, 
    0x0000, 0x0000, 0x0036, 0x0000, 0x0000, 0x0000, 0xFFF6, 0xFFF7, 0xFFF7, 0xFFF8, 0xFFF8, 0xFFF9, 0xFFFA, 0xFFFB, 
    0xFFFB, 0xFFFB, 0xFFFB, 0xFFFB, 0xFFFB, 0xFFFB, 0xFFFB, 0xFFFB, 0xFFFB, 0xFFFB, 0xFFFB, 0xFFFB, 0xFFFB, 0xFFFC, 
    0xFFFC, 0xFFFB, 0xFFFB, 0xFFFB, 0xFFFA, 0xFFF9, 0xFFF9, 0xFFF8, 0xFFF7, 0xFFF7, 0xFFD2, 0xFFD0, 0xFFCF, 0xFFCD, 
    0xFFCC, 0xFFCA, 0xFFC9, 0xFFC8, 0xFFC8, 0xFFC7, 0xFFC6, 0xFFC5, 0xFFC5, 0xFFC5, 0xFFC5, 0xFFC6, 0xFFC8, 0xFFCA, 
    0xFFCE, 0xFFD3, 0xFFD8, 0xFFDC, 0xFFE1, 0xFFE4, 0xFFE5, 0xFFE5, 0xFFE4, 0xFFE1, 0xFFDE, 0xFFDB, 0xFFD7, 0xFFD4, 
    0x7B37, 0x7AA8, 0x79D7, 0x78DB, 0x77C8, 0x76B4, 0x75B5, 0x74E0, 0x744A, 0x73EA, 0x73A7, 0x737F, 0x7374, 0x7383, 
    0x73AC, 0x73EF, 0x744A, 0x74D5, 0x7599, 0x7683, 0x7781, 0x7880, 0x796D, 0x7A35, 0x7AC6, 0x7B2B, 0x7B7B, 0x7BB5, 
    0x7BD5, 0x7BDB, 0x7BC4, 0x7B8E, 
};

JointIndex object_bg_Anim_001384JointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0002, 0x0002, 0x0002 },
    { 0x0002, 0x0003, 0x0012 },
    { 0x0032, 0x0004, 0x0052 },
    { 0x0072, 0x0092, 0x00B2 },
    { 0x00D2, 0x00F2, 0x0112 },
    { 0x0002, 0x0002, 0x0005 },
    { 0x0006, 0x0007, 0x0008 },
    { 0x0132, 0x0152, 0x0172 },
    { 0x0192, 0x01B2, 0x01D2 },
    { 0x0002, 0x0002, 0x0005 },
    { 0x0009, 0x000A, 0x000B },
    { 0x01F2, 0x0212, 0x0232 },
    { 0x000C, 0x0252, 0x0272 },
    { 0x000D, 0x000E, 0x000F },
    { 0x0292, 0x02B2, 0x02D2 },
    { 0x0010, 0x0002, 0x02F2 },
    { 0x0002, 0x0002, 0x0011 },
    { 0x0312, 0x0332, 0x0352 },
    { 0x000D, 0x000E, 0x000F },
    { 0x0372, 0x0392, 0x03B2 },
    { 0x03D2, 0x0002, 0x03F2 },
    { 0x0002, 0x0002, 0x0011 },
    { 0x0412, 0x0432, 0x0452 },
};

AnimationHeader object_bg_Anim_001384 = { 
    { 32 }, object_bg_Anim_001384FrameData,
    object_bg_Anim_001384JointIndices, 18
};

u8 object_bg_possiblePadding_001394[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx object_bgVtx_0013A0[] = {
#include "assets/objects/object_bg/object_bgVtx_0013A0.vtx.inc"
};

Gfx gTreasureChestShopGalHeadDL[] = {
    gsSPMatrix(0x0D000080, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_bgVtx_0013A0, 5, 0),
    gsSPMatrix(0x0D0000C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_bgVtx_0013A0[5], 19, 5),
    gsSP2Triangles(0, 5, 6, 0, 7, 4, 3, 0),
    gsSP2Triangles(4, 8, 9, 0, 4, 10, 11, 0),
    gsSP2Triangles(12, 0, 1, 0, 13, 2, 0, 0),
    gsSP2Triangles(14, 15, 1, 0, 16, 4, 17, 0),
    gsSP2Triangles(1, 4, 18, 0, 3, 2, 19, 0),
    gsSP2Triangles(20, 21, 4, 0, 3, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalHairTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x007C),
    gsSPVertex(&object_bgVtx_0013A0[24], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(4, 5, 2, 0, 4, 2, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalHair2Tex, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 16, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 3, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x063C, 0x003C),
    gsSPVertex(&object_bgVtx_0013A0[30], 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_bgVtx_0013A0[33], 8, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 5, 4, 0),
    gsSPVertex(&object_bgVtx_0013A0[41], 10, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 2, 1, 0),
    gsSP2Triangles(4, 5, 6, 0, 6, 5, 7, 0),
    gsSP1Triangle(8, 3, 9, 0),
    gsSPVertex(&object_bgVtx_0013A0[51], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_bgVtx_0013A0[54], 21, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 2, 1, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
    gsSP2Triangles(8, 2, 3, 0, 9, 10, 6, 0),
    gsSP2Triangles(11, 9, 1, 0, 12, 13, 14, 0),
    gsSP2Triangles(3, 15, 16, 0, 14, 13, 17, 0),
    gsSP2Triangles(7, 4, 18, 0, 2, 8, 19, 0),
    gsSP2Triangles(11, 10, 9, 0, 0, 11, 1, 0),
    gsSP2Triangles(15, 20, 17, 0, 20, 9, 17, 0),
    gsSP2Triangles(3, 20, 15, 0, 20, 1, 9, 0),
    gsSP1Triangle(3, 1, 20, 0),
    gsSPVertex(&object_bgVtx_0013A0[75], 14, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 6, 0),
    gsSP1Triangle(11, 12, 13, 0),
    gsSPVertex(&object_bgVtx_0013A0[89], 12, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 8, 7, 9, 0),
    gsSP2Triangles(10, 3, 11, 0, 6, 0, 7, 0),
    gsSPVertex(&object_bgVtx_0013A0[101], 4, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(0x08000000, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                         G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[105], 7, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 1, 0),
    gsSP2Triangles(0, 5, 6, 0, 3, 6, 5, 0),
    gsSP2Triangles(1, 0, 6, 0, 1, 6, 3, 0),
    gsSPVertex(&object_bgVtx_0013A0[112], 7, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
    gsSP2Triangles(0, 4, 1, 0, 5, 6, 1, 0),
    gsSP2Triangles(3, 2, 6, 0, 1, 6, 2, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalMouthTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[119], 20, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
    gsSP2Triangles(5, 3, 0, 0, 4, 1, 0, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 3, 10, 0),
    gsSP2Triangles(6, 8, 11, 0, 10, 3, 12, 0),
    gsSP2Triangles(9, 10, 13, 0, 11, 8, 12, 0),
    gsSP2Triangles(8, 7, 13, 0, 12, 8, 10, 0),
    gsSP2Triangles(10, 8, 13, 0, 9, 14, 15, 0),
    gsSP2Triangles(7, 6, 16, 0, 16, 6, 17, 0),
    gsSP2Triangles(5, 12, 3, 0, 15, 18, 13, 0),
    gsSP2Triangles(9, 13, 19, 0, 4, 3, 9, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalEarAndBellyButtonTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 253, 255, 255),
    gsSPVertex(&object_bgVtx_0013A0[139], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_bgVtx_0013A0[143], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[147], 16, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 6, 0, 0, 7, 8, 9, 0),
    gsSP2Triangles(10, 7, 9, 0, 2, 3, 5, 0),
    gsSP2Triangles(5, 11, 2, 0, 12, 13, 8, 0),
    gsSP2Triangles(14, 8, 13, 0, 7, 12, 8, 0),
    gsSP2Triangles(9, 8, 15, 0, 1, 3, 2, 0),
    gsSPEndDisplayList(),
};

Gfx gTreasureChestShopGalNeckDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[163], 5, 0),
    gsSPMatrix(0x0D000080, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[168], 15, 5),
    gsSP2Triangles(2, 5, 3, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 2, 9, 0, 4, 10, 11, 0),
    gsSP2Triangles(12, 1, 3, 0, 13, 0, 1, 0),
    gsSP2Triangles(1, 14, 15, 0, 16, 2, 4, 0),
    gsSP2Triangles(0, 17, 4, 0, 3, 18, 19, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[183], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSP2Triangles(4, 1, 3, 0, 5, 6, 2, 0),
    gsSP2Triangles(0, 2, 6, 0, 5, 7, 8, 0),
    gsSP2Triangles(3, 9, 4, 0, 7, 9, 3, 0),
    gsSP2Triangles(5, 8, 6, 0, 5, 9, 7, 0),
    gsSPEndDisplayList(),
};

Gfx gTreasureChestShopGalLeftHandDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000140, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[193], 4, 0),
    gsSPMatrix(0x0D000180, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[197], 12, 4),
    gsSP2Triangles(2, 4, 1, 0, 2, 3, 5, 0),
    gsSP2Triangles(0, 6, 3, 0, 7, 8, 0, 0),
    gsSP2Triangles(9, 10, 0, 0, 0, 1, 11, 0),
    gsSP2Triangles(12, 13, 1, 0, 3, 14, 15, 0),
    gsSPVertex(&object_bgVtx_0013A0[209], 11, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(4, 2, 1, 0, 5, 6, 3, 0),
    gsSP2Triangles(7, 6, 5, 0, 8, 7, 5, 0),
    gsSP2Triangles(9, 3, 2, 0, 10, 8, 9, 0),
    gsSP2Triangles(10, 7, 8, 0, 4, 9, 2, 0),
    gsSP2Triangles(6, 0, 3, 0, 10, 9, 4, 0),
    gsSP1Triangle(6, 7, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalFingersTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[220], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 4, 0),
    gsSP2Triangles(5, 2, 1, 0, 3, 5, 1, 0),
    gsSP2Triangles(2, 5, 3, 0, 4, 1, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[226], 7, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 5, 0, 0, 6, 4, 0, 0),
    gsSP2Triangles(6, 5, 4, 0, 5, 6, 0, 0),
    gsSP2Triangles(3, 5, 2, 0, 3, 0, 4, 0),
    gsSP1Triangle(3, 1, 0, 0),
    gsSPEndDisplayList(),
};

Gfx gTreasureChestShopGalLeftForearmDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000100, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[233], 4, 0),
    gsSPMatrix(0x0D000140, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[237], 12, 4),
    gsSP2Triangles(4, 5, 2, 0, 2, 3, 6, 0),
    gsSP2Triangles(7, 8, 2, 0, 9, 1, 10, 0),
    gsSP2Triangles(11, 12, 1, 0, 13, 0, 2, 0),
    gsSP2Triangles(1, 0, 14, 0, 1, 15, 3, 0),
    gsSPVertex(&object_bgVtx_0013A0[249], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(4, 2, 5, 0, 5, 6, 7, 0),
    gsSP2Triangles(7, 6, 3, 0, 3, 6, 0, 0),
    gsSP2Triangles(2, 1, 5, 0, 7, 4, 5, 0),
    gsSPEndDisplayList(),
};

Gfx gTreasureChestShopGalLeftUpperArmDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[257], 8, 0),
    gsSPMatrix(0x0D000100, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsSPVertex(&object_bgVtx_0013A0[265], 3, 8),
    gsSP2Triangles(4, 5, 8, 0, 5, 3, 9, 0),
    gsSP1Triangle(4, 10, 1, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[268], 13, 8),
    gsSP2Triangles(8, 2, 9, 0, 2, 10, 11, 0),
    gsSP2Triangles(0, 12, 13, 0, 6, 0, 14, 0),
    gsSP2Triangles(6, 15, 7, 0, 16, 2, 17, 0),
    gsSP2Triangles(18, 2, 7, 0, 19, 20, 6, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[281], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 2, 4, 0),
    gsSP2Triangles(2, 1, 4, 0, 5, 6, 0, 0),
    gsSP2Triangles(0, 6, 1, 0, 4, 7, 3, 0),
    gsSP2Triangles(3, 7, 5, 0, 5, 7, 6, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[289], 7, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(2, 4, 0, 0, 0, 4, 5, 0),
    gsSP1Triangle(4, 6, 5, 0),
    gsSPEndDisplayList(),
};

Gfx gTreasureChestShopGalRightHandDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000200, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[296], 4, 0),
    gsSPMatrix(0x0D000240, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[300], 12, 4),
    gsSP2Triangles(1, 4, 2, 0, 5, 3, 2, 0),
    gsSP2Triangles(3, 6, 0, 0, 0, 7, 8, 0),
    gsSP2Triangles(0, 9, 10, 0, 11, 1, 0, 0),
    gsSP2Triangles(1, 12, 13, 0, 14, 15, 3, 0),
    gsSPVertex(&object_bgVtx_0013A0[312], 11, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(1, 0, 4, 0, 3, 5, 6, 0),
    gsSP2Triangles(6, 5, 7, 0, 6, 7, 8, 0),
    gsSP2Triangles(0, 3, 9, 0, 9, 8, 10, 0),
    gsSP2Triangles(8, 7, 10, 0, 0, 9, 4, 0),
    gsSP2Triangles(3, 2, 5, 0, 4, 9, 10, 0),
    gsSP1Triangle(2, 7, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalFingersTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[323], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 4, 0),
    gsSP2Triangles(1, 0, 5, 0, 1, 5, 4, 0),
    gsSP2Triangles(4, 5, 0, 0, 2, 1, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[329], 7, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 3, 0, 0, 2, 4, 6, 0),
    gsSP2Triangles(4, 3, 6, 0, 2, 6, 3, 0),
    gsSP2Triangles(0, 3, 5, 0, 4, 2, 5, 0),
    gsSP1Triangle(2, 1, 5, 0),
    gsSPEndDisplayList(),
};

Gfx gTreasureChestShopGalRightForearmDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D0001C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[336], 4, 0),
    gsSPMatrix(0x0D000200, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[340], 12, 4),
    gsSP2Triangles(2, 4, 5, 0, 6, 3, 2, 0),
    gsSP2Triangles(2, 7, 8, 0, 9, 1, 10, 0),
    gsSP2Triangles(1, 11, 12, 0, 2, 0, 13, 0),
    gsSP2Triangles(14, 0, 1, 0, 3, 15, 1, 0),
    gsSPVertex(&object_bgVtx_0013A0[352], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(4, 0, 5, 0, 6, 7, 4, 0),
    gsSP2Triangles(3, 7, 6, 0, 2, 7, 3, 0),
    gsSP2Triangles(4, 1, 0, 0, 4, 5, 6, 0),
    gsSPEndDisplayList(),
};

Gfx gTreasureChestShopGalRightUpperArmDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[360], 8, 0),
    gsSPMatrix(0x0D0001C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsSPVertex(&object_bgVtx_0013A0[368], 3, 8),
    gsSP2Triangles(8, 5, 4, 0, 9, 3, 5, 0),
    gsSP1Triangle(1, 10, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[371], 13, 8),
    gsSP2Triangles(8, 2, 9, 0, 10, 11, 2, 0),
    gsSP2Triangles(12, 13, 0, 0, 14, 0, 6, 0),
    gsSP2Triangles(7, 15, 6, 0, 16, 2, 17, 0),
    gsSP2Triangles(7, 2, 18, 0, 6, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[384], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 0, 4, 0),
    gsSP2Triangles(3, 1, 0, 0, 2, 5, 6, 0),
    gsSP2Triangles(1, 5, 2, 0, 4, 7, 3, 0),
    gsSP2Triangles(6, 7, 4, 0, 5, 7, 6, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[392], 7, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSP2Triangles(2, 4, 0, 0, 5, 4, 2, 0),
    gsSP1Triangle(5, 6, 4, 0),
    gsSPEndDisplayList(),
};

Gfx gTreasureChestShopGalTorsoDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[399], 6, 0),
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalEarAndBellyButtonTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[405], 18, 6),
    gsSP2Triangles(5, 6, 7, 0, 2, 1, 8, 0),
    gsSP2Triangles(9, 2, 10, 0, 1, 11, 12, 0),
    gsSP2Triangles(13, 3, 2, 0, 2, 14, 15, 0),
    gsSP2Triangles(16, 5, 3, 0, 17, 4, 18, 0),
    gsSP2Triangles(19, 4, 5, 0, 20, 21, 5, 0),
    gsSP2Triangles(0, 22, 1, 0, 23, 0, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsSPVertex(&object_bgVtx_0013A0[423], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 4, 0),
    gsSP2Triangles(5, 0, 6, 0, 7, 5, 8, 0),
    gsSP2Triangles(9, 10, 11, 0, 1, 12, 13, 0),
    gsSP2Triangles(13, 12, 3, 0, 1, 13, 2, 0),
    gsSP2Triangles(13, 3, 2, 0, 12, 1, 14, 0),
    gsSP2Triangles(3, 12, 15, 0, 11, 10, 16, 0),
    gsSP2Triangles(17, 18, 19, 0, 11, 16, 20, 0),
    gsSP2Triangles(7, 21, 14, 0, 20, 16, 22, 0),
    gsSP2Triangles(20, 22, 0, 0, 0, 22, 19, 0),
    gsSP2Triangles(21, 7, 23, 0, 23, 7, 8, 0),
    gsSP2Triangles(0, 24, 1, 0, 4, 3, 15, 0),
    gsSP2Triangles(4, 15, 25, 0, 10, 9, 25, 0),
    gsSP2Triangles(12, 21, 15, 0, 23, 8, 26, 0),
    gsSP2Triangles(7, 14, 1, 0, 24, 0, 5, 0),
    gsSP2Triangles(24, 5, 7, 0, 22, 27, 19, 0),
    gsSP2Triangles(28, 25, 29, 0, 28, 30, 25, 0),
    gsSP2Triangles(23, 15, 21, 0, 18, 6, 19, 0),
    gsSP2Triangles(31, 23, 26, 0, 31, 15, 23, 0),
    gsSP1Triangle(25, 15, 29, 0),
    gsSPVertex(&object_bgVtx_0013A0[455], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 1, 6, 0, 7, 6, 3, 0),
    gsSP2Triangles(7, 3, 5, 0, 6, 7, 2, 0),
    gsSP2Triangles(8, 9, 10, 0, 11, 12, 13, 0),
    gsSP2Triangles(14, 15, 16, 0, 1, 17, 3, 0),
    gsSP2Triangles(1, 3, 6, 0, 18, 19, 7, 0),
    gsSP2Triangles(7, 19, 20, 0, 18, 7, 5, 0),
    gsSP2Triangles(7, 20, 2, 0, 4, 3, 17, 0),
    gsSP2Triangles(18, 5, 4, 0, 21, 22, 20, 0),
    gsSP2Triangles(23, 22, 21, 0, 1, 0, 17, 0),
    gsSP2Triangles(23, 24, 22, 0, 25, 24, 23, 0),
    gsSP2Triangles(25, 26, 24, 0, 20, 27, 28, 0),
    gsSP2Triangles(23, 21, 29, 0, 28, 8, 20, 0),
    gsSP2Triangles(19, 27, 20, 0, 18, 27, 19, 0),
    gsSP1Triangle(30, 27, 18, 0),
    gsSPVertex(&object_bgVtx_0013A0[486], 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPEndDisplayList(),
};

Gfx gTreasureChestShopGalLeftFootDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000380, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[584], 4, 0),
    gsSPMatrix(0x0D0003C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[588], 12, 4),
    gsSP2Triangles(2, 4, 3, 0, 5, 6, 3, 0),
    gsSP2Triangles(1, 3, 7, 0, 8, 3, 9, 0),
    gsSP2Triangles(10, 0, 1, 0, 11, 2, 0, 0),
    gsSP2Triangles(12, 13, 0, 0, 14, 15, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[600], 9, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(4, 6, 5, 0, 6, 0, 2, 0),
    gsSP2Triangles(2, 7, 5, 0, 6, 4, 1, 0),
    gsSP2Triangles(5, 6, 2, 0, 1, 0, 6, 0),
    gsSP2Triangles(3, 5, 7, 0, 2, 1, 8, 0),
    gsSP2Triangles(8, 3, 7, 0, 2, 8, 7, 0),
    gsSPEndDisplayList(),
};

Gfx gTreasureChestShopGalLeftShinDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000340, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[609], 5, 0),
    gsSPMatrix(0x0D000380, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[614], 6, 5),
    gsSP2Triangles(5, 0, 6, 0, 7, 0, 8, 0),
    gsSP1Triangle(0, 9, 10, 0),
    gsSPVertex(&object_bgVtx_0013A0[620], 2, 5),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 5, 6, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsSPVertex(&object_bgVtx_0013A0[622], 12, 5),
    gsSP2Triangles(5, 3, 1, 0, 1, 4, 6, 0),
    gsSP2Triangles(7, 4, 8, 0, 2, 9, 4, 0),
    gsSP2Triangles(3, 10, 11, 0, 3, 12, 13, 0),
    gsSP2Triangles(2, 3, 14, 0, 15, 3, 16, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[634], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 4, 0),
    gsSP2Triangles(3, 5, 4, 0, 6, 7, 5, 0),
    gsSPVertex(&object_bgVtx_0013A0[642], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_bgVtx_0013A0[645], 6, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSPVertex(&object_bgVtx_0013A0[651], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[654], 9, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 1, 0),
    gsSP2Triangles(1, 4, 2, 0, 5, 3, 6, 0),
    gsSP2Triangles(7, 5, 6, 0, 0, 7, 6, 0),
    gsSP2Triangles(4, 3, 8, 0, 8, 3, 5, 0),
    gsSP1Triangle(7, 0, 2, 0),
    gsSPEndDisplayList(),
};

Gfx gTreasureChestShopGalLeftThighDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[663], 4, 0),
    gsSPMatrix(0x0D000340, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsSPVertex(&object_bgVtx_0013A0[667], 12, 4),
    gsSP2Triangles(4, 2, 0, 0, 5, 6, 0, 0),
    gsSP2Triangles(1, 7, 0, 0, 8, 9, 1, 0),
    gsSP2Triangles(2, 10, 11, 0, 12, 3, 2, 0),
    gsSP2Triangles(13, 1, 3, 0, 14, 1, 15, 0),
    gsSPEndDisplayList(),
};

Gfx gTreasureChestShopGalRightFootDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D0002C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[489], 4, 0),
    gsSPMatrix(0x0D000300, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[493], 12, 4),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 6, 0),
    gsSP2Triangles(7, 3, 1, 0, 8, 3, 9, 0),
    gsSP2Triangles(1, 0, 10, 0, 0, 2, 11, 0),
    gsSP2Triangles(0, 12, 13, 0, 0, 14, 15, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[505], 9, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(3, 6, 4, 0, 0, 2, 6, 0),
    gsSP2Triangles(3, 7, 0, 0, 1, 4, 6, 0),
    gsSP2Triangles(0, 6, 3, 0, 6, 2, 1, 0),
    gsSP2Triangles(7, 3, 5, 0, 8, 1, 0, 0),
    gsSP2Triangles(7, 5, 8, 0, 7, 8, 0, 0),
    gsSPEndDisplayList(),
};

Gfx gTreasureChestShopGalRightShinDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000280, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[514], 5, 0),
    gsSPMatrix(0x0D0002C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[519], 6, 5),
    gsSP2Triangles(5, 0, 6, 0, 7, 0, 8, 0),
    gsSP1Triangle(9, 10, 0, 0),
    gsSPVertex(&object_bgVtx_0013A0[525], 2, 5),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(5, 6, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsSPVertex(&object_bgVtx_0013A0[527], 12, 5),
    gsSP2Triangles(1, 3, 5, 0, 6, 4, 1, 0),
    gsSP2Triangles(7, 4, 8, 0, 4, 9, 2, 0),
    gsSP2Triangles(10, 11, 3, 0, 12, 13, 3, 0),
    gsSP2Triangles(14, 3, 2, 0, 15, 3, 16, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[539], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 0, 0),
    gsSP2Triangles(3, 5, 4, 0, 5, 6, 7, 0),
    gsSPVertex(&object_bgVtx_0013A0[547], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_bgVtx_0013A0[550], 6, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSPVertex(&object_bgVtx_0013A0[556], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalSkinTex, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_0013A0[559], 9, 0),
    gsSP2Triangles(0, 1, 2, 0, 1, 3, 4, 0),
    gsSP2Triangles(0, 3, 1, 0, 5, 4, 6, 0),
    gsSP2Triangles(5, 6, 7, 0, 5, 7, 2, 0),
    gsSP2Triangles(8, 4, 3, 0, 6, 4, 8, 0),
    gsSP1Triangle(0, 2, 7, 0),
    gsSPEndDisplayList(),
};

Gfx gTreasureChestShopGalRightThighDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[568], 4, 0),
    gsSPMatrix(0x0D000280, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsSPVertex(&object_bgVtx_0013A0[572], 12, 4),
    gsSP2Triangles(0, 2, 4, 0, 0, 5, 6, 0),
    gsSP2Triangles(0, 7, 1, 0, 1, 8, 9, 0),
    gsSP2Triangles(10, 11, 2, 0, 2, 3, 12, 0),
    gsSP2Triangles(3, 1, 13, 0, 14, 1, 15, 0),
    gsSPEndDisplayList(),
};

Gfx gTreasureChestShopGalHipsDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(gTreasureChestShopGalTLUT),
    gsDPLoadTextureBlock(gTreasureChestShopGalClothesTex, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x00FC),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_0013A0[679], 20, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(9, 11, 7, 0, 12, 13, 14, 0),
    gsSP2Triangles(15, 3, 12, 0, 15, 12, 16, 0),
    gsSP2Triangles(3, 5, 12, 0, 3, 15, 17, 0),
    gsSP2Triangles(12, 14, 16, 0, 7, 11, 8, 0),
    gsSP2Triangles(13, 7, 6, 0, 5, 13, 12, 0),
    gsSP2Triangles(17, 15, 0, 0, 9, 5, 18, 0),
    gsSP2Triangles(0, 19, 11, 0, 1, 0, 10, 0),
    gsSP2Triangles(10, 0, 11, 0, 11, 19, 8, 0),
    gsSP2Triangles(17, 0, 2, 0, 7, 5, 9, 0),
    gsSP2Triangles(13, 5, 7, 0, 4, 2, 1, 0),
    gsSP2Triangles(4, 1, 18, 0, 0, 15, 19, 0),
    gsSP2Triangles(18, 5, 4, 0, 19, 15, 16, 0),
    gsSPEndDisplayList(),
};

u64 gTreasureChestShopGalTLUT[] = {
#include "assets/objects/object_bg/treasure_cheat_shop_gal_tlut.rgba16.inc.c"
};

u64 gTreasureChestShopGalHairTex[] = {
#include "assets/objects/object_bg/treasure_cheat_shop_gal_hair.ci8.inc.c"
};

u64 gTreasureChestShopGalHair2Tex[] = {
#include "assets/objects/object_bg/treasure_cheat_shop_gal_hair2.ci8.inc.c"
};

u64 gTreasureChestShopGalEyeOpenUpTex[] = {
#include "assets/objects/object_bg/treasure_cheat_shop_gal_eye_open_up.ci8.inc.c"
};

u64 gTreasureChestShopGalEyeHalfUpTex[] = {
#include "assets/objects/object_bg/treasure_cheat_shop_gal_eye_half_up.ci8.inc.c"
};

u64 gTreasureChestShopGalEyeClosedTex[] = {
#include "assets/objects/object_bg/treasure_cheat_shop_gal_eye_closed.ci8.inc.c"
};

u64 gTreasureChestShopGalEyeOpenDownTex[] = {
#include "assets/objects/object_bg/treasure_cheat_shop_gal_eye_open_down.ci8.inc.c"
};

u64 gTreasureChestShopGalEyeHalfDownTex[] = {
#include "assets/objects/object_bg/treasure_cheat_shop_gal_eye_half_down.ci8.inc.c"
};

u64 gTreasureChestShopGalMouthTex[] = {
#include "assets/objects/object_bg/treasure_cheat_shop_gal_mouth.ci8.inc.c"
};

u64 gTreasureChestShopGalEarAndBellyButtonTex[] = {
#include "assets/objects/object_bg/treasure_cheat_shop_gal_ear_and_belly_button.ci8.inc.c"
};

u64 gTreasureChestShopGalSkinTex[] = {
#include "assets/objects/object_bg/treasure_cheat_shop_gal_skin.ci8.inc.c"
};

u64 gTreasureChestShopGalClothesTex[] = {
#include "assets/objects/object_bg/treasure_cheat_shop_gal_clothes.ci8.inc.c"
};

u64 gTreasureChestShopGalFingersTex[] = {
#include "assets/objects/object_bg/treasure_cheat_shop_gal_fingers.ci8.inc.c"
};

StandardLimb gTreasureChestShopGalRootLimb = { 
    { 4, 3199, 0 }, TREASURE_CHEST_SHOP_GAL_LIMB_HIPS - 1, LIMB_DONE,
    NULL
};

StandardLimb gTreasureChestShopGalHipsLimb = { 
    { 0, 0, 0 }, TREASURE_CHEST_SHOP_GAL_LIMB_TORSO - 1, LIMB_DONE,
    gTreasureChestShopGalHipsDL
};

StandardLimb gTreasureChestShopGalTorsoLimb = { 
    { 797, 0, 0 }, TREASURE_CHEST_SHOP_GAL_LIMB_NECK - 1, TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_LEG_ROOT - 1,
    gTreasureChestShopGalTorsoDL
};

StandardLimb gTreasureChestShopGalNeckLimb = { 
    { 1398, 0, 0 }, TREASURE_CHEST_SHOP_GAL_LIMB_HEAD - 1, TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_ARM_ROOT - 1,
    gTreasureChestShopGalNeckDL
};

StandardLimb gTreasureChestShopGalHeadLimb = { 
    { 286, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gTreasureChestShopGalHeadDL
};

StandardLimb gTreasureChestShopGalLeftArmRootLimb = { 
    { 1331, -571, -84 }, TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_UPPER_ARM - 1, TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_ARM_ROOT -
    1,
    NULL
};

StandardLimb gTreasureChestShopGalLeftUpperArmLimb = { 
    { 0, 0, 0 }, TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_FOREARM - 1, LIMB_DONE,
    gTreasureChestShopGalLeftUpperArmDL
};

StandardLimb gTreasureChestShopGalLeftForearmLimb = { 
    { 885, 0, 0 }, TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_HAND - 1, LIMB_DONE,
    gTreasureChestShopGalLeftForearmDL
};

StandardLimb gTreasureChestShopGalLeftHandLimb = { 
    { 797, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gTreasureChestShopGalLeftHandDL
};

StandardLimb gTreasureChestShopGalRightArmRootLimb = { 
    { 1331, 571, -86 }, TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_UPPER_ARM - 1, LIMB_DONE,
    NULL
};

StandardLimb gTreasureChestShopGalRightUpperArmLimb = { 
    { 0, 0, 0 }, TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_FOREARM - 1, LIMB_DONE,
    gTreasureChestShopGalRightUpperArmDL
};

StandardLimb gTreasureChestShopGalRightForearmLimb = { 
    { 811, 0, 0 }, TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_HAND - 1, LIMB_DONE,
    gTreasureChestShopGalRightForearmDL
};

StandardLimb gTreasureChestShopGalRightHandLimb = { 
    { 726, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gTreasureChestShopGalRightHandDL
};

StandardLimb gTreasureChestShopGalRightLegRootLimb = { 
    { 418, 298, -9 }, TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_THIGH - 1, TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_LEG_ROOT - 1,
    NULL
};

StandardLimb gTreasureChestShopGalRightThighLimb = { 
    { 0, 0, 0 }, TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_SHIN - 1, LIMB_DONE,
    gTreasureChestShopGalRightThighDL
};

StandardLimb gTreasureChestShopGalRightShinLimb = { 
    { 1218, 0, 0 }, TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_FOOT_ROOT - 1, LIMB_DONE,
    gTreasureChestShopGalRightShinDL
};

StandardLimb gTreasureChestShopGalRightFootRootLimb = { 
    { 1968, 5, 0 }, TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_FOOT - 1, LIMB_DONE,
    NULL
};

StandardLimb gTreasureChestShopGalRightFootLimb = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gTreasureChestShopGalRightFootDL
};

StandardLimb gTreasureChestShopGalLeftLegRootLimb = { 
    { 418, -292, -9 }, TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_THIGH - 1, LIMB_DONE,
    NULL
};

StandardLimb gTreasureChestShopGalLeftThighLimb = { 
    { 0, 0, 0 }, TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_SHIN - 1, LIMB_DONE,
    gTreasureChestShopGalLeftThighDL
};

StandardLimb gTreasureChestShopGalLeftShinLimb = { 
    { 1218, 0, 0 }, TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_FOOT_ROOT - 1, LIMB_DONE,
    gTreasureChestShopGalLeftShinDL
};

StandardLimb gTreasureChestShopGalLeftFootRootLimb = { 
    { 1968, 5, 0 }, TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_FOOT - 1, LIMB_DONE,
    NULL
};

StandardLimb gTreasureChestShopGalLeftFootLimb = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gTreasureChestShopGalLeftFootDL
};

void* gTreasureChestShopGalSkelLimbs[] = {
    &gTreasureChestShopGalRootLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_ROOT */
    &gTreasureChestShopGalHipsLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_HIPS */
    &gTreasureChestShopGalTorsoLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_TORSO */
    &gTreasureChestShopGalNeckLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_NECK */
    &gTreasureChestShopGalHeadLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_HEAD */
    &gTreasureChestShopGalLeftArmRootLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_ARM_ROOT */
    &gTreasureChestShopGalLeftUpperArmLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_UPPER_ARM */
    &gTreasureChestShopGalLeftForearmLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_FOREARM */
    &gTreasureChestShopGalLeftHandLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_HAND */
    &gTreasureChestShopGalRightArmRootLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_ARM_ROOT */
    &gTreasureChestShopGalRightUpperArmLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_UPPER_ARM */
    &gTreasureChestShopGalRightForearmLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_FOREARM */
    &gTreasureChestShopGalRightHandLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_HAND */
    &gTreasureChestShopGalRightLegRootLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_LEG_ROOT */
    &gTreasureChestShopGalRightThighLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_THIGH */
    &gTreasureChestShopGalRightShinLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_SHIN */
    &gTreasureChestShopGalRightFootRootLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_FOOT_ROOT */
    &gTreasureChestShopGalRightFootLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_RIGHT_FOOT */
    &gTreasureChestShopGalLeftLegRootLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_LEG_ROOT */
    &gTreasureChestShopGalLeftThighLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_THIGH */
    &gTreasureChestShopGalLeftShinLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_SHIN */
    &gTreasureChestShopGalLeftFootRootLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_FOOT_ROOT */
    &gTreasureChestShopGalLeftFootLimb, /* TREASURE_CHEST_SHOP_GAL_LIMB_LEFT_FOOT */
};

FlexSkeletonHeader gTreasureChestShopGalSkel = { 
    { gTreasureChestShopGalSkelLimbs, ARRAY_COUNT(gTreasureChestShopGalSkelLimbs) }, 16
};

u8 object_bg_possiblePadding_008FD4[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 object_bg_Anim_009890FrameData[] = {
    0x0004, 0x0C7F, 0x0000, 0xC000, 0xDAE8, 0xDD7A, 0xC386, 0x0DB4, 0x02D7, 0xEDE1, 0x2000, 0x4000, 0xE000, 0x3D66, 
    0x8082, 0x0437, 0x03E3, 0x036B, 0x02DB, 0x0240, 0x01A5, 0x0116, 0x009E, 0x0049, 0x0012, 0xFFEB, 0xFFD3, 0xFFCC, 
    0xFFD3, 0xFFEB, 0x0012, 0x0049, 0x009E, 0x0116, 0x01A5, 0x0240, 0x02DB, 0x036B, 0x03E3, 0x0437, 0x046E, 0x0495, 
    0x04AD, 0x04B5, 0x04AD, 0x0495, 0x046E, 0xF2DF, 0xF2D1, 0xF2BE, 0xF2A7, 0xF28E, 0xF275, 0xF25D, 0xF24A, 0xF23C, 
    0xF233, 0xF22D, 0xF229, 0xF228, 0xF229, 0xF22D, 0xF233, 0xF23C, 0xF24A, 0xF25D, 0xF275, 0xF28E, 0xF2A7, 0xF2BE, 
    0xF2D1, 0xF2DF, 0xF2E8, 0xF2EE, 0xF2F2, 0xF2F3, 0xF2F2, 0xF2EE, 0xF2E8, 0x3A34, 0x3B37, 0x3CA6, 0x3E5E, 0x403A, 
    0x4215, 0x43CD, 0x453C, 0x463F, 0x46E8, 0x4760, 0x47A9, 0x47C1, 0x47A9, 0x4760, 0x46E8, 0x463F, 0x453C, 0x43CD, 
    0x4215, 0x403A, 0x3E5E, 0x3CA6, 0x3B37, 0x3A34, 0x398B, 0x3913, 0x38CA, 0x38B2, 0x38CA, 0x3913, 0x398B, 0xF082, 
    0xEFB7, 0xEE98, 0xED41, 0xEBCD, 0xEA59, 0xE901, 0xE7E2, 0xE718, 0xE694, 0xE636, 0xE5FE, 0xE5EB, 0xE5FE, 0xE636, 
    0xE694, 0xE718, 0xE7E2, 0xE901, 0xEA59, 0xEBCD, 0xED41, 0xEE98, 0xEFB7, 0xF082, 0xF105, 0xF164, 0xF19C, 0xF1AF, 
    0xF19C, 0xF164, 0xF105, 0xFF0E, 0xFF0D, 0xFF0A, 0xFF07, 0xFF04, 0xFF01, 0xFEFE, 0xFEFC, 0xFEFA, 0xFEF9, 0xFEF8, 
    0xFEF8, 0xFEF8, 0xFEF8, 0xFEF8, 0xFEF9, 0xFEFA, 0xFEFC, 0xFEFE, 0xFF01, 0xFF04, 0xFF07, 0xFF0A, 0xFF0D, 0xFF0E, 
    0xFF10, 0xFF10, 0xFF11, 0xFF11, 0xFF11, 0xFF10, 0xFF10, 0x0E11, 0x0BC8, 0x088B, 0x04AB, 0x0079, 0xFC47, 0xF866, 
    0xF529, 0xF2E1, 0xF164, 0xF054, 0xEFB1, 0xEF7B, 0xEFB1, 0xF054, 0xF164, 0xF2E1, 0xF529, 0xF866, 0xFC47, 0x0079, 
    0x04AB, 0x088B, 0x0BC8, 0x0E11, 0x0F8D, 0x109D, 0x1140, 0x1177, 0x1140, 0x109D, 0x0F8D, 0x0FB3, 0x10A2, 0x11F4, 
    0x1388, 0x153E, 0x16F4, 0x1889, 0x19DB, 0x1ACA, 0x1B65, 0x1BD4, 0x1C16, 0x1C2C, 0x1C16, 0x1BD4, 0x1B65, 0x1ACA, 
    0x19DB, 0x1889, 0x16F4, 0x153E, 0x1388, 0x11F4, 0x10A2, 0x0FB3, 0x0F18, 0x0EA9, 0x0E67, 0x0E50, 0x0E67, 0x0EA9, 
    0x0F18, 0xE899, 0xE7FE, 0xE723, 0xE61C, 0xE500, 0xE3E4, 0xE2DD, 0xE202, 0xE167, 0xE102, 0xE0BA, 0xE08F, 0xE081, 
    0xE08F, 0xE0BA, 0xE102, 0xE167, 0xE202, 0xE2DD, 0xE3E4, 0xE500, 0xE61C, 0xE723, 0xE7FE, 0xE899, 0xE8FE, 0xE946, 
    0xE971, 0xE97F, 0xE971, 0xE946, 0xE8FE, 0xF127, 0xF201, 0xF336, 0xF4A8, 0xF639, 0xF7C9, 0xF93C, 0xFA71, 0xFB4B, 
    0xFBD9, 0xFC3E, 0xFC7B, 0xFC8F, 0xFC7B, 0xFC3E, 0xFBD9, 0xFB4B, 0xFA71, 0xF93C, 0xF7C9, 0xF639, 0xF4A8, 0xF336, 
    0xF201, 0xF127, 0xF099, 0xF034, 0xEFF7, 0xEFE3, 0xEFF7, 0xF034, 0xF099, 0xF72A, 0xF7AC, 0xF864, 0xF940, 0xFA2F, 
    0xFB1D, 0xFBF9, 0xFCB1, 0xFD33, 0xFD88, 0xFDC4, 0xFDE8, 0xFDF4, 0xFDE8, 0xFDC4, 0xFD88, 0xFD33, 0xFCB1, 0xFBF9, 
    0xFB1D, 0xFA2F, 0xF940, 0xF864, 0xF7AC, 0xF72A, 0xF6D6, 0xF699, 0xF675, 0xF669, 0xF675, 0xF699, 0xF6D6, 0x191C, 
    0x192E, 0x1947, 0x1965, 0x1986, 0x19A6, 0x19C4, 0x19DE, 0x19EF, 0x19FB, 0x1A03, 0x1A08, 0x1A0A, 0x1A08, 0x1A03, 
    0x19FB, 0x19EF, 0x19DE, 0x19C4, 0x19A6, 0x1986, 0x1965, 0x1947, 0x192E, 0x191C, 0x1911, 0x1909, 0x1904, 0x1902, 
    0x1904, 0x1909, 0x1911, 0xF5B2, 0xF6D5, 0xF873, 0xFA63, 0xFC7B, 0xFE93, 0x0082, 0x0220, 0x0344, 0x0402, 0x0489, 
    0x04DB, 0x04F6, 0x04DB, 0x0489, 0x0402, 0x0344, 0x0220, 0x0082, 0xFE93, 0xFC7B, 0xFA63, 0xF873, 0xF6D5, 0xF5B2, 
    0xF4F4, 0xF46C, 0xF41A, 0xF3FF, 0xF41A, 0xF46C, 0xF4F4, 0x1AB7, 0x199A, 0x1806, 0x1623, 0x1417, 0x120C, 0x1029, 
    0x0E94, 0x0D78, 0x0CBE, 0x0C3A, 0x0BEA, 0x0BD0, 0x0BEA, 0x0C3A, 0x0CBE, 0x0D78, 0x0E94, 0x1029, 0x120C, 0x1417, 
    0x1623, 0x1806, 0x199A, 0x1AB7, 0x1B71, 0x1BF5, 0x1C45, 0x1C5F, 0x1C45, 0x1BF5, 0x1B71, 0xF7BD, 0xF81C, 0xF8A4, 
    0xF946, 0xF9F6, 0xFAA6, 0xFB48, 0xFBD0, 0xFC30, 0xFC6E, 0xFC9B, 0xFCB5, 0xFCBE, 0xFCB5, 0xFC9B, 0xFC6E, 0xFC30, 
    0xFBD0, 0xFB48, 0xFAA6, 0xF9F6, 0xF946, 0xF8A4, 0xF81C, 0xF7BD, 0xF77E, 0xF752, 0xF737, 0xF72E, 0xF737, 0xF752, 
    0xF77E, 0xD555, 0xD588, 0xD5CF, 0xD624, 0xD681, 0xD6DD, 0xD732, 0xD77A, 0xD7AC, 0xD7CD, 0xD7E4, 0xD7F2, 0xD7F7, 
    0xD7F2, 0xD7E4, 0xD7CD, 0xD7AC, 0xD77A, 0xD732, 0xD6DD, 0xD681, 0xD624, 0xD5CF, 0xD588, 0xD555, 0xD534, 0xD51D, 
    0xD50F, 0xD50A, 0xD50F, 0xD51D, 0xD534, 0xFFAE, 0x017C, 0x040B, 0x071B, 0x0A6C, 0x0DBD, 0x10CE, 0x135D, 0x152B, 
    0x1658, 0x172F, 0x17B0, 0x17DB, 0x17B0, 0x172F, 0x1658, 0x152B, 0x135D, 0x10CE, 0x0DBD, 0x0A6C, 0x071B, 0x040B, 
    0x017C, 0xFFAE, 0xFE81, 0xFDAA, 0xFD29, 0xFCFE, 0xFD29, 0xFDAA, 0xFE81, 0xFE38, 0xFFB4, 0x01CE, 0x0452, 0x070B, 
    0x09C4, 0x0C48, 0x0E62, 0x0FDD, 0x10D4, 0x1185, 0x11EF, 0x1212, 0x11EF, 0x1185, 0x10D4, 0x0FDD, 0x0E62, 0x0C48, 
    0x09C4, 0x070B, 0x0452, 0x01CE, 0xFFB4, 0xFE38, 0xFD41, 0xFC91, 0xFC27, 0xFC04, 0xFC27, 0xFC91, 0xFD41, 0x151D, 
    0x174F, 0x1A6C, 0x1E25, 0x222D, 0x2635, 0x29EF, 0x2D0C, 0x2F3D, 0x30AB, 0x31B0, 0x324D, 0x3281, 0x324D, 0x31B0, 
    0x30AB, 0x2F3D, 0x2D0C, 0x29EF, 0x2635, 0x222D, 0x1E25, 0x1A6C, 0x174F, 0x151D, 0x13B0, 0x12AA, 0x120E, 0x11D9, 
    0x120E, 0x12AA, 0x13B0, 0xEAE2, 0xE98A, 0xE7A2, 0xE55A, 0xE2E1, 0xE069, 0xDE21, 0xDC38, 0xDAE0, 0xDA00, 0xD960, 
    0xD900, 0xD8E0, 0xD900, 0xD960, 0xDA00, 0xDAE0, 0xDC38, 0xDE21, 0xE069, 0xE2E1, 0xE55A, 0xE7A2, 0xE98A, 0xEAE2, 
    0xEBC2, 0xEC62, 0xECC2, 0xECE2, 0xECC2, 0xEC62, 0xEBC2, 0x112E, 0x0F41, 0x0C86, 0x0940, 0x05B7, 0x022D, 0xFEE7, 
    0xFC2C, 0xFA3F, 0xF8FE, 0xF818, 0xF78F, 0xF761, 0xF78F, 0xF818, 0xF8FE, 0xFA3F, 0xFC2C, 0xFEE7, 0x022D, 0x05B7, 
    0x0940, 0x0C86, 0x0F41, 0x112E, 0x126F, 0x1355, 0x13DE, 0x140C, 0x13DE, 0x1355, 0x126F, 0x1136, 0x106C, 0x0F81, 
    0x0E81, 0x0D75, 0x0C6A, 0x0B69, 0x0A7E, 0x09B4, 0x0915, 0x08A3, 0x085F, 0x0848, 0x085F, 0x08A3, 0x0915, 0x09B4, 
    0x0A7E, 0x0B69, 0x0C6A, 0x0D75, 0x0E81, 0x0F81, 0x106C, 0x1136, 0x11D6, 0x1247, 0x128C, 0x12A3, 0x128C, 0x1247, 
    0x11D6, 0xF393, 0xF4DE, 0xF6B3, 0xF8E4, 0xFB43, 0xFDA3, 0xFFD4, 0x01A9, 0x02F4, 0x03CB, 0x0465, 0x04C1, 0x04E0, 
    0x04C1, 0x0465, 0x03CB, 0x02F4, 0x01A9, 0xFFD4, 0xFDA3, 0xFB43, 0xF8E4, 0xF6B3, 0xF4DE, 0xF393, 0xF2BC, 0xF222, 
    0xF1C6, 0xF1A7, 0xF1C6, 0xF222, 0xF2BC, 0xFEDE, 0xFE54, 0xFD90, 0xFCA5, 0xFBA8, 0xFAAA, 0xF9BF, 0xF8FB, 0xF871, 
    0xF817, 0xF7D6, 0xF7B0, 0xF7A3, 0xF7B0, 0xF7D6, 0xF817, 0xF871, 0xF8FB, 0xF9BF, 0xFAAA, 0xFBA8, 0xFCA5, 0xFD90, 
    0xFE54, 0xFEDE, 0xFF38, 0xFF79, 0xFF9F, 0xFFAC, 0xFF9F, 0xFF79, 0xFF38, 0xDEC1, 0xE0A9, 0xE35E, 0xE69B, 0xEA1D, 
    0xED9E, 0xF0DB, 0xF390, 0xF578, 0xF6B6, 0xF799, 0xF822, 0xF84F, 0xF822, 0xF799, 0xF6B6, 0xF578, 0xF390, 0xF0DB, 
    0xED9E, 0xEA1D, 0xE69B, 0xE35E, 0xE0A9, 0xDEC1, 0xDD83, 0xDCA0, 0xDC18, 0xDBEA, 0xDC18, 0xDCA0, 0xDD83, 0x0003, 
    0x0000, 0x0002, 0x0007, 0xFFEA, 0xFFA2, 0xFF48, 0xFEED, 0xFEA5, 0xFE73, 0xFE4E, 0xFE37, 0xFE2F, 0xFE37, 0xFE4E, 
    0xFE73, 0xFEA5, 0xFEED, 0xFF48, 0xFFA2, 0xFFEA, 0x0007, 0x0000, 0x0003, 0x0000, 0x0000, 0x0004, 0x0000, 0x0000, 
    0x0004, 0x0000, 0x0004, 0xFBFB, 0xFCC7, 0xFDE9, 0xFF45, 0x00BD, 0x0231, 0x0385, 0x049F, 0x0563, 0x05E2, 0x063C, 
    0x0672, 0x0683, 0x0672, 0x063C, 0x05E2, 0x0563, 0x049F, 0x0385, 0x0231, 0x00BD, 0xFF45, 0xFDE9, 0xFCC7, 0xFBFB, 
    0xFB76, 0xFB18, 0xFADF, 0xFACC, 0xFADF, 0xFB18, 0xFB76, 0xB5D3, 0xB5FD, 0xB5E4, 0xB48B, 0xB12F, 0xAF2E, 0xAD9C, 
    0xAC65, 0xAB90, 0xAB07, 0xAAA6, 0xAA6B, 0xAA58, 0xAA6B, 0xAAA6, 0xAB07, 0xAB90, 0xAC65, 0xAD9C, 0xAF2E, 0xB12F, 
    0xB48B, 0xB605, 0xB5DB, 0xB5F4, 0xB5EC, 0xB5C4, 0xB5E2, 0xB5E1, 0xB5C0, 0xB5E6, 0xB5CB, 0x0036, 0x0000, 0x0036, 
    0x0267, 0x07CC, 0x0AE9, 0x0D40, 0x0EFF, 0x1025, 0x10DD, 0x115E, 0x11AA, 0x11C3, 0x11AA, 0x115E, 0x10DD, 0x1025, 
    0x0EFF, 0x0D40, 0x0AE9, 0x07CC, 0x0267, 0x0000, 0x0036, 0x0000, 0x0000, 0x0036, 0x0000, 0x0000, 0x0036, 0x0000, 
    0x0036, 0x00DB, 0x009F, 0x0057, 0x0016, 0xFFF6, 0xFFFE, 0x0000, 0x0000, 0xFFFB, 0xFFFB, 0x0000, 0x0000, 0xFFFA, 
    0xFFFA, 0x0000, 0xFFFB, 0xFFFB, 0x0000, 0x0000, 0xFFFE, 0xFFF6, 0x0016, 0x0057, 0x009F, 0x00DB, 0x0105, 0x0125, 
    0x0139, 0x013F, 0x0139, 0x0125, 0x0105, 0xFC11, 0xFCD7, 0xFDF3, 0xFF4A, 0x00C1, 0x0238, 0x0392, 0x04B2, 0x057C, 
    0x0600, 0x065E, 0x0696, 0x06A9, 0x0696, 0x065E, 0x0600, 0x057C, 0x04B2, 0x0392, 0x0238, 0x00C1, 0xFF4A, 0xFDF3, 
    0xFCD7, 0xFC11, 0xFB91, 0xFB35, 0xFAFF, 0xFAED, 0xFAFF, 0xFB35, 0xFB91, 0xAC8A, 0xAD6B, 0xAEBE, 0xB091, 0xB393, 
    0xB578, 0xB594, 0xB588, 0xB55B, 0xB552, 0xB56C, 0xB568, 0xB544, 0xB545, 0xB56C, 0xB552, 0xB55B, 0xB588, 0xB594, 
    0xB578, 0xB393, 0xB091, 0xAEBE, 0xAD6B, 0xAC8A, 0xABFB, 0xAB97, 0xAB5B, 0xAB47, 0xAB5B, 0xAB97, 0xABFB, 0x0E0F, 
    0x0CCE, 0x0AD9, 0x080D, 0x0344, 0x0037, 0x0000, 0x0000, 0x0036, 0x0036, 0x0000, 0x0000, 0x0036, 0x0037, 0x0000, 
    0x0036, 0x0036, 0x0000, 0x0000, 0x0037, 0x0344, 0x080D, 0x0AD9, 0x0CCE, 0x0E0F, 0x0ED6, 0x0F60, 0x0FB1, 0x0FCC, 
    0x0FB1, 0x0F60, 0x0ED6, 0x0000, 
};

JointIndex object_bg_Anim_009890JointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0002, 0x0002, 0x0002 },
    { 0x000F, 0x002F, 0x004F },
    { 0x006F, 0x008F, 0x00AF },
    { 0x00CF, 0x00EF, 0x010F },
    { 0x012F, 0x014F, 0x016F },
    { 0x0002, 0x0002, 0x0003 },
    { 0x018F, 0x01AF, 0x01CF },
    { 0x01EF, 0x020F, 0x022F },
    { 0x024F, 0x026F, 0x028F },
    { 0x0002, 0x0002, 0x0003 },
    { 0x0004, 0x0005, 0x0006 },
    { 0x02AF, 0x02CF, 0x02EF },
    { 0x0007, 0x0008, 0x0009 },
    { 0x000A, 0x000B, 0x000C },
    { 0x030F, 0x032F, 0x034F },
    { 0x0002, 0x0002, 0x036F },
    { 0x0002, 0x0002, 0x000D },
    { 0x0002, 0x0002, 0x000E },
    { 0x000A, 0x000B, 0x000C },
    { 0x038F, 0x03AF, 0x03CF },
    { 0x0002, 0x0002, 0x03EF },
    { 0x0002, 0x0002, 0x000D },
    { 0x0002, 0x0002, 0x000E },
};

AnimationHeader object_bg_Anim_009890 = { 
    { 32 }, object_bg_Anim_009890FrameData,
    object_bg_Anim_009890JointIndices, 15
};

s16 object_bg_Anim_009F20FrameData[] = {
    0x0004, 0x0C7F, 0x0000, 0xE8C7, 0x4000, 0x01F9, 0xFED2, 0x9AF5, 0x060C, 0xF929, 0xF0E0, 0x6FF7, 0xED42, 0x06E7, 
    0x002B, 0x002B, 0x002B, 0x002A, 0x002A, 0x002A, 0x0029, 0x002A, 0x002A, 0x002B, 0x002D, 0x002F, 0x0031, 0x0033, 
    0x0035, 0x0037, 0x003A, 0x003C, 0x003E, 0x0041, 0x0044, 0x0046, 0x0049, 0x004B, 0x004E, 0x0051, 0x0053, 0x0056, 
    0x0058, 0x005A, 0x005D, 0x005F, 0x0061, 0x0063, 0x0064, 0x0066, 0x0067, 0x0069, 0x006A, 0x006B, 0x006B, 0x006C, 
    0x006C, 0x0063, 0x0059, 0x0050, 0x0047, 0x003E, 0x0035, 0xFFEC, 0xFFE3, 0xFFD4, 0xFFC0, 0xFFA8, 0xFF8E, 0xFF74, 
    0xFF5B, 0xFF45, 0xFF34, 0xFF25, 0xFF15, 0xFF04, 0xFEF3, 0xFEE1, 0xFECF, 0xFEBC, 0xFEAA, 0xFE96, 0xFE83, 0xFE70, 
    0xFE5D, 0xFE4A, 0xFE38, 0xFE26, 0xFE14, 0xFE03, 0xFDF2, 0xFDE2, 0xFDD3, 0xFDC5, 0xFDB8, 0xFDAC, 0xFDA1, 0xFD97, 
    0xFD8F, 0xFD88, 0xFD83, 0xFD7F, 0xFD7D, 0xFD7D, 0xFD7E, 0xFD82, 0xFDDA, 0xFE33, 0xFE8B, 0xFEE3, 0xFF3B, 0xFF93, 
    0xFAB4, 0xFAB3, 0xFAB4, 0xFAB5, 0xFAB6, 0xFAB7, 0xFAB7, 0xFAB7, 0xFAB6, 0xFAB4, 0xFAB0, 0xFAAC, 0xFAA8, 0xFAA3, 
    0xFA9F, 0xFA9A, 0xFA94, 0xFA8F, 0xFA8A, 0xFA84, 0xFA7E, 0xFA78, 0xFA73, 0xFA6D, 0xFA67, 0xFA61, 0xFA5C, 0xFA56, 
    0xFA51, 0xFA4C, 0xFA47, 0xFA42, 0xFA3E, 0xFA39, 0xFA36, 0xFA32, 0xFA2F, 0xFA2C, 0xFA2A, 0xFA28, 0xFA27, 0xFA26, 
    0xFA25, 0xFA3A, 0xFA4E, 0xFA62, 0xFA77, 0xFA8B, 0xFA9F, 0xE055, 0xE04B, 0xE045, 0xE044, 0xE045, 0xE048, 0xE04C, 
    0xE051, 0xE054, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 
    0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 
    0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 0xE055, 
    0xF689, 0xF65C, 0xF63E, 0xF62D, 0xF627, 0xF62C, 0xF639, 0xF64E, 0xF669, 0xF689, 0xF6AD, 0xF6D4, 0xF6FE, 0xF72B, 
    0xF75B, 0xF78D, 0xF7C1, 0xF7F7, 0xF82E, 0xF866, 0xF89F, 0xF8D9, 0xF913, 0xF94D, 0xF987, 0xF9C0, 0xF9F8, 0xFA2F, 
    0xFA65, 0xFA99, 0xFACA, 0xFAFA, 0xFB27, 0xFB51, 0xFB77, 0xFB9B, 0xFBBA, 0xFBD6, 0xFBED, 0xFBFF, 0xFC0D, 0xFC15, 
    0xFC18, 0xFBD1, 0xFB1A, 0xFA1A, 0xF8FB, 0xF7E8, 0xF70A, 0x1DD1, 0x1E11, 0x1E45, 0x1E6B, 0x1E81, 0x1E86, 0x1E78, 
    0x1E57, 0x1E1F, 0x1DD1, 0x1D71, 0x1D08, 0x1C97, 0x1C1E, 0x1B9F, 0x1B19, 0x1A8E, 0x19FE, 0x196A, 0x18D3, 0x183A, 
    0x17A0, 0x1705, 0x166A, 0x15CF, 0x1537, 0x14A0, 0x140D, 0x137E, 0x12F3, 0x126E, 0x11EF, 0x1177, 0x1107, 0x109F, 
    0x1040, 0x0FEC, 0x0FA3, 0x0F65, 0x0F33, 0x0F0F, 0x0EF9, 0x0EF1, 0x0FAE, 0x119A, 0x1447, 0x1745, 0x1A25, 0x1C79, 
    0xECA3, 0xEC72, 0xEC54, 0xEC46, 0xEC46, 0xEC50, 0xEC62, 0xEC78, 0xEC8E, 0xECA3, 0xECB7, 0xECCD, 0xECE4, 0xECFE, 
    0xED18, 0xED34, 0xED51, 0xED6F, 0xED8E, 0xEDAD, 0xEDCD, 0xEDED, 0xEE0D, 0xEE2D, 0xEE4E, 0xEE6D, 0xEE8D, 0xEEAB, 
    0xEEC9, 0xEEE6, 0xEF02, 0xEF1C, 0xEF35, 0xEF4C, 0xEF62, 0xEF76, 0xEF87, 0xEF96, 0xEFA3, 0xEFAE, 0xEFB5, 0xEFBA, 
    0xEFBB, 0xEF94, 0xEF2E, 0xEE9F, 0xEE00, 0xED67, 0xECEB, 0xFD46, 0xFD46, 0xFD46, 0xFD46, 0xFD46, 0xFD46, 0xFD46, 
    0xFD46, 0xFD46, 0xFD46, 0xFD36, 0xFD26, 0xFD16, 0xFD05, 0xFCF5, 0xFCE5, 0xFCD5, 0xFCC5, 0xFCB5, 0xFCA5, 0xFC94, 
    0xFC84, 0xFC74, 0xFC64, 0xFC54, 0xFC44, 0xFC34, 0xFC23, 0xFC13, 0xFC03, 0xFBF3, 0xFBE3, 0xFBD3, 0xFBC3, 0xFBB2, 
    0xFBA2, 0xFB92, 0xFB82, 0xFB72, 0xFB62, 0xFB52, 0xFB41, 0xFB31, 0xFB7D, 0xFBC9, 0xFC16, 0xFC62, 0xFCAE, 0xFCFA, 
    0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 
    0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 0xDD6B, 
    0xDD6C, 0xDD6C, 0xDD6C, 0xDD6C, 0xDD6C, 0xDD6C, 0xDD6C, 0xDD6C, 0xDD6C, 0xDD6C, 0xDD6C, 0xDD6C, 0xDD6C, 0xDD6C, 
    0xDD6C, 0xDD6C, 0xDD6C, 0xDD6C, 0xDD6B, 0xDD6B, 0xDD6B, 0x9B4B, 0x9B4B, 0x9B4B, 0x9B4B, 0x9B4B, 0x9B4B, 0x9B4B, 
    0x9B4B, 0x9B4B, 0x9B4B, 0x9B5E, 0x9B70, 0x9B83, 0x9B95, 0x9BA8, 0x9BBA, 0x9BCD, 0x9BDF, 0x9BF2, 0x9C04, 0x9C17, 
    0x9C29, 0x9C3C, 0x9C4E, 0x9C61, 0x9C73, 0x9C86, 0x9C98, 0x9CAB, 0x9CBD, 0x9CD0, 0x9CE2, 0x9CF5, 0x9D07, 0x9D1A, 
    0x9D2C, 0x9D3F, 0x9D51, 0x9D64, 0x9D76, 0x9D89, 0x9D9B, 0x9DAE, 0x9D57, 0x9CFF, 0x9CA8, 0x9C51, 0x9BFA, 0x9BA2, 
    0xFAC0, 0xFAC0, 0xFAC0, 0xFAC0, 0xFAC0, 0xFAC0, 0xFAC0, 0xFAC0, 0xFAC0, 0xFAC0, 0xFAA8, 0xFA91, 0xFA79, 0xFA62, 
    0xFA4B, 0xFA33, 0xFA1C, 0xFA04, 0xF9ED, 0xF9D6, 0xF9BE, 0xF9D4, 0xF9EF, 0xFA0F, 0xFA34, 0xFA5D, 0xFA89, 0xFAB8, 
    0xFAE9, 0xFB1C, 0xFB4F, 0xFB83, 0xFBB6, 0xFBE8, 0xFC19, 0xFC47, 0xFC72, 0xFC9A, 0xFCBD, 0xFCDC, 0xFCF5, 0xFD09, 
    0xFD15, 0xFCFE, 0xFCB3, 0xFC47, 0xFBCD, 0xFB57, 0xFAF7, 0x1161, 0x1161, 0x1161, 0x1161, 0x1161, 0x1161, 0x1161, 
    0x1161, 0x1161, 0x1161, 0x1185, 0x11A9, 0x11CC, 0x11F0, 0x1214, 0x1238, 0x125C, 0x127F, 0x12A3, 0x12C7, 0x12EB, 
    0x12F9, 0x1307, 0x1315, 0x1322, 0x132E, 0x133A, 0x1344, 0x134E, 0x1357, 0x135E, 0x1365, 0x136A, 0x136E, 0x1370, 
    0x1371, 0x1370, 0x136E, 0x1369, 0x1363, 0x135B, 0x1350, 0x1344, 0x1322, 0x12E0, 0x128A, 0x122C, 0x11D3, 0x118B, 
    0x2951, 0x2951, 0x2951, 0x2951, 0x2951, 0x2951, 0x2951, 0x2951, 0x2951, 0x2951, 0x2A0F, 0x2ACC, 0x2B8A, 0x2C48, 
    0x2D05, 0x2DC3, 0x2E81, 0x2F3E, 0x2FFC, 0x30BA, 0x3177, 0x31BA, 0x31F8, 0x3233, 0x3269, 0x329A, 0x32C6, 0x32ED, 
    0x330F, 0x332B, 0x3341, 0x3351, 0x335B, 0x335E, 0x335A, 0x334F, 0x333D, 0x3323, 0x3301, 0x32D7, 0x32A5, 0x326A, 
    0x3227, 0x3182, 0x3049, 0x2EB5, 0x2D00, 0x2B62, 0x2A15, 0x7DC3, 0x7DC3, 0x7DC3, 0x7DC3, 0x7DC3, 0x7DC3, 0x7DC3, 
    0x7DC3, 0x7DC3, 0x7DC3, 0x7DC6, 0x7DC8, 0x7DCB, 0x7DCE, 0x7DD0, 0x7DD3, 0x7DD5, 0x7DD8, 0x7DDB, 0x7DDD, 0x7DE0, 
    0x7DE2, 0x7DE5, 0x7DE8, 0x7DEA, 0x7DED, 0x7DEF, 0x7DF2, 0x7DF5, 0x7DF7, 0x7DFA, 0x7DFC, 0x7DFF, 0x7E02, 0x7E04, 
    0x7E07, 0x7E09, 0x7E0C, 0x7E0F, 0x7E11, 0x7E14, 0x7E16, 0x7E17, 0x7E0B, 0x7DFF, 0x7DF3, 0x7DE7, 0x7DDB, 0x7DCF, 
    0xCFCB, 0xCFCB, 0xCFCB, 0xCFCB, 0xCFCB, 0xCFCB, 0xCFCB, 0xCFCB, 0xCFCB, 0xCFCB, 0xCFD8, 0xCFE6, 0xCFF3, 0xD001, 
    0xD00E, 0xD01C, 0xD029, 0xD037, 0xD044, 0xD051, 0xD05F, 0xD06C, 0xD07A, 0xD087, 0xD095, 0xD0A2, 0xD0B0, 0xD0BD, 
    0xD0CB, 0xD0D8, 0xD0E6, 0xD0F3, 0xD100, 0xD10E, 0xD11B, 0xD129, 0xD136, 0xD144, 0xD151, 0xD15F, 0xD16C, 0xD17A, 
    0xD187, 0xD148, 0xD108, 0xD0C9, 0xD089, 0xD04A, 0xD00A, 0x76C4, 0x76C4, 0x76C4, 0x76C4, 0x76C4, 0x76C4, 0x76C4, 
    0x76C4, 0x76C4, 0x76C4, 0x76D9, 0x76EE, 0x7703, 0x7719, 0x772E, 0x7743, 0x7758, 0x776D, 0x7782, 0x7797, 0x77AC, 
    0x77C1, 0x77D6, 0x77EC, 0x7801, 0x7816, 0x782B, 0x7840, 0x7855, 0x786A, 0x787F, 0x7894, 0x78AA, 0x78BF, 0x78D4, 
    0x78E9, 0x78FE, 0x7913, 0x7928, 0x793D, 0x7952, 0x7967, 0x797D, 0x7919, 0x78B6, 0x7852, 0x77EF, 0x778B, 0x7728, 
    
};

JointIndex object_bg_Anim_009F20JointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0002, 0x0003, 0x0004 },
    { 0x000E, 0x003F, 0x0070 },
    { 0x0005, 0x00A1, 0x0006 },
    { 0x00D2, 0x0103, 0x0134 },
    { 0x0165, 0x0196, 0x01C7 },
    { 0x0002, 0x0007, 0x0008 },
    { 0x01F8, 0x0229, 0x025A },
    { 0x0009, 0x000A, 0x000B },
    { 0x028B, 0x02BC, 0x02ED },
    { 0x000C, 0x0002, 0x000D },
};

AnimationHeader object_bg_Anim_009F20 = { 
    { 49 }, object_bg_Anim_009F20FrameData,
    object_bg_Anim_009F20JointIndices, 14
};

s16 object_bg_Anim_00A280FrameData[] = {
    0x0004, 0x0C7F, 0x0000, 0xC000, 0x2000, 0x4000, 0xE000, 0x3D66, 0x8082, 0x0426, 0x03DC, 0x0366, 0x02D3, 0x0230, 
    0x018C, 0x00F4, 0x0076, 0x0020, 0xF2D7, 0xF2C9, 0xF2B6, 0xF2A0, 0xF289, 0xF272, 0xF25D, 0xF24B, 0xF240, 0x3A93, 
    0x3B90, 0x3D02, 0x3EC4, 0x40AC, 0x4294, 0x4455, 0x45C6, 0x46C0, 0xF0EC, 0xF1CC, 0xF303, 0xF473, 0xF5FD, 0xF784, 
    0xF8E8, 0xFA0D, 0xFAD2, 0xFE5C, 0xFCB6, 0xFA5B, 0xF788, 0xF47B, 0xF172, 0xEEAA, 0xEC61, 0xEAD5, 0x0D2A, 0x0AFB, 
    0x07D6, 0x040F, 0xFFFA, 0xFBE8, 0xF82D, 0xF51C, 0xF308, 0x0EE1, 0x0DB4, 0x0C48, 0x0AB7, 0x091C, 0x0790, 0x062E, 
    0x0511, 0x0452, 0xE98E, 0xEAEC, 0xEC93, 0xEE66, 0xF045, 0xF212, 0xF3AE, 0xF4FA, 0xF5D8, 0xF2A0, 0xF4B9, 0xF744, 
    0xFA11, 0xFCF1, 0xFFB5, 0x022D, 0x042C, 0x0580, 0xF7B2, 0xF874, 0xF95F, 0xFA62, 0xFB6C, 0xFC6C, 0xFD51, 0xFE09, 
    0xFE84, 0x194C, 0x198F, 0x19E1, 0x1A3B, 0x1A98, 0x1AF1, 0x1B40, 0x1B81, 0x1BAB, 0xF6CE, 0xF864, 0xFA4F, 0xFC6C, 
    0xFE97, 0x00AE, 0x028B, 0x040D, 0x050E, 0x2077, 0x2A7E, 0x3464, 0x3C57, 0x4487, 0x4EEF, 0x5AFA, 0x6663, 0x6EE5, 
    0xF5B9, 0xF1C7, 0xEC28, 0xE16B, 0xD7E0, 0xD489, 0xD254, 0xD108, 0xD06B, 0xD541, 0xD55E, 0xD4ED, 0xD32C, 0xCF5C, 
    0xC3A2, 0xB1D4, 0x9C07, 0x8557, 0xFD05, 0xF6FC, 0xF094, 0xECCB, 0xEDB2, 0xF17C, 0xF564, 0xF942, 0xFD3E, 0xFF81, 
    0x018D, 0x03B7, 0x0558, 0x03F3, 0x00F2, 0xFD8D, 0xF954, 0xF506, 0x1939, 0x2198, 0x2B3B, 0x3322, 0x334B, 0x3148, 
    0x2D8E, 0x25D5, 0x1D0A, 0xED79, 0xF173, 0xF66B, 0xFBFE, 0x01C7, 0x0764, 0x0C6F, 0x1085, 0x1342, 0x115E, 0x113D, 
    0x10DD, 0x104F, 0x0FA6, 0x0EF3, 0x0E49, 0x0DB9, 0x0D56, 0x1076, 0x0F08, 0x0D1A, 0x0AD9, 0x0874, 0x0617, 0x03F1, 
    0x0230, 0x0101, 0xDE1C, 0xE2AF, 0xE838, 0xEE52, 0xF496, 0xFA9C, 0xFFFE, 0x0456, 0x073C, 0xDACF, 0xD700, 0xD263, 
    0xCD4E, 0xC817, 0xC312, 0xBE96, 0xBAF8, 0xB88D, 0xC0D2, 0xBBB5, 0xB4D2, 0xACCB, 0xA443, 0x9BDC, 0x9439, 0x8DFB, 
    0x89C5, 0xF54F, 0xF74B, 0xF96C, 0xFB98, 0xFDB5, 0xFFAB, 0x015E, 0x02B4, 0x0395, 0xFF94, 0xFF38, 0xFE05, 0xFC39, 
    0xFA0E, 0xF7C1, 0xF58F, 0xF3B2, 0xF268, 0xDE01, 0xDDE0, 0xDE3E, 0xDEF9, 0xDFF0, 0xE104, 0xE214, 0xE2FF, 0xE3A3, 
    0x0A45, 0x06BC, 0x0278, 0xFDC8, 0xF8FA, 0xF45C, 0xF03D, 0xECEB, 0xEAB3, 0x01D3, 0x01BE, 0x01A9, 0x0196, 0x0184, 
    0x0174, 0x0167, 0x015D, 0x0156, 0xEF3F, 0xF131, 0xF38A, 0xF621, 0xF8C8, 0xFB56, 0xFD9D, 0xFF74, 0x00AE, 0x0003, 
    0x0000, 0x0000, 0x0006, 0xFFDA, 0xFF8A, 0xFF27, 0xFEC8, 0xFE7F, 0xFC49, 0xFD12, 0xFE38, 0xFF9C, 0x011C, 0x0298, 
    0x03F0, 0x0508, 0x05C4, 0xB5D4, 0xB5FD, 0xB605, 0xB367, 0xB0A5, 0xAEB9, 0xAD2F, 0xABFD, 0xAB32, 0x0036, 0x0000, 
    0x0000, 0x0441, 0x08AB, 0x0BA3, 0x0DEA, 0x0F9B, 0x10AF, 0x00C3, 0x008B, 0x0046, 0x000B, 0x0000, 0xFFFE, 0xFFFD, 
    0x0000, 0xFFFB, 0xFC5D, 0xFD21, 0xFE41, 0xFFA0, 0x0121, 0x02A0, 0x03FF, 0x051E, 0x05E1, 0xACD9, 0xADB8, 0xAF19, 
    0xB114, 0xB598, 0xB57A, 0xB574, 0xB58A, 0xB55D, 0x0D98, 0x0C54, 0x0A47, 0x0739, 0x0000, 0x0037, 0x0036, 0x0000, 
    0x0036, 0x0000, 
};

JointIndex object_bg_Anim_00A280JointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0002, 0x0002, 0x0002 },
    { 0x0009, 0x0012, 0x001B },
    { 0x0024, 0x002D, 0x0036 },
    { 0x003F, 0x0048, 0x0051 },
    { 0x005A, 0x0063, 0x006C },
    { 0x0002, 0x0002, 0x0003 },
    { 0x0075, 0x007E, 0x0087 },
    { 0x0090, 0x0099, 0x00A2 },
    { 0x00AB, 0x00B4, 0x00BD },
    { 0x0002, 0x0002, 0x0003 },
    { 0x00C6, 0x00CF, 0x00D8 },
    { 0x00E1, 0x00EA, 0x00F3 },
    { 0x00FC, 0x0105, 0x010E },
    { 0x0004, 0x0005, 0x0006 },
    { 0x0117, 0x0120, 0x0129 },
    { 0x0002, 0x0002, 0x0132 },
    { 0x0002, 0x0002, 0x0007 },
    { 0x0002, 0x0002, 0x0008 },
    { 0x0004, 0x0005, 0x0006 },
    { 0x013B, 0x0144, 0x014D },
    { 0x0002, 0x0002, 0x0156 },
    { 0x0002, 0x0002, 0x0007 },
    { 0x0002, 0x0002, 0x0008 },
};

AnimationHeader object_bg_Anim_00A280 = { 
    { 9 }, object_bg_Anim_00A280FrameData,
    object_bg_Anim_00A280JointIndices, 9
};

s16 object_bg_Anim_00AD98FrameData[] = {
    0x0004, 0x0C7F, 0x0000, 0xC000, 0x2000, 0x4000, 0xE000, 0x3D66, 0x8082, 0x0000, 0x002F, 0x0066, 0x00A3, 0x00E6, 
    0x012D, 0x0177, 0x01C3, 0x020F, 0x025C, 0x02A7, 0x02F0, 0x0336, 0x0377, 0x03B2, 0x03E7, 0x0414, 0x0437, 0x0455, 
    0x0472, 0x048D, 0x04A5, 0x04BB, 0x04CD, 0x04DC, 0x04E8, 0x04EF, 0x04F2, 0x04EF, 0x04E8, 0x04DB, 0x04C7, 0x04AE, 
    0x048E, 0x0466, 0xF23C, 0xF243, 0xF24B, 0xF254, 0xF25E, 0xF269, 0xF274, 0xF280, 0xF28B, 0xF297, 0xF2A2, 0xF2AD, 
    0xF2B8, 0xF2C2, 0xF2CB, 0xF2D3, 0xF2D9, 0xF2DF, 0xF2E3, 0xF2E7, 0xF2EB, 0xF2EE, 0xF2F1, 0xF2F3, 0xF2F4, 0xF2F5, 
    0xF2F6, 0xF2F6, 0xF2F5, 0xF2F4, 0xF2F2, 0xF2F0, 0xF2ED, 0xF2E9, 0xF2E4, 0x471C, 0x468C, 0x45E4, 0x4528, 0x445C, 
    0x4384, 0x42A1, 0x41B9, 0x40CE, 0x3FE3, 0x3EFC, 0x3E1C, 0x3D47, 0x3C80, 0x3BCB, 0x3B2A, 0x3AA1, 0x3A34, 0x39D7, 
    0x3980, 0x392E, 0x38E4, 0x38A2, 0x3869, 0x383B, 0x3818, 0x3802, 0x37FA, 0x3801, 0x3818, 0x3840, 0x387B, 0x38C9, 
    0x392C, 0x39A4, 0xFB1B, 0xFA9C, 0xFA01, 0xF94E, 0xF889, 0xF7B7, 0xF6E0, 0xF607, 0xF532, 0xF468, 0xF3AD, 0xF308, 
    0xF27D, 0xF20D, 0xF1B1, 0xF168, 0xF12E, 0xF101, 0xF0DE, 0xF0C2, 0xF0AB, 0xF097, 0xF082, 0xF06C, 0xF057, 0xF044, 
    0xF034, 0xF026, 0xF01D, 0xF018, 0xF018, 0xF01E, 0xF02B, 0xF040, 0xF05C, 0xEA43, 0xEC5C, 0xEF0B, 0xF22F, 0xF5A7, 
    0xF951, 0xFD0C, 0x00B5, 0x042B, 0x074C, 0x09F7, 0x0C0B, 0x0D65, 0x0DD0, 0x0D50, 0x0C14, 0x0A4E, 0x082F, 0x05E8, 
    0x03AA, 0x01A6, 0x000C, 0xFF0E, 0xFE8E, 0xFE46, 0xFE2C, 0xFE38, 0xFE5F, 0xFE98, 0xFEDA, 0xFF1C, 0xFF53, 0xFF77, 
    0xFF7E, 0xFF5E, 0xF245, 0xF385, 0xF50E, 0xF6D1, 0xF8C1, 0xFACF, 0xFCF0, 0xFF14, 0x012E, 0x0330, 0x050C, 0x06B6, 
    0x081E, 0x0949, 0x0A45, 0x0B19, 0x0BC8, 0x0C59, 0x0CD0, 0x0D32, 0x0D85, 0x0DCE, 0x0E11, 0x0E5E, 0x0EBD, 0x0F25, 
    0x0F8D, 0x0FEE, 0x1040, 0x1079, 0x1093, 0x1084, 0x1044, 0x0FCC, 0x0F13, 0x03D9, 0x03CD, 0x03BC, 0x03A8, 0x0392, 
    0x037B, 0x0367, 0x0355, 0x0349, 0x0343, 0x0345, 0x0351, 0x0368, 0x038D, 0x03C1, 0x0405, 0x045B, 0x04C5, 0x0572, 
    0x067E, 0x07CF, 0x094B, 0x0AD8, 0x0C5C, 0x0DBE, 0x0EE4, 0x0FB3, 0x103C, 0x10A1, 0x10E2, 0x1101, 0x10FE, 0x10DB, 
    0x1097, 0x1034, 0xF618, 0xF513, 0xF3FF, 0xF2E0, 0xF1B7, 0xF089, 0xEF58, 0xEE27, 0xECF8, 0xEBCF, 0xEAAE, 0xE999, 
    0xE892, 0xE79D, 0xE6BB, 0xE5F0, 0xE540, 0xE4AB, 0xE45F, 0xE476, 0xE4DA, 0xE573, 0xE62D, 0xE6F1, 0xE7A9, 0xE83D, 
    0xE899, 0xE8BC, 0xE8BC, 0xE8A4, 0xE880, 0xE85A, 0xE83F, 0xE839, 0xE853, 0x05B5, 0x0586, 0x056F, 0x056A, 0x0573, 
    0x0586, 0x05A0, 0x05BC, 0x05D5, 0x05E8, 0x05F0, 0x05EA, 0x05D1, 0x05A1, 0x0556, 0x04EC, 0x045E, 0x03A9, 0x0281, 
    0x00B9, 0xFE7E, 0xFBFC, 0xF95C, 0xF6CC, 0xF476, 0xF286, 0xF127, 0xF03A, 0xEF83, 0xEF03, 0xEEBE, 0xEEB6, 0xEEEE, 
    0xEF67, 0xF024, 0xFF9F, 0xFF93, 0x0001, 0x00BA, 0x018F, 0x0251, 0x02D0, 0x0324, 0x0383, 0x03EA, 0x0456, 0x04C5, 
    0x0533, 0x059E, 0x0603, 0x065E, 0x06AD, 0x06EE, 0x071D, 0x0737, 0x0739, 0x0721, 0x06EB, 0x0696, 0x05F5, 0x04EF, 
    0x0398, 0x0207, 0x0050, 0xFE89, 0xFCC6, 0xFB1D, 0xF9A4, 0xF870, 0xF795, 0x1BC3, 0x1890, 0x141B, 0x0F33, 0x0AA9, 
    0x074E, 0x05F3, 0x0608, 0x066F, 0x071E, 0x080C, 0x092F, 0x0A7D, 0x0BEF, 0x0D7A, 0x0F14, 0x10B5, 0x1254, 0x13E6, 
    0x1563, 0x16C1, 0x17F7, 0x18FC, 0x19C6, 0x1A50, 0x1AA2, 0x1AC5, 0x1AC1, 0x1A9E, 0x1A65, 0x1A1F, 0x19D3, 0x198B, 
    0x194F, 0x1927, 0x06CC, 0x0621, 0x05F5, 0x0621, 0x067E, 0x06E3, 0x072A, 0x0761, 0x07AF, 0x080E, 0x087A, 0x08EF, 
    0x0967, 0x09E0, 0x0A53, 0x0ABE, 0x0B1A, 0x0B64, 0x0B97, 0x0BAF, 0x0BA7, 0x0B7B, 0x0B27, 0x0AA4, 0x09BA, 0x0845, 
    0x0663, 0x0431, 0x01CF, 0xFF5B, 0xFCF2, 0xFAB2, 0xF8BB, 0xF729, 0xF61C, 0x723C, 0x61F5, 0x49DC, 0x3BF1, 0x33B3, 
    0x2F89, 0x2BA4, 0x280C, 0x24C9, 0x21E5, 0x1F69, 0x1D5D, 0x1BC9, 0x1AB7, 0x19FB, 0x1962, 0x18E9, 0x188F, 0x184F, 
    0x1828, 0x1818, 0x181B, 0x182F, 0x1851, 0x1880, 0x18B8, 0x18F6, 0x1939, 0x197E, 0x19C2, 0x1A02, 0x1A3C, 0x1A6E, 
    0x1A95, 0x1AAE, 0xD044, 0xCEDD, 0xCE17, 0xD01D, 0xD465, 0xDB02, 0xE2B9, 0xEA08, 0xEF6C, 0xF2C0, 0xF507, 0xF679, 
    0xF74E, 0xF7BD, 0xF804, 0xF83F, 0xF86D, 0xF890, 0xF8A8, 0xF8B7, 0xF8BD, 0xF8BC, 0xF8B4, 0xF8A7, 0xF895, 0xF880, 
    0xF868, 0xF84F, 0xF834, 0xF81A, 0xF802, 0xF7EB, 0xF7D8, 0xF7CA, 0xF7C0, 0x7ADD, 0x9241, 0xB3F9, 0xC4C6, 0xCC2B, 
    0xCDA7, 0xCF10, 0xD05F, 0xD193, 0xD2A5, 0xD393, 0xD458, 0xD4EF, 0xD555, 0xD59A, 0xD5D2, 0xD5FF, 0xD620, 0xD637, 
    0xD645, 0xD64B, 0xD64A, 0xD643, 0xD636, 0xD625, 0xD611, 0xD5FA, 0xD5E1, 0xD5C8, 0xD5AF, 0xD598, 0xD582, 0xD570, 
    0xD562, 0xD558, 0xFF02, 0xFF34, 0xFF82, 0xFFAE, 0xFFBA, 0xFFD3, 0xFFF9, 0x0029, 0x0062, 0x00A3, 0x00EB, 0x0137, 
    0x0187, 0x01D9, 0x022B, 0x027D, 0x02CC, 0x0318, 0x035F, 0x03A0, 0x03D8, 0x0407, 0x042C, 0x0444, 0x044F, 0x044A, 
    0x0436, 0x040F, 0x03D5, 0x0387, 0x0322, 0x02A6, 0x0211, 0x0161, 0x0096, 0xF30E, 0xF2FA, 0xF2E7, 0xF317, 0xF37F, 
    0xF3EA, 0xF459, 0xF4CB, 0xF53F, 0xF5B5, 0xF62D, 0xF6A6, 0xF720, 0xF79C, 0xF817, 0xF893, 0xF90E, 0xF988, 0xFA02, 
    0xFA7A, 0xFAF0, 0xFB64, 0xFBD6, 0xFC45, 0xFCB0, 0xFD18, 0xFD7D, 0xFDDD, 0xFE38, 0xFE5C, 0xFE31, 0xFDE0, 0xFD8F, 
    0xFD68, 0xFD93, 0x18D8, 0x1F51, 0x21B4, 0x228A, 0x22D9, 0x2335, 0x2330, 0x225A, 0x2046, 0x1BD9, 0x155F, 0x0E7C, 
    0x08D4, 0x060C, 0x05D6, 0x06A3, 0x0838, 0x0A5B, 0x0CCE, 0x0F56, 0x11B9, 0x13BA, 0x151D, 0x15D0, 0x1602, 0x15DE, 
    0x1590, 0x1541, 0x151D, 0x14AA, 0x139E, 0x126B, 0x1184, 0x115E, 0x126B, 0x1459, 0x1321, 0x117A, 0x0F72, 0x0D18, 
    0x0A7A, 0x07A6, 0x04AC, 0x0199, 0xFE7C, 0xFB63, 0xF85C, 0xF577, 0xF2C1, 0xF048, 0xEE1C, 0xEC4B, 0xEAE2, 0xE9D6, 
    0xE90C, 0xE87E, 0xE824, 0xE7F9, 0xE7F7, 0xE816, 0xE850, 0xE89F, 0xE8FC, 0xE962, 0xE9C8, 0xEA2A, 0xEA80, 0xEAC3, 
    0xEAEF, 0xEAFB, 0x0D31, 0x0D68, 0x0D02, 0x0CC1, 0x0CD7, 0x0CF3, 0x0D13, 0x0D38, 0x0D60, 0x0D8B, 0x0DB7, 0x0DE4, 
    0x0E11, 0x0E44, 0x0E80, 0x0EC0, 0x0EFE, 0x0F35, 0x0F67, 0x0F9B, 0x0FCF, 0x1003, 0x1036, 0x1068, 0x1097, 0x10C3, 
    0x10EB, 0x110F, 0x112E, 0x1132, 0x1114, 0x10E7, 0x10BF, 0x10B0, 0x10CF, 0x0091, 0x020B, 0x0531, 0x07F3, 0x09D6, 
    0x0BBE, 0x0DA2, 0x0F7C, 0x1142, 0x12EC, 0x1473, 0x15CE, 0x16F5, 0x17A2, 0x17B7, 0x176B, 0x16F1, 0x1680, 0x161B, 
    0x15A5, 0x1524, 0x149A, 0x140C, 0x137D, 0x12F2, 0x126E, 0x11F6, 0x118C, 0x1136, 0x1109, 0x110B, 0x1129, 0x1150, 
    0x116C, 0x1169, 0x084B, 0x0279, 0xF969, 0xEEB9, 0xE403, 0xDAE5, 0xD4FA, 0xD2C3, 0xD310, 0xD4F3, 0xD781, 0xD9CC, 
    0xDAE8, 0xDB18, 0xDB3F, 0xDB5E, 0xDB77, 0xDB88, 0xDB93, 0xDB99, 0xDB9A, 0xDB96, 0xDB8F, 0xDB84, 0xDB77, 0xDB68, 
    0xDB58, 0xDB47, 0xDB35, 0xDB24, 0xDB14, 0xDB06, 0xDAF9, 0xDAF0, 0xDAEA, 0xB7AC, 0xBD50, 0xC623, 0xD084, 0xDAD7, 
    0xE37B, 0xE8D2, 0xEA39, 0xE8DB, 0xE5CE, 0xE22B, 0xDF07, 0xDD7A, 0xDD1F, 0xDCD3, 0xDC97, 0xDC69, 0xDC48, 0xDC32, 
    0xDC27, 0xDC26, 0xDC2C, 0xDC3A, 0xDC4F, 0xDC68, 0xDC84, 0xDCA4, 0xDCC5, 0xDCE6, 0xDD07, 0xDD25, 0xDD41, 0xDD58, 
    0xDD6A, 0xDD76, 0x8839, 0x8CFB, 0x944F, 0x9D00, 0xA5D7, 0xAD9A, 0xB314, 0xB60C, 0xB76D, 0xB7BD, 0xB77D, 0xB732, 
    0xB75D, 0xB7F1, 0xB886, 0xB91C, 0xB9B3, 0xBA4A, 0xBAE1, 0xBB78, 0xBC0F, 0xBCA4, 0xBD38, 0xBDCB, 0xBE5C, 0xBEEA, 
    0xBF76, 0xBFFF, 0xC085, 0xC107, 0xC185, 0xC1FF, 0xC275, 0xC2E5, 0xC350, 0x03E6, 0x0369, 0x02F4, 0x040F, 0x0920, 
    0x0FC1, 0x1253, 0x0FB7, 0x0B2C, 0x059C, 0xFFF4, 0xFB1E, 0xF805, 0xF665, 0xF54B, 0xF49D, 0xF444, 0xF426, 0xF42A, 
    0xF436, 0xF432, 0xF404, 0xF393, 0xF2D6, 0xF1E5, 0xF0D7, 0xEFC4, 0xEEC5, 0xEDF1, 0xED60, 0xED2A, 0xED61, 0xEE11, 
    0xEF49, 0xF11A, 0xF1ED, 0xF087, 0xEE66, 0xED6B, 0xEE7E, 0xF0B8, 0xF344, 0xF60C, 0xF946, 0xFC94, 0xFF9A, 0x01F9, 
    0x0354, 0x03D1, 0x03E2, 0x039D, 0x0314, 0x025E, 0x018D, 0x00B7, 0xFFEF, 0xFF4B, 0xFEDE, 0xFE9D, 0xFE6D, 0xFE4B, 
    0xFE34, 0xFE27, 0xFE20, 0xFE1E, 0xFE1E, 0xFE2A, 0xFE49, 0xFE76, 0xFEAA, 0xE3E1, 0xE86F, 0xEF38, 0xF1B1, 0xEA36, 
    0xDE6A, 0xD8AC, 0xDB7C, 0xE163, 0xE8CD, 0xF027, 0xF5DF, 0xF862, 0xF81C, 0xF6B0, 0xF45C, 0xF15D, 0xEDF1, 0xEA53, 
    0xE6C3, 0xE37C, 0xE0BC, 0xDEC1, 0xDD85, 0xDCC8, 0xDC71, 0xDC64, 0xDC88, 0xDCC2, 0xDCF9, 0xDD11, 0xDD4B, 0xDDD2, 
    0xDE67, 0xDECB, 0xE9E4, 0xF52A, 0x086A, 0x1410, 0x15D8, 0x1619, 0x152B, 0x1364, 0x111C, 0x0EAC, 0x0C69, 0x0AAB, 
    0x09CA, 0x099C, 0x09B6, 0x0A09, 0x0A85, 0x0B1D, 0x0BC2, 0x0C66, 0x0CF9, 0x0D6D, 0x0DB4, 0x0DDA, 0x0DF3, 0x0E02, 
    0x0E08, 0x0E07, 0x0E00, 0x0DF5, 0x0DE8, 0x0DDA, 0x0DCC, 0x0DC0, 0x0DB7, 0x0154, 0x016E, 0x0148, 0x0162, 0x01D8, 
    0x0269, 0x030C, 0x03B6, 0x045D, 0x04F5, 0x0574, 0x05D0, 0x05FF, 0x05FB, 0x05CF, 0x0583, 0x0520, 0x04AF, 0x0439, 
    0x03C5, 0x035E, 0x030C, 0x02D7, 0x02B9, 0x02A5, 0x0299, 0x0294, 0x0294, 0x029A, 0x02A3, 0x02AD, 0x02B9, 0x02C4, 
    0x02CE, 0x02D4, 0x0121, 0xFC20, 0xF399, 0xEDE6, 0xEBEC, 0xEA50, 0xE90A, 0xE814, 0xE769, 0xE701, 0xE6D6, 0xE6E3, 
    0xE720, 0xE7B9, 0xE8CA, 0xEA36, 0xEBDD, 0xEDA2, 0xEF66, 0xF10A, 0xF271, 0xF37D, 0xF40E, 0xF432, 0xF411, 0xF3B7, 
    0xF330, 0xF287, 0xF1C6, 0xF0FB, 0xF02F, 0xEF6F, 0xEEC5, 0xEE3E, 0xEDE5, 0xFE63, 0xFE8F, 0xFEC0, 0xFEF3, 0xFF26, 
    0xFF59, 0xFF88, 0xFFB3, 0xFFD7, 0xFFF3, 0x0005, 0x0001, 0x0001, 0x0002, 0x0000, 0x0003, 0x0003, 0x0003, 0x0004, 
    0x0004, 0x0000, 0x0004, 0x0000, 0x0000, 0x0005, 0x0005, 0x0000, 0x0000, 0x0005, 0x0005, 0x0005, 0x0000, 0x0000, 
    0x0000, 0x0000, 0x0609, 0x059C, 0x051D, 0x048F, 0x03F3, 0x034D, 0x029E, 0x01E9, 0x0131, 0x0078, 0xFFC2, 0xFF10, 
    0xFE68, 0xFDCA, 0xFD3B, 0xFCBC, 0xFC51, 0xFBFB, 0xFBB2, 0xFB6E, 0xFB2E, 0xFAF3, 0xFAC0, 0xFA93, 0xFA6F, 0xFA54, 
    0xFA43, 0xFA3D, 0xFA42, 0xFA54, 0xFA74, 0xFAA2, 0xFADF, 0xFB2C, 0xFB8A, 0xAAE8, 0xAB5D, 0xABE5, 0xAC7F, 0xAD2A, 
    0xADE6, 0xAEB2, 0xAF91, 0xB088, 0xB1A5, 0xB30B, 0xB5E8, 0xB5E7, 0xB5E4, 0xB602, 0xB5DB, 0xB5D7, 0xB5D3, 0xB5CE, 
    0xB5C9, 0xB5E6, 0xB5C0, 0xB5DD, 0xB5D9, 0xB5B3, 0xB5B0, 0xB5D0, 0xB5CF, 0xB5AD, 0xB5AF, 0xB5B2, 0xB5D8, 0xB5DD, 
    0xB5E4, 0xB5EC, 0x1112, 0x1075, 0x0FBB, 0x0EE4, 0x0DF0, 0x0CDE, 0x0BAE, 0x0A5A, 0x08D9, 0x0717, 0x04D9, 0x0036, 
    0x0036, 0x0037, 0x0000, 0x0037, 0x0036, 0x0036, 0x0036, 0x0037, 0x0000, 0x0036, 0x0000, 0x0000, 0x0037, 0x0037, 
    0x0000, 0x0000, 0x0037, 0x0037, 0x0036, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0xFFFC, 0xFFFD, 
    0xFFFD, 0x0000, 0xFFFE, 0x0000, 0xFFF8, 0x0006, 0x001E, 0x003D, 0x005E, 0x0081, 0x00A2, 0x00C1, 0x00DB, 0x00F2, 
    0x0108, 0x011D, 0x0132, 0x0144, 0x0154, 0x0161, 0x016B, 0x0172, 0x0174, 0x0172, 0x016B, 0x0160, 0x014F, 0x0139, 
    0x011E, 0x00FF, 0x0629, 0x05B8, 0x0534, 0x04A2, 0x0402, 0x0358, 0x02A6, 0x01EF, 0x0135, 0x007B, 0xFFC5, 0xFF16, 
    0xFE70, 0xFDD5, 0xFD49, 0xFCCD, 0xFC64, 0xFC11, 0xFBCB, 0xFB88, 0xFB4B, 0xFB12, 0xFAE1, 0xFAB6, 0xFA93, 0xFA7A, 
    0xFA69, 0xFA63, 0xFA68, 0xFA7A, 0xFA98, 0xFAC4, 0xFAFF, 0xFB49, 0xFBA4, 0xB57A, 0xB582, 0xB58A, 0xB56F, 0xB576, 
    0xB57A, 0xB59F, 0xB57E, 0xB59D, 0xB2D4, 0xB15F, 0xB048, 0xAF61, 0xAE9C, 0xADF1, 0xAD60, 0xACE8, 0xAC8A, 0xAC3B, 
    0xABF1, 0xABAC, 0xAB6D, 0xAB36, 0xAB06, 0xAADF, 0xAAC2, 0xAAB0, 0xAAA8, 0xAAAE, 0xAAC1, 0xAAE2, 0xAB13, 0xAB54, 
    0xABA8, 0xAC0E, 0x0000, 0x0000, 0x0000, 0x0037, 0x0036, 0x0037, 0x0000, 0x0036, 0x0000, 0x047D, 0x06CF, 0x0883, 
    0x09E6, 0x0B10, 0x0C0C, 0x0CDE, 0x0D8A, 0x0E0F, 0x0E7D, 0x0EE3, 0x0F41, 0x0F95, 0x0FDF, 0x101D, 0x1050, 0x1076, 
    0x108D, 0x1096, 0x108F, 0x1076, 0x104A, 0x100A, 0x0FB3, 0x0F44, 0x0EB9, 0x0000, 
};

JointIndex object_bg_Anim_00AD98JointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0002, 0x0002, 0x0002 },
    { 0x0009, 0x002C, 0x004F },
    { 0x0072, 0x0095, 0x00B8 },
    { 0x00DB, 0x00FE, 0x0121 },
    { 0x0144, 0x0167, 0x018A },
    { 0x0002, 0x0002, 0x0003 },
    { 0x01AD, 0x01D0, 0x01F3 },
    { 0x0216, 0x0239, 0x025C },
    { 0x027F, 0x02A2, 0x02C5 },
    { 0x0002, 0x0002, 0x0003 },
    { 0x02E8, 0x030B, 0x032E },
    { 0x0351, 0x0374, 0x0397 },
    { 0x03BA, 0x03DD, 0x0400 },
    { 0x0004, 0x0005, 0x0006 },
    { 0x0423, 0x0446, 0x0469 },
    { 0x0002, 0x0002, 0x048C },
    { 0x0002, 0x0002, 0x0007 },
    { 0x0002, 0x0002, 0x0008 },
    { 0x0004, 0x0005, 0x0006 },
    { 0x04AF, 0x04D2, 0x04F5 },
    { 0x0002, 0x0002, 0x0518 },
    { 0x0002, 0x0002, 0x0007 },
    { 0x0002, 0x0002, 0x0008 },
};

AnimationHeader object_bg_Anim_00AD98 = { 
    { 35 }, object_bg_Anim_00AD98FrameData,
    object_bg_Anim_00AD98JointIndices, 9
};

u8 object_bg_possiblePadding_00ADA8[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 object_bg_Anim_00B19CFrameData[] = {
    0x0004, 0x0C7F, 0x0000, 0x4000, 0x0983, 0xF432, 0xDECB, 0x0000, 0x0075, 0x00D1, 0x0118, 0x014B, 0x016C, 0x017C, 
    0x017E, 0x0174, 0x0160, 0x0143, 0x0120, 0x00F8, 0x00CE, 0x00A3, 0x0079, 0x0053, 0x0031, 0x0017, 0x0006, 0x0000, 
    0xFFFF, 0xFFFE, 0xFFFE, 0xFFFE, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFE, 0xFFFE, 0xFFFE, 0xFFFE, 0xFFFF, 
    0xFFFF, 0xFFFF, 0x0000, 0x0000, 0x0000, 0xEDAA, 0xED52, 0xED0C, 0xECD7, 0xECB0, 0xEC98, 0xEC8B, 0xEC8A, 0xEC91, 
    0xECA1, 0xECB6, 0xECD1, 0xECEF, 0xED0F, 0xED2F, 0xED4F, 0xED6C, 0xED85, 0xED99, 0xEDA6, 0x0000, 0x001B, 0x0030, 
    0x0040, 0x004B, 0x0053, 0x0057, 0x0057, 0x0055, 0x0050, 0x004A, 0x0042, 0x0039, 0x002F, 0x0025, 0x001C, 0x0013, 
    0x000B, 0x0005, 0x0001, 0xEE7B, 0xEE2A, 0xEDE9, 0xEDB7, 0xED94, 0xED7D, 0xED72, 0xED70, 0xED77, 0xED85, 0xED99, 
    0xEDB2, 0xEDCE, 0xEDEB, 0xEE09, 0xEE26, 0xEE41, 0xEE58, 0xEE6B, 0xEE77, 0x0000, 0x001B, 0x002E, 0x0039, 0x003F, 
    0x0041, 0x0041, 0x0040, 0x003F, 0x003C, 0x0038, 0x0032, 0x002B, 0x0024, 0x001D, 0x0015, 0x000F, 0x0009, 0x0004, 
    0x0001, 0x1256, 0x1166, 0x1040, 0x0F04, 0x0DD5, 0x0CD3, 0x0C1F, 0x0BDC, 0x0BF8, 0x0C46, 0x0CBC, 0x0D52, 0x0DFF, 
    0x0EB9, 0x0F78, 0x1033, 0x10DF, 0x1176, 0x11EC, 0x123A, 0x0000, 0xFFEE, 0xFFE1, 0xFFD8, 0xFFD2, 0xFFCE, 0xFFCD, 
    0xFFCD, 0xFFCD, 0xFFD0, 0xFFD4, 0xFFD8, 0xFFDE, 0xFFE3, 0xFFE9, 0xFFEF, 0xFFF4, 0xFFF9, 0xFFFD, 0xFFFF, 0x0774, 
    0x080E, 0x08A8, 0x0942, 0x09DB, 0x0A75, 0x0B0F, 0x0BA9, 0x0C43, 0x0CDC, 0x0D76, 0x0CDC, 0x0C43, 0x0BA9, 0x0B0F, 
    0x0A75, 0x09DB, 0x0942, 0x08A8, 0x080E, 0xF5B5, 0xF557, 0xF4F9, 0xF49B, 0xF43D, 0xF3E0, 0xF382, 0xF324, 0xF2C6, 
    0xF268, 0xF20A, 0xF268, 0xF2C6, 0xF324, 0xF382, 0xF3E0, 0xF43D, 0xF49B, 0xF4F9, 0xF557, 0x9285, 0x9260, 0x923B, 
    0x9215, 0x91F0, 0x91CB, 0x91A5, 0x9180, 0x915B, 0x9135, 0x9110, 0x9135, 0x915B, 0x9180, 0x91A5, 0x91CB, 0x91F0, 
    0x9215, 0x923B, 0x9260, 0xE611, 0xE5AE, 0xE54B, 0xE4E7, 0xE484, 0xE421, 0xE3BE, 0xE35B, 0xE2F8, 0xE295, 0xE232, 
    0xE295, 0xE2F8, 0xE35B, 0xE3BE, 0xE421, 0xE484, 0xE4E7, 0xE54B, 0xE5AE, 0xDDCC, 0xDE96, 0xDF60, 0xE02A, 0xE0F3, 
    0xE1BD, 0xE287, 0xE351, 0xE41A, 0xE4E4, 0xE5AE, 0xE4E4, 0xE41A, 0xE351, 0xE287, 0xE1BD, 0xE0F3, 0xE02A, 0xDF60, 
    0xDE96, 0x25E8, 0x2602, 0x261D, 0x2637, 0x2652, 0x266C, 0x2686, 0x26A1, 0x26BB, 0x26D6, 0x26F0, 0x26E9, 0x26D5, 
    0x26B7, 0x2693, 0x266C, 0x2645, 0x2621, 0x2603, 0x25EF, 0xFFD0, 0xFFE7, 0x000E, 0x0039, 0x005B, 0x0069, 0x004B, 
    0x002C, 0x000D, 0xFFEE, 0xFFD0, 0xFFB0, 0xFF8F, 0xFF6F, 0xFF4F, 0xFF2F, 0xFF4F, 0xFF6F, 0xFF8F, 0xFFB0, 0x0543, 
    0x0551, 0x055F, 0x056E, 0x057C, 0x058A, 0x057C, 0x056E, 0x055F, 0x0551, 0x0543, 0x0531, 0x051E, 0x050B, 0x04F9, 
    0x04E6, 0x04F9, 0x050B, 0x051E, 0x0531, 0x129C, 0x1281, 0x1267, 0x124C, 0x1231, 0x1216, 0x1231, 0x124C, 0x1267, 
    0x1281, 0x129C, 0x12B3, 0x12C9, 0x12E0, 0x12F7, 0x130D, 0x12F7, 0x12E0, 0x12C9, 0x12B3, 0xFA9A, 0xFA9E, 0xFAA3, 
    0xFAA7, 0xFAAB, 0xFAAF, 0xFAB4, 0xFAB8, 0xFABC, 0xFAC0, 0xFAC5, 0xFAC0, 0xFABC, 0xFAB8, 0xFAB4, 0xFAAF, 0xFAAB, 
    0xFAA7, 0xFAA3, 0xFA9E, 0xF053, 0xF055, 0xF057, 0xF05A, 0xF05C, 0xF05E, 0xF060, 0xF062, 0xF064, 0xF066, 0xF068, 
    0xF066, 0xF064, 0xF062, 0xF060, 0xF05E, 0xF05C, 0xF05A, 0xF057, 0xF055, 0x6C11, 0x6C06, 0x6BFB, 0x6BF0, 0x6BE5, 
    0x6BDA, 0x6BCF, 0x6BC4, 0x6BB9, 0x6BAE, 0x6BA3, 0x6BAE, 0x6BB9, 0x6BC4, 0x6BCF, 0x6BDA, 0x6BE5, 0x6BF0, 0x6BFB, 
    0x6C06, 0x0000, 0x0042, 0x0084, 0x00C6, 0x0108, 0x014A, 0x00E4, 0x007D, 0x0017, 0xFFB1, 0xFF4B, 0xFFB1, 0x0017, 
    0x007E, 0x00E4, 0x014B, 0x0109, 0x00C7, 0x0084, 0x0042, 0x0000, 0xFFD4, 0xFFA8, 0xFF7B, 0xFF4F, 0xFF23, 0xFF27, 
    0xFF2B, 0xFF2E, 0xFF32, 0xFF36, 0xFF46, 0xFF57, 0xFF68, 0xFF78, 0xFF89, 0xFFA1, 0xFFB9, 0xFFD0, 0xFFE8, 0xF14F, 
    0xF160, 0xF171, 0xF182, 0xF193, 0xF1A4, 0xF1AE, 0xF1B8, 0xF1C2, 0xF1CC, 0xF1D7, 0xF1C9, 0xF1BC, 0xF1AF, 0xF1A2, 
    0xF194, 0xF187, 0xF179, 0xF16B, 0xF15D, 0x0000, 
};

JointIndex object_bg_Anim_00B19CJointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0002, 0x0007, 0x0003 },
    { 0x001B, 0x002F, 0x0043 },
    { 0x0002, 0x0057, 0x0002 },
    { 0x006B, 0x007F, 0x0093 },
    { 0x00A7, 0x00BB, 0x00CF },
    { 0x00E3, 0x00F7, 0x010B },
    { 0x011F, 0x0133, 0x0147 },
    { 0x015B, 0x016F, 0x0183 },
    { 0x0004, 0x0005, 0x0006 },
    { 0x0197, 0x01AB, 0x01BF },
};

AnimationHeader object_bg_Anim_00B19C = { 
    { 20 }, object_bg_Anim_00B19CFrameData,
    object_bg_Anim_00B19CJointIndices, 7
};

Vtx object_bgVtx_00B1B0[] = {
#include "assets/objects/object_bg/object_bgVtx_00B1B0.vtx.inc"
};

Gfx object_bg_DL_00D5E0[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_00B1B0[554], 19, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 4, 6, 0),
    gsSP2Triangles(4, 8, 5, 0, 7, 9, 4, 0),
    gsSP2Triangles(10, 11, 6, 0, 12, 6, 5, 0),
    gsSP2Triangles(12, 10, 6, 0, 6, 13, 7, 0),
    gsSP2Triangles(11, 13, 6, 0, 5, 8, 14, 0),
    gsSP2Triangles(15, 0, 2, 0, 16, 0, 15, 0),
    gsSP2Triangles(7, 1, 3, 0, 7, 13, 1, 0),
    gsSP2Triangles(9, 3, 17, 0, 3, 9, 7, 0),
    gsSP2Triangles(0, 16, 14, 0, 10, 15, 2, 0),
    gsSP2Triangles(10, 2, 11, 0, 14, 8, 18, 0),
    gsSP2Triangles(5, 14, 16, 0, 5, 16, 12, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[573], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 0, 4, 0),
    gsSP2Triangles(0, 2, 5, 0, 5, 4, 0, 0),
    gsSPEndDisplayList(),
};

Gfx object_bg_DL_00D780[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_00B1B0[328], 5, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[333], 3, 5),
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0114F0, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[336], 12, 8),
    gsSP2Triangles(8, 2, 9, 0, 10, 4, 3, 0),
    gsSP2Triangles(11, 2, 4, 0, 12, 2, 13, 0),
    gsSP2Triangles(6, 2, 14, 0, 3, 0, 15, 0),
    gsSP2Triangles(3, 16, 17, 0, 3, 18, 19, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0114F0, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[348], 6, 8),
    gsSP2Triangles(8, 5, 7, 0, 9, 1, 10, 0),
    gsSP2Triangles(11, 7, 12, 0, 5, 13, 1, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0110F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x017C),
    gsSPVertex(&object_bgVtx_00B1B0[354], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(3, 5, 6, 0, 4, 3, 7, 0),
    gsSP2Triangles(7, 3, 8, 0, 3, 6, 0, 0),
    gsSP2Triangles(3, 0, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 9, 13, 0, 12, 10, 9, 0),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 12, 21, 0, 16, 10, 14, 0),
    gsSP2Triangles(12, 13, 21, 0, 13, 9, 6, 0),
    gsSP2Triangles(21, 22, 20, 0, 23, 5, 24, 0),
    gsSP2Triangles(11, 10, 16, 0, 9, 11, 17, 0),
    gsSP2Triangles(15, 25, 26, 0, 14, 25, 15, 0),
    gsSP2Triangles(25, 20, 22, 0, 22, 26, 25, 0),
    gsSP2Triangles(27, 28, 4, 0, 28, 27, 29, 0),
    gsSP2Triangles(29, 27, 30, 0, 7, 27, 4, 0),
    gsSP2Triangles(5, 23, 6, 0, 28, 31, 4, 0),
    gsSPVertex(&object_bgVtx_00B1B0[386], 22, 0),
    gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
    gsSP2Triangles(4, 8, 9, 0, 10, 11, 12, 0),
    gsSP2Triangles(6, 8, 4, 0, 8, 13, 9, 0),
    gsSP2Triangles(4, 14, 15, 0, 8, 0, 13, 0),
    gsSP2Triangles(8, 16, 0, 0, 8, 6, 16, 0),
    gsSP2Triangles(12, 11, 3, 0, 3, 11, 2, 0),
    gsSP2Triangles(11, 17, 18, 0, 11, 18, 2, 0),
    gsSP2Triangles(19, 0, 2, 0, 20, 21, 1, 0),
    gsSP2Triangles(0, 16, 1, 0, 1, 16, 20, 0),
    gsSP1Triangle(1, 21, 3, 0),
    gsSPEndDisplayList(),
};

Gfx object_bg_DL_00DB38[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0110F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x017C),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_00B1B0[120], 5, 0),
    gsSPMatrix(0x0D000080, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0106F0, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[125], 15, 5),
    gsSP2Triangles(0, 5, 6, 0, 7, 8, 0, 0),
    gsSP2Triangles(9, 3, 2, 0, 10, 1, 4, 0),
    gsSP2Triangles(4, 3, 11, 0, 2, 12, 13, 0),
    gsSP2Triangles(14, 2, 0, 0, 0, 1, 15, 0),
    gsSP2Triangles(4, 16, 17, 0, 18, 19, 4, 0),
    gsSPVertex(&object_bgVtx_00B1B0[140], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
    gsSP2Triangles(4, 1, 0, 0, 2, 5, 0, 0),
    gsSP2Triangles(6, 4, 3, 0, 7, 8, 5, 0),
    gsSP2Triangles(3, 9, 6, 0, 9, 8, 7, 0),
    gsSP2Triangles(6, 9, 7, 0, 5, 2, 7, 0),
    gsSPEndDisplayList(),
};

Gfx object_bg_DL_00DCD8[] = {
    gsSPMatrix(0x0D000080, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_bgVtx_00B1B0, 9, 0),
    gsSPMatrix(0x0D0000C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0106F0, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_bgVtx_00B1B0[9], 16, 9),
    gsSP2Triangles(9, 5, 8, 0, 10, 6, 11, 0),
    gsSP2Triangles(12, 13, 6, 0, 8, 6, 14, 0),
    gsSP2Triangles(7, 15, 16, 0, 17, 6, 7, 0),
    gsSP2Triangles(6, 18, 19, 0, 20, 21, 6, 0),
    gsSP2Triangles(22, 23, 8, 0, 7, 2, 24, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0107F0, G_IM_FMT_CI, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 6, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[25], 4, 9),
    gsSP2Triangles(9, 1, 10, 0, 11, 1, 12, 0),
    gsSPVertex(&object_bgVtx_00B1B0[29], 3, 9),
    gsSP2Triangles(0, 3, 9, 0, 10, 0, 11, 0),
    gsSPVertex(&object_bgVtx_00B1B0[32], 4, 9),
    gsSP2Triangles(9, 10, 4, 0, 11, 4, 12, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(0x08000000, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                         G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x007C),
    gsSPVertex(&object_bgVtx_00B1B0[36], 19, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 5, 0, 8, 4, 3, 0),
    gsSP2Triangles(7, 6, 9, 0, 5, 10, 3, 0),
    gsSP2Triangles(5, 7, 10, 0, 11, 9, 6, 0),
    gsSP2Triangles(11, 12, 9, 0, 4, 1, 13, 0),
    gsSP2Triangles(6, 14, 11, 0, 13, 5, 4, 0),
    gsSP2Triangles(5, 14, 6, 0, 15, 14, 5, 0),
    gsSP2Triangles(8, 1, 4, 0, 2, 1, 8, 0),
    gsSP2Triangles(13, 16, 5, 0, 13, 14, 17, 0),
    gsSP2Triangles(18, 11, 14, 0, 12, 11, 18, 0),
    gsSP1Triangle(13, 1, 0, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0104F0, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x007C, 0x007C),
    gsSPVertex(&object_bgVtx_00B1B0[55], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 2, 4, 0),
    gsSP2Triangles(0, 2, 5, 0, 3, 5, 2, 0),
    gsSP1Triangle(1, 4, 2, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0106F0, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[61], 11, 0),
    gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
    gsSP2Triangles(1, 3, 4, 0, 5, 4, 3, 0),
    gsSP2Triangles(6, 2, 7, 0, 8, 9, 7, 0),
    gsSP2Triangles(9, 8, 10, 0, 6, 7, 9, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0107F0, G_IM_FMT_CI, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 6, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[72], 11, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
    gsSP2Triangles(1, 5, 6, 0, 7, 3, 2, 0),
    gsSP2Triangles(6, 8, 9, 0, 10, 2, 1, 0),
    gsSP2Triangles(10, 1, 6, 0, 3, 0, 2, 0),
    gsSP1Triangle(8, 6, 5, 0),
    gsSPVertex(&object_bgVtx_00B1B0[83], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 1, 0),
    gsSP2Triangles(5, 2, 4, 0, 3, 6, 7, 0),
    gsSP2Triangles(2, 1, 4, 0, 3, 7, 4, 0),
    gsSP1Triangle(4, 7, 5, 0),
    gsSPVertex(&object_bgVtx_00B1B0[91], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(4, 5, 0, 0, 0, 2, 4, 0),
    gsSPVertex(&object_bgVtx_00B1B0[97], 7, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 3, 5, 0, 2, 4, 3, 0),
    gsSP1Triangle(2, 1, 4, 0),
    gsSPVertex(&object_bgVtx_00B1B0[104], 5, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
    gsSP1Triangle(1, 4, 2, 0),
    gsSPVertex(&object_bgVtx_00B1B0[109], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 5, 0, 0, 5, 2, 3, 0),
    gsSPVertex(&object_bgVtx_00B1B0[115], 5, 0),
    gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
    gsSP1Triangle(4, 3, 1, 0),
    gsSPEndDisplayList(),
};

Gfx object_bg_DL_00E1C0[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0110F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x017C),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_00B1B0[207], 6, 0),
    gsSPMatrix(0x0D000100, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0110F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x017C),
    gsSPVertex(&object_bgVtx_00B1B0[213], 9, 6),
    gsSP2Triangles(4, 2, 6, 0, 0, 5, 7, 0),
    gsSP2Triangles(4, 8, 5, 0, 5, 9, 10, 0),
    gsSP2Triangles(11, 0, 12, 0, 1, 0, 13, 0),
    gsSP1Triangle(2, 1, 14, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0110F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[222], 6, 6),
    gsSP2Triangles(6, 3, 7, 0, 8, 3, 9, 0),
    gsSP1Triangle(10, 3, 11, 0),
    gsSPVertex(&object_bgVtx_00B1B0[228], 11, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 6, 3, 0, 2, 5, 7, 0),
    gsSP2Triangles(5, 4, 8, 0, 5, 8, 7, 0),
    gsSP2Triangles(5, 2, 6, 0, 0, 9, 1, 0),
    gsSP2Triangles(1, 9, 4, 0, 4, 9, 8, 0),
    gsSP2Triangles(7, 0, 2, 0, 1, 10, 2, 0),
    gsSP1Triangle(2, 10, 6, 0),
    gsSPEndDisplayList(),
};

Gfx object_bg_DL_00E3F8[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000100, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0110F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_00B1B0[183], 4, 0),
    gsSPMatrix(0x0D000140, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0110F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[187], 12, 4),
    gsSP2Triangles(4, 0, 5, 0, 2, 6, 3, 0),
    gsSP2Triangles(7, 8, 0, 0, 9, 10, 2, 0),
    gsSP2Triangles(11, 12, 2, 0, 2, 1, 13, 0),
    gsSP2Triangles(1, 0, 14, 0, 0, 3, 15, 0),
    gsSPVertex(&object_bgVtx_00B1B0[199], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 6, 5, 0, 0),
    gsSP2Triangles(3, 4, 2, 0, 0, 5, 1, 0),
    gsSP2Triangles(3, 7, 4, 0, 4, 7, 5, 0),
    gsSPEndDisplayList(),
};

Gfx object_bg_DL_00E580[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000140, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0110F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_00B1B0[150], 4, 0),
    gsSPMatrix(0x0D000180, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_010FF0, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[154], 12, 4),
    gsSP2Triangles(0, 4, 3, 0, 5, 2, 3, 0),
    gsSP2Triangles(6, 2, 7, 0, 1, 2, 8, 0),
    gsSP2Triangles(9, 10, 1, 0, 11, 1, 12, 0),
    gsSP2Triangles(0, 1, 13, 0, 14, 15, 0, 0),
    gsSPVertex(&object_bgVtx_00B1B0[166], 17, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 0, 0, 1, 8, 9, 0),
    gsSP2Triangles(10, 8, 1, 0, 10, 9, 8, 0),
    gsSP2Triangles(10, 5, 9, 0, 3, 10, 11, 0),
    gsSP2Triangles(3, 5, 10, 0, 7, 11, 10, 0),
    gsSP2Triangles(6, 11, 7, 0, 2, 4, 6, 0),
    gsSP2Triangles(10, 1, 12, 0, 10, 0, 7, 0),
    gsSP2Triangles(1, 0, 12, 0, 2, 6, 0, 0),
    gsSP2Triangles(10, 13, 0, 0, 14, 12, 13, 0),
    gsSP2Triangles(14, 13, 15, 0, 10, 15, 13, 0),
    gsSP2Triangles(10, 12, 14, 0, 10, 14, 15, 0),
    gsSP2Triangles(12, 0, 13, 0, 9, 16, 1, 0),
    gsSP2Triangles(16, 2, 1, 0, 5, 16, 9, 0),
    gsSP2Triangles(16, 4, 2, 0, 16, 5, 4, 0),
    gsSPEndDisplayList(),
};

Gfx object_bg_DL_00E758[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0110F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x017C),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_00B1B0[296], 6, 0),
    gsSPMatrix(0x0D0001C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0110F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x017C),
    gsSPVertex(&object_bgVtx_00B1B0[302], 9, 6),
    gsSP2Triangles(6, 2, 4, 0, 7, 5, 0, 0),
    gsSP2Triangles(5, 8, 4, 0, 9, 10, 5, 0),
    gsSP2Triangles(11, 0, 12, 0, 13, 0, 1, 0),
    gsSP1Triangle(14, 1, 2, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0110F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[311], 6, 6),
    gsSP2Triangles(6, 3, 7, 0, 8, 3, 9, 0),
    gsSP1Triangle(10, 3, 11, 0),
    gsSPVertex(&object_bgVtx_00B1B0[317], 11, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 6, 3, 0, 7, 3, 0, 0),
    gsSP2Triangles(8, 4, 3, 0, 7, 8, 3, 0),
    gsSP2Triangles(6, 0, 3, 0, 1, 9, 2, 0),
    gsSP2Triangles(4, 9, 1, 0, 8, 9, 4, 0),
    gsSP2Triangles(0, 2, 7, 0, 0, 10, 1, 0),
    gsSP1Triangle(6, 10, 0, 0),
    gsSPEndDisplayList(),
};

Gfx object_bg_DL_00E990[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D0001C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0110F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_00B1B0[272], 4, 0),
    gsSPMatrix(0x0D000200, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0110F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[276], 12, 4),
    gsSP2Triangles(4, 0, 5, 0, 3, 6, 2, 0),
    gsSP2Triangles(0, 7, 8, 0, 2, 9, 10, 0),
    gsSP2Triangles(2, 11, 12, 0, 13, 1, 2, 0),
    gsSP2Triangles(14, 0, 1, 0, 15, 3, 0, 0),
    gsSPVertex(&object_bgVtx_00B1B0[288], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSP2Triangles(4, 5, 6, 0, 2, 5, 4, 0),
    gsSP2Triangles(0, 6, 3, 0, 1, 5, 2, 0),
    gsSP2Triangles(6, 7, 3, 0, 5, 7, 6, 0),
    gsSPEndDisplayList(),
};

Gfx object_bg_DL_00EB18[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000200, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0110F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_00B1B0[239], 4, 0),
    gsSPMatrix(0x0D000240, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_010FF0, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[243], 12, 4),
    gsSP2Triangles(3, 4, 0, 0, 3, 2, 5, 0),
    gsSP2Triangles(6, 2, 7, 0, 8, 2, 1, 0),
    gsSP2Triangles(1, 9, 10, 0, 11, 1, 12, 0),
    gsSP2Triangles(13, 1, 0, 0, 0, 14, 15, 0),
    gsSPVertex(&object_bgVtx_00B1B0[255], 17, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 6, 7, 0, 8, 9, 1, 0),
    gsSP2Triangles(1, 9, 10, 0, 9, 8, 10, 0),
    gsSP2Triangles(8, 3, 10, 0, 11, 10, 5, 0),
    gsSP2Triangles(10, 3, 5, 0, 10, 11, 6, 0),
    gsSP2Triangles(6, 11, 7, 0, 7, 4, 0, 0),
    gsSP2Triangles(12, 1, 10, 0, 6, 2, 10, 0),
    gsSP2Triangles(12, 2, 1, 0, 2, 7, 0, 0),
    gsSP2Triangles(2, 13, 10, 0, 13, 12, 14, 0),
    gsSP2Triangles(15, 13, 14, 0, 13, 15, 10, 0),
    gsSP2Triangles(15, 14, 12, 0, 15, 12, 10, 0),
    gsSP2Triangles(13, 2, 12, 0, 1, 16, 8, 0),
    gsSP2Triangles(1, 0, 16, 0, 8, 16, 3, 0),
    gsSP2Triangles(0, 4, 16, 0, 4, 3, 16, 0),
    gsSPEndDisplayList(),
};

Gfx object_bg_DL_00ECF0[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_00B1B0[538], 4, 0),
    gsSPMatrix(0x0D000340, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[542], 12, 4),
    gsSP2Triangles(2, 4, 0, 0, 1, 0, 5, 0),
    gsSP2Triangles(0, 6, 7, 0, 2, 8, 9, 0),
    gsSP2Triangles(1, 10, 11, 0, 12, 13, 2, 0),
    gsSP2Triangles(1, 14, 3, 0, 15, 2, 3, 0),
    gsSPEndDisplayList(),
};

Gfx object_bg_DL_00EE50[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000340, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_00B1B0[508], 4, 0),
    gsSPMatrix(0x0D000380, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[512], 16, 4),
    gsSP2Triangles(4, 2, 5, 0, 6, 2, 7, 0),
    gsSP2Triangles(8, 9, 0, 0, 3, 10, 2, 0),
    gsSP2Triangles(11, 12, 2, 0, 1, 13, 0, 0),
    gsSP2Triangles(2, 14, 1, 0, 15, 16, 1, 0),
    gsSP2Triangles(3, 0, 17, 0, 18, 3, 19, 0),
    gsSPVertex(&object_bgVtx_00B1B0[528], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 1, 6, 0, 1, 4, 6, 0),
    gsSP2Triangles(2, 7, 8, 0, 0, 3, 5, 0),
    gsSP2Triangles(0, 8, 3, 0, 2, 8, 0, 0),
    gsSP2Triangles(6, 9, 7, 0, 2, 6, 7, 0),
    gsSPEndDisplayList(),
};

Gfx object_bg_DL_00EFE8[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000380, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_00B1B0[481], 4, 0),
    gsSPMatrix(0x0D0003C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[485], 12, 4),
    gsSP2Triangles(1, 4, 2, 0, 0, 5, 6, 0),
    gsSP2Triangles(1, 0, 7, 0, 2, 8, 9, 0),
    gsSP2Triangles(3, 2, 10, 0, 2, 11, 12, 0),
    gsSP2Triangles(3, 13, 0, 0, 0, 14, 15, 0),
    gsSPVertex(&object_bgVtx_00B1B0[497], 7, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 4, 0),
    gsSP2Triangles(5, 4, 3, 0, 5, 0, 6, 0),
    gsSP2Triangles(6, 4, 5, 0, 1, 0, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[504], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
    gsSP1Triangle(2, 1, 3, 0),
    gsSPEndDisplayList(),
};

Gfx object_bg_DL_00F1F0[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_00B1B0[465], 4, 0),
    gsSPMatrix(0x0D000280, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[469], 12, 4),
    gsSP2Triangles(0, 4, 2, 0, 5, 0, 1, 0),
    gsSP2Triangles(6, 7, 0, 0, 8, 9, 2, 0),
    gsSP2Triangles(10, 11, 1, 0, 2, 12, 13, 0),
    gsSP2Triangles(3, 14, 1, 0, 3, 2, 15, 0),
    gsSPEndDisplayList(),
};

Gfx object_bg_DL_00F350[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D000280, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_00B1B0[435], 4, 0),
    gsSPMatrix(0x0D0002C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[439], 16, 4),
    gsSP2Triangles(4, 2, 5, 0, 6, 2, 7, 0),
    gsSP2Triangles(0, 8, 9, 0, 2, 10, 3, 0),
    gsSP2Triangles(2, 11, 12, 0, 0, 13, 1, 0),
    gsSP2Triangles(1, 14, 2, 0, 1, 15, 16, 0),
    gsSP2Triangles(17, 0, 3, 0, 18, 3, 19, 0),
    gsSPVertex(&object_bgVtx_00B1B0[455], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 1, 0, 0, 6, 4, 1, 0),
    gsSP2Triangles(7, 8, 0, 0, 3, 5, 2, 0),
    gsSP2Triangles(5, 7, 2, 0, 2, 7, 0, 0),
    gsSP2Triangles(8, 9, 6, 0, 8, 6, 0, 0),
    gsSPEndDisplayList(),
};

Gfx object_bg_DL_00F4E8[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPMatrix(0x0D0002C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_bgVtx_00B1B0[408], 4, 0),
    gsSPMatrix(0x0D000300, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[412], 12, 4),
    gsSP2Triangles(2, 4, 1, 0, 5, 6, 0, 0),
    gsSP2Triangles(7, 0, 1, 0, 8, 9, 2, 0),
    gsSP2Triangles(10, 2, 3, 0, 11, 12, 2, 0),
    gsSP2Triangles(0, 13, 3, 0, 14, 15, 0, 0),
    gsSPVertex(&object_bgVtx_00B1B0[424], 7, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 0, 0),
    gsSP2Triangles(4, 3, 5, 0, 6, 2, 5, 0),
    gsSP2Triangles(5, 3, 6, 0, 5, 2, 1, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bg_TLUT_00F6F0),
    gsDPLoadTextureBlock(object_bg_Tex_0115F0, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_bgVtx_00B1B0[431], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 2, 1, 0),
    gsSP1Triangle(3, 1, 0, 0),
    gsSPEndDisplayList(),
};

u64 object_bg_TLUT_00F6F0[] = {
#include "assets/objects/object_bg/tlut_00F6F0.rgba16.inc.c"
};

u64 object_bg_Tex_00F8F0[] = {
#include "assets/objects/object_bg/tex_00F8F0.ci8.inc.c"
};

u64 object_bg_Tex_00FCF0[] = {
#include "assets/objects/object_bg/tex_00FCF0.ci8.inc.c"
};

u64 object_bg_Tex_0100F0[] = {
#include "assets/objects/object_bg/tex_0100F0.ci8.inc.c"
};

u64 object_bg_Tex_0104F0[] = {
#include "assets/objects/object_bg/tex_0104F0.ci8.inc.c"
};

u64 object_bg_Tex_0106F0[] = {
#include "assets/objects/object_bg/tex_0106F0.ci8.inc.c"
};

u64 object_bg_Tex_0107F0[] = {
#include "assets/objects/object_bg/tex_0107F0.ci8.inc.c"
};

u64 object_bg_Tex_010FF0[] = {
#include "assets/objects/object_bg/tex_010FF0.ci8.inc.c"
};

u64 object_bg_Tex_0110F0[] = {
#include "assets/objects/object_bg/tex_0110F0.ci8.inc.c"
};

u64 object_bg_Tex_0114F0[] = {
#include "assets/objects/object_bg/tex_0114F0.ci8.inc.c"
};

u64 object_bg_Tex_0115F0[] = {
#include "assets/objects/object_bg/tex_0115F0.ci8.inc.c"
};

StandardLimb object_bg_Standardlimb_0119F0 = { 
    { 4, 3199, 0 }, OBJECT_BG_2_LIMB_02 - 1, LIMB_DONE,
    NULL
};

StandardLimb object_bg_Standardlimb_0119FC = { 
    { 0, 0, 0 }, OBJECT_BG_2_LIMB_03 - 1, LIMB_DONE,
    object_bg_DL_00D5E0
};

StandardLimb object_bg_Standardlimb_011A08 = { 
    { 797, 0, 0 }, OBJECT_BG_2_LIMB_04 - 1, OBJECT_BG_2_LIMB_0E - 1,
    object_bg_DL_00D780
};

StandardLimb object_bg_Standardlimb_011A14 = { 
    { 1398, 0, 0 }, OBJECT_BG_2_LIMB_05 - 1, OBJECT_BG_2_LIMB_06 - 1,
    object_bg_DL_00DB38
};

StandardLimb object_bg_Standardlimb_011A20 = { 
    { 286, 0, 0 }, LIMB_DONE, LIMB_DONE,
    object_bg_DL_00DCD8
};

StandardLimb object_bg_Standardlimb_011A2C = { 
    { 1331, -571, -84 }, OBJECT_BG_2_LIMB_07 - 1, OBJECT_BG_2_LIMB_0A - 1,
    NULL
};

StandardLimb object_bg_Standardlimb_011A38 = { 
    { 0, 0, 0 }, OBJECT_BG_2_LIMB_08 - 1, LIMB_DONE,
    object_bg_DL_00E1C0
};

StandardLimb object_bg_Standardlimb_011A44 = { 
    { 885, 0, 0 }, OBJECT_BG_2_LIMB_09 - 1, LIMB_DONE,
    object_bg_DL_00E3F8
};

StandardLimb object_bg_Standardlimb_011A50 = { 
    { 797, 0, 0 }, LIMB_DONE, LIMB_DONE,
    object_bg_DL_00E580
};

StandardLimb object_bg_Standardlimb_011A5C = { 
    { 1331, 571, -86 }, OBJECT_BG_2_LIMB_0B - 1, LIMB_DONE,
    NULL
};

StandardLimb object_bg_Standardlimb_011A68 = { 
    { 0, 0, 0 }, OBJECT_BG_2_LIMB_0C - 1, LIMB_DONE,
    object_bg_DL_00E758
};

StandardLimb object_bg_Standardlimb_011A74 = { 
    { 811, 0, 0 }, OBJECT_BG_2_LIMB_0D - 1, LIMB_DONE,
    object_bg_DL_00E990
};

StandardLimb object_bg_Standardlimb_011A80 = { 
    { 726, 0, 0 }, LIMB_DONE, LIMB_DONE,
    object_bg_DL_00EB18
};

StandardLimb object_bg_Standardlimb_011A8C = { 
    { 418, 298, -9 }, OBJECT_BG_2_LIMB_0F - 1, OBJECT_BG_2_LIMB_13 - 1,
    NULL
};

StandardLimb object_bg_Standardlimb_011A98 = { 
    { 0, 0, 0 }, OBJECT_BG_2_LIMB_10 - 1, LIMB_DONE,
    object_bg_DL_00F1F0
};

StandardLimb object_bg_Standardlimb_011AA4 = { 
    { 1218, 0, 0 }, OBJECT_BG_2_LIMB_11 - 1, LIMB_DONE,
    object_bg_DL_00F350
};

StandardLimb object_bg_Standardlimb_011AB0 = { 
    { 1968, 5, 0 }, OBJECT_BG_2_LIMB_12 - 1, LIMB_DONE,
    NULL
};

StandardLimb object_bg_Standardlimb_011ABC = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    object_bg_DL_00F4E8
};

StandardLimb object_bg_Standardlimb_011AC8 = { 
    { 418, -292, -9 }, OBJECT_BG_2_LIMB_14 - 1, LIMB_DONE,
    NULL
};

StandardLimb object_bg_Standardlimb_011AD4 = { 
    { 0, 0, 0 }, OBJECT_BG_2_LIMB_15 - 1, LIMB_DONE,
    object_bg_DL_00ECF0
};

StandardLimb object_bg_Standardlimb_011AE0 = { 
    { 1218, 0, 0 }, OBJECT_BG_2_LIMB_16 - 1, LIMB_DONE,
    object_bg_DL_00EE50
};

StandardLimb object_bg_Standardlimb_011AEC = { 
    { 1968, 5, 0 }, OBJECT_BG_2_LIMB_17 - 1, LIMB_DONE,
    NULL
};

StandardLimb object_bg_Standardlimb_011AF8 = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    object_bg_DL_00EFE8
};

void* object_bg_Skel_011B60Limbs[] = {
    &object_bg_Standardlimb_0119F0, /* OBJECT_BG_2_LIMB_01 */
    &object_bg_Standardlimb_0119FC, /* OBJECT_BG_2_LIMB_02 */
    &object_bg_Standardlimb_011A08, /* OBJECT_BG_2_LIMB_03 */
    &object_bg_Standardlimb_011A14, /* OBJECT_BG_2_LIMB_04 */
    &object_bg_Standardlimb_011A20, /* OBJECT_BG_2_LIMB_05 */
    &object_bg_Standardlimb_011A2C, /* OBJECT_BG_2_LIMB_06 */
    &object_bg_Standardlimb_011A38, /* OBJECT_BG_2_LIMB_07 */
    &object_bg_Standardlimb_011A44, /* OBJECT_BG_2_LIMB_08 */
    &object_bg_Standardlimb_011A50, /* OBJECT_BG_2_LIMB_09 */
    &object_bg_Standardlimb_011A5C, /* OBJECT_BG_2_LIMB_0A */
    &object_bg_Standardlimb_011A68, /* OBJECT_BG_2_LIMB_0B */
    &object_bg_Standardlimb_011A74, /* OBJECT_BG_2_LIMB_0C */
    &object_bg_Standardlimb_011A80, /* OBJECT_BG_2_LIMB_0D */
    &object_bg_Standardlimb_011A8C, /* OBJECT_BG_2_LIMB_0E */
    &object_bg_Standardlimb_011A98, /* OBJECT_BG_2_LIMB_0F */
    &object_bg_Standardlimb_011AA4, /* OBJECT_BG_2_LIMB_10 */
    &object_bg_Standardlimb_011AB0, /* OBJECT_BG_2_LIMB_11 */
    &object_bg_Standardlimb_011ABC, /* OBJECT_BG_2_LIMB_12 */
    &object_bg_Standardlimb_011AC8, /* OBJECT_BG_2_LIMB_13 */
    &object_bg_Standardlimb_011AD4, /* OBJECT_BG_2_LIMB_14 */
    &object_bg_Standardlimb_011AE0, /* OBJECT_BG_2_LIMB_15 */
    &object_bg_Standardlimb_011AEC, /* OBJECT_BG_2_LIMB_16 */
    &object_bg_Standardlimb_011AF8, /* OBJECT_BG_2_LIMB_17 */
};

FlexSkeletonHeader object_bg_Skel_011B60 = { 
    { object_bg_Skel_011B60Limbs, ARRAY_COUNT(object_bg_Skel_011B60Limbs) }, 16
};

