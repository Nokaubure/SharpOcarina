#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_box.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

s16 sBoxBigChestOpenChildAnimFrameData[] = {
    0x0000, 0xC000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 
    0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 
    0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x7FAD, 0x7F1A, 
    0x7E55, 0x7D6B, 0x7C68, 0x7B5B, 0x7A50, 0x7954, 0x7875, 0x77C0, 0x7743, 0x7709, 0x76F9, 0x76EE, 0x76E7, 0x76E4, 
    0x76E6, 0x76EC, 0x76F6, 0x7704, 0x7716, 0x772B, 0x7743, 0x775F, 0x777D, 0x779E, 0x77C2, 0x77E9, 0x7811, 0x783C, 
    0x7869, 0x7898, 0x78C8, 0x78FA, 0x792D, 0x7961, 0x7996, 0x79CC, 0x7A03, 0x7A3A, 0x7A71, 0x7AA9, 0x7AE0, 0x7B17, 
    0x7B4E, 0x7B85, 0x7BBA, 0x7BEF, 0x7C23, 0x7C55, 0x7C9B, 0x7D03, 0x7D82, 0x7E0E, 0x7E9E, 0x7F28, 0x7FA1, 0x8000, 
    0x8000, 0x8000, 0x8000, 0x8000, 0x7DCB, 0x7B96, 0x7961, 0x772C, 0x74F7, 0x6EC3, 0x6694, 0x6016, 0x5B9B, 0x570C, 
    0x5276, 0x4DE4, 0x4964, 0x4501, 0x40C8, 0x3CC6, 0x3906, 0x3595, 0x327F, 0x2FD1, 0x2F44, 0x3152, 0x3427, 0x35EE, 
    0x35D6, 0x34F4, 0x344C, 0x3450, 0x348E, 0x34B5, 
};

JointIndex sBoxBigChestOpenChildAnimJointIndices[] = {
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0001, 0x0000 },
    { 0x0000, 0x0000, 0x0002 },
    { 0x0000, 0x0000, 0x0000 },
};

AnimationHeader gBoxBigChestOpenChildAnim = { 
    { 130 }, sBoxBigChestOpenChildAnimFrameData,
    sBoxBigChestOpenChildAnimJointIndices, 2
};

u8 object_box_possiblePadding_000138[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 sBoxBigChestOpenAdultAnimFrameData[] = {
    0x0000, 0xC000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 
    0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x800A, 0x801A, 0x801D, 0x8000, 0x7FAB, 0x7EC7, 0x7D6A, 0x7ABA, 
    0x7479, 0x6EE2, 0x6D00, 0x6C2C, 0x6BAF, 0x6AD0, 0x695D, 0x67B9, 0x660A, 0x6476, 0x62D4, 0x6121, 0x5FBB, 0x5EFF, 
    0x5EE3, 0x5F13, 0x5F81, 0x601E, 0x60DD, 0x61AF, 0x637F, 0x65A1, 0x660A, 0x6546, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 
    0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 
    0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 0x64B4, 
    0x64B4, 0x64B4, 0x64B4, 0x64E1, 0x6526, 0x6580, 0x65EB, 0x6663, 0x66E4, 0x676C, 0x67F6, 0x6880, 0x6904, 0x6981, 
    0x69F1, 0x6A52, 0x6AA1, 0x6AD8, 0x6AF6, 0x6AF1, 0x69DC, 0x6667, 0x605E, 0x5918, 0x511E, 0x48F6, 0x4125, 0x3A33, 
    0x34A5, 0x334D, 0x35B7, 0x377F, 0x3612, 0x34A5, 
};

JointIndex sBoxBigChestOpenAdultAnimJointIndices[] = {
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0001, 0x0000 },
    { 0x0000, 0x0000, 0x0002 },
    { 0x0000, 0x0000, 0x0000 },
};

AnimationHeader gBoxBigChestOpenAdultAnim = { 
    { 116 }, sBoxBigChestOpenAdultAnimFrameData,
    sBoxBigChestOpenAdultAnimJointIndices, 2
};

u8 object_box_zeroes_unk_0000025C[] = {
#include "assets/objects/object_box/object_box_zeroes_unk_0000025C.bin.inc.c"
};

s16 sBoxChestOpenAnimFrameData[] = {
    0x0000, 0xC000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 
    0x0000, 0x0000, 0x003A, 0x004D, 0xFFE7, 0xFFDD, 0x0006, 0x0028, 0x0003, 0xFFF2, 0x0008, 0x0009, 0x0000, 0x0000, 
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x8000, 0x8000, 0x8000, 0x8000, 
    0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 
    0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x7AD8, 0x7110, 0x6433, 0x55C9, 
    0x475C, 0x3A74, 0x309C, 0x32E8, 0x3927, 0x3550, 0x30FB, 0x32F0, 0x35A7, 0x34BD, 0x3376, 0x336D, 0x3386, 0x33B5, 
    0x33F3, 0x3436, 0x3474, 0x34A5, 
};

JointIndex sBoxChestOpenAnimJointIndices[] = {
    { 0x0000, 0x0000, 0x0002 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0001, 0x0000 },
    { 0x0000, 0x0000, 0x0034 },
    { 0x0000, 0x0000, 0x0000 },
};

AnimationHeader gBoxChestOpenAnim = { 
    { 50 }, sBoxChestOpenAnimFrameData,
    sBoxChestOpenAnimJointIndices, 2
};

u8 object_box_zeroes_unk_0000044C[] = {
#include "assets/objects/object_box/object_box_zeroes_unk_0000044C.bin.inc.c"
};

Vtx object_boxVtx_0004B0[] = {
#include "assets/objects/object_box/object_boxVtx_0004B0.vtx.inc"
};

Gfx gBoxChestBaseDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gBoxChestCornerTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPDisplayList(0x08000000),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_boxVtx_0004B0, 28, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
    gsSP2Triangles(24, 25, 26, 0, 24, 26, 27, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gBoxChestLockTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_MIRROR | G_TX_WRAP, G_TX_MIRROR
                         | G_TX_WRAP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boxVtx_0004B0[28], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSPEndDisplayList(),
};

Vtx object_boxVtx_000810[] = {
#include "assets/objects/object_box/object_boxVtx_000810.vtx.inc"
};

Gfx gBoxChestBaseGildedDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gBoxChestCornerGildedTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPDisplayList(0x08000000),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_boxVtx_000810, 28, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
    gsSP2Triangles(24, 25, 26, 0, 24, 26, 27, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gBoxChestLockGildedTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_WRAP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boxVtx_000810[28], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSPEndDisplayList(),
};

Vtx object_boxVtx_000B70[] = {
#include "assets/objects/object_box/object_boxVtx_000B70.vtx.inc"
};

Gfx gBoxChestBaseOrnateDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gBoxChestCornerOrnateTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPDisplayList(0x08000000),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_boxVtx_000B70, 16, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gBoxChestLockOrnateTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_WRAP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boxVtx_000B70[16], 20, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSPEndDisplayList(),
};

Vtx object_boxVtx_000EC8[] = {
#include "assets/objects/object_box/object_boxVtx_000EC8.vtx.inc"
};

Gfx gBoxChestLidDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gBoxChestCornerTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPDisplayList(0x08000000),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_boxVtx_000EC8, 30, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
    gsSP2Triangles(18, 19, 20, 0, 21, 22, 23, 0),
    gsSP2Triangles(24, 25, 26, 0, 27, 28, 29, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gBoxChestLockTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_MIRROR | G_TX_WRAP, G_TX_MIRROR
                         | G_TX_WRAP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boxVtx_000EC8[30], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
    gsSP2Triangles(24, 25, 26, 0, 24, 26, 27, 0),
    gsSP2Triangles(28, 29, 30, 0, 28, 30, 31, 0),
    gsSPVertex(&object_boxVtx_000EC8[62], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

Vtx object_boxVtx_001430[] = {
#include "assets/objects/object_box/object_boxVtx_001430.vtx.inc"
};

Gfx gBoxChestLidGildedDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gBoxChestCornerGildedTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPDisplayList(0x08000000),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_boxVtx_001430, 30, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
    gsSP2Triangles(18, 19, 20, 0, 21, 22, 23, 0),
    gsSP2Triangles(24, 25, 26, 0, 27, 28, 29, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gBoxChestLockGildedTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_WRAP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boxVtx_001430[30], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
    gsSP2Triangles(24, 25, 26, 0, 24, 26, 27, 0),
    gsSP2Triangles(28, 29, 30, 0, 28, 30, 31, 0),
    gsSPVertex(&object_boxVtx_001430[62], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

Vtx object_boxVtx_001998[] = {
#include "assets/objects/object_box/object_boxVtx_001998.vtx.inc"
};

Gfx gBoxChestLidOrnateDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gBoxChestCornerOrnateTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPDisplayList(0x08000000),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_boxVtx_001998, 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
    gsSP2Triangles(24, 25, 26, 0, 24, 26, 27, 0),
    gsSP1Triangle(28, 29, 30, 0),
    gsSPVertex(&object_boxVtx_001998[31], 29, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 2, 0),
    gsSP2Triangles(5, 6, 2, 0, 7, 2, 8, 0),
    gsSP2Triangles(9, 10, 11, 0, 9, 11, 12, 0),
    gsSP2Triangles(13, 14, 15, 0, 13, 15, 16, 0),
    gsSP2Triangles(17, 18, 19, 0, 17, 20, 21, 0),
    gsSP2Triangles(17, 22, 23, 0, 24, 25, 26, 0),
    gsSP1Triangle(25, 27, 28, 0),
    gsSPEndDisplayList(),
};

u64 gBoxChestLockTex[] = {
#include "assets/objects/object_box/chest_lock.rgba16.inc.c"
};

u64 gBoxChestCornerTex[] = {
#include "assets/objects/object_box/chest_corner.rgba16.inc.c"
};

u64 gBoxChestLockGildedTex[] = {
#include "assets/objects/object_box/chest_lock_gilded.rgba16.inc.c"
};

u64 gBoxChestCornerGildedTex[] = {
#include "assets/objects/object_box/chest_corner_gilded.rgba16.inc.c"
};

u64 gBoxChestLockOrnateTex[] = {
#include "assets/objects/object_box/chest_lock_ornate.rgba16.inc.c"
};

u64 gBoxChestCornerOrnateTex[] = {
#include "assets/objects/object_box/chest_corner_ornate.rgba16.inc.c"
};

StandardLimb object_box_Standardlimb_006660 = { 
    { 0, 0, 0 }, OBJECT_BOX_CHEST_LIMB_02 - 1, LIMB_DONE,
    NULL
};

StandardLimb object_box_Standardlimb_00666C = { 
    { 0, 2733, 1982 }, OBJECT_BOX_CHEST_LIMB_03 - 1, OBJECT_BOX_CHEST_LIMB_04 - 1,
    NULL
};

StandardLimb object_box_Standardlimb_006678 = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    NULL
};

StandardLimb object_box_Standardlimb_006684 = { 
    { 0, 2700, 0 }, LIMB_DONE, LIMB_DONE,
    NULL
};

void* gBoxChestSkelLimbs[] = {
    &object_box_Standardlimb_006660, /* OBJECT_BOX_CHEST_LIMB_01 */
    &object_box_Standardlimb_00666C, /* OBJECT_BOX_CHEST_LIMB_02 */
    &object_box_Standardlimb_006678, /* OBJECT_BOX_CHEST_LIMB_03 */
    &object_box_Standardlimb_006684, /* OBJECT_BOX_CHEST_LIMB_04 */
};

SkeletonHeader gBoxChestSkel = { 
    gBoxChestSkelLimbs, ARRAY_COUNT(gBoxChestSkelLimbs)
};

u8 object_box_unaccounted_0066A8[] = {
    0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

u8 object_boxCurveAnime_Ref_0066B0[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 
    0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 
    0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 
    0x00, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 object_boxCurveAnime_Copy_006730[] = {
      1024,   1024,   1024,      0,      0,      0,      0,      0, 
         0,   1024,   1024,      0,      0,      0,      0,      0, 
         0,   1024,   1024,   1024,      0,      0,      0,   2127, 
      2734,      0,   1024,   1024,      0,      0,      0,      0, 
         0,   1024,   1024,   1024,      0,      0,      0,  -2127, 
     -2734,      0,   1024,   1024,   1024,      0,  16384,      0, 
         0,   2734,  -1551,   1024,   1024,      0,      0,      0, 
         0,      0,   1024,   1024,   1024,      0, -16384,      0, 
     -1551,  -2734,      0,   1024,   1024,   1024,      0, -32768, 
         0,  -2127,   2734,      0,   1024,   1024,      0,      0, 
         0,      0,      0,   1024,   1024,   1024,      0, -32768, 
         0,  -2127,  -2734,      0,   1024,   1024,   1024,      0, 
    -16384,      0,      0,   2734,   1551,   1024,   1024,      0, 
         0,      0,      0,      0,   1024,   1024,   1024,      0, 
     16384,      0,  -1551,  -2734,      0, 
};

TransformData object_boxCurveAnime_TransformData_00681C[] = {
    { 0x000C, 0x0001, 0, 0, 1.200000f },
    { 0x0004, 0x0012, 0, 0, 1.200000f },
    { 0x0004, 0x001C, 3, 3, 2.000000f },
    { 0x0004, 0x0032, 0, 0, 2.300000f },
    { 0x0004, 0x0057, 0, 0, 2.300000f },
    { 0x0004, 0x006B, 9, 9, 3.500000f },
    { 0x0014, 0x0088, 0, 0, 4.000000f },
    { 0x000C, 0x0001, 0, 0, 0.000000f },
    { 0x0004, 0x0014, 0, 0, 0.000000f },
    { 0x0004, 0x001E, 0, 0, 5.500000f },
    { 0x0004, 0x0032, 0, 0, 0.000000f },
    { 0x0014, 0x0074, 0, 0, 0.000000f },
    { 0x000C, 0x0001, 0, 0, -85.000000f },
    { 0x0004, 0x0015, 0, 0, -85.000000f },
    { 0x0004, 0x0032, 0, 0, -36.000000f },
    { 0x0014, 0x0074, 0, 0, -36.000000f },
    { 0x000C, 0x0001, 0, 0, 0.000000f },
    { 0x0004, 0x0014, 0, 0, 0.000000f },
    { 0x0004, 0x001E, 0, 0, 5.500000f },
    { 0x0004, 0x0032, 0, 0, 0.000000f },
    { 0x0014, 0x0074, 0, 0, 0.000000f },
    { 0x000C, 0x0001, 0, 0, -85.000000f },
    { 0x0004, 0x0015, 0, 0, -85.000000f },
    { 0x0004, 0x0032, 0, 0, -40.000000f },
    { 0x0014, 0x0074, 0, 0, -40.000000f },
    { 0x000C, 0x0001, 0, 0, 0.000000f },
    { 0x0004, 0x0014, 0, 0, 0.000000f },
    { 0x0004, 0x001E, 0, 0, 5.500000f },
    { 0x0004, 0x0032, 0, 0, 0.000000f },
    { 0x0014, 0x0074, 0, 0, 0.000000f },
    { 0x000C, 0x0001, 0, 0, -85.000000f },
    { 0x0004, 0x0015, 0, 0, -85.000000f },
    { 0x0004, 0x0032, 0, 0, -36.000000f },
    { 0x0014, 0x0074, 0, 0, -36.000000f },
    { 0x000C, 0x0001, 0, 0, 0.000000f },
    { 0x0004, 0x0014, 0, 0, 0.000000f },
    { 0x0004, 0x001E, 0, 0, 1.200000f },
    { 0x0004, 0x0032, 0, 0, 0.000000f },
    { 0x0014, 0x0074, 0, 0, 0.000000f },
    { 0x000C, 0x0001, 0, 0, -40.000000f },
    { 0x0004, 0x0014, 0, 0, -40.000000f },
    { 0x0004, 0x0032, 0, 0, 6.000000f },
    { 0x0014, 0x0074, 0, 0, 6.000000f },
};

TransformUpdateIndex gBoxLightAdultCurveAnim = { 
    object_boxCurveAnime_Ref_0066B0,
    object_boxCurveAnime_TransformData_00681C,
    object_boxCurveAnime_Copy_006730,
    1, 136
};

u8 object_boxCurveAnime_Ref_006A30[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00, 
    0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 
    0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x07, 0x00, 0x00, 0x00, 0x05, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 
    0x00, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 object_boxCurveAnime_Copy_006AB0[] = {
      1024,   1024,   1024,      0,      0,      0,      0,      0, 
         0,   1024,   1024,      0,      0,      0,      0,      0, 
         0,   1024,   1024,   1024,      0,      0,      0,   2127, 
      2734,      0,   1024,   1024,      0,      0,      0,      0, 
         0,   1024,   1024,   1024,      0,      0,      0,  -2127, 
     -2734,      0,   1024,   1024,   1024,      0,  16384,      0, 
         0,   2734,  -1551,   1024,   1024,      0,      0,      0, 
         0,      0,   1024,   1024,   1024,      0, -16384,      0, 
     -1551,  -2734,      0,   1024,   1024,   1024,      0, -32768, 
         0,  -2127,   2734,      0,   1024,   1024,      0,      0, 
         0,      0,      0,   1024,   1024,   1024,      0, -32768, 
         0,  -2127,  -2734,      0,   1024,   1024,   1024,      0, 
    -16384,      0,      0,   2734,   1551,   1024,   1024,      0, 
         0,      0,      0,      0,   1024,   1024,   1024,      0, 
     16384,      0,  -1551,  -2734,      0, 
};

TransformData object_boxCurveAnime_TransformData_006B9C[] = {
    { 0x000C, 0x0001, 0, 0, 1.200000f },
    { 0x0004, 0x0026, 0, 0, 1.200000f },
    { 0x0004, 0x0030, 3, 3, 1.600000f },
    { 0x0004, 0x0046, 0, 0, 1.800000f },
    { 0x0004, 0x0057, 0, 0, 1.800000f },
    { 0x0004, 0x006B, 8, 8, 2.800000f },
    { 0x0014, 0x0088, 0, 0, 3.500000f },
    { 0x000C, 0x0001, 0, 0, 0.000000f },
    { 0x0004, 0x0028, 0, 0, 0.000000f },
    { 0x0004, 0x0032, 0, 0, 5.500000f },
    { 0x0004, 0x0046, 0, 0, 0.000000f },
    { 0x0004, 0x0066, 0, 0, 0.000000f },
    { 0x0004, 0x0070, 0, 0, 5.500000f },
    { 0x0014, 0x0084, 0, 0, 0.000000f },
    { 0x000C, 0x0001, 0, 0, -85.000000f },
    { 0x0004, 0x0029, 0, 0, -85.000000f },
    { 0x0004, 0x0046, 0, 0, -36.000000f },
    { 0x0004, 0x0067, 0, 0, -85.000000f },
    { 0x0014, 0x0084, 0, 0, -36.000000f },
    { 0x000C, 0x0001, 0, 0, 0.000000f },
    { 0x0004, 0x0028, 0, 0, 0.000000f },
    { 0x0004, 0x0032, 0, 0, 5.500000f },
    { 0x0004, 0x0046, 0, 0, 0.000000f },
    { 0x0004, 0x0066, 0, 0, 0.000000f },
    { 0x0004, 0x0070, 0, 0, 5.500000f },
    { 0x0014, 0x0084, 0, 0, 0.000000f },
    { 0x000C, 0x0001, 0, 0, -85.000000f },
    { 0x0004, 0x0029, 0, 0, -85.000000f },
    { 0x0004, 0x0046, 0, 0, -40.000000f },
    { 0x0004, 0x0067, 0, 0, -85.000000f },
    { 0x0014, 0x0084, 0, 0, -40.000000f },
    { 0x000C, 0x0001, 0, 0, 0.000000f },
    { 0x0004, 0x0028, 0, 0, 0.000000f },
    { 0x0004, 0x0032, 0, 0, 5.500000f },
    { 0x0004, 0x0046, 0, 0, 0.000000f },
    { 0x0004, 0x0066, 0, 0, 0.000000f },
    { 0x0004, 0x0070, 0, 0, 5.500000f },
    { 0x0014, 0x0084, 0, 0, 0.000000f },
    { 0x000C, 0x0001, 0, 0, -85.000000f },
    { 0x0004, 0x0029, 0, 0, -85.000000f },
    { 0x0004, 0x0046, 0, 0, -36.000000f },
    { 0x0004, 0x0067, 0, 0, -85.000000f },
    { 0x0014, 0x0084, 0, 0, -36.000000f },
    { 0x000C, 0x0001, 0, 0, 0.000000f },
    { 0x0004, 0x0028, 0, 0, 0.000000f },
    { 0x0004, 0x0032, 0, 0, 1.200000f },
    { 0x0004, 0x0046, 0, 0, 0.000000f },
    { 0x0004, 0x0066, 0, 0, 0.000000f },
    { 0x0004, 0x0070, 0, 0, 1.200000f },
    { 0x0014, 0x0084, 0, 0, 0.000000f },
    { 0x000C, 0x0001, 0, 0, -40.000000f },
    { 0x0004, 0x0028, 0, 0, -40.000000f },
    { 0x0004, 0x0046, 0, 0, 6.000000f },
    { 0x0004, 0x0066, 0, 0, -40.000000f },
    { 0x0014, 0x0084, 0, 0, 6.000000f },
};

TransformUpdateIndex gBoxLightChildCurveAnim = { 
    object_boxCurveAnime_Ref_006A30,
    object_boxCurveAnime_TransformData_006B9C,
    object_boxCurveAnime_Copy_006AB0,
    1, 136
};

u64 gBoxLightTex[] = {
#include "assets/objects/object_box/box_light.i8.inc.c"
};

Vtx object_boxVtx_007640[] = {
#include "assets/objects/object_box/object_boxVtx_007640.vtx.inc"
};

Gfx object_box_DL_007890[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gBoxLightTex, G_IM_FMT_I, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_MIRROR |
                         G_TX_CLAMP, 6, 5, 15, G_TX_NOLOD),
    gsDPLoadMultiBlock(gBoxLightTex, 0x0100, 1, G_IM_FMT_I, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                       G_TX_MIRROR | G_TX_CLAMP, 6, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL1, PRIMITIVE, TEXEL0, TEXEL0, TEXEL1, TEXEL0, PRIM_LOD_FRAC, TEXEL0, PRIMITIVE, ENVIRONMENT,
                       COMBINED, ENVIRONMENT, COMBINED, 0, PRIMITIVE, 0),
    gsDPSetRenderMode(G_RM_PASS, G_RM_AA_ZB_XLU_SURF2),
    gsSPClearGeometryMode(G_CULL_BACK | G_FOG | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_LIGHTING),
    gsSPDisplayList(0x08000000),
    gsSPVertex(object_boxVtx_007640, 21, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 4, 0),
    gsSP2Triangles(5, 6, 7, 0, 5, 8, 6, 0),
    gsSP2Triangles(9, 10, 11, 0, 9, 12, 10, 0),
    gsSP2Triangles(13, 14, 15, 0, 13, 16, 14, 0),
    gsSP2Triangles(17, 18, 19, 0, 17, 20, 18, 0),
    gsSPEndDisplayList(),
};

Gfx object_box_DL_007978[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gBoxLightTex, G_IM_FMT_I, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_MIRROR |
                         G_TX_CLAMP, 6, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock(gBoxLightTex, 0x0100, 1, G_IM_FMT_I, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                       G_TX_MIRROR | G_TX_CLAMP, 6, 5, 1, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL1, PRIMITIVE, TEXEL0, TEXEL0, TEXEL1, TEXEL0, PRIM_LOD_FRAC, TEXEL0, PRIMITIVE, ENVIRONMENT,
                       COMBINED, ENVIRONMENT, COMBINED, 0, PRIMITIVE, 0),
    gsDPSetRenderMode(G_RM_PASS, G_RM_AA_ZB_XLU_SURF2),
    gsSPClearGeometryMode(G_CULL_BACK | G_FOG | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_LIGHTING),
    gsSPDisplayList(0x08000000),
    gsSPVertex(&object_boxVtx_007640[21], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

Gfx object_box_DL_007A40[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gBoxLightTex, G_IM_FMT_I, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_MIRROR |
                         G_TX_CLAMP, 6, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock(gBoxLightTex, 0x0100, 1, G_IM_FMT_I, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                       G_TX_MIRROR | G_TX_CLAMP, 6, 5, 1, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL1, PRIMITIVE, TEXEL0, TEXEL0, TEXEL1, TEXEL0, PRIM_LOD_FRAC, TEXEL0, PRIMITIVE, ENVIRONMENT,
                       COMBINED, ENVIRONMENT, COMBINED, 0, PRIMITIVE, 0),
    gsDPSetRenderMode(G_RM_PASS, G_RM_AA_ZB_XLU_SURF2),
    gsSPClearGeometryMode(G_CULL_BACK | G_FOG | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_LIGHTING),
    gsSPDisplayList(0x08000000),
    gsSPVertex(&object_boxVtx_007640[25], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
    gsSPEndDisplayList(),
};

Gfx object_box_DL_007B08[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gBoxLightTex, G_IM_FMT_I, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_MIRROR |
                         G_TX_CLAMP, 6, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock(gBoxLightTex, 0x0100, 1, G_IM_FMT_I, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                       G_TX_MIRROR | G_TX_CLAMP, 6, 5, 1, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL1, PRIMITIVE, TEXEL0, TEXEL0, TEXEL1, TEXEL0, PRIM_LOD_FRAC, TEXEL0, PRIMITIVE, ENVIRONMENT,
                       COMBINED, ENVIRONMENT, COMBINED, 0, PRIMITIVE, 0),
    gsDPSetRenderMode(G_RM_PASS, G_RM_AA_ZB_XLU_SURF2),
    gsSPClearGeometryMode(G_CULL_BACK | G_FOG | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_LIGHTING),
    gsSPDisplayList(0x08000000),
    gsSPVertex(&object_boxVtx_007640[29], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
    gsSPEndDisplayList(),
};

Gfx object_box_DL_007BD0[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gBoxLightTex, G_IM_FMT_I, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_MIRROR |
                         G_TX_CLAMP, 6, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadMultiBlock(gBoxLightTex, 0x0100, 1, G_IM_FMT_I, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                       G_TX_MIRROR | G_TX_CLAMP, 6, 5, 1, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL1, PRIMITIVE, TEXEL0, TEXEL0, TEXEL1, TEXEL0, PRIM_LOD_FRAC, TEXEL0, PRIMITIVE, ENVIRONMENT,
                       COMBINED, ENVIRONMENT, COMBINED, 0, PRIMITIVE, 0),
    gsDPSetRenderMode(G_RM_PASS, G_RM_AA_ZB_XLU_SURF2),
    gsSPClearGeometryMode(G_CULL_BACK | G_FOG | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_LIGHTING),
    gsSPDisplayList(0x08000000),
    gsSPVertex(&object_boxVtx_007640[33], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
    gsSPEndDisplayList(),
};

SkelCurveLimb object_box_Curvelimb_007C98 = { 
    OBJECT_BOX_LIGHT_LIMB_02 - 1, LIMB_DONE,
    { NULL, NULL }
};

SkelCurveLimb object_box_Curvelimb_007CA4 = { 
    LIMB_DONE, OBJECT_BOX_LIGHT_LIMB_03 - 1,
    { NULL, object_box_DL_007890 }
};

SkelCurveLimb object_box_Curvelimb_007CB0 = { 
    OBJECT_BOX_LIGHT_LIMB_04 - 1, OBJECT_BOX_LIGHT_LIMB_06 - 1,
    { NULL, NULL }
};

SkelCurveLimb object_box_Curvelimb_007CBC = { 
    OBJECT_BOX_LIGHT_LIMB_05 - 1, LIMB_DONE,
    { NULL, NULL }
};

SkelCurveLimb object_box_Curvelimb_007CC8 = { 
    LIMB_DONE, LIMB_DONE,
    { NULL, object_box_DL_007B08 }
};

SkelCurveLimb object_box_Curvelimb_007CD4 = { 
    OBJECT_BOX_LIGHT_LIMB_07 - 1, OBJECT_BOX_LIGHT_LIMB_09 - 1,
    { NULL, NULL }
};

SkelCurveLimb object_box_Curvelimb_007CE0 = { 
    OBJECT_BOX_LIGHT_LIMB_08 - 1, LIMB_DONE,
    { NULL, NULL }
};

SkelCurveLimb object_box_Curvelimb_007CEC = { 
    LIMB_DONE, LIMB_DONE,
    { NULL, object_box_DL_007A40 }
};

SkelCurveLimb object_box_Curvelimb_007CF8 = { 
    OBJECT_BOX_LIGHT_LIMB_10 - 1, OBJECT_BOX_LIGHT_LIMB_12 - 1,
    { NULL, NULL }
};

SkelCurveLimb object_box_Curvelimb_007D04 = { 
    OBJECT_BOX_LIGHT_LIMB_11 - 1, LIMB_DONE,
    { NULL, NULL }
};

SkelCurveLimb object_box_Curvelimb_007D10 = { 
    LIMB_DONE, LIMB_DONE,
    { NULL, object_box_DL_007BD0 }
};

SkelCurveLimb object_box_Curvelimb_007D1C = { 
    OBJECT_BOX_LIGHT_LIMB_13 - 1, LIMB_DONE,
    { NULL, NULL }
};

SkelCurveLimb object_box_Curvelimb_007D28 = { 
    OBJECT_BOX_LIGHT_LIMB_14 - 1, LIMB_DONE,
    { NULL, NULL }
};

SkelCurveLimb object_box_Curvelimb_007D34 = { 
    LIMB_DONE, LIMB_DONE,
    { NULL, object_box_DL_007978 }
};

SkelCurveLimb* gBoxLightCurveSkelLimbs[] = {
    &object_box_Curvelimb_007C98, /* OBJECT_BOX_LIGHT_LIMB_01 */
    &object_box_Curvelimb_007CA4, /* OBJECT_BOX_LIGHT_LIMB_02 */
    &object_box_Curvelimb_007CB0, /* OBJECT_BOX_LIGHT_LIMB_03 */
    &object_box_Curvelimb_007CBC, /* OBJECT_BOX_LIGHT_LIMB_04 */
    &object_box_Curvelimb_007CC8, /* OBJECT_BOX_LIGHT_LIMB_05 */
    &object_box_Curvelimb_007CD4, /* OBJECT_BOX_LIGHT_LIMB_06 */
    &object_box_Curvelimb_007CE0, /* OBJECT_BOX_LIGHT_LIMB_07 */
    &object_box_Curvelimb_007CEC, /* OBJECT_BOX_LIGHT_LIMB_08 */
    &object_box_Curvelimb_007CF8, /* OBJECT_BOX_LIGHT_LIMB_09 */
    &object_box_Curvelimb_007D04, /* OBJECT_BOX_LIGHT_LIMB_10 */
    &object_box_Curvelimb_007D10, /* OBJECT_BOX_LIGHT_LIMB_11 */
    &object_box_Curvelimb_007D1C, /* OBJECT_BOX_LIGHT_LIMB_12 */
    &object_box_Curvelimb_007D28, /* OBJECT_BOX_LIGHT_LIMB_13 */
    &object_box_Curvelimb_007D34, /* OBJECT_BOX_LIGHT_LIMB_14 */
};

SkelCurveLimbList gBoxLightCurveSkel = { 
    gBoxLightCurveSkelLimbs, ARRAY_COUNT(gBoxLightCurveSkelLimbs)
};

s16 sBoxBigChestOpenGoronAnimFrameData[] = {
    0x0000, 0xC000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 
    0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x7FAE, 
    0x7EC3, 0x7D77, 0x7BF5, 0x7A68, 0x78F9, 0x77D4, 0x7723, 0x76EB, 0x76C7, 0x76AD, 0x769E, 0x7698, 0x769A, 0x76A5, 
    0x76B6, 0x76CE, 0x76EC, 0x770F, 0x7736, 0x7760, 0x778D, 0x77BC, 0x77EC, 0x781D, 0x784E, 0x787E, 0x78AC, 0x78D8, 
    0x7901, 0x7926, 0x7947, 0x7962, 0x7977, 0x7977, 0x7977, 0x7977, 0x7977, 0x7977, 0x7977, 0x7977, 0x7977, 0x7977, 
    0x758D, 0x6EDE, 0x6723, 0x6016, 0x59B7, 0x5306, 0x4C37, 0x4581, 0x3F1A, 0x3936, 0x340C, 0x2FD1, 0x3015, 0x3427, 
    0x360B, 0x34F4, 0x3442, 0x348E, 0x34B5, 0x0000, 
};

JointIndex sBoxBigChestOpenGoronAnimJointIndices[] = {
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0001, 0x0000 },
    { 0x0000, 0x0000, 0x0002 },
    { 0x0000, 0x0000, 0x0000 },
};

AnimationHeader gBoxBigChestOpenGoronAnim = { 
    { 87 }, sBoxBigChestOpenGoronAnimFrameData,
    sBoxBigChestOpenGoronAnimJointIndices, 2
};

u8 object_box_possiblePadding_007E64[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 sBoxBigChestOpenDekuAnimFrameData[] = {
    0x0000, 0xC000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 0x8000, 
    0x8012, 0x801D, 0x7FEB, 0x7EC7, 0x79D7, 0x6CF8, 0x5664, 0x3FF6, 0x2C78, 0x46AD, 0x4F30, 0x5612, 0x5BCF, 0x5D20, 
    0x5C03, 0x5C32, 0x5C42, 0x5CD4, 0x5E8C, 0x5F59, 0x5F0B, 0x5FD0, 0x5FE6, 0x5FFA, 0x600B, 0x6019, 0x6023, 0x6029, 
    0x602C, 0x6029, 0x6023, 0x6019, 0x600D, 0x5FFF, 0x5FF0, 0x5FE1, 0x5FD3, 0x5FC6, 0x5FBB, 0x5FB3, 0x5FAE, 0x5FAE, 
    0x5FB3, 0x5FBE, 0x5FD0, 0x5FFF, 0x6055, 0x60C3, 0x6137, 0x61A2, 0x61F2, 0x6219, 0x61B5, 0x6037, 0x5E24, 0x5B85, 
    0x5742, 0x50E6, 0x4954, 0x417B, 0x3A46, 0x34A5, 0x34EF, 0x377F, 0x34A5, 0x0000, 
};

JointIndex sBoxBigChestOpenDekuAnimJointIndices[] = {
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0001, 0x0000 },
    { 0x0000, 0x0000, 0x0002 },
    { 0x0000, 0x0000, 0x0000 },
};

AnimationHeader gBoxBigChestOpenDekuAnim = { 
    { 77 }, sBoxBigChestOpenDekuAnimFrameData,
    sBoxBigChestOpenDekuAnimJointIndices, 2
};

u8 object_box_zeroes_unk_00007F40[] = {
#include "assets/objects/object_box/object_box_zeroes_unk_00007F40.bin.inc.c"
};

CamData gBoxChestColCamDataList[] = {
    { 0x0000, 0, NULL },
};

SurfaceType gBoxChestColSurfaceType[] = {
    {0x00000000, 0x000207CA},   {0x00200000, 0x000207CA},
};

CollisionPoly gBoxChestColPolygons[] = {
    {0x0000, 0x2000, 0x0001, 0x0002, 0x0000, 0x7FFF, 0x0000, 0xEE85},
    {0x0000, 0x2000, 0x0002, 0x0003, 0x0000, 0x7FFF, 0x0000, 0xEE85},
    {0x0001, 0x2004, 0x0001, 0x0000, 0x0000, 0x0000, 0x7FFF, 0xF856},
    {0x0001, 0x2004, 0x0000, 0x0005, 0x0000, 0x0000, 0x7FFF, 0xF856},
    {0x0001, 0x2006, 0x0002, 0x0001, 0x7FFF, 0x0000, 0x0000, 0xF623},
    {0x0001, 0x2006, 0x0001, 0x0004, 0x7FFF, 0x0000, 0x0000, 0xF623},
    {0x0001, 0x2007, 0x0003, 0x0002, 0x0000, 0x0000, 0x8001, 0xF86A},
    {0x0001, 0x2007, 0x0002, 0x0006, 0x0000, 0x0000, 0x8001, 0xF86A},
    {0x0001, 0x2005, 0x0000, 0x0003, 0x8001, 0x0000, 0x0000, 0xF623},
    {0x0001, 0x2005, 0x0003, 0x0007, 0x8001, 0x0000, 0x0000, 0xF623},
    {0x0000, 0x2007, 0x0006, 0x0004, 0x0000, 0x8001, 0x0000, 0x0002},
    {0x0000, 0x2007, 0x0004, 0x0005, 0x0000, 0x8001, 0x0000, 0x0002},
};

Vec3s gBoxChestColVertices[] = {
    {  -2525,   4475,   1962 },
    {   2525,   4475,   1962 },
    {   2525,   4475,  -1942 },
    {  -2525,   4475,  -1942 },
    {   2525,      2,   1962 },
    {  -2525,      2,   1962 },
    {   2525,      2,  -1942 },
    {  -2525,      2,  -1942 },
};

CollisionHeader gBoxChestCol = { 
    { -2525, 2, -1942 },
    { 2525, 4475, 1962 },
    ARRAY_COUNT(gBoxChestColVertices), gBoxChestColVertices,
    ARRAY_COUNT(gBoxChestColPolygons), gBoxChestColPolygons,
    gBoxChestColSurfaceType,
    gBoxChestColCamDataList,
    0, NULL
};

