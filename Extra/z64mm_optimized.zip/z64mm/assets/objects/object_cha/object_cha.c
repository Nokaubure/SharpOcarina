#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_cha.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

Vtx object_chaVtx_000000[] = {
#include "assets/objects/object_cha/object_chaVtx_000000.vtx.inc"
};

Gfx object_cha_DL_000710[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_cha_TLUT_000B08),
    gsDPLoadTextureBlock(object_cha_Tex_000D08, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_chaVtx_000000, 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 14, 15, 12, 0),
    gsSP2Triangles(2, 16, 0, 0, 8, 17, 6, 0),
    gsSP2Triangles(5, 18, 3, 0, 11, 19, 9, 0),
    gsSP2Triangles(20, 21, 22, 0, 23, 24, 25, 0),
    gsSP2Triangles(26, 27, 28, 0, 29, 30, 31, 0),
    gsSPVertex(&object_chaVtx_000000[32], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(3, 12, 4, 0, 10, 9, 13, 0),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(17, 20, 18, 0, 14, 21, 15, 0),
    gsSP2Triangles(22, 23, 24, 0, 25, 26, 27, 0),
    gsSP2Triangles(28, 23, 22, 0, 25, 29, 26, 0),
    gsSPVertex(&object_chaVtx_000000[62], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_cha_TLUT_000B08),
    gsDPLoadTextureBlock(object_cha_Tex_001108, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_chaVtx_000000[68], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_cha_TLUT_000B08),
    gsDPLoadTextureBlock(object_cha_Tex_001508, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_chaVtx_000000[80], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSPEndDisplayList(),
};

Gfx object_cha_DL_000958[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_cha_TLUT_000B08),
    gsDPLoadTextureBlock(object_cha_Tex_001608, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_chaVtx_000000[84], 25, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
    gsSP2Triangles(4, 5, 0, 0, 0, 2, 4, 0),
    gsSP2Triangles(0, 5, 6, 0, 0, 7, 8, 0),
    gsSP2Triangles(8, 3, 0, 0, 0, 6, 7, 0),
    gsSP2Triangles(9, 10, 11, 0, 11, 12, 9, 0),
    gsSP2Triangles(13, 14, 15, 0, 15, 16, 13, 0),
    gsSP2Triangles(11, 10, 17, 0, 17, 18, 11, 0),
    gsSP2Triangles(9, 1, 3, 0, 12, 1, 9, 0),
    gsSP2Triangles(13, 18, 17, 0, 17, 14, 13, 0),
    gsSP2Triangles(4, 15, 5, 0, 4, 16, 15, 0),
    gsSP2Triangles(18, 13, 19, 0, 11, 18, 19, 0),
    gsSP2Triangles(12, 11, 19, 0, 13, 16, 19, 0),
    gsSP2Triangles(19, 1, 12, 0, 4, 19, 16, 0),
    gsSP2Triangles(2, 19, 4, 0, 2, 1, 19, 0),
    gsSP2Triangles(15, 6, 5, 0, 8, 9, 3, 0),
    gsSP2Triangles(15, 14, 20, 0, 20, 21, 15, 0),
    gsSP2Triangles(6, 15, 21, 0, 20, 17, 22, 0),
    gsSP2Triangles(14, 17, 20, 0, 23, 10, 9, 0),
    gsSP2Triangles(9, 24, 23, 0, 9, 8, 24, 0),
    gsSP2Triangles(17, 23, 22, 0, 17, 10, 23, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(object_cha_Tex_001A08, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_WRAP, 4, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_chaVtx_000000[109], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSPEndDisplayList(),
};

u64 object_cha_TLUT_000B08[] = {
#include "assets/objects/object_cha/tlut_000B08.rgba16.inc.c"
};

u64 object_cha_Tex_000D08[] = {
#include "assets/objects/object_cha/tex_000D08.ci8.inc.c"
};

u64 object_cha_Tex_001108[] = {
#include "assets/objects/object_cha/tex_001108.ci8.inc.c"
};

u64 object_cha_Tex_001508[] = {
#include "assets/objects/object_cha/tex_001508.ci8.inc.c"
};

u64 object_cha_Tex_001608[] = {
#include "assets/objects/object_cha/tex_001608.ci8.inc.c"
};

u64 object_cha_Tex_001A08[] = {
#include "assets/objects/object_cha/tex_001A08.rgba16.inc.c"
};

