#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_bai.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

s16 object_bai_Anim_0008B4FrameData[] = {
    0x0000, 0x0FB9, 0x01F4, 0xC000, 0x0000, 0xFFFC, 0xFFF7, 0xFFF3, 0xFFEE, 0xFFEA, 0xFFE8, 0xFFE7, 0xFFE8, 0xFFEA, 
    0xFFEE, 0xFFF3, 0xFFF7, 0xFFFC, 0x0000, 0x0004, 0x0008, 0x000D, 0x0011, 0x0015, 0x0018, 0x001B, 0x001B, 0x001B, 
    0x0018, 0x0015, 0x0011, 0x000D, 0x0008, 0x0004, 0x0FB9, 0x0FB6, 0x0FB0, 0x0FA7, 0x0F9B, 0x0F90, 0x0F84, 0x0F7A, 
    0x0F70, 0x0F65, 0x0F59, 0x0F4D, 0x0F44, 0x0F3E, 0x0F3C, 0x0F3E, 0x0F44, 0x0F4C, 0x0F56, 0x0F61, 0x0F6D, 0x0F77, 
    0x0F80, 0x0F88, 0x0F92, 0x0F9B, 0x0FA5, 0x0FAD, 0x0FB3, 0x0FB8, 0x02C5, 0x02CC, 0x02DF, 0x02FB, 0x0320, 0x034B, 
    0x037A, 0x03AB, 0x03DC, 0x040A, 0x0435, 0x045A, 0x0477, 0x048A, 0x0490, 0x048B, 0x047C, 0x0466, 0x0448, 0x0426, 
    0x03FF, 0x03D6, 0x03AB, 0x0380, 0x0356, 0x0330, 0x030D, 0x02F0, 0x02D9, 0x02CA, 0x00B4, 0x00BB, 0x00C7, 0x00D6, 
    0x00E7, 0x00F8, 0x0106, 0x0111, 0x0119, 0x0120, 0x0124, 0x0125, 0x0124, 0x0121, 0x011B, 0x0112, 0x0106, 0x00F9, 
    0x00EA, 0x00DC, 0x00D0, 0x00C5, 0x00BE, 0x00BA, 0x00B6, 0x00B3, 0x00B1, 0x00B0, 0x00B0, 0x00B1, 0xFDBD, 0xFDAE, 
    0xFD9C, 0xFD8B, 0xFD7A, 0xFD6D, 0xFD63, 0xFD61, 0xFD65, 0xFD70, 0xFD7F, 0xFD91, 0xFDA4, 0xFDB6, 0xFDC5, 0xFDD3, 
    0xFDE3, 0xFDF4, 0xFE04, 0xFE13, 0xFE1E, 0xFE26, 0xFE29, 0xFE25, 0xFE1C, 0xFE0F, 0xFE00, 0xFDEE, 0xFDDD, 0xFDCC, 
    0xF63B, 0xF60B, 0xF591, 0xF4E2, 0xF415, 0xF33B, 0xF267, 0xF1A5, 0xF0E4, 0xF017, 0xEF50, 0xEE9D, 0xEE0C, 0xEDAD, 
    0xED8B, 0xEDA9, 0xEDF8, 0xEE6F, 0xEF04, 0xEFAF, 0xF065, 0xF11B, 0xF1C4, 0xF26C, 0xF323, 0xF3DE, 0xF494, 0xF539, 
    0xF5C1, 0xF61B, 0x1603, 0x164A, 0x16FC, 0x17F5, 0x1913, 0x1A37, 0x1B49, 0x1C33, 0x1D1A, 0x1E1E, 0x1F22, 0x200F, 
    0x20D1, 0x2152, 0x2180, 0x2157, 0x20EB, 0x2049, 0x1F80, 0x1E9D, 0x1DB0, 0x1CC9, 0x1BFE, 0x1B34, 0x1A4B, 0x1953, 
    0x185B, 0x1774, 0x16B4, 0x1631, 0xFE2B, 0xFE31, 0xFE40, 0xFE58, 0xFE76, 0xFE99, 0xFEC0, 0xFEE8, 0xFF10, 0xFF36, 
    0xFF59, 0xFF77, 0xFF8F, 0xFF9E, 0xFFA4, 0xFF9F, 0xFF94, 0xFF81, 0xFF69, 0xFF4C, 0xFF2D, 0xFF0B, 0xFEE8, 0xFEC5, 
    0xFEA3, 0xFE83, 0xFE66, 0xFE4E, 0xFE3C, 0xFE30, 0xF0D5, 0xF0D5, 0xF0D4, 0xF0D2, 0xF0D0, 0xF0CD, 0xF0CB, 0xF0C8, 
    0xF0C5, 0xF0C3, 0xF0C0, 0xF0BE, 0xF0BD, 0xF0BC, 0xF0BB, 0xF0BB, 0xF0BC, 0xF0BE, 0xF0BF, 0xF0C1, 0xF0C3, 0xF0C6, 
    0xF0C8, 0xF0CA, 0xF0CD, 0xF0CF, 0xF0D1, 0xF0D3, 0xF0D4, 0xF0D5, 0xB1A2, 0xB193, 0xB169, 0xB128, 0xB0D6, 0xB075, 
    0xB00C, 0xAF9F, 0xAF31, 0xAEC8, 0xAE68, 0xAE15, 0xADD5, 0xADAB, 0xAD9C, 0xADA7, 0xADC8, 0xADFB, 0xAE3D, 0xAE8A, 
    0xAEE2, 0xAF3F, 0xAF9F, 0xAFFF, 0xB05C, 0xB0B3, 0xB101, 0xB143, 0xB176, 0xB196, 0x0020, 0x0025, 0x002C, 0x0035, 
    0x003D, 0x0046, 0x004C, 0x0050, 0x0051, 0x004F, 0x004B, 0x0045, 0x003E, 0x0036, 0x002F, 0x0028, 0x001F, 0x0016, 
    0x000E, 0x0007, 0x0001, 0xFFFE, 0xFFFC, 0xFFFE, 0x0001, 0x0006, 0x000B, 0x0010, 0x0016, 0x001B, 0xFFA0, 0xFF91, 
    0xFF80, 0xFF6D, 0xFF5C, 0xFF4E, 0xFF45, 0xFF41, 0xFF45, 0xFF4F, 0xFF5E, 0xFF6F, 0xFF81, 0xFF92, 0xFFA1, 0xFFB0, 
    0xFFC0, 0xFFD1, 0xFFE2, 0xFFF1, 0xFFFD, 0x0006, 0x0009, 0x0006, 0xFFFD, 0xFFF1, 0xFFE2, 0xFFD1, 0xFFC0, 0xFFAF, 
    0xEC02, 0xEBD2, 0xEB59, 0xEAAE, 0xE9E5, 0xE911, 0xE842, 0xE787, 0xE6CD, 0xE606, 0xE542, 0xE491, 0xE402, 0xE3A4, 
    0xE384, 0xE3A4, 0xE3F7, 0xE472, 0xE50C, 0xE5B9, 0xE670, 0xE724, 0xE7C9, 0xE86A, 0xE919, 0xE9CD, 0xEA7A, 0xEB16, 
    0xEB94, 0xEBE7, 0x1764, 0x17A8, 0x184D, 0x1931, 0x1A35, 0x1B3D, 0x1C32, 0x1D00, 0x1DCA, 0x1EB0, 0x1F99, 0x206F, 
    0x211D, 0x2191, 0x21B8, 0x218E, 0x2124, 0x2089, 0x1FC9, 0x1EF4, 0x1E17, 0x1D45, 0x1C91, 0x1BE0, 0x1B15, 0x1A3C, 
    0x1963, 0x189A, 0x17F5, 0x1787, 0x0061, 0x005B, 0x004A, 0x002F, 0x000D, 0xFFE6, 0xFFBB, 0xFF8F, 0xFF62, 0xFF37, 
    0xFF10, 0xFEEE, 0xFED3, 0xFEC2, 0xFEBC, 0xFEC1, 0xFECE, 0xFEE3, 0xFEFE, 0xFF1E, 0xFF41, 0xFF67, 0xFF8F, 0xFFB6, 
    0xFFDC, 0xFFFF, 0x001F, 0x003A, 0x004F, 0x005C, 0x0ED4, 0x0ED3, 0x0ED3, 0x0ED2, 0x0ED1, 0x0ED0, 0x0ECF, 0x0ECE, 
    0x0ECC, 0x0ECB, 0x0ECA, 0x0EC9, 0x0EC8, 0x0EC8, 0x0EC7, 0x0EC8, 0x0EC8, 0x0EC9, 0x0EC9, 0x0ECA, 0x0ECB, 0x0ECC, 
    0x0ECE, 0x0ECF, 0x0ED0, 0x0ED1, 0x0ED2, 0x0ED2, 0x0ED3, 0x0ED3, 0xBA6F, 0xBA5D, 0xBA2D, 0xB9E3, 0xB984, 0xB916, 
    0xB89D, 0xB81F, 0xB7A1, 0xB729, 0xB6BA, 0xB65B, 0xB611, 0xB5E1, 0xB5D0, 0xB5DD, 0xB603, 0xB63D, 0xB689, 0xB6E2, 
    0xB746, 0xB7B1, 0xB81F, 0xB88D, 0xB8F8, 0xB95C, 0xB9B6, 0xBA01, 0xBA3C, 0xBA61, 0x8177, 0x8170, 0x815B, 0x813A, 
    0x8110, 0x80DF, 0x80AA, 0x8073, 0x803B, 0x8006, 0x7FD5, 0x7FAC, 0x7F8B, 0x7F76, 0x7F6E, 0x7F74, 0x7F84, 0x7F9E, 
    0x7FBF, 0x7FE7, 0x8013, 0x8042, 0x8073, 0x80A3, 0x80D2, 0x80FF, 0x8126, 0x8147, 0x8161, 0x8172, 0x0000, 0xFFFA, 
    0xFFF1, 0xFFE8, 0xFFE4, 0xFFE7, 0xFFEC, 0xFFF4, 0xFFFB, 0x0001, 0x0002, 0x0002, 0x0001, 0x0001, 0x0000, 0x0000, 
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0001, 0x0002, 0x0002, 
    0x0000, 0x0036, 0x0074, 0x00A6, 0x00BA, 0x00A9, 0x0081, 0x004D, 0x001A, 0xFFF3, 0xFFE6, 0xFFE9, 0xFFF0, 0xFFF9, 
    0x0000, 0x0005, 0x000B, 0x000F, 0x000D, 0x0000, 0xFFE3, 0xFFB9, 0xFF89, 0xFF5D, 0xFF3C, 0xFF2F, 0xFF3E, 0xFF64, 
    0xFF97, 0xFFCE, 0x01B6, 0x0123, 0x005D, 0xFFC4, 0xFFB3, 0x004C, 0x014E, 0x0281, 0x03AD, 0x049C, 0x0511, 0x04DD, 
    0x03CB, 0x0268, 0x01B6, 0x0202, 0x02BC, 0x039E, 0x0465, 0x04C9, 0x04C3, 0x0486, 0x0425, 0x03B3, 0x0344, 0x02EB, 
    0x02AC, 0x0277, 0x0242, 0x0205, 0x03E8, 0x0389, 0x02B6, 0x01FD, 0x01A1, 0x0199, 0x01CE, 0x020C, 0x0251, 0x029A, 
    0x02E4, 0x032D, 0x0373, 0x03B2, 0x03E8, 0x0406, 0x03DD, 0x0351, 0x0298, 0x01FD, 0x01AE, 0x01B1, 0x01E9, 0x0231, 
    0x0281, 0x02D5, 0x0327, 0x0370, 0x03AC, 0x03D5, 0xEC73, 0xEC5B, 0xEC39, 0xEC2F, 0xEC29, 0xEC23, 0xEC21, 0xEC21, 
    0xEC24, 0xEC2B, 0xEC35, 0xEC42, 0xEC52, 0xEC63, 0xEC73, 0xEC78, 0xEC66, 0xEC48, 0xEC33, 0xEC2F, 0xEC2B, 0xEC25, 
    0xEC24, 0xEC25, 0xEC2A, 0xEC33, 0xEC40, 0xEC50, 0xEC5F, 0xEC6C, 0x6601, 0x66D5, 0x689E, 0x6A22, 0x6AE4, 0x6AF9, 
    0x6A8E, 0x6A0E, 0x697E, 0x68E3, 0x6843, 0x67A3, 0x670A, 0x667D, 0x6601, 0x65C0, 0x6623, 0x6757, 0x68E0, 0x6A22, 
    0x6AC7, 0x6AC7, 0x6A54, 0x69C0, 0x6916, 0x6863, 0x67B3, 0x6712, 0x668B, 0x662C, 0xBCDB, 0xBCB8, 0xBCE4, 0xBD48, 
    0xBDCB, 0xBE55, 0xBECF, 0xBFA6, 0xC029, 0xBFCD, 0xBF45, 0xBEA2, 0xBDF8, 0xBD5A, 0xBCDB, 0xBC6F, 0xBC33, 0xBC74, 
    0xBD4E, 0xBE82, 0xBFD5, 0xC10D, 0xC268, 0xC2FD, 0xC258, 0xC16D, 0xC05A, 0xBF3E, 0xBE35, 0xBD60, 0xEF16, 0xEF53, 
    0xEFB1, 0xF021, 0xF093, 0xF0F7, 0xF13E, 0xF159, 0xF13D, 0xF0F5, 0xF090, 0xF01D, 0xEFAD, 0xEF4E, 0xEF11, 0xEEF2, 
    0xEEE1, 0xEEDC, 0xEEE0, 0xEEE9, 0xEEF6, 0xEF02, 0xEF0B, 0xEF31, 0xEF54, 0xEF4A, 0xEF33, 0xEF18, 0xEF03, 0xEEFF, 
    0x042F, 0x03BC, 0x032D, 0x0293, 0x01FF, 0x0182, 0x012E, 0x0112, 0x0140, 0x01AD, 0x0244, 0x02EF, 0x0398, 0x0429, 
    0x048E, 0x04C8, 0x04EC, 0x0500, 0x0509, 0x050E, 0x0515, 0x0522, 0x053C, 0x05A4, 0x05EA, 0x05BF, 0x0584, 0x053B, 
    0x04E7, 0x048D, 0xF238, 0xF2D1, 0xF3DB, 0xF524, 0xF67B, 0xF7AE, 0xF889, 0xF8DB, 0xF885, 0xF7A8, 0xF675, 0xF51C, 
    0xF3CD, 0xF2B8, 0xF20E, 0xF1C2, 0xF1A3, 0xF1AA, 0xF1CE, 0xF208, 0xF250, 0xF29D, 0xF2E9, 0xF3F8, 0xF4D8, 0xF48C, 
    0xF3F3, 0xF33C, 0xF296, 0xF230, 0x06E2, 0x06D5, 0x06CF, 0x06CD, 0x06D1, 0x06D9, 0x06E6, 0x06F9, 0x0716, 0x073E, 
    0x076C, 0x079D, 0x07CA, 0x07F0, 0x0809, 0x0818, 0x0822, 0x0827, 0x0826, 0x081F, 0x0814, 0x0805, 0x07F2, 0x07D8, 
    0x07B6, 0x078F, 0x0765, 0x073C, 0x0716, 0x06F7, 0x7896, 0x78A7, 0x78BD, 0x78D6, 0x78EE, 0x7904, 0x7916, 0x7922, 
    0x7927, 0x7926, 0x7920, 0x7916, 0x790A, 0x78FD, 0x78F0, 0x78E0, 0x78CD, 0x78B7, 0x78A0, 0x7889, 0x7874, 0x7863, 
    0x7858, 0x7853, 0x7854, 0x7859, 0x7862, 0x786D, 0x787A, 0x7888, 0x0F20, 0x0F44, 0x0F8F, 0x0FF2, 0x1063, 0x10D3, 
    0x113A, 0x118B, 0x11D8, 0x1231, 0x128C, 0x12DF, 0x1322, 0x134C, 0x1354, 0x1337, 0x12FB, 0x12A9, 0x1247, 0x11DF, 
    0x1178, 0x111B, 0x10D1, 0x1090, 0x1046, 0x0FFA, 0x0FB1, 0x0F70, 0x0F3F, 0x0F22, 0x2790, 0x27D5, 0x285F, 0x2918, 
    0x29E7, 0x2AB6, 0x2B71, 0x2C04, 0x2C8F, 0x2D2F, 0x2DD2, 0x2E68, 0x2EE0, 0x2F2A, 0x2F37, 0x2EFF, 0x2E90, 0x2DF7, 
    0x2D42, 0x2C81, 0x2BC4, 0x2B19, 0x2A94, 0x2A1E, 0x299A, 0x2912, 0x288F, 0x281C, 0x27C4, 0x2792, 0x09D6, 0x09DE, 
    0x0A0E, 0x0A59, 0x0AAF, 0x0B01, 0x0B42, 0x0B63, 0x0B5E, 0x0B3B, 0x0B09, 0x0AD1, 0x0AA0, 0x0A81, 0x0A7F, 0x0AA2, 
    0x0AE2, 0x0B34, 0x0B8E, 0x0BE4, 0x0C2B, 0x0C5A, 0x0C65, 0x0C43, 0x0BF9, 0x0B95, 0x0B24, 0x0AB2, 0x0A4C, 0x09FE, 
    0xEFAB, 0xEFAD, 0xEFB2, 0xEFBA, 0xEFC3, 0xEFCD, 0xEFD6, 0xEFDE, 0xEFE7, 0xEFF0, 0xEFFA, 0xF003, 0xF00B, 0xF010, 
    0xF012, 0xF010, 0xF00B, 0xF004, 0xEFFC, 0xEFF3, 0xEFEA, 0xEFE1, 0xEFDA, 0xEFD3, 0xEFCB, 0xEFC3, 0xEFBC, 0xEFB5, 
    0xEFAF, 0xEFAC, 0x10EA, 0x10E1, 0x10CA, 0x10AA, 0x1083, 0x105A, 0x1032, 0x100F, 0x0FEC, 0x0FC3, 0x0F99, 0x0F72, 
    0x0F51, 0x0F3B, 0x0F34, 0x0F3C, 0x0F50, 0x0F6E, 0x0F91, 0x0FB8, 0x0FDF, 0x1003, 0x1022, 0x1040, 0x1061, 0x1082, 
    0x10A3, 0x10C0, 0x10D7, 0x10E6, 
};

JointIndex object_bai_Anim_0008B4JointIndices[] = {
    { 0x0004, 0x0022, 0x0002 },
    { 0x0003, 0x0040, 0x0003 },
    { 0x005E, 0x007C, 0x009A },
    { 0x0000, 0x0000, 0x00B8 },
    { 0x00D6, 0x00F4, 0x0112 },
    { 0x0130, 0x014E, 0x016C },
    { 0x0000, 0x0000, 0x018A },
    { 0x01A8, 0x01C6, 0x01E4 },
    { 0x0000, 0x0000, 0x0202 },
    { 0x0220, 0x023E, 0x025C },
    { 0x027A, 0x0298, 0x02B6 },
    { 0x0000, 0x0000, 0x02D4 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x02F2, 0x0310, 0x032E },
    { 0x034C, 0x036A, 0x0388 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x03A6 },
    { 0x03C4, 0x03E2, 0x0400 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x0000 },
};

AnimationHeader object_bai_Anim_0008B4 = { 
    { 30 }, object_bai_Anim_0008B4FrameData,
    object_bai_Anim_0008B4JointIndices, 4
};

u8 object_bai_possiblePadding_0008C4[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 object_bai_Anim_0011C0FrameData[] = {
    0x0000, 0x1004, 0x0064, 0x1004, 0x1003, 0x1002, 0x0FFF, 0x0FFB, 0x0FF7, 0x0FF3, 0x0FEE, 0x0FE9, 0x0FE5, 0x0FE0, 
    0x0FDD, 0x0FDA, 0x0FD8, 0x0FD8, 0x0FD8, 0x0FD9, 0x0FDC, 0x0FDF, 0x0FE2, 0x0FE6, 0x0FEA, 0x0FEE, 0x0FF2, 0x0FF6, 
    0x0FFA, 0x0FFD, 0x1000, 0x1002, 0x1004, 0xC000, 0xC001, 0xC002, 0xC004, 0xC005, 0xC006, 0xC007, 0xC008, 0xC008, 
    0xC007, 0xC006, 0xC004, 0xC003, 0xC001, 0xC000, 0xBFFF, 0xBFFE, 0xBFFC, 0xBFFB, 0xBFFA, 0xBFFA, 0xBFF9, 0xBFF9, 
    0xBFF9, 0xBFFA, 0xBFFB, 0xBFFC, 0xBFFD, 0xBFFE, 0xBFFF, 0x02C5, 0x02C8, 0x02CE, 0x02D8, 0x02E3, 0x02EE, 0x02FA, 
    0x0304, 0x030E, 0x0319, 0x0325, 0x0331, 0x033A, 0x0340, 0x0342, 0x0340, 0x033A, 0x0332, 0x0328, 0x031D, 0x0312, 
    0x0307, 0x02FE, 0x02F6, 0x02ED, 0x02E3, 0x02DA, 0x02D1, 0x02CB, 0x02C7, 0xC000, 0xC00F, 0xC022, 0xC036, 0xC049, 
    0xC059, 0xC064, 0xC069, 0xC064, 0xC059, 0xC049, 0xC036, 0xC022, 0xC00F, 0xC000, 0xBFF2, 0xBFE3, 0xBFD3, 0xBFC4, 
    0xBFB7, 0xBFAD, 0xBFA6, 0xBFA3, 0xBFA6, 0xBFAD, 0xBFB7, 0xBFC4, 0xBFD3, 0xBFE3, 0xBFF2, 0xFFEC, 0xFFE7, 0xFFE2, 
    0xFFDB, 0xFFD5, 0xFFCE, 0xFFC9, 0xFFC5, 0xFFC5, 0xFFC7, 0xFFCB, 0xFFD1, 0xFFD7, 0xFFDE, 0xFFE4, 0xFFE9, 0xFFEF, 
    0xFFF5, 0xFFFB, 0x0000, 0x0004, 0x0006, 0x0007, 0x0006, 0x0003, 0x0000, 0xFFFC, 0xFFF8, 0xFFF4, 0xFFF0, 0x005F, 
    0x0074, 0x008D, 0x00A7, 0x00C0, 0x00D5, 0x00E3, 0x00E8, 0x00E3, 0x00D4, 0x00BE, 0x00A5, 0x008B, 0x0073, 0x005F, 
    0x004D, 0x0039, 0x0025, 0x0012, 0x0000, 0xFFF3, 0xFFE9, 0xFFE6, 0xFFE9, 0xFFF2, 0x0000, 0x0011, 0x0024, 0x0039, 
    0x004D, 0xF3B9, 0xF3B2, 0xF38D, 0xF350, 0xF301, 0xF2A4, 0xF23E, 0xF1D5, 0xF16A, 0xF100, 0xF09D, 0xF045, 0xEFFF, 
    0xEFCE, 0xEFB9, 0xEFBD, 0xEFD4, 0xEFFC, 0xF032, 0xF074, 0xF0C0, 0xF112, 0xF169, 0xF1C5, 0xF225, 0xF284, 0xF2DE, 
    0xF330, 0xF373, 0xF3A2, 0x0F4F, 0x0F56, 0x0F88, 0x0FDE, 0x1051, 0x10DA, 0x1173, 0x1216, 0x12BD, 0x135D, 0x13F1, 
    0x1472, 0x14D8, 0x151F, 0x1540, 0x153E, 0x1523, 0x14F0, 0x14A8, 0x144D, 0x13E2, 0x1368, 0x12E2, 0x1253, 0x11C0, 
    0x112F, 0x10A4, 0x1027, 0x0FBF, 0x0F74, 0xFF7B, 0xFF77, 0xFF7B, 0xFF85, 0xFF95, 0xFFA9, 0xFFC0, 0xFFD8, 0xFFF2, 
    0x000A, 0x0021, 0x0035, 0x0045, 0x004F, 0x0053, 0x0050, 0x0048, 0x003B, 0x002B, 0x0018, 0x0003, 0xFFED, 0xFFD6, 
    0xFFC0, 0xFFAC, 0xFF99, 0xFF8A, 0xFF7E, 0xFF78, 0xFF76, 0xF09B, 0xF09B, 0xF09B, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 
    0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 
    0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09B, 0xF09B, 0xBA7A, 0xBA85, 0xBA7C, 0xBA60, 0xBA36, 
    0xBA00, 0xB9C2, 0xB97F, 0xB93A, 0xB8F7, 0xB8B9, 0xB883, 0xB858, 0xB83C, 0xB832, 0xB83A, 0xB851, 0xB873, 0xB89F, 
    0xB8D3, 0xB90C, 0xB948, 0xB985, 0xB9C0, 0xB9F8, 0xBA29, 0xBA53, 0xBA72, 0xBA84, 0xBA88, 0x0014, 0x0010, 0x000B, 
    0x0006, 0x0000, 0xFFFB, 0xFFF7, 0xFFF5, 0xFFF6, 0xFFFA, 0x0000, 0x0008, 0x000F, 0x0017, 0x001D, 0x0022, 0x0027, 
    0x002D, 0x0031, 0x0035, 0x0037, 0x0038, 0x0037, 0x0035, 0x0031, 0x002C, 0x0027, 0x0022, 0x001D, 0x0018, 0xFFA0, 
    0xFFB4, 0xFFCD, 0xFFE7, 0x0000, 0x0015, 0x0023, 0x0029, 0x0023, 0x0014, 0xFFFF, 0xFFE6, 0xFFCC, 0xFFB4, 0xFFA0, 
    0xFF8E, 0xFF7A, 0xFF66, 0xFF52, 0xFF41, 0xFF33, 0xFF2A, 0xFF26, 0xFF29, 0xFF32, 0xFF40, 0xFF51, 0xFF65, 0xFF79, 
    0xFF8D, 0xF3B9, 0xF39D, 0xF35F, 0xF309, 0xF2A3, 0xF235, 0xF1C6, 0xF15D, 0xF0FA, 0xF09F, 0xF04F, 0xF00D, 0xEFDC, 
    0xEFBE, 0xEFB9, 0xEFCB, 0xEFF2, 0xF02B, 0xF071, 0xF0C2, 0xF11B, 0xF178, 0xF1D5, 0xF231, 0xF28B, 0xF2E0, 0xF32C, 
    0xF36B, 0xF39B, 0xF3B6, 0x0F4E, 0x0F7B, 0x0FDA, 0x105C, 0x10F7, 0x119E, 0x1248, 0x12EC, 0x1383, 0x1409, 0x147A, 
    0x14D5, 0x1516, 0x153B, 0x1540, 0x1525, 0x14EE, 0x149E, 0x143A, 0x13C4, 0x1341, 0x12B5, 0x1225, 0x1195, 0x110C, 
    0x108C, 0x101A, 0x0FBD, 0x0F78, 0x0F51, 0x0061, 0x0064, 0x0060, 0x0055, 0x0044, 0x0030, 0x0018, 0xFFFF, 0xFFE5, 
    0xFFCC, 0xFFB5, 0xFFA1, 0xFF91, 0xFF86, 0xFF82, 0xFF85, 0xFF8E, 0xFF9A, 0xFFAB, 0xFFBE, 0xFFD4, 0xFFEA, 0x0001, 
    0x0017, 0x002C, 0x003F, 0x004F, 0x005C, 0x0063, 0x0065, 0x0ED4, 0x0ED4, 0x0ED4, 0x0ED4, 0x0ED4, 0x0ED4, 0x0ED4, 
    0x0ED4, 0x0ED4, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED4, 
    0x0ED4, 0x0ED4, 0x0ED4, 0x0ED4, 0x0ED4, 0x0ED4, 0x0ED4, 0x0ED4, 0x0ED4, 0xBA6F, 0xBA78, 0xBA6C, 0xBA4D, 0xBA1F, 
    0xB9E5, 0xB9A3, 0xB95C, 0xB913, 0xB8CD, 0xB88B, 0xB852, 0xB825, 0xB808, 0xB7FE, 0xB806, 0xB81D, 0xB841, 0xB86F, 
    0xB8A6, 0xB8E2, 0xB921, 0xB961, 0xB9A0, 0xB9DB, 0xBA11, 0xBA3D, 0xBA60, 0xBA75, 0xBA7B, 0x0000, 0xFFF4, 0xFFE6, 
    0xFFD8, 0xFFCB, 0xFFBF, 0xFFB5, 0xFFAF, 0xFFAD, 0xFFB0, 0xFFB8, 0xFFC5, 0xFFD4, 0xFFE4, 0xFFF3, 0x0000, 0x000D, 
    0x001B, 0x002A, 0x0039, 0x0046, 0x0051, 0x0058, 0x005B, 0x0057, 0x004E, 0x0040, 0x002F, 0x001E, 0x000E, 0x8319, 
    0x831B, 0x8322, 0x832B, 0x8337, 0x8345, 0x8353, 0x8360, 0x836C, 0x8379, 0x8388, 0x8398, 0x83A7, 0x83B4, 0x83BC, 
    0x83C0, 0x83BD, 0x83B7, 0x83AD, 0x83A1, 0x8394, 0x8386, 0x8379, 0x836D, 0x8360, 0x8351, 0x8341, 0x8332, 0x8325, 
    0x831C, 0x0000, 0xFFE1, 0xFFBB, 0xFF92, 0xFF68, 0xFF42, 0xFF23, 0xFF0E, 0xFF06, 0xFF10, 0xFF2C, 0xFF55, 0xFF84, 
    0xFFB3, 0xFFDF, 0x0000, 0x001B, 0x0035, 0x004E, 0x0064, 0x0077, 0x0086, 0x0090, 0x0093, 0x008E, 0x0081, 0x006D, 
    0x0054, 0x0038, 0x001C, 0x01B6, 0x01AC, 0x0195, 0x0173, 0x0149, 0x011B, 0x00EB, 0x00BC, 0x0092, 0x0065, 0x0030, 
    0xFFF8, 0xFFC3, 0xFF96, 0xFF78, 0xFF6E, 0xFF79, 0xFF93, 0xFFB9, 0xFFE7, 0x001B, 0x004F, 0x0080, 0x00AB, 0x00D7, 
    0x0109, 0x013C, 0x016B, 0x0193, 0x01AD, 0x0F39, 0x0F36, 0x0F2E, 0x0F21, 0x0F11, 0x0EFE, 0x0EE9, 0x0ED3, 0x0EBE, 
    0x0EA9, 0x0E98, 0x0E89, 0x0E80, 0x0E7D, 0x0E7F, 0x0E84, 0x0E8D, 0x0E99, 0x0EA6, 0x0EB5, 0x0EC5, 0x0ED6, 0x0EE6, 
    0x0EF6, 0x0F06, 0x0F14, 0x0F20, 0x0F2A, 0x0F32, 0x0F37, 0xF3C2, 0xF3BD, 0xF3B1, 0xF39E, 0xF386, 0xF36C, 0xF352, 
    0xF338, 0xF320, 0xF30B, 0xF2FA, 0xF2EE, 0xF2E6, 0xF2E3, 0xF2E5, 0xF2E9, 0xF2F1, 0xF2FB, 0xF308, 0xF317, 0xF328, 
    0xF33B, 0xF34F, 0xF363, 0xF377, 0xF38B, 0xF39C, 0xF3AC, 0xF3B8, 0xF3BF, 0x8147, 0x8150, 0x816B, 0x8194, 0x81C9, 
    0x8207, 0x824B, 0x8291, 0x82D8, 0x831A, 0x8355, 0x8383, 0x83A2, 0x83AD, 0x83A7, 0x8394, 0x8377, 0x8351, 0x8325, 
    0x82F4, 0x82BF, 0x8289, 0x8253, 0x821E, 0x81EC, 0x81BF, 0x8197, 0x8176, 0x815D, 0x814D, 0xF30B, 0xF2FD, 0xF2D4, 
    0xF295, 0xF245, 0xF1E7, 0xF181, 0xF116, 0xF0AC, 0xF046, 0xEFE8, 0xEF98, 0xEF59, 0xEF30, 0xEF22, 0xEF2D, 0xEF4D, 
    0xEF7E, 0xEFBE, 0xF00A, 0xF05F, 0xF0B9, 0xF116, 0xF174, 0xF1CE, 0xF223, 0xF26F, 0xF2AF, 0xF2E0, 0xF300, 0x00ED, 
    0x00EA, 0x00E2, 0x00D5, 0x00C4, 0x00B0, 0x009A, 0x0083, 0x006B, 0x0054, 0x003E, 0x002A, 0x0019, 0x000C, 0x0003, 
    0x0000, 0x0003, 0x000C, 0x0019, 0x002A, 0x003E, 0x0054, 0x006B, 0x0083, 0x009A, 0x00B0, 0x00C4, 0x00D5, 0x00E2, 
    0x00EA, 0x0897, 0x0897, 0x0897, 0x0898, 0x0899, 0x089A, 0x089B, 0x089C, 0x089E, 0x089F, 0x08A0, 0x08A1, 0x08A2, 
    0x08A3, 0x08A3, 0x08A3, 0x08A3, 0x08A3, 0x08A2, 0x08A1, 0x08A0, 0x089F, 0x089E, 0x089C, 0x089B, 0x089A, 0x0899, 
    0x0898, 0x0897, 0x0897, 0x046B, 0x045C, 0x0434, 0x03F5, 0x03A4, 0x0346, 0x02DD, 0x026E, 0x01FD, 0x018E, 0x0125, 
    0x00C6, 0x0076, 0x0037, 0x000E, 0x0000, 0x000E, 0x0037, 0x0076, 0x00C6, 0x0125, 0x018E, 0x01FD, 0x026E, 0x02DD, 
    0x0346, 0x03A4, 0x03F5, 0x0434, 0x045C, 0x087A, 0x0877, 0x0869, 0x0855, 0x083C, 0x0820, 0x0805, 0x07EB, 0x07D1, 
    0x07B4, 0x0792, 0x0770, 0x0750, 0x0737, 0x0727, 0x0722, 0x0727, 0x0733, 0x0745, 0x075C, 0x0775, 0x078F, 0x07A8, 
    0x07C1, 0x07DD, 0x07FE, 0x0820, 0x0841, 0x085D, 0x0872, 0x7965, 0x7960, 0x7952, 0x793E, 0x7926, 0x790D, 0x78F4, 
    0x78DD, 0x78C9, 0x78B3, 0x789A, 0x7880, 0x7868, 0x7854, 0x7848, 0x7846, 0x784D, 0x785B, 0x786C, 0x7881, 0x7897, 
    0x78AD, 0x78C2, 0x78D5, 0x78EB, 0x7905, 0x7920, 0x793A, 0x7950, 0x795F, 0x0D48, 0x0D51, 0x0D67, 0x0D85, 0x0DAB, 
    0x0DD4, 0x0DFE, 0x0E26, 0x0E4B, 0x0E6B, 0x0E87, 0x0E9E, 0x0EAF, 0x0EBA, 0x0EBD, 0x0EB7, 0x0EA8, 0x0E94, 0x0E7C, 
    0x0E60, 0x0E42, 0x0E22, 0x0E01, 0x0DE1, 0x0DC1, 0x0DA1, 0x0D84, 0x0D6B, 0x0D58, 0x0D4C, 0x2C65, 0x2C77, 0x2CA5, 
    0x2CE6, 0x2D36, 0x2D8E, 0x2DE8, 0x2E3E, 0x2E8C, 0x2ED3, 0x2F14, 0x2F4C, 0x2F78, 0x2F96, 0x2FA2, 0x2F97, 0x2F79, 
    0x2F4D, 0x2F18, 0x2EDB, 0x2E98, 0x2E52, 0x2E0B, 0x2DC5, 0x2D7F, 0x2D38, 0x2CF5, 0x2CBA, 0x2C8B, 0x2C6E, 0x09D6, 
    0x09D8, 0x09DF, 0x09EA, 0x09F8, 0x0A07, 0x0A19, 0x0A2B, 0x0A3C, 0x0A4E, 0x0A5E, 0x0A6B, 0x0A76, 0x0A7D, 0x0A7F, 
    0x0A7D, 0x0A78, 0x0A6F, 0x0A65, 0x0A58, 0x0A4A, 0x0A3A, 0x0A2B, 0x0A1B, 0x0A0B, 0x09FD, 0x09F0, 0x09E6, 0x09DD, 
    0x09D8, 0xEFAB, 0xEFAC, 0xEFB1, 0xEFB7, 0xEFBF, 0xEFC9, 0xEFD3, 0xEFDE, 0xEFE9, 0xEFF4, 0xEFFE, 0xF006, 0xF00C, 
    0xF010, 0xF012, 0xF011, 0xF00E, 0xF008, 0xF002, 0xEFFA, 0xEFF1, 0xEFE8, 0xEFDE, 0xEFD5, 0xEFCB, 0xEFC3, 0xEFBB, 
    0xEFB4, 0xEFAF, 0xEFAC, 0x10EA, 0x10E4, 0x10D2, 0x10B6, 0x1093, 0x106A, 0x103E, 0x100F, 0x0FE0, 0x0FB4, 0x0F8B, 
    0x0F68, 0x0F4C, 0x0F3A, 0x0F34, 0x0F39, 0x0F47, 0x0F5C, 0x0F78, 0x0F9A, 0x0FBF, 0x0FE6, 0x100F, 0x1038, 0x1060, 
    0x1085, 0x10A6, 0x10C2, 0x10D7, 0x10E5, 0x0000, 
};

JointIndex object_bai_Anim_0011C0JointIndices[] = {
    { 0x0000, 0x0003, 0x0002 },
    { 0x0021, 0x003F, 0x005D },
    { 0x007B, 0x0099, 0x00B7 },
    { 0x0000, 0x0000, 0x00D5 },
    { 0x00F3, 0x0111, 0x012F },
    { 0x014D, 0x016B, 0x0189 },
    { 0x0000, 0x0000, 0x01A7 },
    { 0x01C5, 0x01E3, 0x0201 },
    { 0x0000, 0x021F, 0x023D },
    { 0x0000, 0x025B, 0x0279 },
    { 0x0297, 0x02B5, 0x02D3 },
    { 0x0000, 0x0000, 0x02F1 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x030F, 0x032D, 0x034B },
    { 0x0369, 0x0387, 0x03A5 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x03C3 },
    { 0x03E1, 0x03FF, 0x041D },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x0000 },
};

AnimationHeader object_bai_Anim_0011C0 = { 
    { 30 }, object_bai_Anim_0011C0FrameData,
    object_bai_Anim_0011C0JointIndices, 3
};

Vtx object_baiVtx_0011D0[] = {
#include "assets/objects/object_bai/object_baiVtx_0011D0.vtx.inc"
};

Gfx object_bai_DL_0049C0[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_0073D8, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[200], 9, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 1, 0, 4, 1, 0, 0),
    gsSP2Triangles(3, 2, 5, 0, 3, 5, 4, 0),
    gsSP1Triangle(6, 7, 8, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_0074D8, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_baiVtx_0011D0[209], 15, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 7, 8, 0),
    gsSP2Triangles(9, 10, 11, 0, 0, 12, 3, 0),
    gsSP2Triangles(5, 4, 8, 0, 13, 10, 14, 0),
    gsSP1Triangle(13, 11, 10, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(object_bai_Tex_0075D8, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[224], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 6, 7, 4, 0),
    gsSP2Triangles(8, 9, 10, 0, 10, 11, 8, 0),
    gsSPEndDisplayList(),
};

Gfx object_bai_DL_004BA8[] = {
    gsSPMatrix(0x0D000340, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[143], 11, 0),
    gsSPMatrix(0x0D000380, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_007258, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[154], 2, 11),
    gsSP1Triangle(1, 11, 12, 0),
    gsSPVertex(&object_baiVtx_0011D0[156], 5, 11),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(11, 2, 12, 0, 3, 13, 4, 0),
    gsSP1Triangle(14, 7, 15, 0),
    gsSPVertex(&object_baiVtx_0011D0[161], 3, 11),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(11, 12, 8, 0, 9, 13, 1, 0),
    gsSPVertex(&object_baiVtx_0011D0[164], 2, 11),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(11, 5, 12, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_006A58, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_baiVtx_0011D0[166], 4, 11),
    gsSP2Triangles(11, 12, 0, 0, 6, 13, 0, 0),
    gsSP1Triangle(10, 0, 14, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_007258, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[170], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 4, 3, 0, 7, 8, 9, 0),
    gsSPVertex(&object_baiVtx_0011D0[180], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_baiVtx_0011D0[183], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_baiVtx_0011D0[186], 6, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_007398, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_baiVtx_0011D0[192], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
    gsSP2Triangles(4, 5, 6, 0, 6, 5, 7, 0),
    gsSPEndDisplayList(),
};

Gfx object_bai_DL_004EC0[] = {
    gsSPMatrix(0x0D000300, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[236], 8, 0),
    gsSPMatrix(0x0D000340, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_006A58, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_baiVtx_0011D0[244], 12, 8),
    gsSP2Triangles(0, 2, 8, 0, 4, 1, 9, 0),
    gsSP2Triangles(10, 4, 11, 0, 12, 13, 3, 0),
    gsSP2Triangles(5, 14, 15, 0, 2, 16, 17, 0),
    gsSP2Triangles(5, 18, 6, 0, 19, 3, 7, 0),
    gsSPVertex(&object_baiVtx_0011D0[256], 30, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(1, 6, 2, 0, 7, 8, 9, 0),
    gsSP2Triangles(10, 11, 12, 0, 13, 14, 15, 0),
    gsSP2Triangles(15, 16, 13, 0, 17, 5, 4, 0),
    gsSP2Triangles(18, 10, 12, 0, 19, 20, 21, 0),
    gsSP2Triangles(22, 23, 24, 0, 25, 21, 20, 0),
    gsSP2Triangles(26, 22, 24, 0, 27, 28, 29, 0),
    gsSPEndDisplayList(),
};

Gfx object_bai_DL_004FF0[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_0072D8, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[286], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
    gsSP2Triangles(5, 6, 7, 0, 8, 9, 10, 0),
    gsSP2Triangles(10, 9, 11, 0, 6, 12, 13, 0),
    gsSP2Triangles(9, 14, 11, 0, 15, 16, 17, 0),
    gsSP2Triangles(18, 19, 20, 0, 6, 5, 12, 0),
    gsSP2Triangles(1, 0, 4, 0, 21, 22, 23, 0),
    gsSP2Triangles(24, 21, 25, 0, 23, 25, 21, 0),
    gsSP2Triangles(26, 22, 21, 0, 27, 28, 29, 0),
    gsSP2Triangles(0, 2, 30, 0, 16, 15, 31, 0),
    gsSPVertex(&object_baiVtx_0011D0[318], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSPEndDisplayList(),
};

Gfx object_bai_DL_0050F8[] = {
    gsSPMatrix(0x0D000280, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[324], 11, 0),
    gsSPMatrix(0x0D0002C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_007258, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[335], 2, 11),
    gsSP1Triangle(11, 12, 1, 0),
    gsSPVertex(&object_baiVtx_0011D0[337], 5, 11),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(11, 2, 12, 0, 4, 13, 3, 0),
    gsSP1Triangle(14, 7, 15, 0),
    gsSPVertex(&object_baiVtx_0011D0[342], 3, 11),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(8, 11, 12, 0, 1, 13, 9, 0),
    gsSPVertex(&object_baiVtx_0011D0[345], 2, 11),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(11, 5, 12, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_006A58, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_baiVtx_0011D0[347], 4, 11),
    gsSP2Triangles(0, 11, 6, 0, 0, 12, 13, 0),
    gsSP1Triangle(14, 0, 10, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_007258, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[351], 10, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 4, 6, 0, 7, 8, 9, 0),
    gsSPVertex(&object_baiVtx_0011D0[361], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_baiVtx_0011D0[364], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_baiVtx_0011D0[367], 6, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_007398, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_baiVtx_0011D0[373], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 5, 4, 0),
    gsSPEndDisplayList(),
};

Gfx object_bai_DL_005410[] = {
    gsSPMatrix(0x0D000240, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[381], 8, 0),
    gsSPMatrix(0x0D000280, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_006A58, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_baiVtx_0011D0[389], 12, 8),
    gsSP2Triangles(8, 0, 2, 0, 9, 3, 4, 0),
    gsSP2Triangles(10, 4, 11, 0, 1, 12, 13, 0),
    gsSP2Triangles(14, 15, 5, 0, 16, 17, 0, 0),
    gsSP2Triangles(6, 18, 5, 0, 7, 1, 19, 0),
    gsSPVertex(&object_baiVtx_0011D0[401], 30, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 8, 9, 0),
    gsSP2Triangles(10, 11, 12, 0, 12, 13, 10, 0),
    gsSP2Triangles(7, 9, 14, 0, 15, 16, 17, 0),
    gsSP2Triangles(18, 19, 20, 0, 16, 15, 21, 0),
    gsSP2Triangles(18, 20, 22, 0, 23, 24, 25, 0),
    gsSP2Triangles(26, 27, 28, 0, 27, 26, 29, 0),
    gsSPEndDisplayList(),
};

Gfx object_bai_DL_005540[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_0072D8, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[431], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 2, 0),
    gsSP2Triangles(5, 6, 7, 0, 8, 9, 10, 0),
    gsSP2Triangles(11, 9, 8, 0, 12, 13, 6, 0),
    gsSP2Triangles(11, 14, 9, 0, 15, 16, 17, 0),
    gsSP2Triangles(18, 19, 20, 0, 13, 7, 6, 0),
    gsSP2Triangles(3, 2, 1, 0, 21, 22, 23, 0),
    gsSP2Triangles(24, 23, 25, 0, 23, 24, 21, 0),
    gsSP2Triangles(23, 22, 26, 0, 27, 28, 29, 0),
    gsSP2Triangles(30, 0, 2, 0, 31, 17, 16, 0),
    gsSPVertex(&object_baiVtx_0011D0[463], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSPEndDisplayList(),
};

Gfx object_bai_DL_005648[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_006A58, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[469], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(4, 5, 6, 0, 6, 7, 4, 0),
    gsSPVertex(&object_baiVtx_0011D0[477], 6, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSPVertex(&object_baiVtx_0011D0[483], 7, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP1Triangle(4, 5, 6, 0),
    gsSPVertex(&object_baiVtx_0011D0[490], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_baiVtx_0011D0[493], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_baiVtx_0011D0[496], 11, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 0, 4, 0),
    gsSP2Triangles(5, 6, 7, 0, 8, 9, 10, 0),
    gsSP1Triangle(2, 4, 0, 0),
    gsSPVertex(&object_baiVtx_0011D0[507], 6, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSPVertex(&object_baiVtx_0011D0[513], 4, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
    gsSPVertex(&object_baiVtx_0011D0[517], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_baiVtx_0011D0[520], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_baiVtx_0011D0[523], 7, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP1Triangle(4, 5, 6, 0),
    gsSPVertex(&object_baiVtx_0011D0[530], 4, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSPVertex(&object_baiVtx_0011D0[534], 5, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP1Triangle(3, 2, 4, 0),
    gsSPVertex(&object_baiVtx_0011D0[539], 13, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP1Triangle(11, 12, 9, 0),
    gsSPVertex(&object_baiVtx_0011D0[552], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_baiVtx_0011D0[555], 8, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 4, 0, 4, 3, 6, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_0074D8, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[563], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 4, 3, 0, 5, 4, 7, 0),
    gsSP2Triangles(8, 4, 6, 0, 9, 4, 8, 0),
    gsSP2Triangles(10, 4, 9, 0, 11, 12, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_007318, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 3, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[577], 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_baiVtx_0011D0[580], 7, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP1Triangle(6, 3, 5, 0),
    gsSPVertex(&object_baiVtx_0011D0[587], 3, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPVertex(&object_baiVtx_0011D0[590], 7, 0),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP1Triangle(3, 5, 6, 0),
    gsSPEndDisplayList(),
};

Gfx object_bai_DL_005A30[] = {
    gsSPMatrix(0x0D0001C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_baiVtx_0011D0, 9, 0),
    gsSPMatrix(0x0D000200, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_0072D8, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_baiVtx_0011D0[9], 13, 9),
    gsSP2Triangles(9, 1, 0, 0, 10, 11, 0, 0),
    gsSP2Triangles(0, 3, 12, 0, 13, 14, 4, 0),
    gsSP2Triangles(4, 5, 15, 0, 6, 7, 16, 0),
    gsSP2Triangles(17, 18, 6, 0, 19, 8, 2, 0),
    gsSP1Triangle(2, 20, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_006A58, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[22], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(4, 6, 5, 0, 7, 8, 9, 0),
    gsSP2Triangles(10, 11, 12, 0, 10, 13, 11, 0),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 19, 18, 0, 16, 21, 14, 0),
    gsSP2Triangles(22, 18, 17, 0, 17, 23, 22, 0),
    gsSP2Triangles(9, 24, 7, 0, 12, 25, 10, 0),
    gsSP2Triangles(26, 27, 28, 0, 29, 26, 28, 0),
    gsSPVertex(&object_baiVtx_0011D0[52], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(4, 6, 5, 0, 5, 7, 8, 0),
    gsSP2Triangles(5, 6, 7, 0, 9, 10, 11, 0),
    gsSP2Triangles(9, 12, 10, 0, 13, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 17, 16, 15, 0),
    gsSP2Triangles(15, 16, 13, 0, 19, 20, 21, 0),
    gsSP2Triangles(22, 23, 24, 0, 24, 25, 22, 0),
    gsSP2Triangles(26, 27, 28, 0, 29, 26, 28, 0),
    gsSP1Triangle(28, 30, 29, 0),
    gsSPVertex(&object_baiVtx_0011D0[83], 11, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 8, 9, 0),
    gsSP1Triangle(7, 10, 8, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_007258, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[94], 25, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 7, 9, 8, 0),
    gsSP2Triangles(7, 6, 10, 0, 11, 12, 13, 0),
    gsSP2Triangles(11, 14, 12, 0, 15, 13, 12, 0),
    gsSP2Triangles(16, 17, 18, 0, 19, 20, 21, 0),
    gsSP1Triangle(22, 23, 24, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_007298, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_baiVtx_0011D0[119], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
    gsSP2Triangles(3, 4, 0, 0, 5, 4, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_0072D8, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_baiVtx_0011D0[125], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(3, 6, 4, 0, 3, 7, 6, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_007318, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 3, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[137], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSPEndDisplayList(),
};

Gfx object_bai_DL_005EA8[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_0073D8, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[843], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 5, 0, 2, 8, 0, 0),
    gsSP2Triangles(4, 3, 9, 0, 5, 7, 3, 0),
    gsSP2Triangles(5, 10, 6, 0, 11, 12, 13, 0),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(18, 17, 20, 0, 21, 22, 23, 0),
    gsSP2Triangles(21, 23, 24, 0, 25, 23, 26, 0),
    gsSP2Triangles(26, 23, 22, 0, 27, 28, 29, 0),
    gsSPVertex(&object_baiVtx_0011D0[873], 22, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 8, 9, 0),
    gsSP2Triangles(10, 11, 12, 0, 10, 12, 13, 0),
    gsSP2Triangles(14, 15, 16, 0, 14, 16, 17, 0),
    gsSP2Triangles(18, 19, 20, 0, 19, 21, 20, 0),
    gsSPEndDisplayList(),
};

Gfx object_bai_DL_005FC8[] = {
    gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[691], 10, 0),
    gsSPMatrix(0x0D000100, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_0073D8, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_baiVtx_0011D0[701], 13, 10),
    gsSP2Triangles(10, 11, 0, 0, 0, 2, 12, 0),
    gsSP2Triangles(13, 3, 4, 0, 14, 4, 15, 0),
    gsSP2Triangles(16, 17, 6, 0, 8, 18, 6, 0),
    gsSP2Triangles(1, 19, 20, 0, 1, 21, 9, 0),
    gsSP1Triangle(7, 22, 5, 0),
    gsSPVertex(&object_baiVtx_0011D0[714], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSPEndDisplayList(),
};

Gfx object_bai_DL_0060D0[] = {
    gsSPMatrix(0x0D000100, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[633], 10, 0),
    gsSPMatrix(0x0D000140, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_006A58, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_baiVtx_0011D0[643], 14, 10),
    gsSP2Triangles(10, 0, 11, 0, 2, 12, 13, 0),
    gsSP2Triangles(5, 0, 14, 0, 6, 15, 16, 0),
    gsSP2Triangles(17, 18, 6, 0, 3, 19, 1, 0),
    gsSP2Triangles(20, 21, 1, 0, 22, 2, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_0072D8, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_baiVtx_0011D0[657], 2, 10),
    gsSP2Triangles(10, 4, 8, 0, 11, 9, 7, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_006A58, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_baiVtx_0011D0[659], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 4, 3, 9, 0),
    gsSP2Triangles(10, 11, 12, 0, 13, 14, 15, 0),
    gsSP2Triangles(0, 16, 1, 0, 17, 11, 10, 0),
    gsSP2Triangles(18, 13, 15, 0, 19, 20, 21, 0),
    gsSP2Triangles(8, 22, 6, 0, 23, 19, 21, 0),
    gsSP2Triangles(24, 25, 26, 0, 27, 28, 29, 0),
    gsSP2Triangles(26, 25, 30, 0, 29, 31, 27, 0),
    gsSPEndDisplayList(),
};

Gfx object_bai_DL_0062F8[] = {
    gsSPMatrix(0x0D000140, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[597], 9, 0),
    gsSPMatrix(0x0D000180, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_0074D8, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_baiVtx_0011D0[606], 14, 9),
    gsSP2Triangles(9, 10, 0, 0, 2, 11, 0, 0),
    gsSP2Triangles(1, 12, 13, 0, 14, 15, 4, 0),
    gsSP2Triangles(16, 5, 17, 0, 18, 3, 6, 0),
    gsSP2Triangles(19, 6, 20, 0, 4, 7, 21, 0),
    gsSP1Triangle(22, 8, 1, 0),
    gsSPVertex(&object_baiVtx_0011D0[620], 13, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 8, 7, 9, 0),
    gsSP1Triangle(10, 11, 12, 0),
    gsSPEndDisplayList(),
};

Gfx object_bai_DL_006410[] = {
    gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[814], 10, 0),
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_0073D8, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_baiVtx_0011D0[824], 13, 10),
    gsSP2Triangles(0, 10, 11, 0, 12, 2, 0, 0),
    gsSP2Triangles(4, 3, 13, 0, 14, 4, 15, 0),
    gsSP2Triangles(6, 16, 17, 0, 6, 18, 8, 0),
    gsSP2Triangles(19, 20, 1, 0, 9, 21, 1, 0),
    gsSP1Triangle(5, 22, 7, 0),
    gsSPVertex(&object_baiVtx_0011D0[837], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSPEndDisplayList(),
};

Gfx object_bai_DL_006518[] = {
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[756], 10, 0),
    gsSPMatrix(0x0D000080, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_006A58, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_baiVtx_0011D0[766], 14, 10),
    gsSP2Triangles(10, 0, 11, 0, 12, 13, 2, 0),
    gsSP2Triangles(14, 0, 5, 0, 15, 16, 6, 0),
    gsSP2Triangles(6, 17, 18, 0, 1, 19, 3, 0),
    gsSP2Triangles(1, 20, 21, 0, 22, 2, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_0072D8, G_IM_FMT_CI, G_IM_SIZ_8b, 8, 8, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 3, 3, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_baiVtx_0011D0[780], 2, 10),
    gsSP2Triangles(8, 4, 10, 0, 7, 9, 11, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_006A58, G_IM_FMT_CI, G_IM_SIZ_8b, 32, 64, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_baiVtx_0011D0[782], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 5, 4, 0),
    gsSP2Triangles(10, 11, 12, 0, 13, 14, 15, 0),
    gsSP2Triangles(1, 16, 2, 0, 12, 11, 17, 0),
    gsSP2Triangles(13, 15, 18, 0, 19, 20, 21, 0),
    gsSP2Triangles(8, 22, 6, 0, 19, 21, 23, 0),
    gsSP2Triangles(24, 25, 26, 0, 27, 28, 29, 0),
    gsSP2Triangles(30, 25, 24, 0, 29, 31, 27, 0),
    gsSPEndDisplayList(),
};

Gfx object_bai_DL_006740[] = {
    gsSPMatrix(0x0D000080, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_baiVtx_0011D0[720], 9, 0),
    gsSPMatrix(0x0D0000C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal256(object_bai_TLUT_006858),
    gsDPLoadTextureBlock(object_bai_Tex_0074D8, G_IM_FMT_CI, G_IM_SIZ_8b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_baiVtx_0011D0[729], 14, 9),
    gsSP2Triangles(0, 9, 10, 0, 0, 11, 2, 0),
    gsSP2Triangles(4, 12, 13, 0, 14, 5, 15, 0),
    gsSP2Triangles(6, 3, 16, 0, 17, 6, 18, 0),
    gsSP2Triangles(19, 7, 4, 0, 1, 8, 20, 0),
    gsSP1Triangle(21, 22, 1, 0),
    gsSPVertex(&object_baiVtx_0011D0[743], 13, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 7, 6, 0),
    gsSP1Triangle(10, 11, 12, 0),
    gsSPEndDisplayList(),
};

u64 object_bai_TLUT_006858[] = {
#include "assets/objects/object_bai/tlut_006858.rgba16.inc.c"
};

u64 object_bai_Tex_006A58[] = {
#include "assets/objects/object_bai/tex_006A58.ci8.inc.c"
};

u64 object_bai_Tex_007258[] = {
#include "assets/objects/object_bai/tex_007258.ci8.inc.c"
};

u64 object_bai_Tex_007298[] = {
#include "assets/objects/object_bai/tex_007298.ci8.inc.c"
};

u64 object_bai_Tex_0072D8[] = {
#include "assets/objects/object_bai/tex_0072D8.ci8.inc.c"
};

u64 object_bai_Tex_007318[] = {
#include "assets/objects/object_bai/tex_007318.ci8.inc.c"
};

u64 object_bai_Tex_007398[] = {
#include "assets/objects/object_bai/tex_007398.ci8.inc.c"
};

u64 object_bai_Tex_0073D8[] = {
#include "assets/objects/object_bai/tex_0073D8.ci8.inc.c"
};

u64 object_bai_Tex_0074D8[] = {
#include "assets/objects/object_bai/tex_0074D8.ci8.inc.c"
};

u64 object_bai_Tex_0075D8[] = {
#include "assets/objects/object_bai/tex_0075D8.rgba16.inc.c"
};

StandardLimb object_bai_Standardlimb_0077D8 = { 
    { 0, 4100, 100 }, OBJECT_BAI_LIMB_02 - 1, LIMB_DONE,
    object_bai_DL_005EA8
};

StandardLimb object_bai_Standardlimb_0077E4 = { 
    { 950, 0, 300 }, OBJECT_BAI_LIMB_03 - 1, OBJECT_BAI_LIMB_05 - 1,
    object_bai_DL_006410
};

StandardLimb object_bai_Standardlimb_0077F0 = { 
    { 1200, 0, 0 }, OBJECT_BAI_LIMB_04 - 1, LIMB_DONE,
    object_bai_DL_006518
};

StandardLimb object_bai_Standardlimb_0077FC = { 
    { 1500, 0, 0 }, LIMB_DONE, LIMB_DONE,
    object_bai_DL_006740
};

StandardLimb object_bai_Standardlimb_007808 = { 
    { 950, 0, -300 }, OBJECT_BAI_LIMB_06 - 1, OBJECT_BAI_LIMB_08 - 1,
    object_bai_DL_005FC8
};

StandardLimb object_bai_Standardlimb_007814 = { 
    { 1200, 0, 0 }, OBJECT_BAI_LIMB_07 - 1, LIMB_DONE,
    object_bai_DL_0060D0
};

StandardLimb object_bai_Standardlimb_007820 = { 
    { 1500, 0, 0 }, LIMB_DONE, LIMB_DONE,
    object_bai_DL_0062F8
};

StandardLimb object_bai_Standardlimb_00782C = { 
    { 0, 0, 0 }, OBJECT_BAI_LIMB_09 - 1, LIMB_DONE,
    object_bai_DL_005648
};

StandardLimb object_bai_Standardlimb_007838 = { 
    { 1250, 0, 0 }, LIMB_DONE, OBJECT_BAI_LIMB_0A - 1,
    object_bai_DL_005A30
};

StandardLimb object_bai_Standardlimb_007844 = { 
    { 950, -200, 550 }, OBJECT_BAI_LIMB_0B - 1, OBJECT_BAI_LIMB_0E - 1,
    object_bai_DL_005540
};

StandardLimb object_bai_Standardlimb_007850 = { 
    { 1150, 0, 0 }, OBJECT_BAI_LIMB_0C - 1, LIMB_DONE,
    NULL
};

StandardLimb object_bai_Standardlimb_00785C = { 
    { 0, 0, 0 }, LIMB_DONE, OBJECT_BAI_LIMB_0D - 1,
    object_bai_DL_005410
};

StandardLimb object_bai_Standardlimb_007868 = { 
    { 1050, 0, 0 }, LIMB_DONE, LIMB_DONE,
    object_bai_DL_0050F8
};

StandardLimb object_bai_Standardlimb_007874 = { 
    { 950, -200, -750 }, OBJECT_BAI_LIMB_0F - 1, LIMB_DONE,
    NULL
};

StandardLimb object_bai_Standardlimb_007880 = { 
    { 0, 0, 0 }, LIMB_DONE, OBJECT_BAI_LIMB_10 - 1,
    object_bai_DL_004FF0
};

StandardLimb object_bai_Standardlimb_00788C = { 
    { 950, 0, 0 }, OBJECT_BAI_LIMB_11 - 1, LIMB_DONE,
    object_bai_DL_004EC0
};

StandardLimb object_bai_Standardlimb_007898 = { 
    { 1100, 0, 0 }, OBJECT_BAI_LIMB_12 - 1, LIMB_DONE,
    NULL
};

StandardLimb object_bai_Standardlimb_0078A4 = { 
    { 0, 0, 0 }, LIMB_DONE, OBJECT_BAI_LIMB_13 - 1,
    object_bai_DL_004BA8
};

StandardLimb object_bai_Standardlimb_0078B0 = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    object_bai_DL_0049C0
};

void* object_bai_Skel_007908Limbs[] = {
    &object_bai_Standardlimb_0077D8, /* OBJECT_BAI_LIMB_01 */
    &object_bai_Standardlimb_0077E4, /* OBJECT_BAI_LIMB_02 */
    &object_bai_Standardlimb_0077F0, /* OBJECT_BAI_LIMB_03 */
    &object_bai_Standardlimb_0077FC, /* OBJECT_BAI_LIMB_04 */
    &object_bai_Standardlimb_007808, /* OBJECT_BAI_LIMB_05 */
    &object_bai_Standardlimb_007814, /* OBJECT_BAI_LIMB_06 */
    &object_bai_Standardlimb_007820, /* OBJECT_BAI_LIMB_07 */
    &object_bai_Standardlimb_00782C, /* OBJECT_BAI_LIMB_08 */
    &object_bai_Standardlimb_007838, /* OBJECT_BAI_LIMB_09 */
    &object_bai_Standardlimb_007844, /* OBJECT_BAI_LIMB_0A */
    &object_bai_Standardlimb_007850, /* OBJECT_BAI_LIMB_0B */
    &object_bai_Standardlimb_00785C, /* OBJECT_BAI_LIMB_0C */
    &object_bai_Standardlimb_007868, /* OBJECT_BAI_LIMB_0D */
    &object_bai_Standardlimb_007874, /* OBJECT_BAI_LIMB_0E */
    &object_bai_Standardlimb_007880, /* OBJECT_BAI_LIMB_0F */
    &object_bai_Standardlimb_00788C, /* OBJECT_BAI_LIMB_10 */
    &object_bai_Standardlimb_007898, /* OBJECT_BAI_LIMB_11 */
    &object_bai_Standardlimb_0078A4, /* OBJECT_BAI_LIMB_12 */
    &object_bai_Standardlimb_0078B0, /* OBJECT_BAI_LIMB_13 */
};

FlexSkeletonHeader object_bai_Skel_007908 = { 
    { object_bai_Skel_007908Limbs, ARRAY_COUNT(object_bai_Skel_007908Limbs) }, 16
};

u8 object_bai_possiblePadding_007914[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 object_bai_Anim_008198FrameData[] = {
    0x0000, 0x1004, 0x0064, 0x1004, 0x1003, 0x1002, 0x0FFF, 0x0FFB, 0x0FF7, 0x0FF3, 0x0FEE, 0x0FE9, 0x0FE5, 0x0FE0, 
    0x0FDD, 0x0FDA, 0x0FD8, 0x0FD8, 0x0FD8, 0x0FD9, 0x0FDC, 0x0FDF, 0x0FE2, 0x0FE6, 0x0FEA, 0x0FEE, 0x0FF2, 0x0FF6, 
    0x0FFA, 0x0FFD, 0x1000, 0x1002, 0x1004, 0xC000, 0xC001, 0xC002, 0xC004, 0xC005, 0xC006, 0xC007, 0xC008, 0xC008, 
    0xC007, 0xC006, 0xC004, 0xC003, 0xC001, 0xC000, 0xBFFF, 0xBFFE, 0xBFFC, 0xBFFB, 0xBFFA, 0xBFFA, 0xBFF9, 0xBFF9, 
    0xBFF9, 0xBFFA, 0xBFFB, 0xBFFC, 0xBFFD, 0xBFFE, 0xBFFF, 0x02C5, 0x02C8, 0x02CE, 0x02D8, 0x02E3, 0x02EE, 0x02FA, 
    0x0304, 0x030E, 0x0319, 0x0325, 0x0331, 0x033A, 0x0340, 0x0342, 0x0340, 0x033A, 0x0332, 0x0328, 0x031D, 0x0312, 
    0x0307, 0x02FE, 0x02F6, 0x02ED, 0x02E3, 0x02DA, 0x02D1, 0x02CB, 0x02C7, 0xC000, 0xC00F, 0xC022, 0xC036, 0xC049, 
    0xC059, 0xC064, 0xC069, 0xC064, 0xC059, 0xC049, 0xC036, 0xC022, 0xC00F, 0xC000, 0xBFF2, 0xBFE3, 0xBFD3, 0xBFC4, 
    0xBFB7, 0xBFAD, 0xBFA6, 0xBFA3, 0xBFA6, 0xBFAD, 0xBFB7, 0xBFC4, 0xBFD3, 0xBFE3, 0xBFF2, 0xFFEC, 0xFFE7, 0xFFE2, 
    0xFFDB, 0xFFD5, 0xFFCE, 0xFFC9, 0xFFC5, 0xFFC5, 0xFFC7, 0xFFCB, 0xFFD1, 0xFFD7, 0xFFDE, 0xFFE4, 0xFFE9, 0xFFEF, 
    0xFFF5, 0xFFFB, 0x0000, 0x0004, 0x0006, 0x0007, 0x0006, 0x0003, 0x0000, 0xFFFC, 0xFFF8, 0xFFF4, 0xFFF0, 0x005F, 
    0x0074, 0x008D, 0x00A7, 0x00C0, 0x00D5, 0x00E3, 0x00E8, 0x00E3, 0x00D4, 0x00BE, 0x00A5, 0x008B, 0x0073, 0x005F, 
    0x004D, 0x0039, 0x0025, 0x0012, 0x0000, 0xFFF3, 0xFFE9, 0xFFE6, 0xFFE9, 0xFFF2, 0x0000, 0x0011, 0x0024, 0x0039, 
    0x004D, 0xF3B9, 0xF3B2, 0xF38D, 0xF350, 0xF301, 0xF2A4, 0xF23E, 0xF1D5, 0xF16A, 0xF100, 0xF09D, 0xF045, 0xEFFF, 
    0xEFCE, 0xEFB9, 0xEFBD, 0xEFD4, 0xEFFC, 0xF032, 0xF074, 0xF0C0, 0xF112, 0xF169, 0xF1C5, 0xF225, 0xF284, 0xF2DE, 
    0xF330, 0xF373, 0xF3A2, 0x0F4F, 0x0F56, 0x0F88, 0x0FDE, 0x1051, 0x10DA, 0x1173, 0x1216, 0x12BD, 0x135D, 0x13F1, 
    0x1472, 0x14D8, 0x151F, 0x1540, 0x153E, 0x1523, 0x14F0, 0x14A8, 0x144D, 0x13E2, 0x1368, 0x12E2, 0x1253, 0x11C0, 
    0x112F, 0x10A4, 0x1027, 0x0FBF, 0x0F74, 0xFF7B, 0xFF7F, 0xFF87, 0xFF95, 0xFFA6, 0xFFBA, 0xFFD0, 0xFFE7, 0xFFFE, 
    0x0014, 0x0028, 0x0039, 0x0047, 0x0050, 0x0053, 0x0050, 0x004A, 0x003F, 0x0031, 0x0021, 0x000F, 0xFFFB, 0xFFE7, 
    0xFFD3, 0xFFC0, 0xFFAD, 0xFF9D, 0xFF8F, 0xFF85, 0xFF7E, 0xF09B, 0xF09B, 0xF09B, 0xF09B, 0xF09B, 0xF09B, 0xF09B, 
    0xF09B, 0xF09B, 0xF09B, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09A, 0xF09B, 
    0xF09B, 0xF09B, 0xF09B, 0xF09B, 0xF09B, 0xF09B, 0xF09B, 0xF09B, 0xF09B, 0xBA7A, 0xBA71, 0xBA5A, 0xBA35, 0xBA06, 
    0xB9D0, 0xB994, 0xB956, 0xB918, 0xB8DD, 0xB8A6, 0xB877, 0xB853, 0xB83B, 0xB832, 0xB839, 0xB84B, 0xB868, 0xB88E, 
    0xB8BA, 0xB8EB, 0xB920, 0xB956, 0xB98D, 0xB9C1, 0xB9F3, 0xBA1F, 0xBA44, 0xBA61, 0xBA73, 0x0014, 0x0010, 0x000B, 
    0x0006, 0x0000, 0xFFFB, 0xFFF7, 0xFFF5, 0xFFF6, 0xFFFA, 0x0000, 0x0008, 0x000F, 0x0017, 0x001D, 0x0022, 0x0027, 
    0x002D, 0x0031, 0x0035, 0x0037, 0x0038, 0x0037, 0x0035, 0x0031, 0x002C, 0x0027, 0x0022, 0x001D, 0x0018, 0xFFA0, 
    0xFFB4, 0xFFCD, 0xFFE7, 0x0000, 0x0015, 0x0023, 0x0029, 0x0023, 0x0014, 0xFFFF, 0xFFE6, 0xFFCC, 0xFFB4, 0xFFA0, 
    0xFF8E, 0xFF7A, 0xFF66, 0xFF52, 0xFF41, 0xFF33, 0xFF2A, 0xFF26, 0xFF29, 0xFF32, 0xFF40, 0xFF51, 0xFF65, 0xFF79, 
    0xFF8D, 0xF3B9, 0xF39D, 0xF35F, 0xF309, 0xF2A3, 0xF235, 0xF1C6, 0xF15D, 0xF0FA, 0xF09F, 0xF04F, 0xF00D, 0xEFDC, 
    0xEFBE, 0xEFB9, 0xEFCB, 0xEFF2, 0xF02B, 0xF071, 0xF0C2, 0xF11B, 0xF178, 0xF1D5, 0xF231, 0xF28B, 0xF2E0, 0xF32C, 
    0xF36B, 0xF39B, 0xF3B6, 0x0F4E, 0x0F7B, 0x0FDA, 0x105C, 0x10F7, 0x119E, 0x1248, 0x12EC, 0x1383, 0x1409, 0x147A, 
    0x14D5, 0x1516, 0x153B, 0x1540, 0x1525, 0x14EE, 0x149E, 0x143A, 0x13C4, 0x1341, 0x12B5, 0x1225, 0x1195, 0x110C, 
    0x108C, 0x101A, 0x0FBD, 0x0F78, 0x0F51, 0x0061, 0x005E, 0x0055, 0x0047, 0x0035, 0x0020, 0x0009, 0xFFF2, 0xFFDA, 
    0xFFC3, 0xFFAE, 0xFF9D, 0xFF8F, 0xFF86, 0xFF82, 0xFF85, 0xFF8C, 0xFF97, 0xFFA5, 0xFFB6, 0xFFC9, 0xFFDD, 0xFFF2, 
    0x0006, 0x001A, 0x002D, 0x003E, 0x004C, 0x0057, 0x005E, 0x0ED4, 0x0ED4, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 
    0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 
    0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED3, 0x0ED4, 0xBA6F, 0xBA65, 0xBA4C, 0xBA25, 0xB9F3, 
    0xB9B8, 0xB979, 0xB936, 0xB8F4, 0xB8B4, 0xB879, 0xB847, 0xB820, 0xB807, 0xB7FE, 0xB805, 0xB818, 0xB837, 0xB85F, 
    0xB88F, 0xB8C3, 0xB8FC, 0xB936, 0xB970, 0xB9A9, 0xB9DE, 0xBA0D, 0xBA35, 0xBA54, 0xBA68, 0x8826, 0x882C, 0x883C, 
    0x8855, 0x8875, 0x889A, 0x88C2, 0x88EC, 0x8916, 0x893F, 0x8964, 0x8984, 0x899C, 0x89AD, 0x89B2, 0x89AE, 0x89A1, 
    0x898E, 0x8974, 0x8956, 0x8935, 0x8911, 0x88EC, 0x88C7, 0x88A3, 0x8882, 0x8864, 0x884B, 0x8837, 0x882B, 0x0C0F, 
    0x0C02, 0x0BDE, 0x0BA5, 0x0B5E, 0x0B0A, 0x0AAE, 0x0A4F, 0x09EF, 0x0994, 0x0940, 0x08F8, 0x08C0, 0x089B, 0x088E, 
    0x0898, 0x08B5, 0x08E1, 0x091B, 0x095E, 0x09AA, 0x09FB, 0x0A4F, 0x0AA3, 0x0AF4, 0x0B3F, 0x0B83, 0x0BBD, 0x0BE9, 
    0x0C05, 0x0F39, 0x0F3A, 0x0F3E, 0x0F43, 0x0F49, 0x0F51, 0x0F59, 0x0F61, 0x0F69, 0x0F70, 0x0F77, 0x0F7B, 0x0F7F, 
    0x0F80, 0x0F7F, 0x0F7D, 0x0F7A, 0x0F76, 0x0F71, 0x0F6C, 0x0F66, 0x0F60, 0x0F5A, 0x0F54, 0x0F4E, 0x0F48, 0x0F43, 
    0x0F3F, 0x0F3C, 0x0F3A, 0xF3C2, 0xF3C3, 0xF3C7, 0xF3CD, 0xF3D5, 0xF3DE, 0xF3E9, 0xF3F3, 0xF3FE, 0xF408, 0xF411, 
    0xF418, 0xF41D, 0xF41E, 0xF41D, 0xF41A, 0xF416, 0xF410, 0xF409, 0xF402, 0xF3FA, 0xF3F2, 0xF3EA, 0xF3E2, 0xF3DB, 
    0xF3D4, 0xF3CE, 0xF3C9, 0xF3C5, 0xF3C3, 0x8147, 0x8143, 0x8137, 0x8125, 0x810F, 0x80F5, 0x80D9, 0x80BD, 0x80A2, 
    0x8089, 0x8074, 0x8063, 0x8058, 0x8054, 0x8056, 0x805D, 0x8067, 0x8075, 0x8085, 0x8098, 0x80AC, 0x80C1, 0x80D6, 
    0x80EB, 0x8100, 0x8113, 0x8124, 0x8132, 0x813D, 0x8144, 0xF30B, 0xF2FD, 0xF2D4, 0xF295, 0xF245, 0xF1E7, 0xF181, 
    0xF116, 0xF0AC, 0xF046, 0xEFE8, 0xEF98, 0xEF59, 0xEF30, 0xEF22, 0xEF2D, 0xEF4D, 0xEF7E, 0xEFBE, 0xF00A, 0xF05F, 
    0xF0B9, 0xF116, 0xF174, 0xF1CE, 0xF223, 0xF26F, 0xF2AF, 0xF2E0, 0xF300, 0x00ED, 0x00EA, 0x00E2, 0x00D5, 0x00C4, 
    0x00B0, 0x009A, 0x0083, 0x006B, 0x0054, 0x003E, 0x002A, 0x0019, 0x000C, 0x0003, 0x0000, 0x0003, 0x000C, 0x0019, 
    0x002A, 0x003E, 0x0054, 0x006B, 0x0083, 0x009A, 0x00B0, 0x00C4, 0x00D5, 0x00E2, 0x00EA, 0x0897, 0x0897, 0x0897, 
    0x0898, 0x0899, 0x089A, 0x089B, 0x089C, 0x089E, 0x089F, 0x08A0, 0x08A1, 0x08A2, 0x08A3, 0x08A3, 0x08A3, 0x08A3, 
    0x08A3, 0x08A2, 0x08A1, 0x08A0, 0x089F, 0x089E, 0x089C, 0x089B, 0x089A, 0x0899, 0x0898, 0x0897, 0x0897, 0x046B, 
    0x045C, 0x0434, 0x03F5, 0x03A4, 0x0346, 0x02DD, 0x026E, 0x01FD, 0x018E, 0x0125, 0x00C6, 0x0076, 0x0037, 0x000E, 
    0x0000, 0x000E, 0x0037, 0x0076, 0x00C6, 0x0125, 0x018E, 0x01FD, 0x026E, 0x02DD, 0x0346, 0x03A4, 0x03F5, 0x0434, 
    0x045C, 0x01D1, 0x01D6, 0x01D2, 0x01C6, 0x01B4, 0x019C, 0x0180, 0x0160, 0x0139, 0x010C, 0x00DD, 0x00AF, 0x0086, 
    0x0065, 0x0050, 0x0046, 0x0043, 0x0045, 0x004E, 0x005D, 0x0072, 0x008C, 0x00AB, 0x00D0, 0x00FA, 0x0127, 0x0154, 
    0x017F, 0x01A3, 0x01C0, 0x74C3, 0x74B8, 0x749E, 0x747A, 0x744E, 0x741E, 0x73ED, 0x73BD, 0x738F, 0x7363, 0x733B, 
    0x7318, 0x72FD, 0x72ED, 0x72E8, 0x72F0, 0x7303, 0x731E, 0x7341, 0x7368, 0x7393, 0x73BE, 0x73EA, 0x7413, 0x743C, 
    0x7462, 0x7484, 0x74A0, 0x74B5, 0x74C1, 0x0C2A, 0x0C3E, 0x0C5E, 0x0C87, 0x0CB4, 0x0CE3, 0x0D10, 0x0D37, 0x0D57, 
    0x0D6C, 0x0D7A, 0x0D80, 0x0D80, 0x0D79, 0x0D6E, 0x0D5D, 0x0D43, 0x0D24, 0x0D01, 0x0CDC, 0x0CB6, 0x0C92, 0x0C70, 
    0x0C54, 0x0C3D, 0x0C2C, 0x0C20, 0x0C1A, 0x0C1A, 0x0C1F, 0x2D30, 0x2D59, 0x2DA1, 0x2DFF, 0x2E6B, 0x2EDD, 0x2F4E, 
    0x2FB5, 0x300D, 0x3056, 0x308F, 0x30B7, 0x30CE, 0x30D3, 0x30C6, 0x30A4, 0x306D, 0x3026, 0x2FD2, 0x2F77, 0x2F17, 
    0x2EB8, 0x2E5E, 0x2E0C, 0x2DC4, 0x2D88, 0x2D59, 0x2D37, 0x2D24, 0x2D21, 0x0931, 0x0935, 0x0941, 0x0953, 0x096A, 
    0x0985, 0x09A2, 0x09C1, 0x09E0, 0x09FD, 0x0A18, 0x0A2F, 0x0A41, 0x0A4D, 0x0A51, 0x0A4E, 0x0A45, 0x0A37, 0x0A24, 
    0x0A0E, 0x09F6, 0x09DC, 0x09C1, 0x09A6, 0x098C, 0x0974, 0x095E, 0x094B, 0x093D, 0x0934, 0xEF4F, 0xEF4F, 0xEF50, 
    0xEF50, 0xEF51, 0xEF52, 0xEF53, 0xEF54, 0xEF55, 0xEF56, 0xEF57, 0xEF57, 0xEF58, 0xEF58, 0xEF59, 0xEF58, 0xEF58, 
    0xEF58, 0xEF57, 0xEF56, 0xEF56, 0xEF55, 0xEF54, 0xEF53, 0xEF52, 0xEF51, 0xEF51, 0xEF50, 0xEF50, 0xEF4F, 0x128E, 
    0x128D, 0x128B, 0x1289, 0x1285, 0x1281, 0x127C, 0x1278, 0x1273, 0x126E, 0x126A, 0x1267, 0x1264, 0x1262, 0x1261, 
    0x1262, 0x1263, 0x1266, 0x1268, 0x126C, 0x126F, 0x1273, 0x1278, 0x127C, 0x1280, 0x1283, 0x1287, 0x128A, 0x128C, 
    0x128D, 0x0000, 
};

JointIndex object_bai_Anim_008198JointIndices[] = {
    { 0x0000, 0x0003, 0x0002 },
    { 0x0021, 0x003F, 0x005D },
    { 0x007B, 0x0099, 0x00B7 },
    { 0x0000, 0x0000, 0x00D5 },
    { 0x00F3, 0x0111, 0x012F },
    { 0x014D, 0x016B, 0x0189 },
    { 0x0000, 0x0000, 0x01A7 },
    { 0x01C5, 0x01E3, 0x0201 },
    { 0x0000, 0x0000, 0x021F },
    { 0x0000, 0x0000, 0x023D },
    { 0x025B, 0x0279, 0x0297 },
    { 0x0000, 0x0000, 0x02B5 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x02D3, 0x02F1, 0x030F },
    { 0x032D, 0x034B, 0x0369 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x0387 },
    { 0x03A5, 0x03C3, 0x03E1 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x0000 },
};

AnimationHeader object_bai_Anim_008198 = { 
    { 30 }, object_bai_Anim_008198FrameData,
    object_bai_Anim_008198JointIndices, 3
};

