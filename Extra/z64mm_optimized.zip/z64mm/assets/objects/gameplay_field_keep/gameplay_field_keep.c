#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "gameplay_field_keep.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gameplay_field_keep_Tex_000000[] = {
#include "assets/objects/gameplay_field_keep/tex_000000.rgba16.inc.c"
};

u64 gameplay_field_keep_Tex_000400[] = {
#include "assets/objects/gameplay_field_keep/tex_000400.rgba16.inc.c"
};

Vtx gameplay_field_keepVtx_000C00[] = {
#include "assets/objects/gameplay_field_keep/gameplay_field_keepVtx_000C00.vtx.inc"
};

Gfx gameplay_field_keep_DL_000C40[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_field_keep_Tex_000CD0, G_IM_FMT_IA, G_IM_SIZ_16b, 32, 64, 0, G_TX_MIRROR | G_TX_WRAP,
                         G_TX_MIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_XLU_DECAL2),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_field_keepVtx_000C00, 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

u64 gameplay_field_keep_Tex_000CD0[] = {
#include "assets/objects/gameplay_field_keep/tex_000CD0.ia16.inc.c"
};

s16 sameplay_field_keep_Anim_001D20FrameData[] = {
    0x0000, 0x4000, 0xC000, 0x8000, 0x5C72, 0x61FA, 0x6C3F, 0x71C7, 0x6C3F, 0x61FA, 0x5C72, 0x61FA, 0x6C3F, 0x71C7, 
    0x6C3F, 0x61FA, 
};

JointIndex sameplay_field_keep_Anim_001D20JointIndices[] = {
    { 0x0000, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0001, 0x0000, 0x0000 },
    { 0x0000, 0x0000, 0x0004 },
    { 0x0000, 0x0000, 0x0000 },
    { 0x0002, 0x0003, 0x0000 },
    { 0x0000, 0x0000, 0x000A },
    { 0x0000, 0x0000, 0x0000 },
};

AnimationHeader gameplay_field_keep_Anim_001D20 = { 
    { 6 }, sameplay_field_keep_Anim_001D20FrameData,
    sameplay_field_keep_Anim_001D20JointIndices, 4
};

Gfx gameplay_field_keep_DL_001D30[] = {
    gsDPPipeSync(),
    gsDPSetPrimColor(0, 0x01, 255, 255, 255, 255),
    gsDPPipeSync(),
    gsDPSetRenderMode(AA_EN | Z_CMP | Z_UPD | IM_RD | CVG_DST_CLAMP | ZMODE_INTER | CVG_X_ALPHA | ALPHA_CVG_SEL |
                      G_RM_FOG_SHADE_A, AA_EN | Z_CMP | Z_UPD | IM_RD | CVG_DST_CLAMP | ZMODE_INTER | CVG_X_ALPHA |
                      ALPHA_CVG_SEL | GBL_c2(G_BL_CLR_IN, G_BL_A_IN, G_BL_CLR_MEM, G_BL_1MA)),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, PRIMITIVE, 0, TEXEL0, 0, PRIMITIVE, 0, COMBINED, 0, SHADE, 0, TEXEL1, 0,
                       PRIM_LOD_FRAC, COMBINED),
    gsDPLoadTextureBlock(gameplay_field_keep_Tex_001F30, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPClearGeometryMode(G_CULL_BACK),
    gsSPSetGeometryMode(G_LIGHTING),
    gsSPSetGeometryMode(G_SHADING_SMOOTH),
    gsSPVertex(gameplay_field_keepVtx_001DF0, 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSPEndDisplayList(),
};

Gfx gameplay_field_keep_DL_001DD0[] = {
    gsSPDisplayList(gameplay_field_keep_DL_001D30),
    gsSPEndDisplayList(),
};

Gfx gameplay_field_keep_DL_001DE0[] = {
    gsSPDisplayList(gameplay_field_keep_DL_001DD0),
    gsSPEndDisplayList(),
};

Vtx gameplay_field_keepVtx_001DF0[] = {
#include "assets/objects/gameplay_field_keep/gameplay_field_keepVtx_001DF0.vtx.inc"
};

Gfx gameplay_field_keep_DL_001E30[] = {
    gsDPPipeSync(),
    gsDPSetPrimColor(0, 0x01, 255, 255, 255, 255),
    gsDPPipeSync(),
    gsDPSetRenderMode(AA_EN | Z_CMP | Z_UPD | IM_RD | CVG_DST_CLAMP | ZMODE_INTER | CVG_X_ALPHA | ALPHA_CVG_SEL |
                      G_RM_FOG_SHADE_A, AA_EN | Z_CMP | Z_UPD | IM_RD | CVG_DST_CLAMP | ZMODE_INTER | CVG_X_ALPHA |
                      ALPHA_CVG_SEL | GBL_c2(G_BL_CLR_IN, G_BL_A_IN, G_BL_CLR_MEM, G_BL_1MA)),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, PRIMITIVE, 0, TEXEL0, 0, PRIMITIVE, 0, COMBINED, 0, SHADE, 0, TEXEL1, 0,
                       PRIM_LOD_FRAC, COMBINED),
    gsDPLoadTextureBlock(gameplay_field_keep_Tex_001F30, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 64, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPClearGeometryMode(G_CULL_BACK),
    gsSPSetGeometryMode(G_LIGHTING),
    gsSPSetGeometryMode(G_SHADING_SMOOTH),
    gsSPVertex(gameplay_field_keepVtx_001EF0, 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSPEndDisplayList(),
};

Gfx gameplay_field_keep_DL_001ED0[] = {
    gsSPDisplayList(gameplay_field_keep_DL_001E30),
    gsSPEndDisplayList(),
};

Gfx gameplay_field_keep_DL_001EE0[] = {
    gsSPDisplayList(gameplay_field_keep_DL_001ED0),
    gsSPEndDisplayList(),
};

Vtx gameplay_field_keepVtx_001EF0[] = {
#include "assets/objects/gameplay_field_keep/gameplay_field_keepVtx_001EF0.vtx.inc"
};

u64 gameplay_field_keep_Tex_001F30[] = {
#include "assets/objects/gameplay_field_keep/tex_001F30.rgba16.inc.c"
};

StandardLimb gameplay_field_keep_Standardlimb_002F30 = { 
    { 0, 0, 0 }, BUTTERFLY_LIMB_02 - 1, LIMB_DONE,
    NULL
};

StandardLimb gameplay_field_keep_Standardlimb_002F3C = { 
    { 0, 0, 0 }, BUTTERFLY_LIMB_03 - 1, BUTTERFLY_LIMB_05 - 1,
    NULL
};

StandardLimb gameplay_field_keep_Standardlimb_002F48 = { 
    { 0, 0, 0 }, BUTTERFLY_LIMB_04 - 1, LIMB_DONE,
    NULL
};

StandardLimb gameplay_field_keep_Standardlimb_002F54 = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gameplay_field_keep_DL_001DE0
};

StandardLimb gameplay_field_keep_Standardlimb_002F60 = { 
    { 0, 0, 0 }, BUTTERFLY_LIMB_06 - 1, LIMB_DONE,
    NULL
};

StandardLimb gameplay_field_keep_Standardlimb_002F6C = { 
    { 0, 0, 0 }, BUTTERFLY_LIMB_07 - 1, LIMB_DONE,
    NULL
};

StandardLimb gameplay_field_keep_Standardlimb_002F78 = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gameplay_field_keep_DL_001EE0
};

void* gameplay_field_keep_Skel_002FA0Limbs[] = {
    &gameplay_field_keep_Standardlimb_002F30, /* BUTTERFLY_LIMB_01 */
    &gameplay_field_keep_Standardlimb_002F3C, /* BUTTERFLY_LIMB_02 */
    &gameplay_field_keep_Standardlimb_002F48, /* BUTTERFLY_LIMB_03 */
    &gameplay_field_keep_Standardlimb_002F54, /* BUTTERFLY_LIMB_04 */
    &gameplay_field_keep_Standardlimb_002F60, /* BUTTERFLY_LIMB_05 */
    &gameplay_field_keep_Standardlimb_002F6C, /* BUTTERFLY_LIMB_06 */
    &gameplay_field_keep_Standardlimb_002F78, /* BUTTERFLY_LIMB_07 */
};

SkeletonHeader gameplay_field_keep_Skel_002FA0 = { 
    gameplay_field_keep_Skel_002FA0Limbs, ARRAY_COUNT(gameplay_field_keep_Skel_002FA0Limbs)
};

u8 gameplay_field_keep_possiblePadding_002FA8[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

u64 gameplay_field_keep_TLUT_002FB0[] = {
#include "assets/objects/gameplay_field_keep/tlut_002FB0.rgba16.inc.c"
};

u64 gameplay_field_keep_Tex_002FD0[] = {
#include "assets/objects/gameplay_field_keep/tex_002FD0.ci4.inc.c"
};

u64 gameplay_field_keep_Tex_0033D0[] = {
#include "assets/objects/gameplay_field_keep/tex_0033D0.ci4.inc.c"
};

Vtx gameplay_field_keepVtx_0037D0[] = {
#include "assets/objects/gameplay_field_keep/gameplay_field_keepVtx_0037D0.vtx.inc"
};

Gfx gameplay_field_keep_DL_003870[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock_4b(gameplay_field_keep_Tex_002FD0, G_IM_FMT_CI, 32, 64, 0, G_TX_MIRROR | G_TX_WRAP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadTLUT_pal16(0, gameplay_field_keep_TLUT_002FB0),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsDPSetPrimColor(0, 0, 205, 190, 183, 255),
    gsSPVertex(gameplay_field_keepVtx_0037D0, 5, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
    gsSP1Triangle(4, 3, 2, 0),
    gsSPEndDisplayList(),
};

Gfx gameplay_field_keep_DL_003938[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock_4b(gameplay_field_keep_Tex_0033D0, G_IM_FMT_CI, 32, 64, 0, G_TX_MIRROR | G_TX_WRAP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 5, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadTLUT_pal16(0, gameplay_field_keep_TLUT_002FB0),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsDPSetPrimColor(0, 0, 205, 190, 183, 255),
    gsSPVertex(&gameplay_field_keepVtx_0037D0[5], 5, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
    gsSP1Triangle(4, 3, 2, 0),
    gsSPEndDisplayList(),
};

CamData gameplay_field_keep_Colheader_003A60CamDataList[] = {
    { 0x0000, 0, NULL },
};

SurfaceType gameplay_field_keep_Colheader_003A60SurfaceType[] = {
    {0x00000000, 0x000007CB},
};

CollisionPoly gameplay_field_keep_Colheader_003A60Polygons[] = {
    {0x0000, 0x0000, 0x0001, 0x0002, 0xCD94, 0x0000, 0x75A6, 0xFEEC},
    {0x0000, 0x0003, 0x0000, 0x0002, 0x0000, 0x150B, 0x7E41, 0xFEDF},
    {0x0000, 0x0004, 0x0003, 0x0002, 0x326C, 0x0000, 0x75A6, 0xFEEC},
};

Vec3s gameplay_field_keep_Colheader_003A60Vertices[] = {
    {   -700,   1760,      0 },
    {   -700,    -40,      0 },
    {      0,    -40,    300 },
    {    700,   1760,      0 },
    {    700,    -40,      0 },
};

CollisionHeader gameplay_field_keep_Colheader_003A60 = { 
    { -700, -40, 0 },
    { 700, 1760, 300 },
    ARRAY_COUNT(gameplay_field_keep_Colheader_003A60Vertices), gameplay_field_keep_Colheader_003A60Vertices,
    ARRAY_COUNT(gameplay_field_keep_Colheader_003A60Polygons), gameplay_field_keep_Colheader_003A60Polygons,
    gameplay_field_keep_Colheader_003A60SurfaceType,
    gameplay_field_keep_Colheader_003A60CamDataList,
    0, NULL
};

Vtx gameplay_field_keepVtx_003A90[] = {
#include "assets/objects/gameplay_field_keep/gameplay_field_keepVtx_003A90.vtx.inc"
};

Gfx gFieldWoodDoorFrameDL[] = {
    gsDPPipeSync(),
    gsDPLoadTextureBlock_4b(gFieldWoodDoorTex, G_IM_FMT_I, 64, 128, 0, G_TX_MIRROR | G_TX_WRAP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 7, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetPrimColor(0, 0, 235, 200, 145, 255),
    gsSPVertex(&gameplay_field_keepVtx_003A90[68], 16, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 11, 9, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 15, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gFieldWoodDoorLeftDL[] = {
    gsDPLoadTextureBlock_4b(gFieldWoodDoorTex, G_IM_FMT_I, 64, 128, 0, G_TX_MIRROR | G_TX_WRAP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 7, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsDPSetPrimColor(0, 0, 235, 200, 145, 255),
    gsSPVertex(gameplay_field_keepVtx_003A90, 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gameplay_field_keep_Tex_004400, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_MIRROR | G_TX_WRAP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetPrimColor(0, 0, 140, 140, 140, 255),
    gsSPVertex(&gameplay_field_keepVtx_003A90[4], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsDPPipeSync(),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(&gameplay_field_keepVtx_003A90[12], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gameplay_field_keep_Tex_004600, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_field_keepVtx_003A90[16], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(0, 3, 4, 0, 0, 4, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gameplay_field_keep_Tex_004400, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_MIRROR | G_TX_WRAP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0, 102, 102, 102, 255),
    gsSPVertex(&gameplay_field_keepVtx_003A90[22], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsDPPipeSync(),
    gsDPSetPrimColor(0, 0, 204, 204, 204, 255),
    gsSPVertex(&gameplay_field_keepVtx_003A90[26], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSPDisplayList(gFieldWoodDoorFrameDL),
    gsSPEndDisplayList(),
};

Gfx gFieldWoodDoorRightDL[] = {
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPLoadTextureBlock_4b(gFieldWoodDoorTex, G_IM_FMT_I, 64, 128, 0, G_TX_MIRROR | G_TX_WRAP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 7, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetPrimColor(0, 0, 235, 200, 145, 255),
    gsSPVertex(&gameplay_field_keepVtx_003A90[34], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gameplay_field_keep_Tex_004400, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_MIRROR | G_TX_WRAP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetPrimColor(0, 0, 140, 140, 140, 255),
    gsSPVertex(&gameplay_field_keepVtx_003A90[38], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsDPPipeSync(),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(&gameplay_field_keepVtx_003A90[46], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gameplay_field_keep_Tex_004600, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&gameplay_field_keepVtx_003A90[50], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(0, 3, 4, 0, 0, 4, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gameplay_field_keep_Tex_004400, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_MIRROR | G_TX_WRAP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0, 102, 102, 102, 255),
    gsSPVertex(&gameplay_field_keepVtx_003A90[56], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsDPPipeSync(),
    gsDPSetPrimColor(0, 0, 204, 204, 204, 255),
    gsSPVertex(&gameplay_field_keepVtx_003A90[60], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSPDisplayList(gFieldWoodDoorFrameDL),
    gsSPEndDisplayList(),
};

u8 gameplay_field_keep_possiblePadding_0043F8[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

u64 gameplay_field_keep_Tex_004400[] = {
#include "assets/objects/gameplay_field_keep/tex_004400.rgba16.inc.c"
};

u64 gameplay_field_keep_Tex_004600[] = {
#include "assets/objects/gameplay_field_keep/tex_004600.rgba16.inc.c"
};

u64 gFieldWoodDoorTex[] = {
#include "assets/objects/gameplay_field_keep/wood_door.i4.inc.c"
};

u64 gameplay_field_keep_TLUT_005800[] = {
#include "assets/objects/gameplay_field_keep/tlut_005800.rgba16.inc.c"
};

u8 gameplay_field_keep_possiblePadding_005820[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

u64 gameplay_field_keep_Tex_005828[] = {
#include "assets/objects/gameplay_field_keep/tex_005828.ci4.inc.c"
};

Vtx gameplay_field_keepVtx_006028[] = {
#include "assets/objects/gameplay_field_keep/gameplay_field_keepVtx_006028.vtx.inc"
};

Gfx gameplay_field_keep_DL_0061E8[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock_4b(gameplay_field_keep_Tex_005828, G_IM_FMT_CI, 64, 64, 0, G_TX_NOMIRROR | G_TX_WRAP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadTLUT_pal16(0, gameplay_field_keep_TLUT_005800),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, COMBINED, 0, PRIMITIVE, 0),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPDisplayList(0x08000000),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPVertex(gameplay_field_keepVtx_006028, 28, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(3, 6, 4, 0, 5, 4, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 9, 11, 10, 0),
    gsSP2Triangles(10, 11, 12, 0, 11, 13, 12, 0),
    gsSP2Triangles(12, 14, 15, 0, 15, 6, 16, 0),
    gsSP2Triangles(15, 13, 17, 0, 18, 10, 19, 0),
    gsSP2Triangles(10, 12, 19, 0, 12, 15, 19, 0),
    gsSP2Triangles(19, 15, 20, 0, 3, 20, 15, 0),
    gsSP2Triangles(5, 21, 3, 0, 21, 20, 3, 0),
    gsSP2Triangles(10, 18, 8, 0, 22, 23, 24, 0),
    gsSP2Triangles(23, 25, 24, 0, 25, 26, 24, 0),
    gsSP2Triangles(26, 27, 24, 0, 27, 22, 24, 0),
    gsSPEndDisplayList(),
};

Vtx gameplay_field_keepVtx_006300[] = {
#include "assets/objects/gameplay_field_keep/gameplay_field_keepVtx_006300.vtx.inc"
};

Gfx gameplay_field_keep_DL_006420[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock_4b(gameplay_field_keep_Tex_005828, G_IM_FMT_CI, 64, 64, 0, G_TX_NOMIRROR | G_TX_WRAP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPLoadTLUT_pal16(0, gameplay_field_keep_TLUT_005800),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPVertex(gameplay_field_keepVtx_006300, 18, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
    gsSP2Triangles(8, 9, 10, 0, 11, 12, 13, 0),
    gsSP2Triangles(10, 9, 14, 0, 13, 15, 16, 0),
    gsSP2Triangles(13, 12, 15, 0, 16, 17, 8, 0),
    gsSP2Triangles(16, 15, 17, 0, 8, 17, 9, 0),
    gsSPEndDisplayList(),
};

Vtx gameplay_field_keepVtx_006500[] = {
#include "assets/objects/gameplay_field_keep/gameplay_field_keepVtx_006500.vtx.inc"
};

Gfx gameplay_field_keep_DL_0066B0[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_field_keep_Tex_006810, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, 0, 0, 0, COMBINED, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPVertex(gameplay_field_keepVtx_006500, 27, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 4, 0),
    gsSP2Triangles(5, 6, 7, 0, 0, 8, 9, 0),
    gsSP2Triangles(10, 11, 6, 0, 12, 13, 14, 0),
    gsSP2Triangles(15, 7, 6, 0, 16, 1, 17, 0),
    gsSP2Triangles(18, 19, 20, 0, 21, 22, 16, 0),
    gsSP2Triangles(23, 24, 16, 0, 25, 26, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gameplay_field_keep_DL_006760[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_field_keep_Tex_006810, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_WRAP, G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, 1, COMBINED, 0, PRIMITIVE, 0, COMBINED, 0, PRIMITIVE, 0),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_XLU_SURF2),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPVertex(gameplay_field_keepVtx_006500, 27, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 4, 0),
    gsSP2Triangles(5, 6, 7, 0, 0, 8, 9, 0),
    gsSP2Triangles(10, 11, 6, 0, 12, 13, 14, 0),
    gsSP2Triangles(15, 7, 6, 0, 16, 1, 17, 0),
    gsSP2Triangles(18, 19, 20, 0, 21, 22, 16, 0),
    gsSP2Triangles(23, 24, 16, 0, 25, 26, 13, 0),
    gsSPEndDisplayList(),
};

u64 gameplay_field_keep_Tex_006810[] = {
#include "assets/objects/gameplay_field_keep/tex_006810.rgba16.inc.c"
};

u64 gameplay_field_keep_Tex_007010[] = {
#include "assets/objects/gameplay_field_keep/tex_007010.rgba16.inc.c"
};

Vtx gameplay_field_keepVtx_007810[] = {
#include "assets/objects/gameplay_field_keep/gameplay_field_keepVtx_007810.vtx.inc"
};

Gfx gKusaBushType1DL[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_field_keep_Tex_007010, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, COMBINED, 0, PRIMITIVE, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsSPClearGeometryMode(G_CULL_BACK | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_FOG | G_LIGHTING),
    gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
    gsSPVertex(gameplay_field_keepVtx_007810, 9, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP1Triangle(6, 7, 8, 0),
    gsSPEndDisplayList(),
};

Gfx gKusaBushType2DL[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock(gameplay_field_keep_Tex_007010, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR |
                         G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineMode(G_CC_MODULATEIDECALA, G_CC_MODULATEIA_PRIM2),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_XLU_SURF2),
    gsSPClearGeometryMode(G_CULL_BACK | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_FOG | G_LIGHTING),
    gsSPVertex(gameplay_field_keepVtx_007810, 9, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP1Triangle(6, 7, 8, 0),
    gsSPEndDisplayList(),
};

u8 gameplay_field_keep_possiblePadding_0079C8[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

u64 gFieldSandstorm1Tex[] = {
#include "assets/objects/gameplay_field_keep/sandstorm_1.i8.inc.c"
};

u64 gFieldSandstorm2Tex[] = {
#include "assets/objects/gameplay_field_keep/sandstorm_2.ia8.inc.c"
};

Gfx gFieldSandstormDL[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPSetRenderMode(G_RM_PASS, G_RM_CLD_SURF2),
    gsDPSetCombineLERP(TEXEL1, TEXEL0, PRIM_LOD_FRAC, TEXEL0, TEXEL1, TEXEL0, ENVIRONMENT, TEXEL0, PRIMITIVE,
                       ENVIRONMENT, COMBINED, ENVIRONMENT, COMBINED, 0, PRIMITIVE, 0),
    gsSPClearGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsDPLoadTextureBlock(gFieldSandstorm1Tex, G_IM_FMT_I, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 6, 5, 1, G_TX_NOLOD),
    gsDPLoadMultiBlock(gFieldSandstorm2Tex, 0x0100, 1, G_IM_FMT_IA, G_IM_SIZ_8b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                       G_TX_NOMIRROR | G_TX_WRAP, 6, 5, 2, 1),
    gsSPDisplayList(0x08000000),
    gsSPTextureRectangle(0, 0, 0x0500, 0x03C0, G_TX_RENDERTILE, 0, 0, 0x008C, -0x008C),
    gsSPEndDisplayList(),
};

u64 gameplay_field_keep_Tex_008A90[] = {
#include "assets/objects/gameplay_field_keep/tex_008A90.rgba16.inc.c"
};

