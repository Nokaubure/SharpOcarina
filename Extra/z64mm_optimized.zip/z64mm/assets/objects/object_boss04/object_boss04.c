#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_boss04.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

s16 sWartIdleAnimFrameData[] = {
    0x0009, 0x0000, 0xFF70, 0xC000, 0x4000, 0xBFD6, 0x7703, 0x8000, 0xF703, 0x0000, 
};

JointIndex sWartIdleAnimJointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0003, 0x0001, 0x0001 },
    { 0x0001, 0x0001, 0x0004 },
    { 0x0001, 0x0001, 0x0003 },
    { 0x0001, 0x0001, 0x0005 },
    { 0x0004, 0x0001, 0x0001 },
    { 0x0001, 0x0001, 0x0006 },
    { 0x0004, 0x0007, 0x0007 },
    { 0x0007, 0x0007, 0x0008 },
};

AnimationHeader gWartIdleAnim = { 
    { 21 }, sWartIdleAnimFrameData,
    sWartIdleAnimJointIndices, 9
};

Vtx object_boss04Vtx_000060[] = {
#include "assets/objects/object_boss04/object_boss04Vtx_000060.vtx.inc"
};

Gfx gWartShellDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gWartShellTLUT),
    gsDPLoadTextureBlock_4b(gWartShellTex, G_IM_FMT_CI, 64, 64, 15, G_TX_MIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x01FC, 0x00FC),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_boss04Vtx_000060, 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
    gsSP2Triangles(1, 3, 4, 0, 4, 3, 5, 0),
    gsSP2Triangles(4, 5, 6, 0, 6, 5, 7, 0),
    gsSP2Triangles(6, 7, 8, 0, 8, 7, 9, 0),
    gsSP2Triangles(8, 9, 10, 0, 10, 9, 11, 0),
    gsSP2Triangles(10, 11, 12, 0, 12, 11, 13, 0),
    gsSP2Triangles(12, 13, 14, 0, 14, 13, 15, 0),
    gsSP2Triangles(14, 15, 16, 0, 16, 15, 17, 0),
    gsSP2Triangles(16, 17, 18, 0, 19, 16, 18, 0),
    gsSP2Triangles(19, 18, 20, 0, 21, 14, 16, 0),
    gsSP2Triangles(21, 16, 19, 0, 22, 12, 14, 0),
    gsSP2Triangles(22, 14, 21, 0, 23, 0, 2, 0),
    gsSP2Triangles(0, 23, 24, 0, 0, 24, 3, 0),
    gsSP2Triangles(3, 24, 25, 0, 3, 25, 5, 0),
    gsSP2Triangles(5, 25, 26, 0, 5, 26, 7, 0),
    gsSP2Triangles(7, 26, 27, 0, 7, 27, 9, 0),
    gsSP2Triangles(9, 27, 28, 0, 9, 28, 11, 0),
    gsSP2Triangles(11, 28, 29, 0, 11, 29, 13, 0),
    gsSP2Triangles(13, 29, 30, 0, 13, 30, 15, 0),
    gsSP2Triangles(15, 30, 31, 0, 15, 31, 17, 0),
    gsSPVertex(&object_boss04Vtx_000060[32], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 1, 0, 4, 1, 0, 0),
    gsSP2Triangles(6, 7, 5, 0, 6, 5, 4, 0),
    gsSP2Triangles(8, 9, 7, 0, 8, 7, 6, 0),
    gsSP2Triangles(10, 11, 9, 0, 10, 9, 8, 0),
    gsSP2Triangles(11, 10, 12, 0, 13, 14, 15, 0),
    gsSP2Triangles(13, 15, 16, 0, 17, 18, 14, 0),
    gsSP2Triangles(17, 14, 13, 0, 19, 3, 18, 0),
    gsSP2Triangles(19, 18, 17, 0, 20, 21, 12, 0),
    gsSP2Triangles(21, 20, 22, 0, 21, 22, 23, 0),
    gsSP2Triangles(23, 22, 24, 0, 23, 24, 25, 0),
    gsSP2Triangles(25, 24, 26, 0, 25, 26, 27, 0),
    gsSP2Triangles(27, 26, 28, 0, 27, 28, 29, 0),
    gsSP2Triangles(29, 28, 30, 0, 29, 30, 31, 0),
    gsSPVertex(&object_boss04Vtx_000060[64], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(3, 2, 4, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 4, 6, 0, 5, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 9, 0, 12, 9, 8, 0),
    gsSP2Triangles(14, 15, 13, 0, 14, 13, 12, 0),
    gsSP2Triangles(16, 17, 18, 0, 17, 16, 19, 0),
    gsSP2Triangles(17, 19, 20, 0, 20, 19, 21, 0),
    gsSP2Triangles(20, 21, 22, 0, 22, 21, 23, 0),
    gsSP2Triangles(22, 23, 24, 0, 24, 23, 25, 0),
    gsSP2Triangles(24, 25, 26, 0, 26, 25, 27, 0),
    gsSP2Triangles(26, 27, 1, 0, 1, 27, 28, 0),
    gsSP2Triangles(1, 28, 2, 0, 2, 28, 29, 0),
    gsSP2Triangles(2, 29, 4, 0, 4, 29, 30, 0),
    gsSP1Triangle(4, 30, 6, 0),
    gsSPVertex(&object_boss04Vtx_000060[95], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 1, 0, 4, 1, 0, 0),
    gsSP2Triangles(5, 4, 6, 0, 7, 8, 6, 0),
    gsSP2Triangles(8, 7, 9, 0, 8, 9, 10, 0),
    gsSP2Triangles(10, 9, 11, 0, 10, 11, 12, 0),
    gsSP2Triangles(12, 11, 13, 0, 12, 13, 14, 0),
    gsSP2Triangles(14, 13, 15, 0, 14, 15, 16, 0),
    gsSP2Triangles(16, 15, 17, 0, 16, 17, 18, 0),
    gsSP2Triangles(18, 17, 19, 0, 18, 19, 20, 0),
    gsSP2Triangles(20, 19, 21, 0, 20, 21, 22, 0),
    gsSP2Triangles(22, 21, 23, 0, 22, 23, 24, 0),
    gsSP2Triangles(25, 7, 6, 0, 7, 25, 26, 0),
    gsSP2Triangles(7, 26, 9, 0, 9, 26, 27, 0),
    gsSP2Triangles(9, 27, 11, 0, 11, 27, 28, 0),
    gsSP2Triangles(11, 28, 13, 0, 13, 28, 29, 0),
    gsSP2Triangles(13, 29, 15, 0, 15, 29, 30, 0),
    gsSP2Triangles(15, 30, 17, 0, 17, 30, 31, 0),
    gsSP1Triangle(17, 31, 19, 0),
    gsSPVertex(&object_boss04Vtx_000060[127], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(3, 2, 4, 0, 3, 4, 5, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gWartRidgesTLUT),
    gsDPLoadTextureBlock_4b(gWartRidgesTex, G_IM_FMT_CI, 8, 16, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 3, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x001C, 0x00BC),
    gsSPVertex(&object_boss04Vtx_000060[133], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
    gsSP2Triangles(1, 3, 4, 0, 4, 3, 5, 0),
    gsSP2Triangles(4, 5, 6, 0, 6, 5, 7, 0),
    gsSP2Triangles(6, 7, 8, 0, 8, 7, 9, 0),
    gsSP2Triangles(8, 9, 10, 0, 10, 9, 11, 0),
    gsSP2Triangles(10, 11, 12, 0, 12, 11, 13, 0),
    gsSP2Triangles(12, 13, 14, 0, 14, 13, 15, 0),
    gsSP2Triangles(14, 15, 16, 0, 16, 15, 17, 0),
    gsSP2Triangles(16, 17, 18, 0, 19, 20, 21, 0),
    gsSP2Triangles(19, 21, 22, 0, 23, 24, 20, 0),
    gsSP2Triangles(23, 20, 19, 0, 25, 26, 24, 0),
    gsSP2Triangles(25, 24, 23, 0, 27, 6, 8, 0),
    gsSP2Triangles(27, 8, 28, 0, 28, 8, 10, 0),
    gsSP2Triangles(28, 10, 29, 0, 29, 10, 12, 0),
    gsSP2Triangles(29, 12, 30, 0, 30, 12, 14, 0),
    gsSP2Triangles(30, 14, 31, 0, 31, 14, 16, 0),
    gsSPVertex(&object_boss04Vtx_000060[165], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(2, 3, 4, 0, 5, 6, 7, 0),
    gsSP2Triangles(6, 5, 8, 0, 6, 8, 9, 0),
    gsSP2Triangles(9, 8, 10, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 13, 0, 16, 13, 12, 0),
    gsSP2Triangles(18, 19, 17, 0, 18, 17, 16, 0),
    gsSP2Triangles(20, 21, 7, 0, 21, 20, 22, 0),
    gsSP2Triangles(21, 22, 23, 0, 23, 22, 18, 0),
    gsSP2Triangles(23, 18, 24, 0, 24, 18, 16, 0),
    gsSP2Triangles(24, 16, 25, 0, 25, 16, 12, 0),
    gsSP2Triangles(25, 12, 26, 0, 26, 12, 15, 0),
    gsSP2Triangles(26, 15, 27, 0, 27, 15, 28, 0),
    gsSP2Triangles(27, 28, 29, 0, 29, 28, 30, 0),
    gsSP1Triangle(29, 30, 31, 0),
    gsSPVertex(&object_boss04Vtx_000060[197], 11, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 5, 0, 8, 5, 4, 0),
    gsSP1Triangle(9, 8, 10, 0),
    gsSPEndDisplayList(),
};

Gfx gWartBottomEyelidDL[] = {
    gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss04Vtx_000060[266], 6, 0),
    gsSPVertex(&object_boss04Vtx_000060[272], 1, 6),
    gsSPMatrix(0x0D0000C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gWartShellTLUT),
    gsDPLoadTextureBlock_4b(gWartShellTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_boss04Vtx_000060[273], 25, 7),
    gsSP2Triangles(1, 7, 8, 0, 0, 9, 10, 0),
    gsSP2Triangles(1, 11, 5, 0, 12, 13, 4, 0),
    gsSP2Triangles(4, 14, 15, 0, 4, 16, 6, 0),
    gsSP2Triangles(6, 17, 18, 0, 6, 19, 3, 0),
    gsSP2Triangles(20, 21, 2, 0, 0, 2, 22, 0),
    gsSP2Triangles(3, 23, 24, 0, 25, 2, 3, 0),
    gsSP2Triangles(5, 26, 27, 0, 28, 4, 5, 0),
    gsSP2Triangles(1, 0, 29, 0, 30, 31, 0, 0),
    gsSPVertex(&object_boss04Vtx_000060[298], 6, 7),
    gsSP2Triangles(0, 7, 8, 0, 1, 9, 10, 0),
    gsSP1Triangle(11, 12, 1, 0),
    gsSPVertex(&object_boss04Vtx_000060[304], 20, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(3, 2, 4, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 4, 6, 0, 5, 6, 7, 0),
    gsSP2Triangles(7, 6, 8, 0, 7, 8, 9, 0),
    gsSP2Triangles(9, 8, 10, 0, 9, 10, 11, 0),
    gsSP2Triangles(11, 10, 12, 0, 11, 12, 13, 0),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSPEndDisplayList(),
};

Gfx gWartTopEyelidDL[] = {
    gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss04Vtx_000060[208], 5, 0),
    gsSPVertex(&object_boss04Vtx_000060[213], 2, 5),
    gsSPMatrix(0x0D000080, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gWartShellTLUT),
    gsDPLoadTextureBlock_4b(gWartShellTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_boss04Vtx_000060[215], 25, 7),
    gsSP2Triangles(7, 8, 1, 0, 9, 10, 0, 0),
    gsSP2Triangles(4, 11, 1, 0, 3, 12, 13, 0),
    gsSP2Triangles(5, 14, 15, 0, 5, 16, 3, 0),
    gsSP2Triangles(6, 17, 18, 0, 6, 19, 5, 0),
    gsSP2Triangles(2, 20, 21, 0, 22, 2, 0, 0),
    gsSP2Triangles(23, 24, 6, 0, 6, 2, 25, 0),
    gsSP2Triangles(26, 27, 4, 0, 4, 3, 28, 0),
    gsSP2Triangles(29, 0, 1, 0, 0, 30, 31, 0),
    gsSPVertex(&object_boss04Vtx_000060[240], 6, 7),
    gsSP2Triangles(7, 8, 0, 0, 9, 10, 1, 0),
    gsSP1Triangle(1, 11, 12, 0),
    gsSPVertex(&object_boss04Vtx_000060[246], 20, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 1, 0, 4, 1, 0, 0),
    gsSP2Triangles(6, 7, 5, 0, 6, 5, 4, 0),
    gsSP2Triangles(8, 9, 7, 0, 8, 7, 6, 0),
    gsSP2Triangles(10, 11, 9, 0, 10, 9, 8, 0),
    gsSP2Triangles(12, 13, 11, 0, 12, 11, 10, 0),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSPEndDisplayList(),
};

Gfx gWartEyeDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gWartEyeTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                         | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 253, 252, 243, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(&object_boss04Vtx_000060[324], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(11, 10, 12, 0, 11, 12, 13, 0),
    gsSP2Triangles(13, 12, 14, 0, 13, 14, 15, 0),
    gsSP2Triangles(15, 14, 16, 0, 15, 16, 1, 0),
    gsSP2Triangles(1, 16, 17, 0, 1, 17, 2, 0),
    gsSP2Triangles(2, 17, 18, 0, 6, 15, 1, 0),
    gsSP2Triangles(6, 1, 0, 0, 19, 20, 5, 0),
    gsSP2Triangles(19, 5, 4, 0, 9, 21, 22, 0),
    gsSP2Triangles(9, 22, 10, 0, 10, 22, 23, 0),
    gsSP2Triangles(10, 23, 12, 0, 12, 23, 24, 0),
    gsSP2Triangles(12, 24, 14, 0, 14, 24, 25, 0),
    gsSP2Triangles(14, 25, 16, 0, 16, 25, 26, 0),
    gsSP2Triangles(16, 26, 17, 0, 17, 26, 18, 0),
    gsSP2Triangles(5, 13, 15, 0, 5, 15, 6, 0),
    gsSP2Triangles(7, 6, 0, 0, 7, 0, 27, 0),
    gsSP2Triangles(21, 28, 29, 0, 21, 29, 22, 0),
    gsSP2Triangles(22, 29, 30, 0, 22, 30, 23, 0),
    gsSP2Triangles(23, 30, 31, 0, 23, 31, 24, 0),
    gsSPVertex(&object_boss04Vtx_000060[356], 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(3, 2, 4, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 4, 6, 0, 7, 8, 9, 0),
    gsSP2Triangles(7, 9, 10, 0, 11, 12, 13, 0),
    gsSP2Triangles(11, 13, 14, 0, 15, 16, 17, 0),
    gsSP2Triangles(15, 17, 18, 0, 18, 17, 19, 0),
    gsSP2Triangles(18, 19, 20, 0, 20, 19, 21, 0),
    gsSP2Triangles(20, 21, 1, 0, 1, 21, 22, 0),
    gsSP2Triangles(1, 22, 2, 0, 2, 22, 23, 0),
    gsSP2Triangles(2, 23, 4, 0, 4, 23, 6, 0),
    gsSP2Triangles(24, 25, 8, 0, 24, 8, 7, 0),
    gsSP2Triangles(14, 13, 6, 0, 16, 26, 27, 0),
    gsSP2Triangles(16, 27, 17, 0, 17, 27, 28, 0),
    gsSP2Triangles(17, 28, 19, 0, 19, 28, 29, 0),
    gsSP2Triangles(19, 29, 21, 0, 21, 29, 30, 0),
    gsSP2Triangles(21, 30, 22, 0, 22, 30, 31, 0),
    gsSP2Triangles(22, 31, 23, 0, 23, 31, 6, 0),
    gsSPVertex(&object_boss04Vtx_000060[388], 17, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 0, 3, 0),
    gsSP2Triangles(7, 3, 8, 0, 8, 3, 9, 0),
    gsSP2Triangles(8, 9, 10, 0, 10, 9, 11, 0),
    gsSP2Triangles(10, 11, 12, 0, 12, 11, 13, 0),
    gsSP2Triangles(12, 13, 14, 0, 14, 13, 15, 0),
    gsSP2Triangles(14, 15, 16, 0, 16, 15, 6, 0),
    gsSPEndDisplayList(),
};

u64 gWartShellTLUT[] = {
#include "assets/objects/object_boss04/wart_shell_tlut.rgba16.inc.c"
};

u64 gWartRidgesTLUT[] = {
#include "assets/objects/object_boss04/wart_ridges_tlut.rgba16.inc.c"
};

u64 gWartShellTex[] = {
#include "assets/objects/object_boss04/wart_shell.ci4.inc.c"
};

u64 gWartRidgesTex[] = {
#include "assets/objects/object_boss04/wart_ridges.ci4.inc.c"
};

u64 gWartEyeTex[] = {
#include "assets/objects/object_boss04/wart_eye.rgba16.inc.c"
};

Vtx object_boss04Vtx_0033A8[] = {
#include "assets/objects/object_boss04/object_boss04Vtx_0033A8.vtx.inc"
};

Gfx gWartBubbleOpaqueMaterialDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gWartBubbleTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_FOG | G_SHADING_SMOOTH),
    gsSPEndDisplayList(),
};

Gfx gWartBubbleMaterialDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_PASS, G_RM_ZB_CLD_SURF2),
    gsDPSetCombineMode(G_CC_MODULATEIA_PRIM, G_CC_PASS2),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gWartBubbleTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPClearGeometryMode(G_FOG | G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK),
    gsSPEndDisplayList(),
};

Gfx gWartBubbleModelDL[] = {
    gsSPVertex(object_boss04Vtx_0033A8, 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPEndDisplayList(),
};

u64 gWartBubbleTex[] = {
#include "assets/objects/object_boss04/wart_bubble.rgba16.inc.c"
};

Vtx object_boss04Vtx_003CE0[] = {
#include "assets/objects/object_boss04/object_boss04Vtx_003CE0.vtx.inc"
};

u64 gWartShadowTex[] = {
#include "assets/objects/object_boss04/wart_shadow.ia16.inc.c"
};

Gfx gWartShadowMaterialDL[] = {
    gsDPLoadTextureBlock(gWartShadowTex, G_IM_FMT_IA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                         | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPEndDisplayList(),
};

Gfx gWartShadowModelDL[] = {
    gsSPVertex(object_boss04Vtx_003CE0, 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPEndDisplayList(),
};

StandardLimb gWartRootLimb = { 
    { 9, 0, -144 }, WART_LIMB_BODY - 1, LIMB_DONE,
    NULL
};

StandardLimb gWartBodyLimb = { 
    { 0, 0, 0 }, WART_LIMB_EYE_ROOT - 1, LIMB_DONE,
    gWartShellDL
};

StandardLimb gWartEyeRootLimb = { 
    { -32, 7, 0 }, WART_LIMB_EYE - 1, WART_LIMB_TOP_EYELID_ROOT - 1,
    NULL
};

StandardLimb gWartEyeLimb = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gWartEyeDL
};

StandardLimb gWartTopEyelidRootLimb = { 
    { -133, 9, 54 }, WART_LIMB_TOP_EYELID - 1, WART_LIMB_BOTTOM_EYELID_ROOT - 1,
    NULL
};

StandardLimb gWartTopEyelidLimb = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gWartTopEyelidDL
};

StandardLimb gWartBottomEyelidRootLimb = { 
    { -133, 9, -54 }, WART_LIMB_BOTTOM_EYELID - 1, LIMB_DONE,
    NULL
};

StandardLimb gWartBottomEyelidLimb = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gWartBottomEyelidDL
};

void* gWartSkelLimbs[] = {
    &gWartRootLimb, /* WART_LIMB_ROOT */
    &gWartBodyLimb, /* WART_LIMB_BODY */
    &gWartEyeRootLimb, /* WART_LIMB_EYE_ROOT */
    &gWartEyeLimb, /* WART_LIMB_EYE */
    &gWartTopEyelidRootLimb, /* WART_LIMB_TOP_EYELID_ROOT */
    &gWartTopEyelidLimb, /* WART_LIMB_TOP_EYELID */
    &gWartBottomEyelidRootLimb, /* WART_LIMB_BOTTOM_EYELID_ROOT */
    &gWartBottomEyelidLimb, /* WART_LIMB_BOTTOM_EYELID */
};

FlexSkeletonHeader gWartSkel = { 
    { gWartSkelLimbs, ARRAY_COUNT(gWartSkelLimbs) }, 4
};

