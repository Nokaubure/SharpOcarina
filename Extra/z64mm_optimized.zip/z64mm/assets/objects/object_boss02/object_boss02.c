#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_boss02.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gTwinmoldDustMaskTex[] = {
#include "assets/objects/object_boss02/dust_mask.i4.inc.c"
};

Vtx object_boss02Vtx_000200[] = {
#include "assets/objects/object_boss02/object_boss02Vtx_000200.vtx.inc"
};

Gfx gTwinmoldDustMaterialDL[] = {
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPLoadTextureBlock_4b(gEffFireMask1Tex, G_IM_FMT_I, 32, 64, 0, G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMIRROR |
                            G_TX_WRAP, 5, 6, G_TX_NOLOD, 15),
    gsDPLoadMultiBlock_4b(gTwinmoldDustMaskTex, 0x0100, 1, G_IM_FMT_I, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                          G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(TEXEL0, 0, ENV_ALPHA, TEXEL1, TEXEL0, 1, ENVIRONMENT, TEXEL1, PRIMITIVE, ENVIRONMENT, COMBINED,
                       ENVIRONMENT, COMBINED, 0, PRIMITIVE, 0),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_ZB_CLD_SURF2),
    gsSPClearGeometryMode(G_LIGHTING | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldDustModelDL[] = {
    gsSPDisplayList(0x08000000),
    gsSPVertex(object_boss02Vtx_000200, 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPEndDisplayList(),
};

u64 gTwinmoldSkinTLUT[] = {
#include "assets/objects/object_boss02/twinmold_skin_tlut.rgba16.inc.c"
};

u64 gTwinmoldSnoutTLUT[] = {
#include "assets/objects/object_boss02/twinmold_snout_tlut.rgba16.inc.c"
};

u64 gTwinmoldVeinsTLUT[] = {
#include "assets/objects/object_boss02/twinmold_veins_tlut.rgba16.inc.c"
};

u64 gTwinmoldUndersideTLUT[] = {
#include "assets/objects/object_boss02/twinmold_underside_tlut.rgba16.inc.c"
};

u64 gTwinmoldSpikeAndMandibleTLUT[] = {
#include "assets/objects/object_boss02/twinmold_spike_and_mandible_tlut.rgba16.inc.c"
};

u64 gTwinmoldRedSkinTex[] = {
#include "assets/objects/object_boss02/twinmold_red_skin.ci4.inc.c"
};

u64 gTwinmoldEyeTex[] = {
#include "assets/objects/object_boss02/twinmold_eye.rgba16.inc.c"
};

u64 gTwinmoldSnoutTex[] = {
#include "assets/objects/object_boss02/twinmold_snout.ci4.inc.c"
};

u64 gTwinmoldVeinsTex[] = {
#include "assets/objects/object_boss02/twinmold_veins.ci4.inc.c"
};

u64 gTwinmoldTeethTex[] = {
#include "assets/objects/object_boss02/twinmold_teeth.rgba16.inc.c"
};

u64 gTwinmoldUndersideTex[] = {
#include "assets/objects/object_boss02/twinmold_underside.ci4.inc.c"
};

u64 gTwinmoldSpikeAndMandibleTex[] = {
#include "assets/objects/object_boss02/twinmold_spike_and_mandible.ci4.inc.c"
};

u64 gTwinmoldAntennaTex[] = {
#include "assets/objects/object_boss02/twinmold_antenna.rgba16.inc.c"
};

u64 gTwinmoldTailGemTex[] = {
#include "assets/objects/object_boss02/twinmold_tail_gem.rgba16.inc.c"
};

u64 gTwinmoldBlueSkinTex[] = {
#include "assets/objects/object_boss02/twinmold_blue_skin.ci4.inc.c"
};

u8 object_boss02_unaccounted_0049A0[] = {
    0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 sTwinmoldHeadStationaryAnimFrameData[] = {
    0x0003, 0xFFE0, 0xFE22, 0xC000, 0x0000, 0xBFE0, 0x4020, 0xB3C1, 0x8000, 0x33C1, 0xBF9F, 0x00CC, 0x3F9F, 0x0000, 
    
};

JointIndex sTwinmoldHeadStationaryAnimJointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0003, 0x0004, 0x0004 },
    { 0x0004, 0x0004, 0x0005 },
    { 0x0004, 0x0004, 0x0006 },
    { 0x0004, 0x0004, 0x0007 },
    { 0x0004, 0x0008, 0x0006 },
    { 0x0008, 0x0008, 0x0009 },
    { 0x0004, 0x0004, 0x0006 },
    { 0x0004, 0x0004, 0x000A },
    { 0x0004, 0x0004, 0x000B },
    { 0x0004, 0x0008, 0x0006 },
    { 0x0008, 0x0008, 0x000C },
    { 0x0004, 0x0004, 0x000B },
};

AnimationHeader gTwinmoldHeadStationaryAnim = { 
    { 41 }, sTwinmoldHeadStationaryAnimFrameData,
    sTwinmoldHeadStationaryAnimJointIndices, 13
};

Vtx object_boss02Vtx_004A30[] = {
#include "assets/objects/object_boss02/object_boss02Vtx_004A30.vtx.inc"
};

Gfx gTwinmoldHeadDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPVertex(object_boss02Vtx_004A30, 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsDPPipeSync(),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gTwinmoldEyeTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPClearGeometryMode(G_LIGHTING),
    gsSPVertex(&object_boss02Vtx_004A30[12], 17, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
    gsSP2Triangles(4, 3, 2, 0, 2, 5, 4, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 8, 0),
    gsSP2Triangles(8, 11, 9, 0, 8, 12, 13, 0),
    gsSP2Triangles(14, 12, 8, 0, 13, 15, 8, 0),
    gsSP2Triangles(8, 16, 14, 0, 8, 10, 6, 0),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPSetGeometryMode(G_LIGHTING),
    gsSPVertex(&object_boss02Vtx_004A30[29], 28, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(5, 6, 3, 0, 7, 8, 9, 0),
    gsSP2Triangles(10, 4, 11, 0, 7, 10, 12, 0),
    gsSP2Triangles(2, 13, 0, 0, 11, 12, 10, 0),
    gsSP2Triangles(7, 12, 14, 0, 15, 6, 2, 0),
    gsSP2Triangles(6, 5, 2, 0, 9, 16, 7, 0),
    gsSP2Triangles(2, 1, 15, 0, 14, 8, 7, 0),
    gsSP1Triangle(5, 4, 10, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSnoutTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSnoutTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(17, 18, 19, 0, 20, 19, 21, 0),
    gsSP2Triangles(21, 22, 20, 0, 20, 17, 19, 0),
    gsSP1Triangle(21, 23, 22, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldVeinsTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldVeinsTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(24, 25, 26, 0, 26, 27, 24, 0),
    gsSPVertex(&object_boss02Vtx_004A30[57], 28, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 4, 3, 0, 1, 0, 7, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gTwinmoldTeethTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(8, 9, 10, 0, 10, 11, 8, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(12, 13, 14, 0, 14, 15, 12, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(16, 17, 18, 0, 19, 20, 21, 0),
    gsSP2Triangles(22, 23, 24, 0, 25, 26, 27, 0),
    gsSPVertex(&object_boss02Vtx_004A30[85], 30, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(12, 13, 14, 0, 13, 12, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 19, 17, 16, 0),
    gsSP2Triangles(20, 21, 22, 0, 23, 20, 24, 0),
    gsSP2Triangles(25, 24, 26, 0, 22, 21, 27, 0),
    gsSP2Triangles(22, 27, 28, 0, 28, 29, 22, 0),
    gsSP2Triangles(22, 24, 20, 0, 24, 25, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldVeinsTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldVeinsTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_004A30[115], 28, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(2, 6, 0, 0, 5, 7, 3, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gTwinmoldEyeTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(8, 9, 10, 0, 11, 12, 13, 0),
    gsSP2Triangles(11, 13, 14, 0, 15, 9, 8, 0),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldVeinsTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldVeinsTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(16, 17, 18, 0, 19, 20, 21, 0),
    gsSP2Triangles(22, 23, 24, 0, 25, 26, 27, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldHeadLeftAntennaBackDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gTwinmoldAntennaTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPVertex(&object_boss02Vtx_004A30[299], 24, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
    gsSP2Triangles(18, 19, 20, 0, 21, 22, 23, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldHeadLeftAntennaFrontDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gTwinmoldAntennaTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPVertex(&object_boss02Vtx_004A30[275], 24, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
    gsSP2Triangles(18, 19, 20, 0, 21, 22, 23, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldHeadRightAntennaBackDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gTwinmoldAntennaTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPVertex(&object_boss02Vtx_004A30[347], 24, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
    gsSP2Triangles(18, 19, 20, 0, 21, 22, 23, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldHeadRightAntennaFrontDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gTwinmoldAntennaTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPVertex(&object_boss02Vtx_004A30[323], 24, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
    gsSP2Triangles(18, 19, 20, 0, 21, 22, 23, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldHeadLeftMandibleDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPVertex(&object_boss02Vtx_004A30[143], 30, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 4, 6, 0),
    gsSP2Triangles(8, 9, 10, 0, 11, 8, 10, 0),
    gsSP2Triangles(12, 13, 14, 0, 15, 12, 14, 0),
    gsSP2Triangles(16, 17, 18, 0, 19, 20, 21, 0),
    gsSP2Triangles(22, 23, 24, 0, 25, 22, 24, 0),
    gsSP2Triangles(26, 27, 28, 0, 29, 26, 28, 0),
    gsSPVertex(&object_boss02Vtx_004A30[173], 30, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 4, 6, 0),
    gsSP2Triangles(8, 9, 10, 0, 11, 12, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldVeinsTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldVeinsTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 23, 20, 22, 0),
    gsSP2Triangles(24, 25, 26, 0, 27, 28, 29, 0),
    gsSPVertex(&object_boss02Vtx_004A30[203], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldHeadRightMandibleDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPVertex(&object_boss02Vtx_004A30[209], 30, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 19, 20, 21, 0),
    gsSP2Triangles(22, 23, 24, 0, 22, 24, 25, 0),
    gsSP2Triangles(26, 27, 28, 0, 26, 28, 29, 0),
    gsSPVertex(&object_boss02Vtx_004A30[239], 30, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP2Triangles(8, 9, 10, 0, 11, 12, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldVeinsTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldVeinsTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
    gsSP2Triangles(24, 25, 26, 0, 27, 28, 29, 0),
    gsSPVertex(&object_boss02Vtx_004A30[269], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSPEndDisplayList(),
};

Vtx object_boss02Vtx_006E10[] = {
#include "assets/objects/object_boss02/object_boss02Vtx_006E10.vtx.inc"
};

Gfx gTwinmoldRuinPyramidDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldRuinPyramidTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldRuinPyramidTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR
                            | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x01FC),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_boss02Vtx_006E10, 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSPVertex(&object_boss02Vtx_006E10[8], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPLoadTLUT_pal16(15, gTwinmoldRuinPillarTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldRuinPillarTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_006E10[16], 12, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 0, 0),
    gsSP2Triangles(5, 6, 7, 0, 0, 4, 8, 0),
    gsSP2Triangles(2, 9, 0, 0, 10, 2, 1, 0),
    gsSP2Triangles(8, 10, 1, 0, 1, 0, 8, 0),
    gsSP2Triangles(7, 11, 5, 0, 0, 9, 3, 0),
    gsSPEndDisplayList(),
};

u64 gTwinmoldRuinPyramidTLUT[] = {
#include "assets/objects/object_boss02/ruin_pyramid_tlut.rgba16.inc.c"
};

u64 gTwinmoldRuinPyramidTex[] = {
#include "assets/objects/object_boss02/ruin_pyramid.ci4.inc.c"
};

Vtx object_boss02Vtx_007978[] = {
#include "assets/objects/object_boss02/object_boss02Vtx_007978.vtx.inc"
};

Gfx gRuinFragmentDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldRuinPillarTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldRuinPillarTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_boss02Vtx_007978, 17, 0),
    gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 8, 9, 0),
    gsSP2Triangles(1, 10, 2, 0, 10, 1, 3, 0),
    gsSP2Triangles(11, 12, 13, 0, 14, 15, 16, 0),
    gsSPEndDisplayList(),
};

Vtx object_boss02Vtx_007B58[] = {
#include "assets/objects/object_boss02/object_boss02Vtx_007B58.vtx.inc"
};

Gfx gTwinmoldRuinPillarDL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldRuinPillarTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldRuinPillarTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_boss02Vtx_007B58, 11, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 2, 1, 0),
    gsSP2Triangles(4, 5, 6, 0, 7, 3, 1, 0),
    gsSP1Triangle(8, 9, 10, 0),
    gsDPSetTileSize(G_TX_RENDERTILE, 0, 0, 0x00FC, 0x02FC),
    gsDPSetPrimColor(0, 0x80, 255, 252, 255, 255),
    gsSPVertex(&object_boss02Vtx_007B58[11], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPVertex(&object_boss02Vtx_007B58[19], 9, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSP1Triangle(4, 8, 5, 0),
    gsSPEndDisplayList(),
};

u64 gTwinmoldRuinPillarTLUT[] = {
#include "assets/objects/object_boss02/ruin_pillar_tlut.rgba16.inc.c"
};

u64 gTwinmoldRuinPillarTex[] = {
#include "assets/objects/object_boss02/ruin_pillar.ci4.inc.c"
};

u64 gTwinmoldTitleCardTex[] = {
#include "assets/objects/object_boss02/twinmold_title_card.ia8.inc.c"
};

StandardLimb gTwinmoldHeadRootLimb = { 
    { 3, -32, -478 }, TWINMOLD_HEAD_LIMB_HEAD - 1, LIMB_DONE,
    NULL
};

StandardLimb gTwinmoldHeadLimb = { 
    { 0, 0, 0 }, TWINMOLD_HEAD_LIMB_RIGHT_MANDIBLE_ROOT - 1, LIMB_DONE,
    gTwinmoldHeadDL
};

StandardLimb gTwinmoldHeadRightMandibleRootLimb = { 
    { 681, -204, -20 }, TWINMOLD_HEAD_LIMB_RIGHT_MANDIBLE - 1, TWINMOLD_HEAD_LIMB_LEFT_MANDIBLE_ROOT - 1,
    NULL
};

StandardLimb gTwinmoldHeadRightMandibleLimb = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gTwinmoldHeadRightMandibleDL
};

StandardLimb gTwinmoldHeadLeftMandibleRootLimb = { 
    { 679, 203, -20 }, TWINMOLD_HEAD_LIMB_LEFT_MANDIBLE - 1, TWINMOLD_HEAD_LIMB_RIGHT_ANTENNA_ROOT - 1,
    NULL
};

StandardLimb gTwinmoldHeadLeftMandibleLimb = { 
    { 0, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gTwinmoldHeadLeftMandibleDL
};

StandardLimb gTwinmoldHeadRightAntennaRootLimb = { 
    { 829, -56, -48 }, TWINMOLD_HEAD_LIMB_RIGHT_ANTENNA_BACK - 1, TWINMOLD_HEAD_LIMB_LEFT_ANTENNA_ROOT - 1,
    NULL
};

StandardLimb gTwinmoldHeadRightAntennaBackLimb = { 
    { 0, 0, 0 }, TWINMOLD_HEAD_LIMB_RIGHT_ANTENNA_FRONT - 1, LIMB_DONE,
    gTwinmoldHeadRightAntennaBackDL
};

StandardLimb gTwinmoldHeadRightAntennaFrontLimb = { 
    { 242, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gTwinmoldHeadRightAntennaFrontDL
};

StandardLimb gTwinmoldHeadLeftAntennaRootLimb = { 
    { 828, 56, -48 }, TWINMOLD_HEAD_LIMB_LEFT_ANTENNA_BACK - 1, LIMB_DONE,
    NULL
};

StandardLimb gTwinmoldHeadLeftAntennaBackLimb = { 
    { 0, 0, 0 }, TWINMOLD_HEAD_LIMB_LEFT_ANTENNA_FRONT - 1, LIMB_DONE,
    gTwinmoldHeadLeftAntennaBackDL
};

StandardLimb gTwinmoldHeadLeftAntennaFrontLimb = { 
    { 242, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gTwinmoldHeadLeftAntennaFrontDL
};

void* gTwinmoldHeadSkelLimbs[] = {
    &gTwinmoldHeadRootLimb, /* TWINMOLD_HEAD_LIMB_ROOT */
    &gTwinmoldHeadLimb, /* TWINMOLD_HEAD_LIMB_HEAD */
    &gTwinmoldHeadRightMandibleRootLimb, /* TWINMOLD_HEAD_LIMB_RIGHT_MANDIBLE_ROOT */
    &gTwinmoldHeadRightMandibleLimb, /* TWINMOLD_HEAD_LIMB_RIGHT_MANDIBLE */
    &gTwinmoldHeadLeftMandibleRootLimb, /* TWINMOLD_HEAD_LIMB_LEFT_MANDIBLE_ROOT */
    &gTwinmoldHeadLeftMandibleLimb, /* TWINMOLD_HEAD_LIMB_LEFT_MANDIBLE */
    &gTwinmoldHeadRightAntennaRootLimb, /* TWINMOLD_HEAD_LIMB_RIGHT_ANTENNA_ROOT */
    &gTwinmoldHeadRightAntennaBackLimb, /* TWINMOLD_HEAD_LIMB_RIGHT_ANTENNA_BACK */
    &gTwinmoldHeadRightAntennaFrontLimb, /* TWINMOLD_HEAD_LIMB_RIGHT_ANTENNA_FRONT */
    &gTwinmoldHeadLeftAntennaRootLimb, /* TWINMOLD_HEAD_LIMB_LEFT_ANTENNA_ROOT */
    &gTwinmoldHeadLeftAntennaBackLimb, /* TWINMOLD_HEAD_LIMB_LEFT_ANTENNA_BACK */
    &gTwinmoldHeadLeftAntennaFrontLimb, /* TWINMOLD_HEAD_LIMB_LEFT_ANTENNA_FRONT */
};

SkeletonHeader gTwinmoldHeadSkel = { 
    gTwinmoldHeadSkelLimbs, ARRAY_COUNT(gTwinmoldHeadSkelLimbs)
};

u8 object_boss02_possiblePadding_009B18[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

s16 sTwinmoldHeadFlyAnimFrameData[] = {
    0x0003, 0xFFE0, 0xFE22, 0xC000, 0x0000, 0xBFE0, 0x4020, 0x8000, 0xBF9F, 0x00CC, 0x3F9F, 0x92EA, 0x920C, 0x9099, 
    0x904F, 0x92EA, 0x9A38, 0xA4F0, 0xB02D, 0xB90A, 0xBCA3, 0xBBAA, 0xB900, 0xB505, 0xB019, 0xAA9D, 0xA4F0, 0x9F74, 
    0x9A88, 0x968D, 0x93E3, 0x12EA, 0x120C, 0x1099, 0x104F, 0x12EA, 0x1A38, 0x24F0, 0x302D, 0x390A, 0x3CA3, 0x3BAA, 
    0x3900, 0x3505, 0x3019, 0x2A9D, 0x24F0, 0x1F74, 0x1A88, 0x168D, 0x13E3, 0xF2F6, 0xF79F, 0x01E0, 0x0C20, 0x10C9, 
    0x0DAF, 0x064A, 0xFD76, 0xF610, 0xF2F6, 0xF610, 0xFD76, 0x064A, 0x0DAF, 0x10C9, 0x0E94, 0x090E, 0x01E0, 0xFAB2, 
    0xF52C, 0xEEBA, 0xF44A, 0x0088, 0x0CC5, 0x1256, 0x0EA2, 0x05CD, 0xFB42, 0xF26E, 0xEEBA, 0xF26E, 0xFB42, 0x05CD, 
    0x0EA2, 0x1256, 0x0FB2, 0x091A, 0x0088, 0xF7F5, 0xF15D, 0x8D0A, 0x8861, 0x7E20, 0x73E0, 0x6F37, 0x7251, 0x79B6, 
    0x828A, 0x89F0, 0x8D0A, 0x89F0, 0x828A, 0x79B6, 0x7251, 0x6F37, 0x716C, 0x76F2, 0x7E20, 0x854E, 0x8AD4, 0xEEBA, 
    0xF44A, 0x0088, 0x0CC5, 0x1256, 0x0EA2, 0x05CD, 0xFB42, 0xF26E, 0xEEBA, 0xF26E, 0xFB42, 0x05CD, 0x0EA2, 0x1256, 
    0x0FB2, 0x091A, 0x0088, 0xF7F5, 0xF15D, 0x0000, 
};

JointIndex sTwinmoldHeadFlyAnimJointIndices[] = {
    { 0x0000, 0x0001, 0x0002 },
    { 0x0003, 0x0004, 0x0004 },
    { 0x0004, 0x0004, 0x0005 },
    { 0x0004, 0x0004, 0x0006 },
    { 0x0004, 0x0004, 0x000B },
    { 0x0004, 0x0007, 0x0006 },
    { 0x0007, 0x0007, 0x001F },
    { 0x0004, 0x0004, 0x0006 },
    { 0x0004, 0x0033, 0x0008 },
    { 0x0004, 0x0047, 0x0009 },
    { 0x0004, 0x0007, 0x0006 },
    { 0x0007, 0x005B, 0x000A },
    { 0x0004, 0x006F, 0x0009 },
};

AnimationHeader gTwinmoldHeadFlyAnim = { 
    { 20 }, sTwinmoldHeadFlyAnimFrameData,
    sTwinmoldHeadFlyAnimJointIndices, 11
};

u8 object_boss02_possiblePadding_009C88[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

AnimatedMaterial gTwinmoldUnusedTexAnim[] = {
    { 0, 6, NULL },
};

u8 object_boss02_possiblePadding_009C98[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
};

Vtx object_boss02Vtx_009CA0[] = {
#include "assets/objects/object_boss02/object_boss02Vtx_009CA0.vtx.inc"
};

Gfx gTwinmoldBodySegment1DL[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPClearGeometryMode(G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPVertex(&object_boss02Vtx_009CA0[1235], 26, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 0, 0, 1, 0, 7, 0),
    gsSP2Triangles(8, 2, 1, 0, 5, 4, 0, 0),
    gsSP2Triangles(5, 0, 2, 0, 9, 10, 11, 0),
    gsSP2Triangles(3, 11, 10, 0, 12, 13, 3, 0),
    gsSP2Triangles(11, 3, 13, 0, 0, 4, 14, 0),
    gsSP2Triangles(4, 10, 6, 0, 6, 10, 7, 0),
    gsSP2Triangles(15, 1, 16, 0, 16, 7, 17, 0),
    gsSP2Triangles(10, 4, 3, 0, 7, 16, 1, 0),
    gsSP2Triangles(1, 15, 8, 0, 3, 5, 12, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(18, 19, 20, 0, 19, 21, 22, 0),
    gsSP2Triangles(22, 23, 19, 0, 20, 19, 23, 0),
    gsSP2Triangles(23, 24, 20, 0, 23, 25, 24, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[1261], 24, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 8, 9, 10, 0),
    gsSP2Triangles(5, 11, 12, 0, 13, 14, 15, 0),
    gsSP2Triangles(15, 16, 17, 0, 2, 18, 19, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldVeinsTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldVeinsTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(20, 21, 22, 0, 22, 23, 20, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment2DL[] = {
    gsSPMatrix(0x0D000000, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[1172], 10, 0),
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[1182], 18, 10),
    gsSP2Triangles(10, 0, 11, 0, 12, 13, 0, 0),
    gsSP2Triangles(4, 3, 14, 0, 15, 16, 3, 0),
    gsSP2Triangles(17, 3, 18, 0, 19, 3, 0, 0),
    gsSP2Triangles(20, 0, 2, 0, 3, 21, 22, 0),
    gsSP1Triangle(0, 23, 24, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(25, 9, 7, 0, 7, 26, 27, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[1200], 21, 10),
    gsSP2Triangles(10, 8, 11, 0, 1, 12, 13, 0),
    gsSP2Triangles(14, 15, 5, 0, 16, 6, 17, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(18, 19, 20, 0, 21, 22, 23, 0),
    gsSP2Triangles(24, 20, 19, 0, 23, 22, 18, 0),
    gsSP2Triangles(23, 18, 20, 0, 25, 26, 21, 0),
    gsSP2Triangles(27, 21, 26, 0, 18, 22, 28, 0),
    gsSP2Triangles(29, 19, 30, 0, 19, 29, 24, 0),
    gsSP1Triangle(21, 23, 25, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[1221], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment3DL[] = {
    gsSPMatrix(0x0D000040, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[1113], 6, 0),
    gsSPMatrix(0x0D000080, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[1119], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[1137], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[1158], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment4DL[] = {
    gsSPMatrix(0x0D000080, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[1054], 6, 0),
    gsSPMatrix(0x0D0000C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[1060], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[1078], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[1099], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment5DL[] = {
    gsSPMatrix(0x0D0000C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[995], 6, 0),
    gsSPMatrix(0x0D000100, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[1001], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[1019], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[1040], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment6DL[] = {
    gsSPMatrix(0x0D000100, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[936], 6, 0),
    gsSPMatrix(0x0D000140, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[942], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[960], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[981], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment7DL[] = {
    gsSPMatrix(0x0D000140, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[877], 6, 0),
    gsSPMatrix(0x0D000180, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[883], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[901], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[922], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment8DL[] = {
    gsSPMatrix(0x0D000180, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[818], 6, 0),
    gsSPMatrix(0x0D0001C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[824], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[842], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[863], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment9DL[] = {
    gsSPMatrix(0x0D0001C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[759], 6, 0),
    gsSPMatrix(0x0D000200, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[765], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[783], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[804], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment10DL[] = {
    gsSPMatrix(0x0D000200, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[700], 6, 0),
    gsSPMatrix(0x0D000240, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[706], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[724], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[745], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment11DL[] = {
    gsSPMatrix(0x0D000240, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[641], 6, 0),
    gsSPMatrix(0x0D000280, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[647], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[665], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[686], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment12DL[] = {
    gsSPMatrix(0x0D000280, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[582], 6, 0),
    gsSPMatrix(0x0D0002C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[588], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[606], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[627], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment13DL[] = {
    gsSPMatrix(0x0D0002C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[523], 6, 0),
    gsSPMatrix(0x0D000300, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[529], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[547], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[568], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment14DL[] = {
    gsSPMatrix(0x0D000300, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[464], 6, 0),
    gsSPMatrix(0x0D000340, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[470], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[488], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[509], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment15DL[] = {
    gsSPMatrix(0x0D000340, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[405], 6, 0),
    gsSPMatrix(0x0D000380, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[411], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[429], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[450], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment16DL[] = {
    gsSPMatrix(0x0D000380, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[346], 6, 0),
    gsSPMatrix(0x0D0003C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[352], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[370], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[391], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment17DL[] = {
    gsSPMatrix(0x0D0003C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[287], 6, 0),
    gsSPMatrix(0x0D000400, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[293], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[311], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[332], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment18DL[] = {
    gsSPMatrix(0x0D000400, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[228], 6, 0),
    gsSPMatrix(0x0D000440, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[234], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[252], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[273], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment19DL[] = {
    gsSPMatrix(0x0D000440, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[169], 6, 0),
    gsSPMatrix(0x0D000480, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[175], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[193], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[214], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment20DL[] = {
    gsSPMatrix(0x0D000480, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[110], 6, 0),
    gsSPMatrix(0x0D0004C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[116], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[134], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[155], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodySegment21DL[] = {
    gsSPMatrix(0x0D0004C0, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(&object_boss02Vtx_009CA0[51], 6, 0),
    gsSPMatrix(0x0D000500, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[57], 18, 6),
    gsSP2Triangles(6, 0, 7, 0, 8, 9, 0, 0),
    gsSP2Triangles(5, 1, 10, 0, 11, 12, 1, 0),
    gsSP2Triangles(13, 1, 14, 0, 15, 1, 0, 0),
    gsSP2Triangles(16, 0, 2, 0, 1, 17, 18, 0),
    gsSP1Triangle(0, 19, 20, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(21, 2, 5, 0, 5, 22, 23, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[75], 21, 6),
    gsSP2Triangles(6, 3, 7, 0, 3, 8, 9, 0),
    gsSP2Triangles(10, 11, 4, 0, 12, 4, 13, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
    gsSP2Triangles(20, 16, 15, 0, 19, 18, 14, 0),
    gsSP2Triangles(19, 14, 16, 0, 21, 22, 17, 0),
    gsSP2Triangles(23, 17, 22, 0, 14, 18, 24, 0),
    gsSP2Triangles(25, 15, 26, 0, 15, 25, 20, 0),
    gsSP1Triangle(17, 19, 21, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[96], 14, 0),
    gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
    gsSP2Triangles(3, 4, 2, 0, 3, 5, 4, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
    gsSP2Triangles(12, 11, 10, 0, 7, 6, 13, 0),
    gsSPEndDisplayList(),
};

Gfx gTwinmoldBodyTailDL[] = {
    gsSPMatrix(0x0D000500, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsSPVertex(object_boss02Vtx_009CA0, 6, 0),
    gsSPMatrix(0x0D000540, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSkinTLUT),
    gsDPLoadTextureBlock_4b(0x08000000, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR | G_TX_CLAMP,
                            6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPVertex(&object_boss02Vtx_009CA0[6], 12, 6),
    gsSP2Triangles(0, 1, 6, 0, 2, 0, 7, 0),
    gsSP2Triangles(8, 9, 0, 0, 10, 1, 4, 0),
    gsSP2Triangles(11, 12, 1, 0, 13, 14, 4, 0),
    gsSP1Triangle(15, 16, 2, 0),
    gsDPPipeSync(),
    gsDPLoadTLUT_pal16(15, gTwinmoldUndersideTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldUndersideTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP, G_TX_NOMIRROR |
                            G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Triangle(17, 5, 3, 0),
    gsDPPipeSync(),
    gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(gTwinmoldTailGemTex, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsSPClearGeometryMode(G_LIGHTING),
    gsSPVertex(&object_boss02Vtx_009CA0[18], 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 0, 0),
    gsSP2Triangles(5, 4, 3, 0, 2, 1, 5, 0),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, gTwinmoldSpikeAndMandibleTLUT),
    gsDPLoadTextureBlock_4b(gTwinmoldSpikeAndMandibleTex, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_CLAMP,
                            G_TX_NOMIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsSPSetGeometryMode(G_LIGHTING),
    gsSPVertex(&object_boss02Vtx_009CA0[24], 27, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
    gsSP2Triangles(6, 7, 8, 0, 2, 9, 0, 0),
    gsSP2Triangles(8, 10, 11, 0, 5, 12, 3, 0),
    gsSP2Triangles(11, 13, 8, 0, 8, 14, 6, 0),
    gsSP2Triangles(15, 16, 17, 0, 18, 19, 20, 0),
    gsSP2Triangles(17, 16, 21, 0, 22, 19, 18, 0),
    gsSP2Triangles(17, 21, 23, 0, 24, 15, 17, 0),
    gsSP2Triangles(18, 20, 25, 0, 26, 22, 18, 0),
    gsSPEndDisplayList(),
};

StandardLimb gTwinmoldBodyRootLimb = { 
    { 0, 0, 171 }, TWINMOLD_BODY_LIMB_SEGMENT_1 - 1, LIMB_DONE,
    NULL
};

StandardLimb gTwinmoldBodySegment1Limb = { 
    { 0, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_2 - 1, LIMB_DONE,
    gTwinmoldBodySegment1DL
};

StandardLimb gTwinmoldBodySegment2Limb = { 
    { 427, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_3 - 1, LIMB_DONE,
    gTwinmoldBodySegment2DL
};

StandardLimb gTwinmoldBodySegment3Limb = { 
    { 432, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_4 - 1, LIMB_DONE,
    gTwinmoldBodySegment3DL
};

StandardLimb gTwinmoldBodySegment4Limb = { 
    { 427, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_5 - 1, LIMB_DONE,
    gTwinmoldBodySegment4DL
};

StandardLimb gTwinmoldBodySegment5Limb = { 
    { 425, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_6 - 1, LIMB_DONE,
    gTwinmoldBodySegment5DL
};

StandardLimb gTwinmoldBodySegment6Limb = { 
    { 429, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_7 - 1, LIMB_DONE,
    gTwinmoldBodySegment6DL
};

StandardLimb gTwinmoldBodySegment7Limb = { 
    { 432, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_8 - 1, LIMB_DONE,
    gTwinmoldBodySegment7DL
};

StandardLimb gTwinmoldBodySegment8Limb = { 
    { 427, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_9 - 1, LIMB_DONE,
    gTwinmoldBodySegment8DL
};

StandardLimb gTwinmoldBodySegment9Limb = { 
    { 425, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_10 - 1, LIMB_DONE,
    gTwinmoldBodySegment9DL
};

StandardLimb gTwinmoldBodySegment10Limb = { 
    { 427, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_11 - 1, LIMB_DONE,
    gTwinmoldBodySegment10DL
};

StandardLimb gTwinmoldBodySegment11Limb = { 
    { 429, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_12 - 1, LIMB_DONE,
    gTwinmoldBodySegment11DL
};

StandardLimb gTwinmoldBodySegment12Limb = { 
    { 429, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_13 - 1, LIMB_DONE,
    gTwinmoldBodySegment12DL
};

StandardLimb gTwinmoldBodySegment13Limb = { 
    { 425, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_14 - 1, LIMB_DONE,
    gTwinmoldBodySegment13DL
};

StandardLimb gTwinmoldBodySegment14Limb = { 
    { 424, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_15 - 1, LIMB_DONE,
    gTwinmoldBodySegment14DL
};

StandardLimb gTwinmoldBodySegment15Limb = { 
    { 427, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_16 - 1, LIMB_DONE,
    gTwinmoldBodySegment15DL
};

StandardLimb gTwinmoldBodySegment16Limb = { 
    { 427, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_17 - 1, LIMB_DONE,
    gTwinmoldBodySegment16DL
};

StandardLimb gTwinmoldBodySegment17Limb = { 
    { 425, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_18 - 1, LIMB_DONE,
    gTwinmoldBodySegment17DL
};

StandardLimb gTwinmoldBodySegment18Limb = { 
    { 427, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_19 - 1, LIMB_DONE,
    gTwinmoldBodySegment18DL
};

StandardLimb gTwinmoldBodySegment19Limb = { 
    { 425, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_20 - 1, LIMB_DONE,
    gTwinmoldBodySegment19DL
};

StandardLimb gTwinmoldBodySegment20Limb = { 
    { 425, 0, 0 }, TWINMOLD_BODY_LIMB_SEGMENT_21 - 1, LIMB_DONE,
    gTwinmoldBodySegment20DL
};

StandardLimb gTwinmoldBodySegment21Limb = { 
    { 429, 0, 0 }, TWINMOLD_BODY_LIMB_TAIL - 1, LIMB_DONE,
    gTwinmoldBodySegment21DL
};

StandardLimb gTwinmoldBodyTailLimb = { 
    { 429, 0, 0 }, LIMB_DONE, LIMB_DONE,
    gTwinmoldBodyTailDL
};

void* gTwinmoldBodySkelLimbs[] = {
    &gTwinmoldBodyRootLimb, /* TWINMOLD_BODY_LIMB_ROOT */
    &gTwinmoldBodySegment1Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_1 */
    &gTwinmoldBodySegment2Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_2 */
    &gTwinmoldBodySegment3Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_3 */
    &gTwinmoldBodySegment4Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_4 */
    &gTwinmoldBodySegment5Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_5 */
    &gTwinmoldBodySegment6Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_6 */
    &gTwinmoldBodySegment7Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_7 */
    &gTwinmoldBodySegment8Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_8 */
    &gTwinmoldBodySegment9Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_9 */
    &gTwinmoldBodySegment10Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_10 */
    &gTwinmoldBodySegment11Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_11 */
    &gTwinmoldBodySegment12Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_12 */
    &gTwinmoldBodySegment13Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_13 */
    &gTwinmoldBodySegment14Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_14 */
    &gTwinmoldBodySegment15Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_15 */
    &gTwinmoldBodySegment16Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_16 */
    &gTwinmoldBodySegment17Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_17 */
    &gTwinmoldBodySegment18Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_18 */
    &gTwinmoldBodySegment19Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_19 */
    &gTwinmoldBodySegment20Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_20 */
    &gTwinmoldBodySegment21Limb, /* TWINMOLD_BODY_LIMB_SEGMENT_21 */
    &gTwinmoldBodyTailLimb, /* TWINMOLD_BODY_LIMB_TAIL */
};

FlexSkeletonHeader gTwinmoldBodySkel = { 
    { gTwinmoldBodySkelLimbs, ARRAY_COUNT(gTwinmoldBodySkelLimbs) }, 22
};

