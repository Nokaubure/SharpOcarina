#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_astr_obj.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 object_astr_obj_TLUT_000000[] = {
#include "assets/objects/object_astr_obj/tlut_000000.rgba16.inc.c"
};

u64 object_astr_obj_Tex_000020[] = {
#include "assets/objects/object_astr_obj/tex_000020.rgba16.inc.c"
};

u64 object_astr_obj_Tex_000820[] = {
#include "assets/objects/object_astr_obj/tex_000820.ci4.inc.c"
};

u64 object_astr_obj_Tex_001020[] = {
#include "assets/objects/object_astr_obj/tex_001020.ia8.inc.c"
};

Vtx object_astr_objVtx_002020[] = {
#include "assets/objects/object_astr_obj/object_astr_objVtx_002020.vtx.inc"
};

Gfx object_astr_obj_DL_002170[] = {
    gsSPEndDisplayList(),
};

Gfx object_astr_obj_DL_002178[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(object_astr_obj_Tex_000020, G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPLoadGeometryMode(G_ZBUFFER | G_SHADE | G_CULL_BACK | G_FOG | G_LIGHTING | G_SHADING_SMOOTH),
    gsSPVertex(object_astr_objVtx_002020, 21, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(3, 4, 5, 0, 3, 5, 0, 0),
    gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
    gsSP2Triangles(10, 11, 12, 0, 10, 12, 6, 0),
    gsSP2Triangles(13, 14, 15, 0, 13, 15, 16, 0),
    gsSP2Triangles(17, 18, 19, 0, 17, 19, 20, 0),
    gsSPEndDisplayList(),
};

Vtx object_astr_objVtx_002230[] = {
#include "assets/objects/object_astr_obj/object_astr_objVtx_002230.vtx.inc"
};

Gfx object_astr_obj_DL_0022E0[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_XLU_DECAL2),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_NONE),
    gsDPLoadTextureBlock(object_astr_obj_Tex_001020, G_IM_FMT_IA, G_IM_SIZ_8b, 64, 64, 0, G_TX_MIRROR | G_TX_CLAMP,
                         G_TX_MIRROR | G_TX_CLAMP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 216),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPClearGeometryMode(G_CULL_FRONT | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPVertex(&object_astr_objVtx_002230[6], 5, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
    gsSP2Triangles(2, 1, 4, 0, 3, 2, 4, 0),
    gsSPEndDisplayList(),
};

Gfx object_astr_obj_DL_002380[] = {
    gsSPTexture(0xFFFF, 0xFFFF, 0, G_TX_RENDERTILE, G_ON),
    gsDPPipeSync(),
    gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, 0, 0, 0, COMBINED),
    gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
    gsDPPipeSync(),
    gsDPSetTextureLUT(G_TT_RGBA16),
    gsDPLoadTLUT_pal16(15, object_astr_obj_TLUT_000000),
    gsDPLoadTextureBlock_4b(object_astr_obj_Tex_000820, G_IM_FMT_CI, 64, 64, 15, G_TX_NOMIRROR | G_TX_WRAP,
                            G_TX_NOMIRROR | G_TX_WRAP, 6, 6, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),
    gsSPSetGeometryMode(G_CULL_BACK | G_FOG | G_LIGHTING),
    gsSPClearGeometryMode(G_CULL_FRONT | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),
    gsSPVertex(object_astr_objVtx_002230, 6, 0),
    gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
    gsSP2Triangles(0, 4, 5, 0, 4, 3, 5, 0),
    gsSPEndDisplayList(),
};

CamData object_astr_obj_Colheader_002498CamDataList[] = {
    { 0x0000, 0, NULL },
};

SurfaceType object_astr_obj_Colheader_002498SurfaceType[] = {
    {0x00000000, 0x000007CB},
};

CollisionPoly object_astr_obj_Colheader_002498Polygons[] = {
    {0x0000, 0x0000, 0x0001, 0x0002, 0x0000, 0x0000, 0x7FFF, 0x0000},
    {0x0000, 0x0000, 0x0002, 0x0003, 0x0000, 0x0000, 0x7FFF, 0x0000},
};

Vec3s object_astr_obj_Colheader_002498Vertices[] = {
    {     70,      0,      0 },
    {     70,    200,      0 },
    {    -70,    200,      0 },
    {    -70,      0,      0 },
};

CollisionHeader object_astr_obj_Colheader_002498 = { 
    { -70, 0, 0 },
    { 70, 200, 0 },
    ARRAY_COUNT(object_astr_obj_Colheader_002498Vertices), object_astr_obj_Colheader_002498Vertices,
    ARRAY_COUNT(object_astr_obj_Colheader_002498Polygons), object_astr_obj_Colheader_002498Polygons,
    object_astr_obj_Colheader_002498SurfaceType,
    object_astr_obj_Colheader_002498CamDataList,
    0, NULL
};

