#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "debug_display.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

Vtx sDebugDisplay1Vtx[] = {
#include "assets/code/debug_display/sDebugDisplay1Vtx.vtx.inc"
};

Gfx sDebugDisplay1DL[] = {
    gsSPVertex(sDebugDisplay1Vtx, 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
    gsSP2Triangles(8, 9, 10, 0, 8, 11, 9, 0),
    gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
    gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
    gsSP2Triangles(20, 21, 22, 0, 23, 24, 25, 0),
    gsSP2Triangles(26, 23, 25, 0, 24, 26, 25, 0),
    gsSP2Triangles(27, 28, 29, 0, 30, 31, 29, 0),
    gsSPVertex(&sDebugDisplay1Vtx[32], 4, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSPEndDisplayList(),
};

Vtx sDebugDisplay2Vtx[] = {
#include "assets/code/debug_display/sDebugDisplay2Vtx.vtx.inc"
};

Gfx sDebugDisplay2DL[] = {
    gsDPPipeSync(),
    gsSPSetGeometryMode(G_CULL_BACK),
    gsSPVertex(sDebugDisplay2Vtx, 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 3, 2, 1, 0),
    gsSP2Triangles(4, 6, 5, 0, 7, 5, 6, 0),
    gsSP2Triangles(7, 3, 5, 0, 1, 5, 3, 0),
    gsSP2Triangles(6, 4, 2, 0, 0, 2, 4, 0),
    gsSP2Triangles(6, 2, 7, 0, 3, 7, 2, 0),
    gsSP2Triangles(5, 1, 4, 0, 0, 4, 1, 0),
    gsSPEndDisplayList(),
};

Vtx sDebugDisplay3Vtx[] = {
#include "assets/code/debug_display/sDebugDisplay3Vtx.vtx.inc"
};

Gfx sDebugDisplay3DL[] = {
    gsSPVertex(sDebugDisplay3Vtx, 32, 0),
    gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
    gsSP2Triangles(3, 4, 2, 0, 5, 0, 2, 0),
    gsSP2Triangles(4, 6, 2, 0, 6, 5, 2, 0),
    gsSP2Triangles(7, 8, 9, 0, 8, 10, 11, 0),
    gsSP2Triangles(8, 11, 12, 0, 7, 10, 8, 0),
    gsSP2Triangles(13, 14, 15, 0, 13, 15, 16, 0),
    gsSP2Triangles(17, 18, 19, 0, 17, 20, 18, 0),
    gsSP2Triangles(21, 22, 23, 0, 22, 24, 23, 0),
    gsSP2Triangles(25, 26, 23, 0, 26, 27, 23, 0),
    gsSP2Triangles(27, 28, 29, 0, 30, 31, 29, 0),
    gsSPVertex(&sDebugDisplay3Vtx[32], 8, 0),
    gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
    gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
    gsSPEndDisplayList(),
};

u64 sDebugDisplayCircleTex[] = {
#include "assets/code/debug_display/debug_circle.i8.inc.c"
};

u64 sDebugDisplayBallTex[] = {
#include "assets/code/debug_display/debug_ball.i8.inc.c"
};

u64 sDebugDisplayCursorTex[] = {
#include "assets/code/debug_display/debug_cursor.i8.inc.c"
};

u64 sDebugDisplayCrossTex[] = {
#include "assets/code/debug_display/debug_cross.i8.inc.c"
};

Vtx sDebugDisplaySpriteVtx[] = {
#include "assets/code/debug_display/sDebugDisplaySpriteVtx.vtx.inc"
};

Gfx sDebugDisplaySpriteDL[] = {
    gsSPVertex(sDebugDisplaySpriteVtx, 4, 0),
    gsSP2Triangles(0, 2, 1, 0, 1, 2, 3, 0),
    gsSPEndDisplayList(),
};

