#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "eff_footmark.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

Vtx gEffFootprintVtx[] = {
#include "assets/code/eff_footmark/gEffFootprintVtx.vtx.inc"
};

Gfx gEffFootprintMaterialDL[] = {
    gsDPLoadTextureBlock(gameplay_keep_Tex_076C40, G_IM_FMT_IA, G_IM_SIZ_16b, 32, 32, 0, G_TX_NOMIRROR | G_TX_CLAMP,
                         G_TX_NOMIRROR | G_TX_CLAMP, 5, 5, G_TX_NOLOD, G_TX_NOLOD),
    gsDPSetCombineLERP(0, 0, 0, PRIMITIVE, TEXEL0, 0, PRIMITIVE, 0, COMBINED, 0, SHADE, 0, 0, 0, 0, COMBINED),
    gsSPEndDisplayList(),
};

Gfx gEffFootprintModelDL[] = {
    gsSPVertex(gEffFootprintVtx, 3, 0),
    gsSP1Triangle(0, 1, 2, 0),
    gsSPEndDisplayList(),
};

