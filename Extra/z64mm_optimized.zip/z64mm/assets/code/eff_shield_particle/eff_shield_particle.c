#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "eff_shield_particle.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

Vtx sEffShieldParticleVtx[] = {
#include "assets/code/eff_shield_particle/sEffShieldParticleVtx.vtx.inc"
};

