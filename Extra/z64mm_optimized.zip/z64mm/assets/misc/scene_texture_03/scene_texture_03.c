#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "scene_texture_03.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u8 scene_texture_03_Blob_002D40[] = {
#include "assets/misc/scene_texture_03/scene_texture_03_Blob_002D40.bin.inc.c"
};

