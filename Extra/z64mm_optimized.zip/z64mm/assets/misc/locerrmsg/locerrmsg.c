#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "locerrmsg.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gNotDesignedForSystemErrorTex[] = {
#include "assets/misc/locerrmsg/not_designed_for_system_error.i4.inc.c"
};

