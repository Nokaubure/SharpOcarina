#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "ger_daytelop_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gDaytelopFirstDayLeftGERTex[] = {
#include "assets/misc/ger_daytelop_static/first_day_left_ger.i4.inc.c"
};

u64 gDaytelopFirstDayRightGERTex[] = {
#include "assets/misc/ger_daytelop_static/first_day_right_ger.i4.inc.c"
};

u64 gDaytelopSecondDayLeftGERTex[] = {
#include "assets/misc/ger_daytelop_static/second_day_left_ger.i4.inc.c"
};

u64 gDaytelopSecondDayRightGERTex[] = {
#include "assets/misc/ger_daytelop_static/second_day_right_ger.i4.inc.c"
};

u64 gDaytelopFinalDayLeftGERTex[] = {
#include "assets/misc/ger_daytelop_static/final_day_left_ger.i4.inc.c"
};

u64 gDaytelopFinalDayRightGERTex[] = {
#include "assets/misc/ger_daytelop_static/final_day_right_ger.i4.inc.c"
};

u64 gDaytelopNewDayLeftGERTex[] = {
#include "assets/misc/ger_daytelop_static/new_day_left_ger.i4.inc.c"
};

u64 gDaytelopNewDayRightGERTex[] = {
#include "assets/misc/ger_daytelop_static/new_day_right_ger.i4.inc.c"
};

u64 gDaytelop72HoursGERTex[] = {
#include "assets/misc/ger_daytelop_static/72_hours_ger.i4.inc.c"
};

u64 gDaytelop48HoursGERTex[] = {
#include "assets/misc/ger_daytelop_static/48_hours_ger.i4.inc.c"
};

u64 gDaytelop24HoursGERTex[] = {
#include "assets/misc/ger_daytelop_static/24_hours_ger.i4.inc.c"
};

