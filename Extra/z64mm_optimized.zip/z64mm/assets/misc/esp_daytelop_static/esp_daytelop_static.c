#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "esp_daytelop_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gDaytelopFirstDayLeftESPTex[] = {
#include "assets/misc/esp_daytelop_static/first_day_left_esp.i4.inc.c"
};

u64 gDaytelopFirstDayRightESPTex[] = {
#include "assets/misc/esp_daytelop_static/first_day_right_esp.i4.inc.c"
};

u64 gDaytelopSecondDayLeftESPTex[] = {
#include "assets/misc/esp_daytelop_static/second_day_left_esp.i4.inc.c"
};

u64 gDaytelopSecondDayRightESPTex[] = {
#include "assets/misc/esp_daytelop_static/second_day_right_esp.i4.inc.c"
};

u64 gDaytelopFinalDayLeftESPTex[] = {
#include "assets/misc/esp_daytelop_static/final_day_left_esp.i4.inc.c"
};

u64 gDaytelopFinalDayRightESPTex[] = {
#include "assets/misc/esp_daytelop_static/final_day_right_esp.i4.inc.c"
};

u64 gDaytelopNewDayLeftESPTex[] = {
#include "assets/misc/esp_daytelop_static/new_day_left_esp.i4.inc.c"
};

u64 gDaytelopNewDayRightESPTex[] = {
#include "assets/misc/esp_daytelop_static/new_day_right_esp.i4.inc.c"
};

u64 gDaytelop72HoursESPTex[] = {
#include "assets/misc/esp_daytelop_static/72_hours_esp.i4.inc.c"
};

u64 gDaytelop48HoursESPTex[] = {
#include "assets/misc/esp_daytelop_static/48_hours_esp.i4.inc.c"
};

u64 gDaytelop24HoursESPTex[] = {
#include "assets/misc/esp_daytelop_static/24_hours_esp.i4.inc.c"
};

