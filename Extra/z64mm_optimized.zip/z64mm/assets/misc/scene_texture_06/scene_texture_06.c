#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "scene_texture_06.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 scene_texture_06_Tex_000000[] = {
#include "assets/misc/scene_texture_06/tex_000000.rgba16.inc.c"
};

u64 scene_texture_06_Tex_000400[] = {
#include "assets/misc/scene_texture_06/tex_000400.ci4.inc.c"
};

u64 scene_texture_06_TLUT_000C00[] = {
#include "assets/misc/scene_texture_06/tlut_000C00.rgba16.inc.c"
};

u64 scene_texture_06_Tex_000C20[] = {
#include "assets/misc/scene_texture_06/tex_000C20.ci4.inc.c"
};

u64 scene_texture_06_TLUT_001420[] = {
#include "assets/misc/scene_texture_06/tlut_001420.rgba16.inc.c"
};

u64 scene_texture_06_Tex_001440[] = {
#include "assets/misc/scene_texture_06/tex_001440.ci4.inc.c"
};

u64 scene_texture_06_TLUT_001C40[] = {
#include "assets/misc/scene_texture_06/tlut_001C40.rgba16.inc.c"
};

u64 scene_texture_06_Tex_001C60[] = {
#include "assets/misc/scene_texture_06/tex_001C60.rgba16.inc.c"
};

u64 scene_texture_06_Tex_002460[] = {
#include "assets/misc/scene_texture_06/tex_002460.rgba16.inc.c"
};

u64 scene_texture_06_Tex_002C60[] = {
#include "assets/misc/scene_texture_06/tex_002C60.rgba16.inc.c"
};

u64 scene_texture_06_Tex_003460[] = {
#include "assets/misc/scene_texture_06/tex_003460.rgba16.inc.c"
};

u64 scene_texture_06_Tex_003C60[] = {
#include "assets/misc/scene_texture_06/tex_003C60.i4.inc.c"
};

u64 scene_texture_06_Tex_004460[] = {
#include "assets/misc/scene_texture_06/tex_004460.rgba16.inc.c"
};

u64 scene_texture_06_Tex_004C60[] = {
#include "assets/misc/scene_texture_06/tex_004C60.rgba16.inc.c"
};

