#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "d2_fine_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"
#include "d2_cloud_static.h"
#include "d2_fine_pal_static.h"

u64 gClearSkybox1Tex[] = {
#include "assets/misc/skyboxes/clear_1.ci8.inc.c"
};

u64 gClearSkybox2Tex[] = {
#include "assets/misc/skyboxes/clear_2.ci8.inc.c"
};

u64 gClearSkybox3Tex[] = {
#include "assets/misc/skyboxes/clear_3.ci8.inc.c"
};

u64 gClearSkybox4Tex[] = {
#include "assets/misc/skyboxes/clear_4.ci8.inc.c"
};

u64 gClearSkybox5Tex[] = {
#include "assets/misc/skyboxes/clear_5.ci8.inc.c"
};

