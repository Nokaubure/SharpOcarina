#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "d2_cloud_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"
#include "d2_fine_static.h"
#include "d2_fine_pal_static.h"

u64 gCloudySkybox1Tex[] = {
#include "assets/misc/skyboxes/cloudy_1.ci8.inc.c"
};

u64 gCloudySkybox2Tex[] = {
#include "assets/misc/skyboxes/cloudy_2.ci8.inc.c"
};

u64 gCloudySkybox3Tex[] = {
#include "assets/misc/skyboxes/cloudy_3.ci8.inc.c"
};

u64 gCloudySkybox4Tex[] = {
#include "assets/misc/skyboxes/cloudy_4.ci8.inc.c"
};

u64 gCloudySkybox5Tex[] = {
#include "assets/misc/skyboxes/cloudy_5.ci8.inc.c"
};

