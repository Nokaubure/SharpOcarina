#ifndef D2_CLOUD_STATIC_H
#define D2_CLOUD_STATIC_H 1

extern u64 gCloudySkybox1Tex[];
extern u64 gCloudySkybox2Tex[];
extern u64 gCloudySkybox3Tex[];
extern u64 gCloudySkybox4Tex[];
extern u64 gCloudySkybox5Tex[];
#endif
