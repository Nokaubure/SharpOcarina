#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "d2_fine_pal_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"
#include "d2_fine_static.h"
#include "d2_cloud_static.h"

u64 gClearSkyboxTlue[] = {
#include "assets/misc/skyboxes/clear_tlut.rgba16.inc.c"
};

