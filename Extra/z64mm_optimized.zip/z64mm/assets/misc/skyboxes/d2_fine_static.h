#ifndef D2_FINE_STATIC_H
#define D2_FINE_STATIC_H 1

extern u64 gClearSkybox1Tex[];
extern u64 gClearSkybox2Tex[];
extern u64 gClearSkybox3Tex[];
extern u64 gClearSkybox4Tex[];
extern u64 gClearSkybox5Tex[];
#endif
