#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "fra_daytelop_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gDaytelopFirstDayLeftFRATex[] = {
#include "assets/misc/fra_daytelop_static/first_day_left_fra.i4.inc.c"
};

u64 gDaytelopFirstDayRightFRATex[] = {
#include "assets/misc/fra_daytelop_static/first_day_right_fra.i4.inc.c"
};

u64 gDaytelopSecondDayLeftFRATex[] = {
#include "assets/misc/fra_daytelop_static/second_day_left_fra.i4.inc.c"
};

u64 gDaytelopSecondDayRightFRATex[] = {
#include "assets/misc/fra_daytelop_static/second_day_right_fra.i4.inc.c"
};

u64 gDaytelopFinalDayLeftFRATex[] = {
#include "assets/misc/fra_daytelop_static/final_day_left_fra.i4.inc.c"
};

u64 gDaytelopFinalDayRightFRATex[] = {
#include "assets/misc/fra_daytelop_static/final_day_right_fra.i4.inc.c"
};

u64 gDaytelopNewDayLeftFRATex[] = {
#include "assets/misc/fra_daytelop_static/new_day_left_fra.i4.inc.c"
};

u64 gDaytelopNewDayRightFRATex[] = {
#include "assets/misc/fra_daytelop_static/new_day_right_fra.i4.inc.c"
};

u64 gDaytelop72HoursFRATex[] = {
#include "assets/misc/fra_daytelop_static/72_hours_fra.i4.inc.c"
};

u64 gDaytelop48HoursFRATex[] = {
#include "assets/misc/fra_daytelop_static/48_hours_fra.i4.inc.c"
};

u64 gDaytelop24HoursFRATex[] = {
#include "assets/misc/fra_daytelop_static/24_hours_fra.i4.inc.c"
};

