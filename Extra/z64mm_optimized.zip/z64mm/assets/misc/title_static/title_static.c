#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "title_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gFileSelNoFileToCopyENGTex[] = {
#include "assets/misc/title_static/no_file_to_copy_eng.ia8.inc.c"
};

u64 gFileSelNoFileToEraseENGTex[] = {
#include "assets/misc/title_static/no_file_to_erase_eng.ia8.inc.c"
};

u64 gFileSelNoEmptyFileENGTex[] = {
#include "assets/misc/title_static/no_empty_file_eng.ia8.inc.c"
};

u64 gFileSelFileEmptyENGTex[] = {
#include "assets/misc/title_static/file_empty_eng.ia8.inc.c"
};

u64 gFileSelFileInUseENGTex[] = {
#include "assets/misc/title_static/file_in_use_eng.ia8.inc.c"
};

u64 gFileSelConnectorTex[] = {
#include "assets/misc/title_static/connector.ia8.inc.c"
};

u64 gFileSelCopyWhichFileENGTex[] = {
#include "assets/misc/title_static/copy_which_file_eng.ia8.inc.c"
};

u64 gFileSelCopyToWhichFileENGTex[] = {
#include "assets/misc/title_static/copy_to_which_file_eng.ia8.inc.c"
};

u64 gFileSelAreYouSureCopyENGTex[] = {
#include "assets/misc/title_static/are_you_sure_copy_eng.ia8.inc.c"
};

u64 gFileSelFileCopiedENGTex[] = {
#include "assets/misc/title_static/file_copied_eng.ia8.inc.c"
};

u64 gFileSelPleaseSelectAFileENGTex[] = {
#include "assets/misc/title_static/please_select_a_file_eng.ia8.inc.c"
};

u64 gFileSelOpenThisFileENGTex[] = {
#include "assets/misc/title_static/open_this_file_eng.ia8.inc.c"
};

u64 gFileSelEraseWhichFileENGTex[] = {
#include "assets/misc/title_static/erase_which_file_eng.ia8.inc.c"
};

u64 gFileSelAreYouSureEraseENGTex[] = {
#include "assets/misc/title_static/are_you_sure_erase_eng.ia8.inc.c"
};

u64 gFileSelFileErasedENGTex[] = {
#include "assets/misc/title_static/file_erased_eng.ia8.inc.c"
};

u64 gFileSelOptionsENGTex[] = {
#include "assets/misc/title_static/options_eng.ia8.inc.c"
};

u64 gFileSelNameENGTex[] = {
#include "assets/misc/title_static/name_eng.ia8.inc.c"
};

u64 gFileSelSurroundENGTex[] = {
#include "assets/misc/title_static/surround_eng.ia8.inc.c"
};

u64 gFileSelHeadsetENGTex[] = {
#include "assets/misc/title_static/headset_eng.ia8.inc.c"
};

u64 gFileSelMonoENGTex[] = {
#include "assets/misc/title_static/mono_eng.ia8.inc.c"
};

u64 gFileSelSoundENGTex[] = {
#include "assets/misc/title_static/sound_eng.ia8.inc.c"
};

u64 gFileSelStereoENGTex[] = {
#include "assets/misc/title_static/stereo_eng.ia8.inc.c"
};

u64 gFileSelTargetingENGTex[] = {
#include "assets/misc/title_static/targeting_eng.ia8.inc.c"
};

u64 gFileSelSwitchENGTex[] = {
#include "assets/misc/title_static/switch_eng.ia8.inc.c"
};

u64 gFileSelHoldENGTex[] = {
#include "assets/misc/title_static/hold_eng.ia8.inc.c"
};

u64 gFileSelCheckBrightnessENGTex[] = {
#include "assets/misc/title_static/check_brightness_eng.ia8.inc.c"
};

u64 gFileSelDolbySurroundLogoENGTex[] = {
#include "assets/misc/title_static/dolby_surround_logo_eng.i8.inc.c"
};

u64 gFileSelDecideCancelENGTex[] = {
#include "assets/misc/title_static/decide_cancel_eng.ia8.inc.c"
};

u64 gFileSelDecideSaveENGTex[] = {
#include "assets/misc/title_static/decide_save_eng.ia8.inc.c"
};

u64 gFileSelPleaseWaitENGTex[] = {
#include "assets/misc/title_static/please_wait_eng.ia8.inc.c"
};

u64 gFileSelWindow00Tex[] = {
#include "assets/misc/title_static/window_00.ia16.inc.c"
};

u64 gFileSelWindow01Tex[] = {
#include "assets/misc/title_static/window_01.ia16.inc.c"
};

u64 gFileSelWindow02Tex[] = {
#include "assets/misc/title_static/window_02.ia16.inc.c"
};

u64 gFileSelWindow03Tex[] = {
#include "assets/misc/title_static/window_03.ia16.inc.c"
};

u64 gFileSelWindow10Tex[] = {
#include "assets/misc/title_static/window_10.ia16.inc.c"
};

u64 gFileSelWindow11Tex[] = {
#include "assets/misc/title_static/window_11.ia16.inc.c"
};

u64 gFileSelWindow12Tex[] = {
#include "assets/misc/title_static/window_12.ia16.inc.c"
};

u64 gFileSelWindow13Tex[] = {
#include "assets/misc/title_static/window_13.ia16.inc.c"
};

u64 gFileSelWindow20Tex[] = {
#include "assets/misc/title_static/window_20.ia16.inc.c"
};

u64 gFileSelWindow21Tex[] = {
#include "assets/misc/title_static/window_21.ia16.inc.c"
};

u64 gFileSelWindow22Tex[] = {
#include "assets/misc/title_static/window_22.ia16.inc.c"
};

u64 gFileSelWindow23Tex[] = {
#include "assets/misc/title_static/window_23.ia16.inc.c"
};

u64 gFileSelWindow30Tex[] = {
#include "assets/misc/title_static/window_30.ia16.inc.c"
};

u64 gFileSelWindow31Tex[] = {
#include "assets/misc/title_static/window_31.ia16.inc.c"
};

u64 gFileSelWindow32Tex[] = {
#include "assets/misc/title_static/window_32.ia16.inc.c"
};

u64 gFileSelWindow33Tex[] = {
#include "assets/misc/title_static/window_33.ia16.inc.c"
};

u64 gFileSelWindow40Tex[] = {
#include "assets/misc/title_static/window_40.ia16.inc.c"
};

u64 gFileSelWindow41Tex[] = {
#include "assets/misc/title_static/window_41.ia16.inc.c"
};

u64 gFileSelWindow42Tex[] = {
#include "assets/misc/title_static/window_42.ia16.inc.c"
};

u64 gFileSelWindow43Tex[] = {
#include "assets/misc/title_static/window_43.ia16.inc.c"
};

u64 gFileSelCopyButtonENGTex[] = {
#include "assets/misc/title_static/copy_button_eng.ia16.inc.c"
};

u64 gFileSelFile1ButtonENGTex[] = {
#include "assets/misc/title_static/file_1_button_eng.ia16.inc.c"
};

u64 gFileSelFile2ButtonENGTex[] = {
#include "assets/misc/title_static/file_2_button_eng.ia16.inc.c"
};

u64 gFileSelFile3ButtonENGTex[] = {
#include "assets/misc/title_static/file_3_button_eng.ia16.inc.c"
};

u64 gFileSelYesButtonENGTex[] = {
#include "assets/misc/title_static/yes_button_eng.ia16.inc.c"
};

u64 gFileSelEraseButtonENGTex[] = {
#include "assets/misc/title_static/erase_button_eng.ia16.inc.c"
};

u64 gFileSelENDButtonENGTex[] = {
#include "assets/misc/title_static/end_button_eng.ia16.inc.c"
};

u64 gFileSelBackspaceButtonTex[] = {
#include "assets/misc/title_static/backspace_button.ia16.inc.c"
};

u64 gFileSelFileNameBoxTex[] = {
#include "assets/misc/title_static/file_name_box.ia16.inc.c"
};

u64 gFileSelFileInfoBox0Tex[] = {
#include "assets/misc/title_static/file_info_box_0.ia16.inc.c"
};

u64 gFileSelFileInfoBox1Tex[] = {
#include "assets/misc/title_static/file_info_box_1.ia16.inc.c"
};

u64 gFileSelFileInfoBox2Tex[] = {
#include "assets/misc/title_static/file_info_box_2.ia16.inc.c"
};

u64 gFileSelFileInfoBox3Tex[] = {
#include "assets/misc/title_static/file_info_box_3.ia16.inc.c"
};

u64 gFileSelFileInfoBox4Tex[] = {
#include "assets/misc/title_static/file_info_box_4.ia16.inc.c"
};

u64 gFileSelOptionsButtonENGTex[] = {
#include "assets/misc/title_static/options_button_eng.ia16.inc.c"
};

u64 gFileSelQuitButtonENGTex[] = {
#include "assets/misc/title_static/quit_button_eng.ia16.inc.c"
};

u64 gFileSelFileExtraInfoBox0Tex[] = {
#include "assets/misc/title_static/file_extra_info_box_0.ia16.inc.c"
};

u64 gFileSelFileExtraInfoBox1Tex[] = {
#include "assets/misc/title_static/file_extra_info_box_1.ia16.inc.c"
};

u64 gFileSelBlankButtonTex[] = {
#include "assets/misc/title_static/file_blank_button.ia16.inc.c"
};

u64 gFileSelOptionsDividerTex[] = {
#include "assets/misc/title_static/options_divider.ia4.inc.c"
};

u64 gFileSelBrightnessCheckTex[] = {
#include "assets/misc/title_static/brightness_check.ia4.inc.c"
};

u64 gFileSelBigButtonHighlightTex[] = {
#include "assets/misc/title_static/big_button_highlight.i8.inc.c"
};

u64 gFileSelCharHighlightTex[] = {
#include "assets/misc/title_static/char_highlight.i8.inc.c"
};

u64 gFileSelMediumButtonHighlightTex[] = {
#include "assets/misc/title_static/medium_button_highlight.i8.inc.c"
};

u64 gFileSelSmallButtonHighlightTex[] = {
#include "assets/misc/title_static/small_button_highlight.i8.inc.c"
};

u64 gFileSelOdolwasRemainsTex[] = {
#include "assets/misc/title_static/odolwas_remains.rgba32.inc.c"
};

u64 gFileSelGohtsRemainsTex[] = {
#include "assets/misc/title_static/gohts_remains.rgba32.inc.c"
};

u64 gFileSelGyorgsRemainsTex[] = {
#include "assets/misc/title_static/gyorgs_remains.rgba32.inc.c"
};

u64 gFileSelTwinmoldsRemainsTex[] = {
#include "assets/misc/title_static/twinmolds_remains.rgba32.inc.c"
};

u64 gFileSelOwlSaveIconTex[] = {
#include "assets/misc/title_static/owl_save_icon.rgba32.inc.c"
};

u64 gFileSelFirstDayENGTex[] = {
#include "assets/misc/title_static/first_day_eng.i4.inc.c"
};

u64 gFileSelSecondDayENGTex[] = {
#include "assets/misc/title_static/second_day_eng.i4.inc.c"
};

u64 gFileSelFinalDayENGTex[] = {
#include "assets/misc/title_static/final_day_eng.i4.inc.c"
};

u64 gFileSelSaveXJPNTex[] = {
#include "assets/misc/title_static/save_x_jpn.i4.inc.c"
};

u64 gFileSelMASKSENGTex[] = {
#include "assets/misc/title_static/masks_eng.i4.inc.c"
};

u64 gFileSel0QuarterHeartENGTex[] = {
#include "assets/misc/title_static/0_quarter_heart.ia8.inc.c"
};

u64 gFileSel1QuarterHeartENGTex[] = {
#include "assets/misc/title_static/1_quarter_heart.ia8.inc.c"
};

u64 gFileSel2QuarterHeartENGTex[] = {
#include "assets/misc/title_static/2_quarter_heart.ia8.inc.c"
};

u64 gFileSel3QuarterHeartENGTex[] = {
#include "assets/misc/title_static/3_quarter_heart.ia8.inc.c"
};

u64 gFileSelRupeeTex[] = {
#include "assets/misc/title_static/rupee.ia8.inc.c"
};

Gfx gFileSelWindow1DL[] = {
    gsDPPipeSync(),
    gsDPLoadTextureBlock(gFileSelWindow00Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(0, 2, 3, 1, 0),
    gsDPLoadTextureBlock(gFileSelWindow10Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(4, 6, 7, 5, 0),
    gsDPLoadTextureBlock(gFileSelWindow20Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(8, 10, 11, 9, 0),
    gsDPLoadTextureBlock(gFileSelWindow30Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(12, 14, 15, 13, 0),
    gsDPLoadTextureBlock(gFileSelWindow40Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(16, 18, 19, 17, 0),
    gsDPLoadTextureBlock(gFileSelWindow01Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(20, 22, 23, 21, 0),
    gsDPLoadTextureBlock(gFileSelWindow11Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(24, 26, 27, 25, 0),
    gsDPLoadTextureBlock(gFileSelWindow21Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(28, 30, 31, 29, 0),
    gsDPPipeSync(),
    gsSPEndDisplayList(),
};

Gfx gFileSelWindow2DL[] = {
    gsDPLoadTextureBlock(gFileSelWindow31Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(0, 2, 3, 1, 0),
    gsDPLoadTextureBlock(gFileSelWindow41Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(4, 6, 7, 5, 0),
    gsDPLoadTextureBlock(gFileSelWindow02Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(8, 10, 11, 9, 0),
    gsDPLoadTextureBlock(gFileSelWindow12Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(12, 14, 15, 13, 0),
    gsDPLoadTextureBlock(gFileSelWindow22Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(16, 18, 19, 17, 0),
    gsDPLoadTextureBlock(gFileSelWindow32Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(20, 22, 23, 21, 0),
    gsDPLoadTextureBlock(gFileSelWindow42Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 64, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(24, 26, 27, 25, 0),
    gsDPLoadTextureBlock(gFileSelWindow03Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 48, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(28, 30, 31, 29, 0),
    gsDPPipeSync(),
    gsSPEndDisplayList(),
};

Gfx gFileSelWindow3DL[] = {
    gsDPLoadTextureBlock(gFileSelWindow13Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 48, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(0, 2, 3, 1, 0),
    gsDPLoadTextureBlock(gFileSelWindow23Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 48, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(4, 6, 7, 5, 0),
    gsDPLoadTextureBlock(gFileSelWindow33Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 48, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(8, 10, 11, 9, 0),
    gsDPLoadTextureBlock(gFileSelWindow43Tex, G_IM_FMT_IA, G_IM_SIZ_16b, 48, 32, 0, G_TX_NOMIRROR | G_TX_WRAP,
                         G_TX_NOMIRROR | G_TX_WRAP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),
    gsSP1Quadrangle(12, 14, 15, 13, 0),
    gsDPPipeSync(),
    gsSPEndDisplayList(),
};

