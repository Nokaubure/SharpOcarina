#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "scene_texture_04.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 scene_texture_04_Tex_000000[] = {
#include "assets/misc/scene_texture_04/tex_000000.rgba16.inc.c"
};

u64 scene_texture_04_Tex_001000[] = {
#include "assets/misc/scene_texture_04/tex_001000.rgba16.inc.c"
};

u64 scene_texture_04_Tex_001800[] = {
#include "assets/misc/scene_texture_04/tex_001800.rgba16.inc.c"
};

u64 scene_texture_04_Tex_002000[] = {
#include "assets/misc/scene_texture_04/tex_002000.rgba16.inc.c"
};

u64 scene_texture_04_Tex_002800[] = {
#include "assets/misc/scene_texture_04/tex_002800.rgba16.inc.c"
};

u64 scene_texture_04_Tex_003000[] = {
#include "assets/misc/scene_texture_04/tex_003000.i4.inc.c"
};

u64 scene_texture_04_Tex_003800[] = {
#include "assets/misc/scene_texture_04/tex_003800.i4.inc.c"
};

u64 scene_texture_04_Tex_004000[] = {
#include "assets/misc/scene_texture_04/tex_004000.i4.inc.c"
};

u64 scene_texture_04_Tex_004200[] = {
#include "assets/misc/scene_texture_04/tex_004200.rgba16.inc.c"
};

u64 scene_texture_04_Tex_004A00[] = {
#include "assets/misc/scene_texture_04/tex_004A00.rgba16.inc.c"
};

