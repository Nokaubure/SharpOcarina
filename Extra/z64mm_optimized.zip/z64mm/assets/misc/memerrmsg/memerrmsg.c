#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "memerrmsg.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gExpansionPakNotInstalledErrorTex[] = {
#include "assets/misc/memerrmsg/expansion_pak_not_installed_error.i4.inc.c"
};

u64 gSeeInstructionBookletErrorTex[] = {
#include "assets/misc/memerrmsg/see_instruction_booklet_error.i4.inc.c"
};

