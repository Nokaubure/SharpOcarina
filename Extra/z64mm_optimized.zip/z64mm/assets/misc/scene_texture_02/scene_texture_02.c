#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "scene_texture_02.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 scene_texture_02_Tex_000000[] = {
#include "assets/misc/scene_texture_02/tex_000000.ci8.inc.c"
};

u64 scene_texture_02_Tex_000400[] = {
#include "assets/misc/scene_texture_02/tex_000400.ci8.inc.c"
};

u64 scene_texture_02_Tex_000600[] = {
#include "assets/misc/scene_texture_02/tex_000600.ci8.inc.c"
};

u64 scene_texture_02_Tex_000700[] = {
#include "assets/misc/scene_texture_02/tex_000700.ci8.inc.c"
};

u64 scene_texture_02_Tex_000B00[] = {
#include "assets/misc/scene_texture_02/tex_000B00.ci8.inc.c"
};

u64 scene_texture_02_Tex_000F00[] = {
#include "assets/misc/scene_texture_02/tex_000F00.ci8.inc.c"
};

u64 scene_texture_02_Tex_001300[] = {
#include "assets/misc/scene_texture_02/tex_001300.ci8.inc.c"
};

u64 scene_texture_02_Tex_001700[] = {
#include "assets/misc/scene_texture_02/tex_001700.ci8.inc.c"
};

u64 scene_texture_02_Tex_001800[] = {
#include "assets/misc/scene_texture_02/tex_001800.ci8.inc.c"
};

u64 scene_texture_02_Tex_001C00[] = {
#include "assets/misc/scene_texture_02/tex_001C00.ci8.inc.c"
};

