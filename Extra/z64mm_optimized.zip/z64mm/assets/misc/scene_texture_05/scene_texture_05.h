#ifndef SCENE_TEXTURE_05_H
#define SCENE_TEXTURE_05_H 1

extern u64 scene_texture_05_Tex_000000[];
extern u64 scene_texture_05_Tex_000800[];
extern u64 scene_texture_05_Tex_001000[];
extern u64 scene_texture_05_Tex_001800[];
extern u64 scene_texture_05_Tex_002000[];
extern u64 scene_texture_05_Tex_002800[];
extern u64 scene_texture_05_Tex_003000[];
extern u64 scene_texture_05_Tex_003800[];
extern u64 scene_texture_05_Tex_004000[];
extern u64 scene_texture_05_Tex_004800[];
extern u64 scene_texture_05_Tex_005000[];
extern u64 scene_texture_05_Tex_005800[];
extern u64 scene_texture_05_Tex_006000[];
#endif
