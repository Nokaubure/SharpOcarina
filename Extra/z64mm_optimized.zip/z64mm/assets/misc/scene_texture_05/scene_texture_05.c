#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "scene_texture_05.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 scene_texture_05_Tex_000000[] = {
#include "assets/misc/scene_texture_05/tex_000000.rgba16.inc.c"
};

u64 scene_texture_05_Tex_000800[] = {
#include "assets/misc/scene_texture_05/tex_000800.rgba16.inc.c"
};

u64 scene_texture_05_Tex_001000[] = {
#include "assets/misc/scene_texture_05/tex_001000.rgba16.inc.c"
};

u64 scene_texture_05_Tex_001800[] = {
#include "assets/misc/scene_texture_05/tex_001800.i4.inc.c"
};

u64 scene_texture_05_Tex_002000[] = {
#include "assets/misc/scene_texture_05/tex_002000.rgba16.inc.c"
};

u64 scene_texture_05_Tex_002800[] = {
#include "assets/misc/scene_texture_05/tex_002800.rgba16.inc.c"
};

u64 scene_texture_05_Tex_003000[] = {
#include "assets/misc/scene_texture_05/tex_003000.rgba16.inc.c"
};

u64 scene_texture_05_Tex_003800[] = {
#include "assets/misc/scene_texture_05/tex_003800.rgba16.inc.c"
};

u64 scene_texture_05_Tex_004000[] = {
#include "assets/misc/scene_texture_05/tex_004000.rgba16.inc.c"
};

u64 scene_texture_05_Tex_004800[] = {
#include "assets/misc/scene_texture_05/tex_004800.rgba16.inc.c"
};

u64 scene_texture_05_Tex_005000[] = {
#include "assets/misc/scene_texture_05/tex_005000.rgba16.inc.c"
};

u64 scene_texture_05_Tex_005800[] = {
#include "assets/misc/scene_texture_05/tex_005800.rgba16.inc.c"
};

u64 scene_texture_05_Tex_006000[] = {
#include "assets/misc/scene_texture_05/tex_006000.i4.inc.c"
};

