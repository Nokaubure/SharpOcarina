#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "story_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gStoryMaskFestivalTex[] = {
#include "assets/misc/story_static/story_mask_festival.ci8.inc.c"
};

u64 gStoryGiantsLeavingTex[] = {
#include "assets/misc/story_static/story_giants_leaving.ci8.inc.c"
};

u64 gStoryMaskFestivalTLUT[] = {
#include "assets/misc/story_static/story_mask_festival_tlut.rgba16.inc.c"
};

u64 gStoryGiantsLeavingTLUT[] = {
#include "assets/misc/story_static/story_giants_leaving_tlut.rgba16.inc.c"
};

