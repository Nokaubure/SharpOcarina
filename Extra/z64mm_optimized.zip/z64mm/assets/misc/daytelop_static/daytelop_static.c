#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "daytelop_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gDaytelopFirstDayLeftNESTex[] = {
#include "assets/misc/daytelop_static/first_day_left_nes.i4.inc.c"
};

u64 gDaytelopFirstDayRightNESTex[] = {
#include "assets/misc/daytelop_static/first_day_right_nes.i4.inc.c"
};

u64 gDaytelopSecondDayLeftNESTex[] = {
#include "assets/misc/daytelop_static/second_day_left_nes.i4.inc.c"
};

u64 gDaytelopSecondDayRightNESTex[] = {
#include "assets/misc/daytelop_static/second_day_right_nes.i4.inc.c"
};

u64 gDaytelopFinalDayLeftNESTex[] = {
#include "assets/misc/daytelop_static/final_day_left_nes.i4.inc.c"
};

u64 gDaytelopFinalDayRightNESTex[] = {
#include "assets/misc/daytelop_static/final_day_right_nes.i4.inc.c"
};

u64 gDaytelopNewDayLeftNESTex[] = {
#include "assets/misc/daytelop_static/new_day_left_nes.i4.inc.c"
};

u64 gDaytelopNewDayRightNESTex[] = {
#include "assets/misc/daytelop_static/new_day_right_nes.i4.inc.c"
};

u64 gDaytelop72HoursNESTex[] = {
#include "assets/misc/daytelop_static/72_hours_nes.i4.inc.c"
};

u64 gDaytelop48HoursNESTex[] = {
#include "assets/misc/daytelop_static/48_hours_nes.i4.inc.c"
};

u64 gDaytelop24HoursNESTex[] = {
#include "assets/misc/daytelop_static/24_hours_nes.i4.inc.c"
};

