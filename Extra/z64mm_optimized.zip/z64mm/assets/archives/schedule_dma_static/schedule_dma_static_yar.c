#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "schedule_dma_static_yar.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gBombersNotebookPhotoAnjuTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_anju.rgba16.inc.c"
};

u64 gBombersNotebookPhotoKafeiTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_kafei.rgba16.inc.c"
};

u64 gBombersNotebookPhotoCuriosityShopManTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_curiosity_shop_man.rgba16.inc.c"
};

u64 gBombersNotebookPhotoBombShopLadyTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_bomb_shop_lady.rgba16.inc.c"
};

u64 gBombersNotebookPhotoRomaniTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_romani.rgba16.inc.c"
};

u64 gBombersNotebookPhotoCremiaTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_cremia.rgba16.inc.c"
};

u64 gBombersNotebookPhotoMayorDotourTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_mayor_dotour.rgba16.inc.c"
};

u64 gBombersNotebookPhotoMadameAromaTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_madame_aroma.rgba16.inc.c"
};

u64 gBombersNotebookPhotoTotoTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_toto.rgba16.inc.c"
};

u64 gBombersNotebookPhotoGormanTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_gorman.rgba16.inc.c"
};

u64 gBombersNotebookPhotoPostmanTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_postman.rgba16.inc.c"
};

u64 gBombersNotebookPhotoRosaSistersTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_rosa_sisters.rgba16.inc.c"
};

u64 gBombersNotebookPhotoToiletHandTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_toilet_hand.rgba16.inc.c"
};

u64 gBombersNotebookPhotoAnjusGrandmotherTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_anjus_grandmother.rgba16.inc.c"
};

u64 gBombersNotebookPhotoKamaroTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_kamaro.rgba16.inc.c"
};

u64 gBombersNotebookPhotoGrogTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_grog.rgba16.inc.c"
};

u64 gBombersNotebookPhotoGormanBrothersTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_gorman_brothers.rgba16.inc.c"
};

u64 gBombersNotebookPhotoShiroTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_shiro.rgba16.inc.c"
};

u64 gBombersNotebookPhotoGuruGuruTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_guru_guru.rgba16.inc.c"
};

u64 gBombersNotebookPhotoBombersTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_bombers.rgba16.inc.c"
};

u64 gBombersNotebookPhotoMadameAromaBrightTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_photo_madame_aroma_bright.rgba16.inc.c"
};

u64 gBombersNotebookEntryIconExclamationPointLargeTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_entry_icon_exclamation_point_large.ia8.inc.c"
};

u64 gBombersNotebookEntryIconMaskTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_entry_icon_mask.ia8.inc.c"
};

u64 gBombersNotebookEntryIconRibbonTex[] = {
#include "assets/archives/schedule_dma_static/bombers_notebook_entry_icon_ribbon.ia8.inc.c"
};

