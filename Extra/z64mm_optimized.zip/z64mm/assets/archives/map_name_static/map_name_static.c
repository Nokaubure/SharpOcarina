#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "map_name_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gMapPointGreatBayENGTex[] = {
#include "assets/archives/map_name_static/map_point_great_bay_eng.ia4.inc.c"
};

u64 gMapPointZoraHallENGTex[] = {
#include "assets/archives/map_name_static/map_point_zora_hall_eng.ia4.inc.c"
};

u64 gMapPointRomaniRanchENGTex[] = {
#include "assets/archives/map_name_static/map_point_romani_ranch_eng.ia4.inc.c"
};

u64 gMapPointDekuPalaceENGTex[] = {
#include "assets/archives/map_name_static/map_point_deku_palace_eng.ia4.inc.c"
};

u64 gMapPointWoodfallENGTex[] = {
#include "assets/archives/map_name_static/map_point_woodfall_eng.ia4.inc.c"
};

u64 gMapPointClockTownENGTex[] = {
#include "assets/archives/map_name_static/map_point_clock_town_eng.ia4.inc.c"
};

u64 gMapPointSnowheadENGTex[] = {
#include "assets/archives/map_name_static/map_point_snowhead_eng.ia4.inc.c"
};

u64 gMapPointIkanaGraveyardENGTex[] = {
#include "assets/archives/map_name_static/map_point_ikana_graveyard_eng.ia4.inc.c"
};

u64 gMapPointIkanaCanyonENGTex[] = {
#include "assets/archives/map_name_static/map_point_ikana_canyon_eng.ia4.inc.c"
};

u64 gMapPointGoronVillageENGTex[] = {
#include "assets/archives/map_name_static/map_point_goron_village_eng.ia4.inc.c"
};

u64 gMapPointStoneTowerENGTex[] = {
#include "assets/archives/map_name_static/map_point_stone_tower_eng.ia4.inc.c"
};

u64 gMapPointGreatBayCoastENGTex[] = {
#include "assets/archives/map_name_static/map_point_great_bay_coast_eng.ia4.inc.c"
};

u64 gMapPointSouthernSwampENGTex[] = {
#include "assets/archives/map_name_static/map_point_southern_swamp_eng.ia4.inc.c"
};

u64 gMapPointMountainVillageENGTex[] = {
#include "assets/archives/map_name_static/map_point_mountain_village_eng.ia4.inc.c"
};

u64 gMapPointMilkRoadENGTex[] = {
#include "assets/archives/map_name_static/map_point_milk_road_eng.ia4.inc.c"
};

u64 gMapPointZoraCapeENGTex[] = {
#include "assets/archives/map_name_static/map_point_zora_cape_eng.ia4.inc.c"
};

