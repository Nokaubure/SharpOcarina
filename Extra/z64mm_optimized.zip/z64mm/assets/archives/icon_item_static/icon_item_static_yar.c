#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "icon_item_static_yar.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gItemIconOcarinaOfTimeTex[] = {
#include "assets/archives/icon_item_static/ocarina_of_time_icon.rgba32.inc.c"
};

u64 gItemIconBowTex[] = {
#include "assets/archives/icon_item_static/bow_icon.rgba32.inc.c"
};

u64 gItemIconFireArrowTex[] = {
#include "assets/archives/icon_item_static/fire_arrow_icon.rgba32.inc.c"
};

u64 gItemIconIceArrowTex[] = {
#include "assets/archives/icon_item_static/ice_arrow_icon.rgba32.inc.c"
};

u64 gItemIconLightArrowTex[] = {
#include "assets/archives/icon_item_static/light_arrow_icon.rgba32.inc.c"
};

u64 gItemIconFairyOcarinaTex[] = {
#include "assets/archives/icon_item_static/fairy_ocarina_icon.rgba32.inc.c"
};

u64 gItemIconBombTex[] = {
#include "assets/archives/icon_item_static/bomb_icon.rgba32.inc.c"
};

u64 gItemIconBombchuTex[] = {
#include "assets/archives/icon_item_static/bombchu_icon.rgba32.inc.c"
};

u64 gItemIconDekuStickTex[] = {
#include "assets/archives/icon_item_static/deku_stick_icon.rgba32.inc.c"
};

u64 gItemIconDekuNutTex[] = {
#include "assets/archives/icon_item_static/deku_nut_icon.rgba32.inc.c"
};

u64 gItemIconMagicBeansTex[] = {
#include "assets/archives/icon_item_static/magic_beans_icon.rgba32.inc.c"
};

u64 gItemIconSlingshotTex[] = {
#include "assets/archives/icon_item_static/slingshot_icon.rgba32.inc.c"
};

u64 gItemIconPowderKegTex[] = {
#include "assets/archives/icon_item_static/powder_keg_icon.rgba32.inc.c"
};

u64 gItemIconPictographBoxTex[] = {
#include "assets/archives/icon_item_static/picto_box_icon.rgba32.inc.c"
};

u64 gItemIconLensofTruthTex[] = {
#include "assets/archives/icon_item_static/lens_of_truth_icon.rgba32.inc.c"
};

u64 gItemIconHookshotTex[] = {
#include "assets/archives/icon_item_static/hookshot_icon.rgba32.inc.c"
};

u64 gItemIconGreatFairysSwordTex[] = {
#include "assets/archives/icon_item_static/great_fairys_sword_icon.rgba32.inc.c"
};

u64 gItemIconLongshotTex[] = {
#include "assets/archives/icon_item_static/longshot_icon.rgba32.inc.c"
};

u64 gItemIconEmptyBottleTex[] = {
#include "assets/archives/icon_item_static/empty_bottle_icon.rgba32.inc.c"
};

u64 gItemIconRedPotionTex[] = {
#include "assets/archives/icon_item_static/red_potion_icon.rgba32.inc.c"
};

u64 gItemIconGreenPotionTex[] = {
#include "assets/archives/icon_item_static/green_potion_icon.rgba32.inc.c"
};

u64 gItemIconBluePotionTex[] = {
#include "assets/archives/icon_item_static/blue_potion_icon.rgba32.inc.c"
};

u64 gItemIconBottledFairyTex[] = {
#include "assets/archives/icon_item_static/bottled_fairy_icon.rgba32.inc.c"
};

u64 gItemIconBottledDekuPrincessTex[] = {
#include "assets/archives/icon_item_static/bottled_deku_princess_icon.rgba32.inc.c"
};

u64 gItemIconBottledFullMilkTex[] = {
#include "assets/archives/icon_item_static/bottled_full_milk_icon.rgba32.inc.c"
};

u64 gItemIconBottledHalfMilkTex[] = {
#include "assets/archives/icon_item_static/bottled_half_milk_icon.rgba32.inc.c"
};

u64 gItemIconBottledFishTex[] = {
#include "assets/archives/icon_item_static/bottled_fish_icon.rgba32.inc.c"
};

u64 gItemIconBottledBugTex[] = {
#include "assets/archives/icon_item_static/bottled_bug_icon.rgba32.inc.c"
};

u64 gItemIconBottledBlueFireTex[] = {
#include "assets/archives/icon_item_static/bottled_blue_fire_icon.rgba32.inc.c"
};

u64 gItemIconBottledPoeTex[] = {
#include "assets/archives/icon_item_static/bottled_poe_icon.rgba32.inc.c"
};

u64 gItemIconBottledBigPoeTex[] = {
#include "assets/archives/icon_item_static/bottled_big_poe_icon.rgba32.inc.c"
};

u64 gItemIconSpringWaterTex[] = {
#include "assets/archives/icon_item_static/spring_water_icon.rgba32.inc.c"
};

u64 gItemIconHotSpringWaterTex[] = {
#include "assets/archives/icon_item_static/hot_spring_water_icon.rgba32.inc.c"
};

u64 gItemIconBottledZoraEggTex[] = {
#include "assets/archives/icon_item_static/bottled_zora_egg_icon.rgba32.inc.c"
};

u64 gItemIconBottledGoldDustTex[] = {
#include "assets/archives/icon_item_static/bottled_gold_dust_icon.rgba32.inc.c"
};

u64 gItemIconBottledMushroomTex[] = {
#include "assets/archives/icon_item_static/bottled_mushroom_icon.rgba32.inc.c"
};

u64 gItemIconBottledSeahorseTex[] = {
#include "assets/archives/icon_item_static/bottled_seahorse_icon.rgba32.inc.c"
};

u64 gItemIconChateauRomaniTex[] = {
#include "assets/archives/icon_item_static/chateau_romani_icon.rgba32.inc.c"
};

u64 gItemIconBottledHylianLoachTex[] = {
#include "assets/archives/icon_item_static/bottled_hylian_loach_icon.rgba32.inc.c"
};

u64 gItemIconEmptyBottle2Tex[] = {
#include "assets/archives/icon_item_static/empty_bottle_2_icon.rgba32.inc.c"
};

u64 gItemIconMoonsTearTex[] = {
#include "assets/archives/icon_item_static/moons_tear_icon.rgba32.inc.c"
};

u64 gItemIconLandDeedTex[] = {
#include "assets/archives/icon_item_static/land_deed_icon.rgba32.inc.c"
};

u64 gItemIconSwampDeedTex[] = {
#include "assets/archives/icon_item_static/swamp_deed_icon.rgba32.inc.c"
};

u64 gItemIconMountainDeedTex[] = {
#include "assets/archives/icon_item_static/mountain_deed_icon.rgba32.inc.c"
};

u64 gItemIconOceanDeedTex[] = {
#include "assets/archives/icon_item_static/ocean_deed_icon.rgba32.inc.c"
};

u64 gItemIconRoomKeyTex[] = {
#include "assets/archives/icon_item_static/room_key_icon.rgba32.inc.c"
};

u64 gItemIconLetterToMamaTex[] = {
#include "assets/archives/icon_item_static/letter_to_mama_icon.rgba32.inc.c"
};

u64 gItemIconLetterToKafeiTex[] = {
#include "assets/archives/icon_item_static/letter_to_kafei_icon.rgba32.inc.c"
};

u64 gItemIconPendantOfMemoriesTex[] = {
#include "assets/archives/icon_item_static/pendant_of_memories_icon.rgba32.inc.c"
};

u64 gItemIconTingleMapTex[] = {
#include "assets/archives/icon_item_static/tingle_map_icon.rgba32.inc.c"
};

u64 gItemIconDekuMaskTex[] = {
#include "assets/archives/icon_item_static/deku_mask_icon.rgba32.inc.c"
};

u64 gItemIconGoronMaskTex[] = {
#include "assets/archives/icon_item_static/goron_mask_icon.rgba32.inc.c"
};

u64 gItemIconZoraMaskTex[] = {
#include "assets/archives/icon_item_static/zora_mask_icon.rgba32.inc.c"
};

u64 gItemIconFierceDeityMaskTex[] = {
#include "assets/archives/icon_item_static/fierce_deity_mask_icon.rgba32.inc.c"
};

u64 gItemIconMaskOfTruthTex[] = {
#include "assets/archives/icon_item_static/mask_of_truth_icon.rgba32.inc.c"
};

u64 gItemIconKafeisMaskTex[] = {
#include "assets/archives/icon_item_static/kafeis_mask_icon.rgba32.inc.c"
};

u64 gItemIconAllNightMaskTex[] = {
#include "assets/archives/icon_item_static/all_night_mask_icon.rgba32.inc.c"
};

u64 gItemIconBunnyHoodTex[] = {
#include "assets/archives/icon_item_static/bunny_hood_icon.rgba32.inc.c"
};

u64 gItemIconKeatonMaskTex[] = {
#include "assets/archives/icon_item_static/keaton_mask_icon.rgba32.inc.c"
};

u64 gItemIconGaroMaskTex[] = {
#include "assets/archives/icon_item_static/garo_mask_icon.rgba32.inc.c"
};

u64 gItemIconRomaniMaskTex[] = {
#include "assets/archives/icon_item_static/romani_mask_icon.rgba32.inc.c"
};

u64 gItemIconCircusLeaderMaskTex[] = {
#include "assets/archives/icon_item_static/circus_leader_mask_icon.rgba32.inc.c"
};

u64 gItemIconPostmansHatTex[] = {
#include "assets/archives/icon_item_static/postmans_hat_icon.rgba32.inc.c"
};

u64 gItemIconCouplesMaskTex[] = {
#include "assets/archives/icon_item_static/couples_mask_icon.rgba32.inc.c"
};

u64 gItemIconGreatFairyMaskTex[] = {
#include "assets/archives/icon_item_static/great_fairy_mask_icon.rgba32.inc.c"
};

u64 gItemIconGibdoMaskTex[] = {
#include "assets/archives/icon_item_static/gibdo_mask_icon.rgba32.inc.c"
};

u64 gItemIconDonGeroMaskTex[] = {
#include "assets/archives/icon_item_static/don_gero_mask_icon.rgba32.inc.c"
};

u64 gItemIconKamaroMaskTex[] = {
#include "assets/archives/icon_item_static/kamaro_mask_icon.rgba32.inc.c"
};

u64 gItemIconCaptainsHatTex[] = {
#include "assets/archives/icon_item_static/captains_hat_icon.rgba32.inc.c"
};

u64 gItemIconStoneMaskTex[] = {
#include "assets/archives/icon_item_static/stone_mask_icon.rgba32.inc.c"
};

u64 gItemIconBremenMaskTex[] = {
#include "assets/archives/icon_item_static/bremen_mask_icon.rgba32.inc.c"
};

u64 gItemIconBlastMaskTex[] = {
#include "assets/archives/icon_item_static/blast_mask_icon.rgba32.inc.c"
};

u64 gItemIconMaskOfScentsTex[] = {
#include "assets/archives/icon_item_static/mask_of_scents_icon.rgba32.inc.c"
};

u64 gItemIconGiantsMaskTex[] = {
#include "assets/archives/icon_item_static/giants_mask_icon.rgba32.inc.c"
};

u64 gItemIconBowFireTex[] = {
#include "assets/archives/icon_item_static/bow_fire_icon.rgba32.inc.c"
};

u64 gItemIconBowIceTex[] = {
#include "assets/archives/icon_item_static/bow_ice_icon.rgba32.inc.c"
};

u64 gItemIconBowLightTex[] = {
#include "assets/archives/icon_item_static/bow_light_icon.rgba32.inc.c"
};

u64 gItemIconKokiriSwordTex[] = {
#include "assets/archives/icon_item_static/kokiri_sword_icon.rgba32.inc.c"
};

u64 gItemIconRazorSwordTex[] = {
#include "assets/archives/icon_item_static/razor_sword_icon.rgba32.inc.c"
};

u64 gItemIconGildedSwordTex[] = {
#include "assets/archives/icon_item_static/gilded_sword_icon.rgba32.inc.c"
};

u64 gItemIconFierceDeitySwordTex[] = {
#include "assets/archives/icon_item_static/fierce_deity_sword_icon.rgba32.inc.c"
};

u64 gItemIconHerosShieldTex[] = {
#include "assets/archives/icon_item_static/heros_shield_icon.rgba32.inc.c"
};

u64 gItemIconMirrorShieldTex[] = {
#include "assets/archives/icon_item_static/mirror_shield_icon.rgba32.inc.c"
};

u64 gItemIconQuiver30Tex[] = {
#include "assets/archives/icon_item_static/quiver_30_icon.rgba32.inc.c"
};

u64 gItemIconQuiver40Tex[] = {
#include "assets/archives/icon_item_static/quiver_40_icon.rgba32.inc.c"
};

u64 gItemIconQuiver50Tex[] = {
#include "assets/archives/icon_item_static/quiver_50_icon.rgba32.inc.c"
};

u64 gItemIconBombBag20Tex[] = {
#include "assets/archives/icon_item_static/bomb_bag_20_icon.rgba32.inc.c"
};

u64 gItemIconBombBag30Tex[] = {
#include "assets/archives/icon_item_static/bomb_bag_30_icon.rgba32.inc.c"
};

u64 gItemIconBombBag40Tex[] = {
#include "assets/archives/icon_item_static/bomb_bag_40_icon.rgba32.inc.c"
};

u64 gItemIconDefaultWalletTex[] = {
#include "assets/archives/icon_item_static/default_wallet_icon.rgba32.inc.c"
};

u64 gItemIconAdultsWalletTex[] = {
#include "assets/archives/icon_item_static/adults_wallet_icon.rgba32.inc.c"
};

u64 gItemIconGiantsWalletTex[] = {
#include "assets/archives/icon_item_static/giants_wallet_icon.rgba32.inc.c"
};

u64 gItemIconFishingRodTex[] = {
#include "assets/archives/icon_item_static/fishing_rod_icon.rgba32.inc.c"
};

u64 gItemIconOdolwasRemainsTex[] = {
#include "assets/archives/icon_item_static/odolwas_remains_icon.rgba32.inc.c"
};

u64 gItemIconGohtsRemainsTex[] = {
#include "assets/archives/icon_item_static/gohts_remains_icon.rgba32.inc.c"
};

u64 gItemIconGyorgsRemainsTex[] = {
#include "assets/archives/icon_item_static/gyorgs_remains_icon.rgba32.inc.c"
};

u64 gItemIconTwinmoldsRemainsTex[] = {
#include "assets/archives/icon_item_static/twinmolds_remains_icon.rgba32.inc.c"
};

u64 gItemIconBombersNotebookTex[] = {
#include "assets/archives/icon_item_static/bombers_notebook_icon.rgba32.inc.c"
};

u64 gItemIconSongNoteTex[] = {
#include "assets/archives/icon_item_static/song_note_icon.ia8.inc.c"
};

u64 gItemIconHeartPiece1Tex[] = {
#include "assets/archives/icon_item_static/heart_piece_icon_1.ia8.inc.c"
};

u64 gItemIconHeartPiece2Tex[] = {
#include "assets/archives/icon_item_static/heart_piece_icon_2.ia8.inc.c"
};

u64 gItemIconHeartPiece3Tex[] = {
#include "assets/archives/icon_item_static/heart_piece_icon_3.ia8.inc.c"
};

u64 gPausePromptCursorTex[] = {
#include "assets/archives/icon_item_static/pause_prompt_cursor.i4.inc.c"
};

u64 gPauseUnusedCursorTex[] = {
#include "assets/archives/icon_item_static/pause_unused_cursor.i8.inc.c"
};

u64 gPauseMenuCursorTex[] = {
#include "assets/archives/icon_item_static/pause_menu_cursor.ia8.inc.c"
};

u64 gPauseMasks00Tex[] = {
#include "assets/archives/icon_item_static/pause_masks_0_0.ia8.inc.c"
};

u64 gPauseMasks10JPNTex[] = {
#include "assets/archives/icon_item_static/pause_masks_1_0_jpn.ia8.inc.c"
};

u64 gPauseMasks20Tex[] = {
#include "assets/archives/icon_item_static/pause_masks_2_0.ia8.inc.c"
};

u64 gPauseSelectItem00JPNTex[] = {
#include "assets/archives/icon_item_static/pause_select_item_0_0_jpn.ia8.inc.c"
};

u64 gPauseSelectItem10JPNTex[] = {
#include "assets/archives/icon_item_static/pause_select_item_1_0_jpn.ia8.inc.c"
};

u64 gPauseSelectItem20JPNTex[] = {
#include "assets/archives/icon_item_static/pause_select_item_2_0_jpn.ia8.inc.c"
};

u64 gPauseMap00Tex[] = {
#include "assets/archives/icon_item_static/pause_map_0_0.ia8.inc.c"
};

u64 gPauseMap10JPNTex[] = {
#include "assets/archives/icon_item_static/pause_map_1_0_jpn.ia8.inc.c"
};

u64 gPauseMap20Tex[] = {
#include "assets/archives/icon_item_static/pause_map_2_0.ia8.inc.c"
};

u64 gPauseQuestStatus00JPNTex[] = {
#include "assets/archives/icon_item_static/pause_quest_status_0_0_jpn.ia8.inc.c"
};

u64 gPauseQuestStatus10JPNTex[] = {
#include "assets/archives/icon_item_static/pause_quest_status_1_0_jpn.ia8.inc.c"
};

u64 gPauseQuestStatus20JPNTex[] = {
#include "assets/archives/icon_item_static/pause_quest_status_2_0_jpn.ia8.inc.c"
};

u64 gPauseSave00Tex[] = {
#include "assets/archives/icon_item_static/pause_save_0_0.ia8.inc.c"
};

u64 gPauseSave10JPNTex[] = {
#include "assets/archives/icon_item_static/pause_save_1_0_jpn.ia8.inc.c"
};

u64 gPauseSave20Tex[] = {
#include "assets/archives/icon_item_static/pause_save_2_0.ia8.inc.c"
};

u64 gPauseGameOver10Tex[] = {
#include "assets/archives/icon_item_static/pause_game_over_1_0.ia8.inc.c"
};

u64 gPauseMasks01Tex[] = {
#include "assets/archives/icon_item_static/pause_masks_0_1.ia8.inc.c"
};

u64 gPauseMasks11Tex[] = {
#include "assets/archives/icon_item_static/pause_masks_1_1.ia8.inc.c"
};

u64 gPauseMasks21Tex[] = {
#include "assets/archives/icon_item_static/pause_masks_2_1.ia8.inc.c"
};

u64 gPauseSelectItem01Tex[] = {
#include "assets/archives/icon_item_static/pause_select_item_0_1.ia8.inc.c"
};

u64 gPauseSelectItem11Tex[] = {
#include "assets/archives/icon_item_static/pause_select_item_1_1.ia8.inc.c"
};

u64 gPauseSelectItem21Tex[] = {
#include "assets/archives/icon_item_static/pause_select_item_2_1.ia8.inc.c"
};

u64 gPauseMap01Tex[] = {
#include "assets/archives/icon_item_static/pause_map_0_1.ia8.inc.c"
};

u64 gPauseMap11Tex[] = {
#include "assets/archives/icon_item_static/pause_map_1_1.ia8.inc.c"
};

u64 gPauseMap21Tex[] = {
#include "assets/archives/icon_item_static/pause_map_2_1.ia8.inc.c"
};

u64 gPauseQuestStatus01Tex[] = {
#include "assets/archives/icon_item_static/pause_quest_status_0_1.ia8.inc.c"
};

u64 gPauseQuestStatus11Tex[] = {
#include "assets/archives/icon_item_static/pause_quest_status_1_1.ia8.inc.c"
};

u64 gPauseQuestStatus21Tex[] = {
#include "assets/archives/icon_item_static/pause_quest_status_2_1.ia8.inc.c"
};

u64 gPauseSave01Tex[] = {
#include "assets/archives/icon_item_static/pause_save_0_1.ia8.inc.c"
};

u64 gPauseSave11Tex[] = {
#include "assets/archives/icon_item_static/pause_save_1_1.ia8.inc.c"
};

u64 gPauseSave21Tex[] = {
#include "assets/archives/icon_item_static/pause_save_2_1.ia8.inc.c"
};

u64 gPauseMasks02Tex[] = {
#include "assets/archives/icon_item_static/pause_masks_0_2.ia8.inc.c"
};

u64 gPauseMasks12Tex[] = {
#include "assets/archives/icon_item_static/pause_masks_1_2.ia8.inc.c"
};

u64 gPauseMasks22Tex[] = {
#include "assets/archives/icon_item_static/pause_masks_2_2.ia8.inc.c"
};

u64 gPauseSelectItem02Tex[] = {
#include "assets/archives/icon_item_static/pause_select_item_0_2.ia8.inc.c"
};

u64 gPauseSelectItem12Tex[] = {
#include "assets/archives/icon_item_static/pause_select_item_1_2.ia8.inc.c"
};

u64 gPauseSelectItem22Tex[] = {
#include "assets/archives/icon_item_static/pause_select_item_2_2.ia8.inc.c"
};

u64 gPauseMap02Tex[] = {
#include "assets/archives/icon_item_static/pause_map_0_2.ia8.inc.c"
};

u64 gPauseMap12Tex[] = {
#include "assets/archives/icon_item_static/pause_map_1_2.ia8.inc.c"
};

u64 gPauseMap22Tex[] = {
#include "assets/archives/icon_item_static/pause_map_2_2.ia8.inc.c"
};

u64 gPauseQuestStatus02Tex[] = {
#include "assets/archives/icon_item_static/pause_quest_status_0_2.ia8.inc.c"
};

u64 gPauseQuestStatus12Tex[] = {
#include "assets/archives/icon_item_static/pause_quest_status_1_2.ia8.inc.c"
};

u64 gPauseQuestStatus22Tex[] = {
#include "assets/archives/icon_item_static/pause_quest_status_2_2.ia8.inc.c"
};

u64 gPauseSave02Tex[] = {
#include "assets/archives/icon_item_static/pause_save_0_2.ia8.inc.c"
};

u64 gPauseSave12Tex[] = {
#include "assets/archives/icon_item_static/pause_save_1_2.ia8.inc.c"
};

u64 gPauseSave22Tex[] = {
#include "assets/archives/icon_item_static/pause_save_2_2.ia8.inc.c"
};

u64 gPauseMasks03Tex[] = {
#include "assets/archives/icon_item_static/pause_masks_0_3.ia8.inc.c"
};

u64 gPauseMasks13Tex[] = {
#include "assets/archives/icon_item_static/pause_masks_1_3.ia8.inc.c"
};

u64 gPauseMasks23Tex[] = {
#include "assets/archives/icon_item_static/pause_masks_2_3.ia8.inc.c"
};

u64 gPauseSelectItem03Tex[] = {
#include "assets/archives/icon_item_static/pause_select_item_0_3.ia8.inc.c"
};

u64 gPauseSelectItem13Tex[] = {
#include "assets/archives/icon_item_static/pause_select_item_1_3.ia8.inc.c"
};

u64 gPauseSelectItem23Tex[] = {
#include "assets/archives/icon_item_static/pause_select_item_2_3.ia8.inc.c"
};

u64 gPauseMap03Tex[] = {
#include "assets/archives/icon_item_static/pause_map_0_3.ia8.inc.c"
};

u64 gPauseMap13Tex[] = {
#include "assets/archives/icon_item_static/pause_map_1_3.ia8.inc.c"
};

u64 gPauseMap23Tex[] = {
#include "assets/archives/icon_item_static/pause_map_2_3.ia8.inc.c"
};

u64 gPauseQuestStatus03Tex[] = {
#include "assets/archives/icon_item_static/pause_quest_status_0_3.ia8.inc.c"
};

u64 gPauseQuestStatus13Tex[] = {
#include "assets/archives/icon_item_static/pause_quest_status_1_3.ia8.inc.c"
};

u64 gPauseQuestStatus23Tex[] = {
#include "assets/archives/icon_item_static/pause_quest_status_2_3.ia8.inc.c"
};

u64 gPauseSave03Tex[] = {
#include "assets/archives/icon_item_static/pause_save_0_3.ia8.inc.c"
};

u64 gPauseSave13Tex[] = {
#include "assets/archives/icon_item_static/pause_save_1_3.ia8.inc.c"
};

u64 gPauseSave23Tex[] = {
#include "assets/archives/icon_item_static/pause_save_2_3.ia8.inc.c"
};

u64 gPauseMasks04Tex[] = {
#include "assets/archives/icon_item_static/pause_masks_0_4.ia8.inc.c"
};

u64 gPauseMasks14Tex[] = {
#include "assets/archives/icon_item_static/pause_masks_1_4.ia8.inc.c"
};

u64 gPauseMasks24Tex[] = {
#include "assets/archives/icon_item_static/pause_masks_2_4.ia8.inc.c"
};

u64 gPauseSelectItem04Tex[] = {
#include "assets/archives/icon_item_static/pause_select_item_0_4.ia8.inc.c"
};

u64 gPauseSelectItem14Tex[] = {
#include "assets/archives/icon_item_static/pause_select_item_1_4.ia8.inc.c"
};

u64 gPauseSelectItem24Tex[] = {
#include "assets/archives/icon_item_static/pause_select_item_2_4.ia8.inc.c"
};

u64 gPauseMap04Tex[] = {
#include "assets/archives/icon_item_static/pause_map_0_4.ia8.inc.c"
};

u64 gPauseMap14Tex[] = {
#include "assets/archives/icon_item_static/pause_map_1_4.ia8.inc.c"
};

u64 gPauseMap24Tex[] = {
#include "assets/archives/icon_item_static/pause_map_2_4.ia8.inc.c"
};

u64 gPauseQuestStatus04Tex[] = {
#include "assets/archives/icon_item_static/pause_quest_status_0_4.ia8.inc.c"
};

u64 gPauseQuestStatus14Tex[] = {
#include "assets/archives/icon_item_static/pause_quest_status_1_4.ia8.inc.c"
};

u64 gPauseQuestStatus24Tex[] = {
#include "assets/archives/icon_item_static/pause_quest_status_2_4.ia8.inc.c"
};

u64 gPauseSave04Tex[] = {
#include "assets/archives/icon_item_static/pause_save_0_4.ia8.inc.c"
};

u64 gPauseSave14Tex[] = {
#include "assets/archives/icon_item_static/pause_save_1_4.ia8.inc.c"
};

u64 gPauseSave24Tex[] = {
#include "assets/archives/icon_item_static/pause_save_2_4.ia8.inc.c"
};

u64 gABtnSymbolTex[] = {
#include "assets/archives/icon_item_static/a_button_symbol.ia8.inc.c"
};

u64 gBBtnSymbolTex[] = {
#include "assets/archives/icon_item_static/b_button_symbol.ia8.inc.c"
};

u64 gCBtnSymbolsTex[] = {
#include "assets/archives/icon_item_static/c_button_symbols.ia8.inc.c"
};

u64 gNamePanelLeftTex[] = {
#include "assets/archives/icon_item_static/name_panel_left.ia8.inc.c"
};

u64 gNamePanelRightTex[] = {
#include "assets/archives/icon_item_static/name_panel_right.ia8.inc.c"
};

u64 gZButtonTex[] = {
#include "assets/archives/icon_item_static/z_button.ia8.inc.c"
};

u64 gRButtonTex[] = {
#include "assets/archives/icon_item_static/r_button.ia8.inc.c"
};

u64 gShowAMusicalNoteTex[] = {
#include "assets/archives/icon_item_static/show_a_musical_note.ia8.inc.c"
};

u64 gMagicArrowEquipEffectTex[] = {
#include "assets/archives/icon_item_static/magic_arrow_equip_effect.ia8.inc.c"
};

