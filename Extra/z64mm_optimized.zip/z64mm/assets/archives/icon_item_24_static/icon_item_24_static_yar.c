#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "icon_item_24_static_yar.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gQuestIconGoldSkulltulaTex[] = {
#include "assets/archives/icon_item_24_static/gold_skulltula_icon.rgba32.inc.c"
};

u64 gQuestIconHeartContainerTex[] = {
#include "assets/archives/icon_item_24_static/heart_container_icon.rgba32.inc.c"
};

u64 gQuestIconPieceOfHeartTex[] = {
#include "assets/archives/icon_item_24_static/piece_of_heart_icon.rgba32.inc.c"
};

u64 gQuestIconPieceOfHeart2Tex[] = {
#include "assets/archives/icon_item_24_static/piece_of_heart_2_icon.rgba32.inc.c"
};

u64 gQuestIconHeartContainer2Tex[] = {
#include "assets/archives/icon_item_24_static/heart_container_2_icon.rgba32.inc.c"
};

u64 gQuestIconHeartContainer3Tex[] = {
#include "assets/archives/icon_item_24_static/heart_container_3_icon.rgba32.inc.c"
};

u64 gQuestIconBossKeyTex[] = {
#include "assets/archives/icon_item_24_static/boss_key_icon.rgba32.inc.c"
};

u64 gQuestIconCompassTex[] = {
#include "assets/archives/icon_item_24_static/compass_icon.rgba32.inc.c"
};

u64 gQuestIconDungeonMapTex[] = {
#include "assets/archives/icon_item_24_static/dungeon_map_icon.rgba32.inc.c"
};

u64 gQuestIconGoldSkulltula2Tex[] = {
#include "assets/archives/icon_item_24_static/gold_skulltula_2_icon.rgba32.inc.c"
};

u64 gQuestIconSmallKeyTex[] = {
#include "assets/archives/icon_item_24_static/small_key_icon.rgba32.inc.c"
};

u64 gQuestIconSmallMagicJarTex[] = {
#include "assets/archives/icon_item_24_static/small_magic_jar_icon.rgba32.inc.c"
};

u64 gQuestIconBigMagicJarTex[] = {
#include "assets/archives/icon_item_24_static/big_magic_jar_icon.rgba32.inc.c"
};

u64 gQuestIconLinkHumanFaceTex[] = {
#include "assets/archives/icon_item_24_static/link_human_face_icon.rgba16.inc.c"
};

