#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "item_name_static.h"
#include "assets/misc/link_animetion/link_animetion.h"
#include "objects/gameplay_keep/gameplay_keep.h"

u64 gItemNameOcarinaOfTimeENGTex[] = {
#include "assets/archives/item_name_static/item_name_ocarina_of_time_eng.ia4.inc.c"
};

u64 gItemNameHerosBowENGTex[] = {
#include "assets/archives/item_name_static/item_name_heros_bow_eng.ia4.inc.c"
};

u64 gItemNameFireArrowENGTex[] = {
#include "assets/archives/item_name_static/item_name_fire_arrow_eng.ia4.inc.c"
};

u64 gItemNameIceArrowENGTex[] = {
#include "assets/archives/item_name_static/item_name_ice_arrow_eng.ia4.inc.c"
};

u64 gItemNameLightArrowENGTex[] = {
#include "assets/archives/item_name_static/item_name_light_arrow_eng.ia4.inc.c"
};

u64 gItemNameFairyOcarinaJPNTex[] = {
#include "assets/archives/item_name_static/item_name_fairy_ocarina_jpn.ia4.inc.c"
};

u64 gItemNameBombENGTex[] = {
#include "assets/archives/item_name_static/item_name_bomb_eng.ia4.inc.c"
};

u64 gItemNameBombchuENGTex[] = {
#include "assets/archives/item_name_static/item_name_bombchu_eng.ia4.inc.c"
};

u64 gItemNameDekuStickENGTex[] = {
#include "assets/archives/item_name_static/item_name_deku_stick_eng.ia4.inc.c"
};

u64 gItemNameDekuNutENGTex[] = {
#include "assets/archives/item_name_static/item_name_deku_nut_eng.ia4.inc.c"
};

u64 gItemNameMagicBeansENGTex[] = {
#include "assets/archives/item_name_static/item_name_magic_beans_eng.ia4.inc.c"
};

u64 gItemNameLongshotJPNTex[] = {
#include "assets/archives/item_name_static/item_name_longshot_jpn.ia4.inc.c"
};

u64 gItemNamePowderKegENGTex[] = {
#include "assets/archives/item_name_static/item_name_powder_keg_eng.ia4.inc.c"
};

u64 gItemNamePictographBoxENGTex[] = {
#include "assets/archives/item_name_static/item_name_pictograph_box_eng.ia4.inc.c"
};

u64 gItemNameLensOfTruthENGTex[] = {
#include "assets/archives/item_name_static/item_name_lens_of_truth_eng.ia4.inc.c"
};

u64 gItemNameHookshotENGTex[] = {
#include "assets/archives/item_name_static/item_name_hookshot_eng.ia4.inc.c"
};

u64 gItemNameGreatFairysSwordENGTex[] = {
#include "assets/archives/item_name_static/item_name_great_fairys_sword_eng.ia4.inc.c"
};

u64 gItemNameFairySlingshotJPNTex[] = {
#include "assets/archives/item_name_static/item_name_fairy_slingshot_jpn.ia4.inc.c"
};

u64 gItemNameEmptyBottleENGTex[] = {
#include "assets/archives/item_name_static/item_name_empty_bottle_eng.ia4.inc.c"
};

u64 gItemNameRedPotionENGTex[] = {
#include "assets/archives/item_name_static/item_name_red_potion_eng.ia4.inc.c"
};

u64 gItemNameGreenPotionENGTex[] = {
#include "assets/archives/item_name_static/item_name_green_potion_eng.ia4.inc.c"
};

u64 gItemNameBluePotionENGTex[] = {
#include "assets/archives/item_name_static/item_name_blue_potion_eng.ia4.inc.c"
};

u64 gItemNameFairyENGTex[] = {
#include "assets/archives/item_name_static/item_name_fairy_eng.ia4.inc.c"
};

u64 gItemNameDekuPrincessENGTex[] = {
#include "assets/archives/item_name_static/item_name_deku_princess_eng.ia4.inc.c"
};

u64 gItemNameFullMilkENGTex[] = {
#include "assets/archives/item_name_static/item_name_full_milk_eng.ia4.inc.c"
};

u64 gItemNameHalfMilkENGTex[] = {
#include "assets/archives/item_name_static/item_name_half_milk_eng.ia4.inc.c"
};

u64 gItemNameFishENGTex[] = {
#include "assets/archives/item_name_static/item_name_fish_eng.ia4.inc.c"
};

u64 gItemNameBugENGTex[] = {
#include "assets/archives/item_name_static/item_name_bug_eng.ia4.inc.c"
};

u64 gItemNameBlueFireENGTex[] = {
#include "assets/archives/item_name_static/item_name_blue_fire_eng.ia4.inc.c"
};

u64 gItemNamePoeENGTex[] = {
#include "assets/archives/item_name_static/item_name_poe_eng.ia4.inc.c"
};

u64 gItemNameBigPoeENGTex[] = {
#include "assets/archives/item_name_static/item_name_big_poe_eng.ia4.inc.c"
};

u64 gItemNameSpringWaterENGTex[] = {
#include "assets/archives/item_name_static/item_name_spring_water_eng.ia4.inc.c"
};

u64 gItemNameHotSpringWaterENGTex[] = {
#include "assets/archives/item_name_static/item_name_hot_spring_water_eng.ia4.inc.c"
};

u64 gItemNameZoraEggENGTex[] = {
#include "assets/archives/item_name_static/item_name_zora_egg_eng.ia4.inc.c"
};

u64 gItemNameGoldDustENGTex[] = {
#include "assets/archives/item_name_static/item_name_gold_dust_eng.ia4.inc.c"
};

u64 gItemNameMagicalMushroomENGTex[] = {
#include "assets/archives/item_name_static/item_name_magical_mushroom_eng.ia4.inc.c"
};

u64 gItemNameSeaHorseENGTex[] = {
#include "assets/archives/item_name_static/item_name_sea_horse_eng.ia4.inc.c"
};

u64 gItemNameChateauRomaniENGTex[] = {
#include "assets/archives/item_name_static/item_name_chateau_romani_eng.ia4.inc.c"
};

u64 gItemNameHylianLoachJPNTex[] = {
#include "assets/archives/item_name_static/item_name_hylian_loach_jpn.ia4.inc.c"
};

u64 gItemNameObabasDrinkJPNTex[] = {
#include "assets/archives/item_name_static/item_name_obabas_drink_jpn.ia4.inc.c"
};

u64 gItemNameMoonsTearENGTex[] = {
#include "assets/archives/item_name_static/item_name_moons_tear_eng.ia4.inc.c"
};

u64 gItemNameLandTitleDeedENGTex[] = {
#include "assets/archives/item_name_static/item_name_land_title_deed_eng.ia4.inc.c"
};

u64 gItemNameSwampTitleDeedENGTex[] = {
#include "assets/archives/item_name_static/item_name_swamp_title_deed_eng.ia4.inc.c"
};

u64 gItemNameMountainTitleDeedENGTex[] = {
#include "assets/archives/item_name_static/item_name_mountain_title_deed_eng.ia4.inc.c"
};

u64 gItemNameOceanTitleDeedENGTex[] = {
#include "assets/archives/item_name_static/item_name_ocean_title_deed_eng.ia4.inc.c"
};

u64 gItemNameRoomKeyENGTex[] = {
#include "assets/archives/item_name_static/item_name_room_key_eng.ia4.inc.c"
};

u64 gItemNameSpecialDeliveryToMamaENGTex[] = {
#include "assets/archives/item_name_static/item_name_special_delivery_to_mama_eng.ia4.inc.c"
};

u64 gItemNameLetterToKafeiENGTex[] = {
#include "assets/archives/item_name_static/item_name_letter_to_kafei_eng.ia4.inc.c"
};

u64 gItemNamePendantOfMemoriesENGTex[] = {
#include "assets/archives/item_name_static/item_name_pendant_of_memories_eng.ia4.inc.c"
};

u64 gItemNameMoonsStoneJPNTex[] = {
#include "assets/archives/item_name_static/item_name_moons_stone_jpn.ia4.inc.c"
};

u64 gItemNameDekuMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_deku_mask_eng.ia4.inc.c"
};

u64 gItemNameGoronMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_goron_mask_eng.ia4.inc.c"
};

u64 gItemNameZoraMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_zora_mask_eng.ia4.inc.c"
};

u64 gItemNameFierceDeitysMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_fierce_deitys_mask_eng.ia4.inc.c"
};

u64 gItemNameMaskOfTruthENGTex[] = {
#include "assets/archives/item_name_static/item_name_mask_of_truth_eng.ia4.inc.c"
};

u64 gItemNameKafeisMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_kafeis_mask_eng.ia4.inc.c"
};

u64 gItemNameAllNightMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_all_night_mask_eng.ia4.inc.c"
};

u64 gItemNameBunnyHoodENGTex[] = {
#include "assets/archives/item_name_static/item_name_bunny_hood_eng.ia4.inc.c"
};

u64 gItemNameKeatonMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_keaton_mask_eng.ia4.inc.c"
};

u64 gItemNameGarosMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_garos_mask_eng.ia4.inc.c"
};

u64 gItemNameRomanisMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_romanis_mask_eng.ia4.inc.c"
};

u64 gItemNameCircusLeadersMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_circus_leaders_mask_eng.ia4.inc.c"
};

u64 gItemNamePostmansHatENGTex[] = {
#include "assets/archives/item_name_static/item_name_postmans_hat_eng.ia4.inc.c"
};

u64 gItemNameCouplesMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_couples_mask_eng.ia4.inc.c"
};

u64 gItemNameGreatFairysMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_great_fairys_mask_eng.ia4.inc.c"
};

u64 gItemNameGibdoMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_gibdo_mask_eng.ia4.inc.c"
};

u64 gItemNameDonGerosMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_don_geros_mask_eng.ia4.inc.c"
};

u64 gItemNameKamarosMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_kamaros_mask_eng.ia4.inc.c"
};

u64 gItemNameCaptainsHatENGTex[] = {
#include "assets/archives/item_name_static/item_name_captains_hat_eng.ia4.inc.c"
};

u64 gItemNameStoneMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_stone_mask_eng.ia4.inc.c"
};

u64 gItemNameBremenMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_bremen_mask_eng.ia4.inc.c"
};

u64 gItemNameBlastMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_blast_mask_eng.ia4.inc.c"
};

u64 gItemNameMaskOfScentsENGTex[] = {
#include "assets/archives/item_name_static/item_name_mask_of_scents_eng.ia4.inc.c"
};

u64 gItemNameGiantsMaskENGTex[] = {
#include "assets/archives/item_name_static/item_name_giants_mask_eng.ia4.inc.c"
};

u64 gItemNameWindMedallionJPNTex[] = {
#include "assets/archives/item_name_static/item_name_wind_medallion_jpn.ia4.inc.c"
};

u64 gItemNameFireMedallionJPNTex[] = {
#include "assets/archives/item_name_static/item_name_fire_medallion_jpn.ia4.inc.c"
};

u64 gItemNameIceMedallionJPNTex[] = {
#include "assets/archives/item_name_static/item_name_ice_medallion_jpn.ia4.inc.c"
};

u64 gItemNameKokiriSwordENGTex[] = {
#include "assets/archives/item_name_static/item_name_kokiri_sword_eng.ia4.inc.c"
};

u64 gItemNameRazorSwordENGTex[] = {
#include "assets/archives/item_name_static/item_name_razor_sword_eng.ia4.inc.c"
};

u64 gItemNameGildedSwordENGTex[] = {
#include "assets/archives/item_name_static/item_name_gilded_sword_eng.ia4.inc.c"
};

u64 gItemNameBrokenGiantsKnifeJPNTex[] = {
#include "assets/archives/item_name_static/item_name_broken_giants_knife_jpn.ia4.inc.c"
};

u64 gItemNameHerosShieldENGTex[] = {
#include "assets/archives/item_name_static/item_name_heros_shield_eng.ia4.inc.c"
};

u64 gItemNameMirrorShieldENGTex[] = {
#include "assets/archives/item_name_static/item_name_mirror_shield_eng.ia4.inc.c"
};

u64 gItemNameQuiver30ENGTex[] = {
#include "assets/archives/item_name_static/item_name_quiver_30_eng.ia4.inc.c"
};

u64 gItemNameQuiver40ENGTex[] = {
#include "assets/archives/item_name_static/item_name_quiver_40_eng.ia4.inc.c"
};

u64 gItemNameQuiver50ENGTex[] = {
#include "assets/archives/item_name_static/item_name_quiver_50_eng.ia4.inc.c"
};

u64 gItemNameBombBag20ENGTex[] = {
#include "assets/archives/item_name_static/item_name_bomb_bag_20_eng.ia4.inc.c"
};

u64 gItemNameBombBag30ENGTex[] = {
#include "assets/archives/item_name_static/item_name_bomb_bag_30_eng.ia4.inc.c"
};

u64 gItemNameBombBag40ENGTex[] = {
#include "assets/archives/item_name_static/item_name_bomb_bag_40_eng.ia4.inc.c"
};

u64 gItemNameBigKey1JPNTex[] = {
#include "assets/archives/item_name_static/item_name_big_key_1_jpn.ia4.inc.c"
};

u64 gItemNameBigKey2JPNTex[] = {
#include "assets/archives/item_name_static/item_name_big_key_2_jpn.ia4.inc.c"
};

u64 gItemNameBigKey3JPNTex[] = {
#include "assets/archives/item_name_static/item_name_big_key_3_jpn.ia4.inc.c"
};

u64 gItemNameBigKey4JPNTex[] = {
#include "assets/archives/item_name_static/item_name_big_key_4_jpn.ia4.inc.c"
};

u64 gItemNameOdolwasRemainsENGTex[] = {
#include "assets/archives/item_name_static/item_name_odolwas_remains_eng.ia4.inc.c"
};

u64 gItemNameGohtsRemainsENGTex[] = {
#include "assets/archives/item_name_static/item_name_gohts_remains_eng.ia4.inc.c"
};

u64 gItemNameGyorgsRemainsENGTex[] = {
#include "assets/archives/item_name_static/item_name_gyorgs_remains_eng.ia4.inc.c"
};

u64 gItemNameTwinmoldsRemainsENGTex[] = {
#include "assets/archives/item_name_static/item_name_twinmolds_remains_eng.ia4.inc.c"
};

u64 gItemNameSonataOfAwakeningENGTex[] = {
#include "assets/archives/item_name_static/item_name_sonata_of_awakening_eng.ia4.inc.c"
};

u64 gItemNameGoronLullabyENGTex[] = {
#include "assets/archives/item_name_static/item_name_goron_lullaby_eng.ia4.inc.c"
};

u64 gItemNameNewWaveBossaNovaENGTex[] = {
#include "assets/archives/item_name_static/item_name_new_wave_bossa_nova_eng.ia4.inc.c"
};

u64 gItemNameElegyOfEmptynessENGTex[] = {
#include "assets/archives/item_name_static/item_name_elegy_of_emptiness_eng.ia4.inc.c"
};

u64 gItemNameOathToOrderENGTex[] = {
#include "assets/archives/item_name_static/item_name_oath_to_order_eng.ia4.inc.c"
};

u64 gItemNameNocturneOfShadowJPNTex[] = {
#include "assets/archives/item_name_static/item_name_nocturne_of_shadow_jpn.ia4.inc.c"
};

u64 gItemNameSongOfTimeENGTex[] = {
#include "assets/archives/item_name_static/item_name_song_of_time_eng.ia4.inc.c"
};

u64 gItemNameSongOfHealingENGTex[] = {
#include "assets/archives/item_name_static/item_name_song_of_healing_eng.ia4.inc.c"
};

u64 gItemNameEponasSongENGTex[] = {
#include "assets/archives/item_name_static/item_name_eponas_song_eng.ia4.inc.c"
};

u64 gItemNameSongOfSoaringENGTex[] = {
#include "assets/archives/item_name_static/item_name_song_of_soaring_eng.ia4.inc.c"
};

u64 gItemNameSongOfStormsENGTex[] = {
#include "assets/archives/item_name_static/item_name_song_of_storms_eng.ia4.inc.c"
};

u64 gItemNameSunsSongJPNTex[] = {
#include "assets/archives/item_name_static/item_name_suns_song_jpn.ia4.inc.c"
};

u64 gItemNameBombersNotebookENGTex[] = {
#include "assets/archives/item_name_static/item_name_bombers_notebook_eng.ia4.inc.c"
};

u64 gItemNameGoldSkulltulaJPNTex[] = {
#include "assets/archives/item_name_static/item_name_gold_skulltula_jpn.ia4.inc.c"
};

u64 gItemNamePieceOfHeartENGTex[] = {
#include "assets/archives/item_name_static/item_name_piece_of_heart_eng.ia4.inc.c"
};

u64 gItemNamePieceOfHeartJPNTex[] = {
#include "assets/archives/item_name_static/item_name_piece_of_heart_jpn.ia4.inc.c"
};

u64 gItemNameSunsSong2JPNTex[] = {
#include "assets/archives/item_name_static/item_name_suns_song_2_jpn.ia4.inc.c"
};

u64 gItemNameSongOfTimeJPNTex[] = {
#include "assets/archives/item_name_static/item_name_song_of_time_jpn.ia4.inc.c"
};

u64 gItemNameLullabyIntroENGTex[] = {
#include "assets/archives/item_name_static/item_name_lullaby_intro_eng.ia4.inc.c"
};

u64 gItemNameBigKeyENGTex[] = {
#include "assets/archives/item_name_static/item_name_big_key_eng.ia4.inc.c"
};

u64 gItemNameCompassENGTex[] = {
#include "assets/archives/item_name_static/item_name_compass_eng.ia4.inc.c"
};

u64 gItemNameDungeonMapENGTex[] = {
#include "assets/archives/item_name_static/item_name_dungeon_map_eng.ia4.inc.c"
};

u64 gItemNameStrayFairiesENGTex[] = {
#include "assets/archives/item_name_static/item_name_stray_fairies_eng.ia4.inc.c"
};

