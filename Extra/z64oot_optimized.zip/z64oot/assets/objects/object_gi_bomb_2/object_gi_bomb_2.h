#ifndef OBJECT_GI_BOMB_2_H
#define OBJECT_GI_BOMB_2_H 1

extern Vtx object_gi_bomb_2Vtx_000000[];
extern Gfx gGiBombchuDL[];

#endif
