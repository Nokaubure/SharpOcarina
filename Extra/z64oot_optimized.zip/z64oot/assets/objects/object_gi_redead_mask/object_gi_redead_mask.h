#ifndef OBJECT_GI_REDEAD_MASK_H
#define OBJECT_GI_REDEAD_MASK_H 1

extern Vtx object_gi_redead_maskVtx_000000[];
extern Gfx gGiSpookyMaskDL[];

#endif
