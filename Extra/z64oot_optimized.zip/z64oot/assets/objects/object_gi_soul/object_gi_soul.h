#ifndef OBJECT_GI_SOUL_H
#define OBJECT_GI_SOUL_H 1

extern u64 object_gi_soulTex_000000[];
extern Vtx object_gi_soulVtx_000400[];
extern Gfx gGiFairyContainerBaseCapDL[];
extern Gfx gGiFairyContainerGlassDL[];
extern Gfx gGiFairyContainerContentsDL[];

#endif
