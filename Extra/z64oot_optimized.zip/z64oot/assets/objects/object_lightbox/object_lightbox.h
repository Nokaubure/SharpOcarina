#ifndef OBJECT_LIGHTBOX_H
#define OBJECT_LIGHTBOX_H 1

extern u8 object_lightbox_Blob_000000[];
extern Gfx object_lightbox_DL_000008[];
extern Vtx object_lightboxVtx_000120[];
extern u8 object_lightbox_Blob_0002A0[];
extern Gfx object_lightbox_DL_0003D0[];
extern Vtx object_lightboxVtx_0004F0[];
extern u8 object_lightbox_Blob_000670[];
extern Gfx object_lightbox_DL_0007A0[];
extern Vtx object_lightboxVtx_0008C0[];
extern u8 object_lightbox_Blob_000A40[];
extern Gfx object_lightbox_DL_000B70[];
extern Vtx object_lightboxVtx_000C90[];
extern u64 object_lightbox_Tex_000E10[];
extern u64 object_lightbox_Tex_001610[];
extern CamData object_lightbox_Col_001F10CamDataList[];
extern SurfaceType object_lightbox_Col_001F10SurfaceType[];
extern CollisionPoly object_lightbox_Col_001F10Polygons[];
extern Vec3s object_lightbox_Col_001F10Vertices[];
extern CollisionHeader object_lightbox_Col_001F10;

#endif
