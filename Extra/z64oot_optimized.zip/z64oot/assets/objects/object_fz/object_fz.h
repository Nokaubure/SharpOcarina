#ifndef OBJECT_FZ_H
#define OBJECT_FZ_H 1

extern Vtx object_fzVtx_000000[];
extern Gfx gFreezardIntactDL[];
extern Vtx object_fzVtx_0013F0[];
extern Gfx gFreezardTopRightHornChippedDL[];
extern Vtx object_fzVtx_0023F0[];
extern Gfx gFreezardHeadChippedDL[];
extern u64 gFreezardSteamTex[];
extern Vtx object_fzVtx_003070[];
extern Gfx gFreezardSteamStartDL[];
extern Gfx gFreezardSteamDL[];
extern Vtx object_fzVtx_003180[];
extern Gfx gFreezardIceTriangleDL[];
extern Vtx object_fzVtx_003310[];
extern Gfx gFreezardIceRockDL[];

#endif
