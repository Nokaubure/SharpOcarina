#ifndef OBJECT_GI_FROG_H
#define OBJECT_GI_FROG_H 1

extern u64 object_gi_frogTex_000000[];
extern Vtx object_gi_frogVtx_000400[];
extern Gfx gGiFrogDL[];
extern Gfx gGiFrogEyesDL[];

#endif
