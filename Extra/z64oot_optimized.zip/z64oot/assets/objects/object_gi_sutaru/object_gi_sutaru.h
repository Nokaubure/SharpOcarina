#ifndef OBJECT_GI_SUTARU_H
#define OBJECT_GI_SUTARU_H 1

extern Vtx object_gi_sutaruVtx_000000[];
extern Gfx gGiSkulltulaTokenDL[];
extern Gfx gGiSkulltulaTokenFlameDL[];

#endif
