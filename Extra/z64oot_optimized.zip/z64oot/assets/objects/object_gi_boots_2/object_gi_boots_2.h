#ifndef OBJECT_GI_BOOTS_2_H
#define OBJECT_GI_BOOTS_2_H 1

extern u64 object_gi_boots_2Tex_000000[];
extern Vtx object_gi_boots_2Vtx_000100[];
extern Gfx gGiIronBootsDL[];
extern Gfx gGiIronBootsRivetsDL[];

#endif
