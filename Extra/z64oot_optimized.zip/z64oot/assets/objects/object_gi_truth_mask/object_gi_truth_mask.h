#ifndef OBJECT_GI_TRUTH_MASK_H
#define OBJECT_GI_TRUTH_MASK_H 1

extern u64 object_gi_truth_maskTex_000000[];
extern u64 object_gi_truth_maskTex_000400[];
extern Vtx object_gi_truth_maskVtx_000800[];
extern Gfx gGiMaskOfTruthDL[];
extern Gfx gGiMaskOfTruthAccentsDL[];

#endif
