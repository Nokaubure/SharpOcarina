#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_mjin_dark.h"

u64 gShadowMedallionPlatformTex[] = {
#include "assets/objects/object_mjin_dark/shadow_medallion.i8.inc.c"
};

