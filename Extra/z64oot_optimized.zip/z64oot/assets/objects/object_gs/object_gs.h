#ifndef OBJECT_GS_H
#define OBJECT_GS_H 1

extern u64 gGossipStoneTex[];
extern Vtx object_gsVtx_000800[];
extern Gfx gGossipStoneMaterialDL[];
extern Gfx gGossipStoneDL[];
extern Gfx gGossipStoneSquishedDL[];

#endif
