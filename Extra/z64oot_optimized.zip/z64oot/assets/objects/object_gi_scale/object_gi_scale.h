#ifndef OBJECT_GI_SCALE_H
#define OBJECT_GI_SCALE_H 1

extern Vtx object_gi_scaleVtx_000000[];
extern Gfx gGiSilverScaleWaterColorDL[];
extern Gfx gGiGoldenScaleWaterColorDL[];
extern Gfx gGiSilverScaleColorDL[];
extern Gfx gGiGoldenScaleColorDL[];
extern Gfx gGiScaleWaterDL[];
extern Gfx gGiScaleDL[];

#endif
