#ifndef OBJECT_EFC_LGT_SHOWER_H
#define OBJECT_EFC_LGT_SHOWER_H 1

extern u64 gEnliveningLightTex[];
extern Vtx object_efc_lgt_showerVtx_001000[];
extern Gfx gEnliveningLightDL[];

#endif
