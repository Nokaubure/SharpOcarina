#ifndef OBJECT_GI_KI_TAN_MASK_H
#define OBJECT_GI_KI_TAN_MASK_H 1

extern u64 object_gi_ki_tan_maskTex_000000[];
extern Vtx object_gi_ki_tan_maskVtx_000100[];
extern Gfx gGiKeatonMaskDL[];
extern Gfx gGiKeatonMaskEyesDL[];

#endif
