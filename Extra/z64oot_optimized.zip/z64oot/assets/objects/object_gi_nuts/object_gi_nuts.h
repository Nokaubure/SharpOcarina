#ifndef OBJECT_GI_NUTS_H
#define OBJECT_GI_NUTS_H 1

extern u64 object_gi_nutsTex_000000[];
extern Vtx object_gi_nutsVtx_000400[];
extern Gfx gGiNutDL[];

#endif
