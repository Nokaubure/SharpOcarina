#ifndef OBJECT_BWALL_H
#define OBJECT_BWALL_H 1

extern Vtx object_bwallVtx_000000[];
extern Gfx object_bwall_DL_000040[];
extern CamData object_bwall_Col_000118CamDataList[];
extern SurfaceType object_bwall_Col_000118SurfaceType[];
extern CollisionPoly object_bwall_Col_000118Polygons[];
extern Vec3s object_bwall_Col_000118Vertices[];
extern CollisionHeader object_bwall_Col_000118;
extern u64 object_bwall_Tex_000150[];

#endif
