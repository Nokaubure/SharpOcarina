#ifndef OBJECT_MASTERKOKIRIHEAD_H
#define OBJECT_MASTERKOKIRIHEAD_H 1

extern u64 gKokiriShopkeeperTLUT[];
extern u64 gKokiriShopkeeperEyeHalfTex[];
extern u64 object_masterkokiriheadTex_0009F0[];
extern u64 object_masterkokiriheadTex_000A30[];
extern u64 gKokiriShopkeeperEyeOpenTex[];
extern u64 gKokiriShopkeeperHairTex[];
extern u64 gKokiriShopkeeperNoseTex[];
extern u64 gKokiriShopkeeperEarTex[];
extern u64 gKokiriShopkeeperEyeDefaultTex[];
extern u64 gKokiriShopkeeperHatTex[];
extern u64 gKokiriShopkeeperMouthAndNoseTex[];
extern Vtx object_masterkokiriheadVtx_0021B0[];
extern Gfx gKokiriShopkeeperHeadDL[];

#endif
