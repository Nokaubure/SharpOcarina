#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_mjin_soul.h"

u64 gSpiritMedallionPlatformTex[] = {
#include "assets/objects/object_mjin_soul/spirit_medallion.i8.inc.c"
};

