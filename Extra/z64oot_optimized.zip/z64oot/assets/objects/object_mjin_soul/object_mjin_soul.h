#ifndef OBJECT_MJIN_SOUL_H
#define OBJECT_MJIN_SOUL_H 1

extern u64 gSpiritMedallionPlatformTex[];

#endif
