#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_mjin_flash.h"

u64 gLightMedallionPlatformTex[] = {
#include "assets/objects/object_mjin_flash/light_medallion.i8.inc.c"
};

