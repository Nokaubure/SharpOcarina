#ifndef OBJECT_GJYO_OBJECTS_H
#define OBJECT_GJYO_OBJECTS_H 1

extern Vtx object_gjyo_objectsVtx_000000[];
extern Gfx gRainbowBridgeDL[];
extern CamData gRainbowBridgeColCamDataList[];
extern SurfaceType gRainbowBridgeColSurfaceType[];
extern CollisionPoly gRainbowBridgeColPolygons[];
extern Vec3s gRainbowBridgeColVertices[];
extern CollisionHeader gRainbowBridgeCol;
extern u64 gRainbowBridgeTex[];

#endif
