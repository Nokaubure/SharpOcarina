#ifndef OBJECT_BXA_H
#define OBJECT_BXA_H 1

extern Vtx object_bxaVtx_000000[];
extern Gfx object_bxa_DL_000890[];
extern u64 object_bxa_Tex_000C40[];
extern u64 object_bxa_Tex_001440[];
extern Vtx object_bxaVtx_001C40[];
extern Gfx object_bxa_DL_001D80[];
extern Vtx object_bxaVtx_001E90[];
extern Gfx object_bxa_DL_0022F0[];
extern u64 object_bxa_Tex_0024F0[];
extern u64 object_bxa_Tex_0026F0[];
extern u64 object_bxa_Tex_0027F0[];
extern u64 object_bxa_Tex_0029F0[];

#endif
