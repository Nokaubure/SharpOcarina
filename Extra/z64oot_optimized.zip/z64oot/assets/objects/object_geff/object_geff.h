#ifndef OBJECT_GEFF_H
#define OBJECT_GEFF_H 1

extern u64 gGanonRubbleInsideTex[];
extern u64 gGanonRubbleOutsideTex[];
extern Vtx object_geffVtx_000C00[];
extern Gfx gGanonRubbleDL[];

#endif
