#ifndef OBJECT_LIGHT_RING_H
#define OBJECT_LIGHT_RING_H 1

extern Vtx object_light_ringVtx_000000[];
extern Gfx gGoldenGoddessLightRingDL[];
extern u64 gGoldenGoddessLightRingTex[];

#endif
