#ifndef OBJECT_GI_GLASSES_H
#define OBJECT_GI_GLASSES_H 1

extern Vtx object_gi_glassesVtx_000000[];
extern Gfx gGiLensDL[];
extern Gfx gGiLensGlassDL[];

#endif
