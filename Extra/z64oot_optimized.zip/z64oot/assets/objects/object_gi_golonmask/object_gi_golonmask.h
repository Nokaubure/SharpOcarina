#ifndef OBJECT_GI_GOLONMASK_H
#define OBJECT_GI_GOLONMASK_H 1

extern u64 object_gi_golonmaskTLUT_000000[];
extern u64 object_gi_golonmaskTex_000208[];
extern u64 object_gi_golonmaskTex_000248[];
extern u64 object_gi_golonmaskTex_000348[];
extern u64 object_gi_golonmaskTex_000748[];
extern Vtx object_gi_golonmaskVtx_000F48[];
extern Gfx gGiGoronMaskDL[];

#endif
