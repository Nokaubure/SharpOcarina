#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_mjin_ice.h"

u64 gWaterMedallionPlatformTex[] = {
#include "assets/objects/object_mjin_ice/water_medallion.i8.inc.c"
};

