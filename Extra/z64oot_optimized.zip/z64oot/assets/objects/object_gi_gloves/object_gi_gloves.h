#ifndef OBJECT_GI_GLOVES_H
#define OBJECT_GI_GLOVES_H 1

extern u64 object_gi_glovesTex_000000[];
extern Vtx object_gi_glovesVtx_000800[];
extern Gfx gGiSilverGauntletsColorDL[];
extern Gfx gGiGoldenGauntletsColorDL[];
extern Gfx gGiSilverGauntletsPlateColorDL[];
extern Gfx gGiGoldenGauntletsPlateColorDL[];
extern Gfx gGiGauntletsDL[];
extern Gfx gGiGauntletsPlateDL[];

#endif
