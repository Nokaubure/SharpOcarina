#ifndef OBJECT_GI_JEWEL_H
#define OBJECT_GI_JEWEL_H 1

extern u64 gGiKokiriEmeraldScintillationTex[];
extern Vtx object_gi_jewelVtx_000800[];
extern Gfx gGiKokiriEmeraldSettingDL[];
extern Gfx gGiKokiriEmeraldGemDL[];
extern u64 gGiGoronRubyScintillationTex[];
extern Vtx object_gi_jewelVtx_001BE0[];
extern Gfx gGiGoronRubySettingDL[];
extern Gfx gGiGoronRubyGemDL[];
extern u64 gGiZoraSapphireScintillationTex[];
extern Vtx object_gi_jewelVtx_0029F0[];
extern Gfx gGiZoraSapphireSettingDL[];
extern Gfx gGiZoraSapphireGemDL[];

#endif
