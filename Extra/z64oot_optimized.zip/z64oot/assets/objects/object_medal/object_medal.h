#ifndef OBJECT_MEDAL_H
#define OBJECT_MEDAL_H 1

extern Vtx object_medalVtx_000000[];
extern Gfx object_medal_DL_000360[];
extern Vtx object_medalVtx_0004E0[];
extern Gfx object_medal_DL_000840[];
extern Vtx object_medalVtx_0009C0[];
extern Gfx object_medal_DL_000D20[];
extern Vtx object_medalVtx_000EA0[];
extern Gfx object_medal_DL_001200[];
extern Vtx object_medalVtx_001380[];
extern Gfx object_medal_DL_0016E0[];
extern Vtx object_medalVtx_001860[];
extern Gfx object_medal_DL_001BC0[];
extern u8 object_medal_Blob_001D40[];
extern u64 object_medal_Tex_002140[];
extern u64 object_medal_Tex_002940[];
extern u64 object_medal_Tex_003140[];
extern u64 object_medal_Tex_003940[];
extern u64 object_medal_Tex_004140[];
extern u64 object_medal_Tex_004940[];

#endif
