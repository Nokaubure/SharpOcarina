#ifndef OBJECT_D_ELEVATOR_H
#define OBJECT_D_ELEVATOR_H 1

extern Vtx object_d_elevatorVtx_000000[];
extern Gfx object_d_elevator_DL_000180[];
extern CamData object_d_elevator_Col_000360CamDataList[];
extern SurfaceType object_d_elevator_Col_000360SurfaceType[];
extern CollisionPoly object_d_elevator_Col_000360Polygons[];
extern Vec3s object_d_elevator_Col_000360Vertices[];
extern CollisionHeader object_d_elevator_Col_000360;
extern u64 object_d_elevator_Tex_000390[];

#endif
