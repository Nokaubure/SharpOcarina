#ifndef OBJECT_GI_RUPY_H
#define OBJECT_GI_RUPY_H 1

extern Vtx object_gi_rupyVtx_000000[];
extern Gfx gGiGreenRupeeInnerColorDL[];
extern Gfx gGiBlueRupeeInnerColorDL[];
extern Gfx gGiRedRupeeInnerColorDL[];
extern Gfx gGiPurpleRupeeInnerColorDL[];
extern Gfx gGiGoldRupeeInnerColorDL[];
extern Gfx gGiGreenRupeeOuterColorDL[];
extern Gfx gGiBlueRupeeOuterColorDL[];
extern Gfx gGiRedRupeeOuterColorDL[];
extern Gfx gGiPurpleRupeeOuterColorDL[];
extern Gfx gGiGoldRupeeOuterColorDL[];
extern Gfx gGiRupeeInnerDL[];
extern Gfx gGiRupeeOuterDL[];

#endif
