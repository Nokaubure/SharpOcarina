#ifndef OBJECT_GI_MAP_H
#define OBJECT_GI_MAP_H 1

extern Vtx object_gi_mapVtx_000000[];
extern Gfx gGiDungeonMapDL[];
extern Vtx object_gi_mapVtx_0005C0[];
extern Gfx gGiStoneOfAgonyDL[];
extern u64 object_gi_mapTex_000D60[];

#endif
