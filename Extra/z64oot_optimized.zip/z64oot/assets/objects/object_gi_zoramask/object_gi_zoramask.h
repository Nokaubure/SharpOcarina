#ifndef OBJECT_GI_ZORAMASK_H
#define OBJECT_GI_ZORAMASK_H 1

extern u64 object_gi_zoramaskTLUT_000000[];
extern u64 object_gi_zoramaskTex_000208[];
extern u64 object_gi_zoramaskTex_000248[];
extern u64 object_gi_zoramaskTex_000648[];
extern u64 object_gi_zoramaskTex_000A48[];
extern Vtx object_gi_zoramaskVtx_000E48[];
extern Gfx gGiZoraMaskDL[];

#endif
