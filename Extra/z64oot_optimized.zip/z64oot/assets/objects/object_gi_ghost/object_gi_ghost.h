#ifndef OBJECT_GI_GHOST_H
#define OBJECT_GI_GHOST_H 1

extern u64 object_gi_ghostTex_000000[];
extern u64 object_gi_ghostTex_000200[];
extern Vtx object_gi_ghostVtx_000400[];
extern Gfx gGiPoeColorDL[];
extern Gfx gGiBigPoeColorDL[];
extern Gfx gGiGhostContainerLidDL[];
extern Gfx gGiGhostContainerGlassDL[];
extern Gfx gGiGhostContainerContentsDL[];

#endif
