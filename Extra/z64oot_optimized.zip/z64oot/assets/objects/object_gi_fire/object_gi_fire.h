#ifndef OBJECT_GI_FIRE_H
#define OBJECT_GI_FIRE_H 1

extern u64 object_gi_fireTex_000000[];
extern u64 object_gi_fireTex_000200[];
extern Vtx object_gi_fireVtx_000400[];
extern Gfx gGiBlueFireChamberstickDL[];
extern Gfx gGiBlueFireFlameDL[];

#endif
