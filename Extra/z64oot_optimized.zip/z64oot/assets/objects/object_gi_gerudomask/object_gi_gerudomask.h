#ifndef OBJECT_GI_GERUDOMASK_H
#define OBJECT_GI_GERUDOMASK_H 1

extern u64 object_gi_gerudomaskTLUT_000000[];
extern u64 object_gi_gerudomaskTex_000208[];
extern u64 object_gi_gerudomaskTex_000248[];
extern u64 object_gi_gerudomaskTex_000348[];
extern u64 object_gi_gerudomaskTex_000448[];
extern Vtx object_gi_gerudomaskVtx_000848[];
extern Gfx gGiGerudoMaskDL[];

#endif
