#ifndef OBJECT_JYA_DOOR_H
#define OBJECT_JYA_DOOR_H 1

extern Vtx object_jya_doorVtx_000000[];
extern Gfx gSpiritDoorDL[];
extern Vtx object_jya_doorVtx_0001B0[];
extern Gfx gJyaDoorMetalBarsDL[];
extern u64 gSpiritDoorTex[];
extern u64 gSpiritDoorMetalBarsTex[];

#endif
