#ifndef OBJECT_BOMBF_H
#define OBJECT_BOMBF_H 1

extern Vtx object_bombfVtx_000000[];
extern Gfx gBombFlowerLeavesDL[];
extern Gfx gBombFlowerBombAndSparkDL[];
extern Gfx gBombFlowerBaseLeavesDL[];
extern u64 gBombFlowerLeafOutwardsTex[];
extern u64 gBombFlowerLeafUpwardsTex[];
extern u64 gBombFlowerBombTex[];
extern u64 gBombFlowerFuseTex[];

#endif
