#ifndef OBJECT_GOD_LGT_H
#define OBJECT_GOD_LGT_H 1

extern Vtx object_god_lgtVtx_000000[];
extern Gfx gGoldenGoddessAuraDL[];
extern u64 gGoldenGoddessAuraHTailTex[];
extern u64 gGoldenGoddessAuraHeadTex[];
extern u64 gGoldenGoddessAuraMaskTex[];
extern Vtx object_god_lgtVtx_001F30[];
extern Gfx gGoldenGoddessBodyDL[];

#endif
