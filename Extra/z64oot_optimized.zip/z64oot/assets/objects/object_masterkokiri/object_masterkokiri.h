#ifndef OBJECT_MASTERKOKIRI_H
#define OBJECT_MASTERKOKIRI_H 1

extern s16 object_masterkokiri_Anim_0004A8FrameData[];
extern JointIndex object_masterkokiri_Anim_0004A8JointIndices[];
extern AnimationHeader object_masterkokiri_Anim_0004A8;

#endif
