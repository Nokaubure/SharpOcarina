#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_mjin_wind.h"

u64 gForestMedallionPlatformTex[] = {
#include "assets/objects/object_mjin_wind/forest_medallion.i8.inc.c"
};

