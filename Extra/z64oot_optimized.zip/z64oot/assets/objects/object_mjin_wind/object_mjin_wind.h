#ifndef OBJECT_MJIN_WIND_H
#define OBJECT_MJIN_WIND_H 1

extern u64 gForestMedallionPlatformTex[];

#endif
