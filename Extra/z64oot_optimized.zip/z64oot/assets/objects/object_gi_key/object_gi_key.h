#ifndef OBJECT_GI_KEY_H
#define OBJECT_GI_KEY_H 1

extern Vtx object_gi_keyVtx_000000[];
extern Gfx gGiSmallKeyDL[];

#endif
