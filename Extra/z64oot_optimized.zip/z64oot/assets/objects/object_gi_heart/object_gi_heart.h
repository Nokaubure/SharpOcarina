#ifndef OBJECT_GI_HEART_H
#define OBJECT_GI_HEART_H 1

extern Vtx object_gi_heartVtx_000000[];
extern Gfx gGiRecoveryHeartDL[];

#endif
