#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_demo_tre_lgt.h"

u8 gWarpDemoTreLgtBlob_000000[] = {
#include "assets/objects/object_demo_tre_lgt/gWarpDemoTreLgtBlob_000000.bin.inc.c"
};

