#ifndef OBJECT_BDOOR_H
#define OBJECT_BDOOR_H 1

extern u64 object_bdoor_Tex_000000[];
extern Vtx object_bdoorVtx_001000[];
extern Gfx object_bdoor_DL_0010C0[];
extern Vtx object_bdoorVtx_001180[];
extern Gfx object_bdoor_DL_001400[];
extern Vtx object_bdoorVtx_0014F0[];
extern Gfx object_bdoor_DL_001530[];
extern u64 object_bdoor_Tex_0015C0[];
extern u64 object_bdoor_Tex_0025C0[];
extern u64 object_bdoor_Tex_0035C0[];
extern u64 object_bdoor_Tex_0045C0[];
extern u64 object_bdoor_Tex_0055C0[];
extern u64 object_bdoor_Tex_0065C0[];

#endif
