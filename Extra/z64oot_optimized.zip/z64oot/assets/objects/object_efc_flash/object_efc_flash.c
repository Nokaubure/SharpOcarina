#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_efc_flash.h"

u8 gEfcFlashBlob_000000[] = {
#include "assets/objects/object_efc_flash/gEfcFlashBlob_000000.bin.inc.c"
};

