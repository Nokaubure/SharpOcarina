#ifndef OBJECT_BB_H
#define OBJECT_BB_H 1

extern s16 object_Bb_Anim_000184FrameData[];
extern JointIndex object_Bb_Anim_000184JointIndices[];
extern AnimationHeader object_Bb_Anim_000184;
extern s16 object_Bb_Anim_0002ACFrameData[];
extern JointIndex object_Bb_Anim_0002ACJointIndices[];
extern AnimationHeader object_Bb_Anim_0002AC;
extern s16 object_Bb_Anim_000444FrameData[];
extern JointIndex object_Bb_Anim_000444JointIndices[];
extern AnimationHeader object_Bb_Anim_000444;
extern Vtx object_BbVtx_000460[];
extern Gfx object_Bb_DL_000C20[];
extern Gfx object_Bb_DL_000CB0[];
extern Gfx object_Bb_DL_000D40[];
extern Gfx object_Bb_DL_000E08[];
extern Gfx object_Bb_DL_001100[];
extern Gfx object_Bb_DL_001190[];
extern u64 object_Bb_Tex_001220[];
extern u64 object_Bb_Tex_001420[];
extern u64 object_Bb_Tex_0014A0[];
extern u64 object_Bb_Tex_0014C0[];
extern u64 object_Bb_Tex_001540[];
extern u64 object_Bb_Tex_0015C0[];
extern u64 object_Bb_Tex_001640[];
extern u64 object_Bb_Tex_001740[];
extern StandardLimb object_Bb_Limb_001940;
extern StandardLimb object_Bb_Limb_00194C;
extern StandardLimb object_Bb_Limb_001958;
extern StandardLimb object_Bb_Limb_001964;
extern StandardLimb object_Bb_Limb_001970;
extern StandardLimb object_Bb_Limb_00197C;
extern StandardLimb object_Bb_Limb_001988;
extern StandardLimb object_Bb_Limb_001994;
extern StandardLimb object_Bb_Limb_0019A0;
extern StandardLimb object_Bb_Limb_0019AC;
extern StandardLimb object_Bb_Limb_0019B8;
extern StandardLimb object_Bb_Limb_0019C4;
extern StandardLimb object_Bb_Limb_0019D0;
extern StandardLimb object_Bb_Limb_0019DC;
extern StandardLimb object_Bb_Limb_0019E8;
extern void* object_Bb_Skel_001A30Limbs[];
extern SkeletonHeader object_Bb_Skel_001A30;

#endif
