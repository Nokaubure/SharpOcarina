#ifndef OBJECT_GI_PRESCRIPTION_H
#define OBJECT_GI_PRESCRIPTION_H 1

extern u64 object_gi_prescriptionTex_000000[];
extern Vtx object_gi_prescriptionVtx_000600[];
extern Gfx gGiPrescriptionDL[];
extern Gfx gGiPrescriptionWritingDL[];

#endif
