#ifndef OBJECT_D_LIFT_H
#define OBJECT_D_LIFT_H 1

extern Vtx object_d_liftVtx_000000[];
extern Gfx gCollapsingPlatformDL[];
extern CamData gCollapsingPlatformColCamDataList[];
extern SurfaceType gCollapsingPlatformColSurfaceType[];
extern CollisionPoly gCollapsingPlatformColPolygons[];
extern Vec3s gCollapsingPlatformColVertices[];
extern CollisionHeader gCollapsingPlatformCol;
extern u64 gCollapsingPlatformSideTex[];
extern u64 gCollapsingPlatformTopTex[];

#endif
