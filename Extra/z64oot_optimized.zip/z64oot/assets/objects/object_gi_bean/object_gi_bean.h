#ifndef OBJECT_GI_BEAN_H
#define OBJECT_GI_BEAN_H 1

extern Vtx object_gi_beanVtx_000000[];
extern Gfx gGiBeanDL[];

#endif
