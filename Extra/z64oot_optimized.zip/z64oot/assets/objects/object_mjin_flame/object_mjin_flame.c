#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "object_mjin_flame.h"

u64 gFireMedallionPlatformTex[] = {
#include "assets/objects/object_mjin_flame/fire_medallion.i8.inc.c"
};

