#ifndef OBJECT_MJIN_FLAME_H
#define OBJECT_MJIN_FLAME_H 1

extern u64 gFireMedallionPlatformTex[];

#endif
