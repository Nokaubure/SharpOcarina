#ifndef OBJECT_GI_EYE_LOTION_H
#define OBJECT_GI_EYE_LOTION_H 1

extern Vtx object_gi_eye_lotionVtx_000000[];
extern Gfx gGiEyeDropsCapDL[];
extern Gfx gGiEyeDropsBottleDL[];

#endif
