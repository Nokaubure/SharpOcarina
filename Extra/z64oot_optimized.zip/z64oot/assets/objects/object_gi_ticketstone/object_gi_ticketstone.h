#ifndef OBJECT_GI_TICKETSTONE_H
#define OBJECT_GI_TICKETSTONE_H 1

extern u64 object_gi_ticketstoneTex_000000[];
extern u64 object_gi_ticketstoneTex_000240[];
extern Vtx object_gi_ticketstoneVtx_000540[];
extern Gfx gGiClaimCheckDL[];
extern Gfx gGiClaimCheckWritingDL[];

#endif
