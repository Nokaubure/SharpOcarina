#ifndef OBJECT_GI_MAGICPOT_H
#define OBJECT_GI_MAGICPOT_H 1

extern Vtx object_gi_magicpotVtx_000000[];
extern Gfx gGiMagicJarSmallDL[];
extern Vtx object_gi_magicpotVtx_0007F0[];
extern Gfx gGiMagicJarLargeDL[];

#endif
