#ifndef OBJECT_GI_BOOMERANG_H
#define OBJECT_GI_BOOMERANG_H 1

extern Vtx object_gi_boomerangVtx_000000[];
extern Gfx gGiBoomerangDL[];

#endif
