#ifndef OBJECT_GI_OCARINA_0_H
#define OBJECT_GI_OCARINA_0_H 1

extern u64 object_gi_ocarina_0Tex_000000[];
extern Vtx object_gi_ocarina_0Vtx_000100[];
extern Gfx gGiOcarinaFairyDL[];
extern Gfx gGiOcarinaFairyHolesDL[];

#endif
