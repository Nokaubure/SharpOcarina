#ifndef OBJECT_GI_GERUDO_H
#define OBJECT_GI_GERUDO_H 1

extern u64 object_gi_gerudoTex_000000[];
extern Vtx object_gi_gerudoVtx_000400[];
extern Gfx gGiGerudoCardDL[];

#endif
