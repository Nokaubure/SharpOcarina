#ifndef OBJECT_GI_HOVERBOOTS_H
#define OBJECT_GI_HOVERBOOTS_H 1

extern u64 object_gi_hoverbootsTex_000000[];
extern u64 object_gi_hoverbootsTex_000300[];
extern Vtx object_gi_hoverbootsVtx_000400[];
extern Gfx gGiHoverBootsDL[];

#endif
