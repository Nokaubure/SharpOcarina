#ifndef OBJECT_BUBBLE_H
#define OBJECT_BUBBLE_H 1

extern u64 gBubbleTex[];
extern Gfx gBubbleDL[];
extern Vtx object_bubbleVtx_001080[];

#endif
