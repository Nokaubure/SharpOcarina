#ifndef OBJECT_KUSA_H
#define OBJECT_KUSA_H 1

extern Vtx object_kusaVtx_000000[];
extern Gfx object_kusa_DL_000140[];
extern Vtx object_kusaVtx_0001F0[];
extern Gfx object_kusa_DL_0002E0[];

#endif
