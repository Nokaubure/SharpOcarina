#ifndef OBJECT_GI_MUSHROOM_H
#define OBJECT_GI_MUSHROOM_H 1

extern Vtx object_gi_mushroomVtx_000000[];
extern Gfx gGiOddMushroomDL[];

#endif
