#ifndef OBJECT_GI_NIWATORI_H
#define OBJECT_GI_NIWATORI_H 1

extern u64 object_gi_niwatoriTex_000000[];
extern u64 object_gi_niwatoriTex_000800[];
extern Vtx object_gi_niwatoriVtx_000C00[];
extern Gfx gGiChickenColorDL[];
extern Gfx gGiCojiroColorDL[];
extern Gfx gGiChickenDL[];
extern Gfx gGiChickenEyesDL[];

#endif
