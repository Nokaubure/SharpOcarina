#ifndef OBJECT_GI_SHIELD_1_H
#define OBJECT_GI_SHIELD_1_H 1

extern u64 object_gi_shield_1Tex_000000[];
extern Vtx object_gi_shield_1Vtx_000400[];
extern Gfx gGiDekuShieldDL[];

#endif
