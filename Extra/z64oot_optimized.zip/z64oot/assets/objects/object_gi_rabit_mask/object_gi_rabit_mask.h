#ifndef OBJECT_GI_RABIT_MASK_H
#define OBJECT_GI_RABIT_MASK_H 1

extern u64 object_gi_rabit_maskTex_000000[];
extern Vtx object_gi_rabit_maskVtx_000100[];
extern Gfx gGiBunnyHoodDL[];
extern Gfx gGiBunnyHoodEyesDL[];

#endif
