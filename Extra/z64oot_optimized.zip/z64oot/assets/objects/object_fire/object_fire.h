#ifndef OBJECT_FIRE_H
#define OBJECT_FIRE_H 1

extern Vtx object_fireVtx_000000[];
extern Gfx gFireDL[];
extern u64 gFire0Tex[];
extern u64 gFire1Tex[];
extern u64 gFire2Tex[];
extern u64 gFire3Tex[];
extern u64 gFire4Tex[];
extern u64 gFire5Tex[];
extern u64 gFire6Tex[];
extern u64 gFire7Tex[];

#endif
