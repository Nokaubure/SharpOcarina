#ifndef OBJECT_EFC_TW_H
#define OBJECT_EFC_TW_H 1

extern u8 object_efc_twCurveAnime_Ref_000000[];
extern s16 object_efc_twCurveAnime_Copy_000014[];
extern TransformData object_efc_twCurveAnime_TransformData_000038[];
extern TransformUpdateIndex gTimeWarpAnim;
extern Vtx gTimeWarpVtx[];
extern Gfx gTimeWarpDL[];
extern u64 gTimeWarpTex[];
extern SkelCurveLimb gTimeWarpSkelLimbsLimb_0012C8;
extern SkelCurveLimb gTimeWarpSkelLimbsLimb_0012D4;
extern SkelCurveLimb* gTimeWarpSkelLimbs[];
extern SkelCurveLimbList gTimeWarpSkel;

#endif
