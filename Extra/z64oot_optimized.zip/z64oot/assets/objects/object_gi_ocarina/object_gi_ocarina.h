#ifndef OBJECT_GI_OCARINA_H
#define OBJECT_GI_OCARINA_H 1

extern u64 object_gi_ocarinaTex_000000[];
extern Vtx object_gi_ocarinaVtx_000100[];
extern Gfx gGiOcarinaTimeDL[];
extern Gfx gGiOcarinaTimeHolesDL[];

#endif
