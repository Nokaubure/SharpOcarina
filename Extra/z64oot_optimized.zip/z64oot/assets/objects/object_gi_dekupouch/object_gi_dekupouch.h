#ifndef OBJECT_GI_DEKUPOUCH_H
#define OBJECT_GI_DEKUPOUCH_H 1

extern u64 object_gi_dekupouchTex_000000[];
extern u64 object_gi_dekupouchTex_000100[];
extern Vtx object_gi_dekupouchVtx_000300[];
extern Gfx gGiBulletBagColorDL[];
extern Gfx gGiBulletBag50ColorDL[];
extern Gfx gGiBulletBagStringColorDL[];
extern Gfx gGiBulletBag50StringColorDL[];
extern Gfx gGiBulletBagDL[];
extern Gfx gGiBulletBagStringDL[];
extern Gfx gGiBulletBagWritingDL[];

#endif
