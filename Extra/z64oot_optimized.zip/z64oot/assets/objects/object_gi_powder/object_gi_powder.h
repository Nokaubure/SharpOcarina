#ifndef OBJECT_GI_POWDER_H
#define OBJECT_GI_POWDER_H 1

extern Vtx object_gi_powderVtx_000000[];
extern Gfx gGiOddPotionDL[];

#endif
