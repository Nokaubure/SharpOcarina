#ifndef OBJECT_GI_SKJ_MASK_H
#define OBJECT_GI_SKJ_MASK_H 1

extern Vtx object_gi_skj_maskVtx_000000[];
extern Gfx gGiSkullMaskDL[];

#endif
