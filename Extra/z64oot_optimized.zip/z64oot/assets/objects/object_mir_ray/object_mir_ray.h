#ifndef OBJECT_MIR_RAY_H
#define OBJECT_MIR_RAY_H 1

extern Vtx object_mir_rayVtx_000000[];
extern Gfx gShieldBeamImageDL[];
extern u64 gShieldBeamImageCircleTex[];
extern u64 gShieldBeamImageGerudoSymbolNewTex[];
extern Vtx object_mir_rayVtx_000B90[];
extern Gfx gShieldBeamGlowDL[];
extern u64 gShieldBeamGlowRayTex[];

#endif
