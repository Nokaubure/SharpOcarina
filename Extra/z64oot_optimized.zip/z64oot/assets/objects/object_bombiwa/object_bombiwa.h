#ifndef OBJECT_BOMBIWA_H
#define OBJECT_BOMBIWA_H 1

extern u64 object_bombiwa_TLUT_000000[];
extern u64 object_bombiwa_Tex_000020[];
extern Vtx object_bombiwaVtx_000820[];
extern Gfx object_bombiwa_DL_0009E0[];

#endif
