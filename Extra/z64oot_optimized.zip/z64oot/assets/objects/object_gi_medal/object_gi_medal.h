#ifndef OBJECT_GI_MEDAL_H
#define OBJECT_GI_MEDAL_H 1

extern Vtx object_gi_medalVtx_000000[];
extern Gfx gGiForestMedallionFaceDL[];
extern Gfx gGiMedallionDL[];
extern Vtx object_gi_medalVtx_001000[];
extern Gfx gGiFireMedallionFaceDL[];
extern Vtx object_gi_medalVtx_001C10[];
extern Gfx gGiWaterMedallionFaceDL[];
extern Vtx object_gi_medalVtx_0029A0[];
extern Gfx gGiSpiritMedallionFaceDL[];
extern Vtx object_gi_medalVtx_003770[];
extern Gfx gGiShadowMedallionFaceDL[];
extern Vtx object_gi_medalVtx_004460[];
extern Gfx gGiLightMedallionFaceDL[];

#endif
