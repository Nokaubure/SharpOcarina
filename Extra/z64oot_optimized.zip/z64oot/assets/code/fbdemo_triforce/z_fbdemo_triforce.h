#ifndef CODE_H
#define CODE_H 1

extern Gfx sTriforceWipeDL[];
extern Vtx sTriforceWipeVtx[];

#endif
