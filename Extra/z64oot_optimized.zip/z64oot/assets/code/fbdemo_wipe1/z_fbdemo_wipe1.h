#ifndef CODE_H
#define CODE_H 1

extern Vtx sWipe1Vtx[];
extern u64 sWipe1Tex[];

#endif
