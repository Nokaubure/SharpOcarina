#include "ultra64.h"
#include "z64.h"
#include "macros.h"
#include "z_fbdemo_wipe1.h"

Vtx sWipe1Vtx[] = {
#include "assets/code/fbdemo_wipe1/sWipe1Vtx.vtx.inc"
};

u64 sWipe1Tex[] = {
#include "assets/code/fbdemo_wipe1/sWipe1Tex.i4.inc.c"
};

