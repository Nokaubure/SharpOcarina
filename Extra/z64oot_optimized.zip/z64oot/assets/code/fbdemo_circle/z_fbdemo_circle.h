#ifndef CODE_H
#define CODE_H 1

extern u64 sTransCircleNormalTex[];
extern u64 sTransCircleWaveTex[];
extern u64 sTransCircleRippleTex[];
extern u64 sTransCircleStarburstTex[];
extern Vtx sCircleWipeVtx[];

#endif
