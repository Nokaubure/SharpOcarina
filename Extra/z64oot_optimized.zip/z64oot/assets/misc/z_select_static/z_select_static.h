#ifndef Z_SELECT_STATIC_H
#define Z_SELECT_STATIC_H 1

extern Gfx gSelectStatic1DL[];
extern Gfx gSelectStatic2DL[];
extern Gfx gSelectStatic3DL[];
extern Gfx gSelectStatic4DL[];
extern Gfx gSelectStatic5DL[];
extern Gfx gSelectStatic6DL[];
extern Gfx gSelectStatic7DL[];
extern Gfx gSelectStatic8DL[];
extern Gfx gSelectStatic9DL[];
extern Gfx gSelectStatic10DL[];
extern Gfx gSelectStatic11DL[];
extern Gfx gSelectStatic12DL[];
extern Gfx gSelectStatic13DL[];
extern Gfx gSelectStatic14DL[];
extern Gfx gSelectStatic15DL[];
extern Gfx gSelectStatic16DL[];
extern Gfx gSelectStatic17DL[];
extern Gfx gSelectStatic18DL[];
extern Gfx gSelectStatic19DL[];
extern Gfx gSelectStatic20DL[];
extern Gfx gSelectStatic21DL[];
extern Gfx gSelectStatic22DL[];
extern Gfx gSelectStatic23DL[];
extern Gfx gSelectStatic24DL[];
extern Gfx gSelectStatic25DL[];
extern Gfx gSelectStatic26DL[];
extern Gfx gSelectStatic27DL[];
extern Gfx gSelectStatic28DL[];
extern Gfx gSelectStatic29DL[];
extern Gfx gSelectStatic30DL[];
extern Gfx gSelectStatic31DL[];
extern Gfx gSelectStatic32DL[];
extern Gfx gSelectStaticMasterDL[];
extern Vtx gSelectStaticVtx[];

#endif
