#ifndef OVL_EN_JSJUTAN_H
#define OVL_EN_JSJUTAN_H 1

extern u8 sShadowTex[2048];

#endif
