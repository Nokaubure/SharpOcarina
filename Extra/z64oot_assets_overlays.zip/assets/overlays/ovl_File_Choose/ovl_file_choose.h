#ifndef OVL_FILE_CHOOSE_H
#define OVL_FILE_CHOOSE_H 1

extern Vtx D_80811BB0[];
extern Vtx D_80811D30[];
extern Vtx D_80811E30[];
extern Vtx D_80811F30[];
extern Vtx D_80812130[];
extern Vtx gOptionsDividerTopVtx[];
extern Vtx gOptionsDividerMiddleVtx[];
extern Vtx gOptionsDividerBottomVtx[];

#endif
