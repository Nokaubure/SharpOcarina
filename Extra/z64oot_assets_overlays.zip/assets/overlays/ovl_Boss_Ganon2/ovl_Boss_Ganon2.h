#ifndef OVL_BOSS_GANON2_H
#define OVL_BOSS_GANON2_H 1


#endif
