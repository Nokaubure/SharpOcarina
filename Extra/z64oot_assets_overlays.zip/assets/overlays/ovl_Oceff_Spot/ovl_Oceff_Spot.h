#ifndef OVL_OCEFF_SPOT_H
#define OVL_OCEFF_SPOT_H 1


#endif
